"""Run an explicit configuration search without changing behavioral thresholds.

python -u -m benchmarks.transfer_suite.solvability_search --plan plan.json --output /tmp/search
Plans contain candidates (name, overrides, optional steps_multiplier) and task names.
All tasks are now inspected development cases, including the former reserved cases.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path
import time

import torch

from . import suite, vector_tasks
from .protocol import test_verdict


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def render(output, records):
    lines = ["# Solvability search", "", "Seed 0, live weights, unchanged thresholds; 24 measurements and five final passing checks. "
             "These are inspected development tasks. Different training budgets and capacities are explicit. "
             "A per-task witness establishes solvability, not a shared default.", "",
             "| Candidate | Task | Sustained | Confirmed step | Budget | Seconds | Final failing metrics |",
             "| --- | --- | --- | ---: | ---: | ---: | --- |"]
    for record in records:
        v = record["verdict"]
        failures = ", ".join(f"{m['metric']}={m['value']:.4g}" if isinstance(m.get("value"), (int, float))
                             else str(m) for m in v.get("metrics", []) if m["status"] != "PASS")
        lines.append(f"| {record['candidate']['name']} | {record['spec']['name']} | {v['status']} | "
                     f"{v.get('convergence', {}).get('confirmed_step')} | {record['spec']['steps']} | "
                     f"{record['seconds']:.2f} | {failures or '—'} |")
    (output / "README.md").write_text("\n".join(lines) + "\n")


def run(plan, output):
    output.mkdir(parents=True, exist_ok=False)
    (output / "episodes").mkdir()
    torch.set_num_threads(1)
    write(output / "plan.json", plan)
    protocol = suite.snapshot(output)
    write(output / "protocol.json", protocol)
    declared = {spec["name"]: spec for spec in suite.manifest()["tasks"]}
    records = []
    for candidate in plan["candidates"]:
        for task in candidate.get("tasks", plan["tasks"]):
            original = declared[task]
            if original["runner"] == "legacy":
                raise ValueError("legacy hosts need explicit config translation, not ignored overrides")
            spec = deepcopy(original)
            spec.update(candidate.get("overrides", {}))
            if spec["thresholds"] != original["thresholds"]:
                raise ValueError("search cannot alter thresholds")
            spec["steps"] = round(spec["steps"] * candidate.get("steps_multiplier", 1))
            spec.update(candidate.get("task_overrides", {}).get(task, {}))
            if spec["thresholds"] != original["thresholds"]:
                raise ValueError("search cannot alter thresholds")
            policy = vector_tasks.fixed_policy(candidate.get("schedule", "cosine"))
            print(json.dumps(dict(event="START", candidate=candidate["name"], task=task, steps=spec["steps"])), flush=True)
            suite.verify_source(protocol)
            result = suite.run_episode(spec, policy, fixed=True, allow_reserved=True)
            verdict = test_verdict(spec, result)
            record = dict(candidate=candidate, original_spec=original, spec=spec, policy=policy,
                          verdict=verdict, seconds=result["seconds"])
            file = f"episodes/{candidate['name']}__{task}.json.gz"
            payload = dict(**record, result=result, source_sha256=protocol["source_sha256"])
            raw = (json.dumps(payload, sort_keys=True, allow_nan=False) + "\n").encode()
            (output / file).write_bytes(gzip.compress(raw, mtime=0))
            record.update(artifact=file, uncompressed_sha256=hashlib.sha256(raw).hexdigest(),
                          live=result.get("live"), ema=result.get("ema"))
            records.append(record)
            write(output / "index.json", dict(records=records))
            render(output, records)
            print(json.dumps(dict(event="DONE", candidate=candidate["name"], task=task,
                                  status=verdict["status"], live=result.get("live"), seconds=result["seconds"],
                                  error=result.get("error"))), flush=True)
    suite.verify_source(protocol)
    return records


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    run(json.loads(args.plan.read_text()), args.output)
