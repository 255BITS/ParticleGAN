"""Pointwise raw/quadratic skip critics; no target-derived features or objectives."""
from copy import deepcopy
import math
import torch
from torch import nn
from .smooth_critic_research import SmoothFourierCritic

ARCHITECTURES=[
 dict(name='fourier_softplus5_linear_skip',features='axis_fourier',activation='softplus5',residual_blocks=0,skip='linear'),
 dict(name='fourier_softplus5_quadratic_skip',features='axis_fourier',activation='softplus5',residual_blocks=0,skip='quadratic'),
 dict(name='fourier_softplus5_raw_mlp_skip',features='axis_fourier',activation='softplus5',residual_blocks=0,skip='raw_mlp32'),
 dict(name='fourier_softplus5_quad_mlp_skip',features='axis_fourier',activation='softplus5',residual_blocks=0,skip='quadratic_mlp32'),
 dict(name='fourier_silu_quadratic_skip',features='axis_fourier',activation='silu',residual_blocks=0,skip='quadratic'),
 dict(name='raw_softplus5_quadratic_skip',features='raw',activation='softplus5',residual_blocks=0,skip='quadratic'),
 dict(name='raw_residual2_silu_quadratic_skip',features='raw',activation='silu',residual_blocks=2,skip='quadratic'),
 dict(name='fourier_residual2_softplus5_quadratic_skip',features='axis_fourier',activation='softplus5',residual_blocks=2,skip='quadratic'),
]
for card in ARCHITECTURES:
 card.update(hidden=64,layers=2,normalization='none',skip_output_initialization='zero',quadratic_basis=['x','y','x*x','x*y','y*y'],feature_seed='none',fourier_bands=2 if card['features']=='axis_fourier' else 0)


def activation(name):
 if name=='softplus5':return nn.Softplus(beta=5.)
 if name=='silu':return nn.SiLU()
 raise ValueError('unsupported skip critic activation')


def quadratic(x):
 return torch.cat([x,x[:,0:1].square(),x[:,0:1]*x[:,1:2],x[:,1:2].square()],dim=1)


class SkipCritic(nn.Module):
 """An additive learned raw-coordinate path around the shared nonlinear critic.

 Quadratic features are fixed coordinate monomials, not target covariance losses.
 All added skip outputs initialize to zero with no seed/initialization search.
 There is no batch normalization, data-dependent projection or auxiliary loss.
 """
 def __init__(self,in_dim=2,hidden_dim=64,n_hidden=2,fourier=2,*,architecture):
  super().__init__();self.architecture=deepcopy(architecture)
  if in_dim!=2 or hidden_dim!=64 or n_hidden!=2:raise ValueError('research card requires original 2D/64x2 host')
  if architecture['features']=='axis_fourier' and not architecture['residual_blocks']:
   base=dict(name='base',features='axis',activation='softplus' if architecture['activation']=='softplus5' else 'silu',beta=5.)
   # Construct the base first, preserving its original weight initialization.
   self.main=SmoothFourierCritic(2,64,2,2,architecture=base)
  else:
   dim=2
   if architecture['features']=='axis_fourier':
    self.register_buffer('freqs',torch.pi*(2.**torch.arange(2,dtype=torch.float32)));dim=10
   if architecture['residual_blocks']:
    self.input=nn.Linear(dim,64);self.activation=activation(architecture['activation'])
    self.blocks=nn.ModuleList([nn.Sequential(nn.Linear(64,64),activation(architecture['activation']),nn.Linear(64,64)) for _ in range(architecture['residual_blocks'])])
    self.output=nn.Linear(64,1)
   else:
    self.main=nn.Sequential(nn.Linear(dim,64),activation(architecture['activation']),nn.Linear(64,64),activation(architecture['activation']),nn.Linear(64,1))
  skip=architecture['skip'];skip_dim=2 if skip in ('linear','raw_mlp32') else 5
  if skip.endswith('mlp32'):
   self.skip=nn.Sequential(nn.Linear(skip_dim,32),activation(architecture['activation']),nn.Linear(32,32),activation(architecture['activation']),nn.Linear(32,1,bias=False))
   nn.init.zeros_(self.skip[-1].weight)
  else:
   self.skip=nn.Linear(skip_dim,1,bias=False);nn.init.zeros_(self.skip.weight)

 def base_score(self,x):
  if not self.architecture['residual_blocks']:
   return self.main(x).reshape(-1)
  features=x
  if self.architecture['features']=='axis_fourier':
   phase=(x.unsqueeze(-1)*self.freqs).flatten(1);features=torch.cat([x,phase.sin(),phase.cos()],dim=1)
  h=self.activation(self.input(features))
  for block in self.blocks:h=self.activation((h+block(h))/math.sqrt(2.))
  return self.output(h).squeeze(-1)

 def forward(self,x):
  features=x if self.architecture['skip'] in ('linear','raw_mlp32') else quadratic(x)
  return self.base_score(x)+self.skip(features).squeeze(-1)


def constructor(architecture):
 card=deepcopy(architecture)
 def create(in_dim=2,hidden_dim=64,n_hidden=2,fourier=2):return SkipCritic(in_dim,hidden_dim,n_hidden,fourier,architecture=card)
 return create
