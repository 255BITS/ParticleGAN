"""Pointwise Gaussian-feature critics for a bounded architecture-only study.

All centers start from a generic standard-normal distribution. No target data,
component labels, centers, moments or observed metrics enter construction.
"""
from copy import deepcopy
import math
import torch
from torch import nn

ARCHITECTURES = [
    dict(name='rbf32_fixed_silu', count=32, scales=[.5,1.,2.,4.], train_centers=False, train_widths=False, activation='silu', residual_blocks=0),
    dict(name='rbf64_fixed_silu', count=64, scales=[.25,.5,1.,2.], train_centers=False, train_widths=False, activation='silu', residual_blocks=0),
    dict(name='rbf64_centers_silu', count=64, scales=[.25,.5,1.,2.], train_centers=True, train_widths=False, activation='silu', residual_blocks=0),
    dict(name='rbf64_full_silu', count=64, scales=[.25,.5,1.,2.], train_centers=True, train_widths=True, activation='silu', residual_blocks=0),
    dict(name='rbf128_full_silu', count=128, scales=[.125,.25,.5,1.,2.,4.], train_centers=True, train_widths=True, activation='silu', residual_blocks=0),
    dict(name='rbf64_full_softplus5', count=64, scales=[.25,.5,1.,2.], train_centers=True, train_widths=True, activation='softplus5', residual_blocks=0),
    dict(name='rbf128_full_softplus5', count=128, scales=[.125,.25,.5,1.,2.,4.], train_centers=True, train_widths=True, activation='softplus5', residual_blocks=0),
    dict(name='rbf64_residual2_silu', count=64, scales=[.25,.5,1.,2.], train_centers=True, train_widths=True, activation='silu', residual_blocks=2),
]
for card in ARCHITECTURES:
    card.update(features='gaussian_rbf_plus_raw', center_initialization='standard_normal', feature_seed=0,
                hidden=64, layers=2, normalization='none', original_fourier_features_used=False)


def _activation(name):
    if name=='silu':
        return nn.SiLU()
    if name=='softplus5':
        return nn.Softplus(beta=5.)
    raise ValueError('unknown local critic activation')


class LocalRBFCritic(nn.Module):
    """RBF features and raw coordinates, followed by a smooth pointwise MLP.

    Positive widths use exp(log_width), with no added regularization or clipping.
    Learned centers/widths receive only the host discriminator objective. A local
    initialization generator leaves global model initialization RNG untouched.
    """
    def __init__(self,in_dim=2,hidden_dim=64,n_hidden=2,fourier=2,*,architecture):
        super().__init__()
        self.architecture=deepcopy(architecture)
        if in_dim!=2 or hidden_dim!=architecture['hidden'] or n_hidden!=architecture['layers']:
            raise ValueError('this card is declared for 2D input and the specified host width/depth')
        count=architecture['count']
        centers=torch.randn(count,in_dim,generator=torch.Generator().manual_seed(architecture['feature_seed']))
        widths=torch.tensor([architecture['scales'][i%len(architecture['scales'])] for i in range(count)])
        if architecture['train_centers']:self.centers=nn.Parameter(centers)
        else:self.register_buffer('centers',centers)
        if architecture['train_widths']:self.log_width=nn.Parameter(widths.log())
        else:self.register_buffer('log_width',widths.log())
        dim=in_dim+count
        if architecture['residual_blocks']:
            self.input=nn.Linear(dim,hidden_dim)
            self.activation=_activation(architecture['activation'])
            self.blocks=nn.ModuleList([nn.Sequential(nn.Linear(hidden_dim,hidden_dim),_activation(architecture['activation']),
                                                    nn.Linear(hidden_dim,hidden_dim)) for _ in range(architecture['residual_blocks'])])
            self.output=nn.Linear(hidden_dim,1)
        else:
            layers=[]
            for _ in range(n_hidden):
                layers.extend([nn.Linear(dim,hidden_dim),_activation(architecture['activation'])]);dim=hidden_dim
            layers.append(nn.Linear(dim,1));self.net=nn.Sequential(*layers)

    def encode(self,x):
        displacement=(x[:,None,:]-self.centers[None,:,:])/self.log_width.exp()[None,:,None]
        local=torch.exp(-.5*displacement.square().sum(-1))
        return torch.cat([x,local],dim=-1)

    def forward(self,x):
        features=self.encode(x)
        if not self.architecture['residual_blocks']:
            return self.net(features).squeeze(-1)
        h=self.activation(self.input(features))
        for block in self.blocks:
            h=self.activation((h+block(h))/math.sqrt(2.))
        return self.output(h).squeeze(-1)


def constructor(architecture):
    card=deepcopy(architecture)
    def create(in_dim=2,hidden_dim=64,n_hidden=2,fourier=2):
        return LocalRBFCritic(in_dim,hidden_dim,n_hidden,fourier,architecture=card)
    return create
