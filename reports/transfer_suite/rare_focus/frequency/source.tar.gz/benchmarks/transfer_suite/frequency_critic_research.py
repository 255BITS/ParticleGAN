"""Research-only generic frequency scale for the existing smooth axis critic."""
from copy import deepcopy
import math
from .smooth_critic_research import SmoothFourierCritic


class FrequencyScaledCritic(SmoothFourierCritic):
    def __init__(self, in_dim=2, hidden_dim=96, n_hidden=2, fourier=2, *, architecture):
        if architecture['features'] != 'axis':
            raise ValueError('frequency scaling currently requires axis features')
        multiplier = architecture['frequency_multiplier']
        if not math.isfinite(multiplier) or multiplier <= 0:
            raise ValueError('frequency multiplier must be finite and positive')
        super().__init__(in_dim, hidden_dim, n_hidden, fourier, architecture=architecture)
        # Fixed buffer only. The native sine/cosine path still differentiates in x.
        self.freqs.mul_(float(multiplier))


def constructor(architecture):
    card = deepcopy(architecture)
    def create(in_dim=2, hidden_dim=96, n_hidden=2, fourier=2):
        return FrequencyScaledCritic(in_dim, hidden_dim, n_hidden, fourier,
                                     architecture=card)
    return create
