"""Research-only fixed balancing of raw and Fourier discriminator features.

All gains are declared architecture constants. No data-derived scales, target
geometry, class labels, or detached input transformations enter the critic.
"""
from copy import deepcopy
import math
import torch
from .smooth_critic_research import SmoothFourierCritic


class SpectralBalancedCritic(SmoothFourierCritic):
    def __init__(self, in_dim=2, hidden_dim=96, n_hidden=2, fourier=2, *, architecture):
        if architecture['features'] != 'axis':
            raise ValueError('spectral balancing currently requires axis features')
        raw_gain = architecture['raw_gain']
        fourier_gain = architecture['fourier_gain']
        harmonic_gains = architecture['harmonic_gains']
        if len(harmonic_gains) != fourier:
            raise ValueError('one fixed gain is required for each Fourier harmonic')
        if any(not math.isfinite(x) or x <= 0 for x in [raw_gain, fourier_gain, *harmonic_gains]):
            raise ValueError('feature gains must be finite and positive')
        super().__init__(in_dim, hidden_dim, n_hidden, fourier, architecture=architecture)
        self.register_buffer('raw_gain', torch.tensor(float(raw_gain)))
        self.register_buffer('feature_amplitudes',
                             (torch.tensor(harmonic_gains, dtype=torch.float32)
                              * float(fourier_gain)).repeat(in_dim))

    def encode(self, x):
        phase = (x.unsqueeze(-1) * self.freqs).flatten(1)
        return torch.cat([x * self.raw_gain,
                          phase.sin() * self.feature_amplitudes,
                          phase.cos() * self.feature_amplitudes], dim=1)


def constructor(architecture):
    card = deepcopy(architecture)
    def create(in_dim=2, hidden_dim=96, n_hidden=2, fourier=2):
        return SpectralBalancedCritic(in_dim, hidden_dim, n_hidden, fourier,
                                     architecture=card)
    return create
