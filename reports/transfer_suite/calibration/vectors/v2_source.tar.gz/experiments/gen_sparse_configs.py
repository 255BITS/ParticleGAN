#!/usr/bin/env python
"""
gen_sparse_configs.py

Config generator for the sparse conditional mixed-output study
(experiments/train_sparse.py). One YAML per run under

    configs/sparse/<stage>/<group>_s<seed>.yaml   ->   results/sparse/runs/<stage>/<group>_s<seed>

Only overridden keys are written (plus seed / total_steps / out_dir). The runner
records the effective trainer defaults and invalidates reuse when they change.

Every stage except `recipe` is generated on top of BASE, the recipe the probe
rounds found (reports/sparse-ucd/FINDINGS.md): the class reaches G *only*
through a class-partitioned particle table (no class embedding), and the
gradient penalty is the one-sided cap on real/fake interpolates. `--base`
overrides / extends it LAST, after each group's overrides, for every stage.
Changing --base, --seeds or --total_steps selects a separate, deterministic
stage namespace so results from different invocations cannot be aggregated
together. Default invocations retain their historical stage paths. A manifest
lists only the current invocation's configs, excluding stale YAML files.

Stages (each answers one question, 3 seeds per cell):

  smoke     one short run per D mode: does everything execute.
  recipe    DOES IT CONVERGE, AND WHAT IS LOAD-BEARING. The 100-Gaussians
            champion as-is (sample-point cap, class embedding in G) against
            each change in isolation and in combination, plus the
            unconditional-G floor and ceiling.
  ucd       THE UCD QUESTION. D mode in {scalar, concat, proj, ucd} with a
            lambda_1 sweep, the frozen-Gaussian prior, embedding-only and
            embedding+partition conditioning, the supervised-symbol anchor,
            and the x-only penalty.
  sparse    THE SPARSITY QUESTION. real_head in {linear, gated x lambda_sp, topk}.
  discrete  THE DISCRETE-OUTPUT QUESTION. cat_mode x tau schedule x
            lambda_sym, plus the 'split' symbol map (K = 2C).
  champion  everything stacked: lambda_1 0.02 + warm-started gated head
            (+ 8k steps, + the injection D modes with the same head).
  fewshot   THE DATA-SPARSITY QUESTION. n_train in {128, 512, 2048, 8192}
            (2 .. 128 samples per mode), and the frozen prior at 512.

Usage:
    python experiments/gen_sparse_configs.py --stage recipe
    python experiments/gen_sparse_configs.py --stage sparse --base "coeff=0.3"
"""

import argparse
import hashlib
import json
from pathlib import Path
from typing import Dict, List, Tuple

import yaml

SEEDS = (1, 2, 3)
TOTAL_STEPS = 5000
CONFIG_ROOT = Path("configs/sparse")
RUNS_ROOT = Path("results/sparse/runs")

# The recipe every non-`recipe` stage builds on (see module docstring).
BASE: Dict = {
    "emb_dim": 0,
    "prior_partition": "class",
    "arm": "g_interp_cap",
    "coeff": 1.0,
    # probe round 4/5: wider nets and a wider latent each bought ~5 modes; the
    # Fourier ramp keeps the core width honest (0.8-0.9 vs 0.5-0.6 without it)
    "hidden": 256,
    "z_dim": 16,
    "fourier_ramp_start": 0.3,
    "fourier_ramp_end": 0.7,
}
# BASE minus the capacity/schedule additions: the two structural changes alone.
BASE_MIN: Dict = {"emb_dim": 0, "prior_partition": "class", "arm": "g_interp_cap", "coeff": 1.0}

CHAMPION: Dict = {"emb_dim": 8, "prior_partition": "none", "arm": "b_cap", "coeff": 1.0}


def parse_kv(s: str) -> Dict:
    out: Dict = {}
    for kv in [p for p in s.split(",") if p.strip()]:
        if "=" not in kv:
            raise ValueError(f"expected key=value, got {kv!r}")
        k, v = kv.split("=", 1)
        k = k.strip()
        if not k or k in out:
            raise ValueError(f"empty or repeated override key: {k!r}")
        if k in ("seed", "out_dir"):
            raise ValueError(f"{k} is managed by the generator; use --seeds for seeds")
        out[k] = yaml.safe_load(v.strip())
    return out


def stage_groups(stage: str) -> List[Tuple[str, Dict]]:
    """(group name, overrides). `recipe` overrides are absolute; the rest sit on BASE."""
    g: List[Tuple[str, Dict]] = []
    if stage == "smoke":
        for dm in ("scalar", "concat", "proj", "ucd"):
            g.append((f"smoke_{dm}", {"d_mode": dm, "total_steps": 300, "eval_interval": 100}))
        return g

    if stage == "recipe":
        ch = dict(CHAMPION)
        g.append(("champion", dict(ch)))                                             # as shipped
        g.append(("champion_f0", {**ch, "fourier": 0}))                             # plain-MLP D
        g.append(("champion_r1r2", {**ch, "arm": "a_r1r2", "coeff": 1.0}))          # zero-centred, strong
        g.append(("champion_einterp", {**ch, "arm": "e_interp", "coeff": 1.0}))     # two-sided interpolate
        g.append(("emb_icap", {**ch, "arm": "g_interp_cap"}))                       # change penalty only
        g.append(("emb_icap_ramp", {**ch, "arm": "g_interp_cap", "fourier_ramp_start": 0.3, "fourier_ramp_end": 0.7}))
        g.append(("pp_bcap", {**ch, "emb_dim": 0, "prior_partition": "class"}))     # change conditioning only
        g.append(("pp_icap", dict(BASE_MIN)))                                       # both structural changes
        g.append(("pp_icap_ramp", {**BASE_MIN, "fourier_ramp_start": 0.3, "fourier_ramp_end": 0.7}))
        g.append(("pp_icap_f0", {**BASE_MIN, "fourier": 0}))
        g.append(("pp_icap_h256", {**BASE_MIN, "hidden": 256}))
        g.append(("pp_icap_z16", {**BASE_MIN, "z_dim": 16}))
        g.append(("base", dict(BASE)))                                              # = every other stage's base
        g.append(("base_f0", {**BASE, "fourier": 0, "fourier_ramp_start": 0.0, "fourier_ramp_end": 0.0}))
        g.append(("base_8k", {**BASE, "total_steps": 8000}))
        g.append(("uncond_floor", {**ch, "emb_dim": 0, "d_mode": "scalar"}))        # no class anywhere
        g.append(("uncond_ceiling", {**ch, "emb_dim": 0, "arm": "g_interp_cap"}))   # G unconditional, D ucd
        return g

    if stage == "ucd":
        g.append(("d_scalar", {"d_mode": "scalar"}))
        g.append(("d_concat", {"d_mode": "concat"}))
        g.append(("d_proj", {"d_mode": "proj"}))
        for lam, tag in ((0.02, "0p02"), (0.1, "0p1"), (0.5, "0p5"), (2.0, "2p0")):
            g.append((f"ucd_l{tag}", {"d_mode": "ucd", "ucd_lambda": lam}))
        g.append(("ucd_gauss", {"prior": "gaussian"}))
        g.append(("ucd_emb_only", {"emb_dim": 8, "prior_partition": "none"}))
        g.append(("ucd_emb_pp", {"emb_dim": 8}))
        g.append(("ucd_symsup", {"lambda_sym": 1.0}))
        g.append(("ucd_gpx", {"gp_on_y": False}))
        return g

    if stage == "sparse":
        g.append(("lin", {}))
        for sp, tag in ((0.0, "0"), (0.01, "0p01"), (0.1, "0p1"), (1.0, "1p0")):
            g.append((f"gated_sp{tag}", {"real_head": "gated", "lambda_sp": sp}))
        g.append(("topk", {"real_head": "topk"}))
        # gate warm-up: linear head for the first 40% of the run, then the gate engages
        g.append(("gated_sp0p01_warm", {"real_head": "gated", "lambda_sp": 0.01, "gate_start_frac": 0.4}))
        g.append(("gated_sp0_warm", {"real_head": "gated", "lambda_sp": 0.0, "gate_start_frac": 0.4}))
        g.append(("topk_warm", {"real_head": "topk", "gate_start_frac": 0.4}))
        return g

    if stage == "discrete":
        g.append(("gst_tau1", {"cat_mode": "gumbel_st"}))
        g.append(("gst_anneal", {"cat_mode": "gumbel_st", "tau_end": 0.1}))
        g.append(("gsoft_anneal", {"cat_mode": "gumbel_soft", "tau_end": 0.1}))
        g.append(("starg", {"cat_mode": "st_argmax"}))
        g.append(("soft", {"cat_mode": "soft"}))
        g.append(("soft_anneal", {"cat_mode": "soft", "tau_end": 0.1}))
        g.append(("gst_symsup", {"cat_mode": "gumbel_st", "lambda_sym": 1.0}))
        g.append(("gst_split", {"cat_mode": "gumbel_st", "symbol_map": "split", "n_symbols": 16}))
        g.append(("soft_split", {"cat_mode": "soft", "symbol_map": "split", "n_symbols": 16}))
        return g

    if stage == "champion":
        # Everything the earlier stages found stacked: lambda_1 0.02 (ucd stage)
        # and the warm-started gated head (sparse stage), on the base; plus the
        # same head under the injection D modes and a longer run.
        gw = {"real_head": "gated", "lambda_sp": 0.01, "gate_start_frac": 0.4}
        g.append(("l0p02", {"ucd_lambda": 0.02}))
        g.append(("l0p02_gw", {"ucd_lambda": 0.02, **gw}))
        g.append(("l0p02_gw_8k", {"ucd_lambda": 0.02, **gw, "total_steps": 8000}))
        g.append(("l0p02_gw_sp0p003", {"ucd_lambda": 0.02, **gw, "lambda_sp": 0.003}))
        g.append(("l0p02_gw_gs0p6", {"ucd_lambda": 0.02, **gw, "gate_start_frac": 0.6}))
        g.append(("concat_gw", {"d_mode": "concat", **gw}))
        g.append(("proj_gw", {"d_mode": "proj", **gw}))
        return g

    if stage == "fewshot":
        for n in (128, 512, 2048, 8192):
            g.append((f"n{n}", {"n_train": n}))
        g.append(("n512_gauss", {"n_train": 512, "prior": "gaussian"}))
        return g

    raise ValueError(f"unknown stage {stage!r}")


def stage_namespace(stage: str, extra: Dict, seeds: List[int], total_steps: int) -> str:
    if not extra and seeds == list(SEEDS) and total_steps == TOTAL_STEPS:
        return stage
    variant = json.dumps({"base": extra, "seeds": seeds, "total_steps": total_steps},
                         sort_keys=True, separators=(",", ":"), allow_nan=False)
    return f"{stage}__{hashlib.sha256(variant.encode()).hexdigest()[:12]}"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", required=True, choices=["smoke", "recipe", "ucd", "sparse", "discrete", "fewshot", "champion"])
    ap.add_argument("--base", type=str, default="", help="comma-separated key=value applied LAST, overriding BASE and group values in every config")
    ap.add_argument("--seeds", type=str, default=",".join(str(s) for s in SEEDS))
    ap.add_argument("--total_steps", type=int, default=TOTAL_STEPS)
    ap.add_argument("--print_stage", action="store_true", help="Print the resolved stage namespace without writing files (for pipelines).")
    args = ap.parse_args()

    try:
        extra = parse_kv(args.base)
        seeds = [int(s) for s in args.seeds.split(",") if s.strip()]
        if not seeds or len(seeds) != len(set(seeds)):
            raise ValueError("--seeds needs at least one distinct integer seed")
        if args.total_steps <= 0:
            raise ValueError("--total_steps must be positive")
        namespace = stage_namespace(args.stage, extra, seeds, args.total_steps)
    except (ValueError, TypeError, yaml.YAMLError) as exc:
        ap.error(str(exc))
    if args.print_stage:
        print(namespace)
        return
    if args.stage == "smoke":
        seeds = seeds[:1]
    cfg_dir = CONFIG_ROOT / namespace
    cfg_dir.mkdir(parents=True, exist_ok=True)
    n = 0
    config_paths = []
    for name, over in stage_groups(args.stage):
        for seed in seeds:
            cfg: Dict = {} if args.stage in ("smoke", "recipe") else dict(BASE)
            cfg.update(over)
            cfg.setdefault("total_steps", args.total_steps)
            cfg.update(extra)
            cfg["seed"] = seed
            cfg["out_dir"] = str(RUNS_ROOT / namespace / f"{name}_s{seed}")
            path = cfg_dir / f"{name}_s{seed}.yaml"
            with path.open("w") as f:
                yaml.safe_dump(cfg, f, sort_keys=True)
            config_paths.append(str(path))
            n += 1
    manifest = cfg_dir / "manifest.json"
    temporary = manifest.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(config_paths, indent=2) + "\n")
    temporary.replace(manifest)
    print(f"[gen_sparse_configs] stage={namespace} overrides={extra} -> {n} configs in {cfg_dir}/; manifest={manifest}")


if __name__ == "__main__":
    main()
