from copy import deepcopy
import hashlib
import json
from pathlib import Path
import torch
from benchmarks.transfer_suite import image_tasks as tasks
root=Path('/tmp/pr36-transfer-images-ratios')
root.mkdir(exist_ok=False)
policy=dict(weights=torch.zeros(2,2,5).tolist(),schedule='cosine')
variants=[('half_g', .00085,.0017),('half_d',.0017,.00085)]
declaration=dict(variants=variants,tasks=[s for s in tasks.TASKS if s['tier']=='ranking'],protocol=tasks.fingerprint(),
                 script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),reserved_evaluated=False)
(root/'declaration.json').write_text(json.dumps(declaration,indent=2))
for name,lr_g,lr_d in variants:
 for original in tasks.TASKS:
  if original['tier']!='ranking': continue
  spec=deepcopy(original); spec.update(lr_g=lr_g,lr_d=lr_d)
  print('START',name,spec['name'],flush=True)
  result=tasks.run_episode(spec,policy,fixed=True)
  (root/f'{name}-{spec["name"]}.json').write_text(json.dumps(result,indent=2,allow_nan=False))
  print(json.dumps(dict(variant=name,task=spec['name'],live=result['live'],convergence=result['convergence'],seconds=result['seconds'],error=result.get('error'))),flush=True)
