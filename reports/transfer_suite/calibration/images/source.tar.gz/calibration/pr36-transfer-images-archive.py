import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

from benchmarks.transfer_suite import image_tasks as tasks
repo=Path.cwd()
root=Path('/tmp/pr36-transfer-images-artifacts')
root.mkdir(exist_ok=False)
manifest=[]
for directory in (Path('/tmp/pr36-transfer-images-v1'),Path('/tmp/pr36-transfer-images-ratios')):
 for path in sorted(directory.glob('*.json')):
  raw=path.read_bytes(); payload=gzip.compress(raw,mtime=0)
  relative=Path(directory.name)/f'{path.name}.gz'
  output=root/relative; output.parent.mkdir(exist_ok=True); output.write_bytes(payload)
  assert gzip.decompress(payload)==raw
  manifest.append(dict(path=str(relative),original_sha256=hashlib.sha256(raw).hexdigest(),
                       compressed_sha256=hashlib.sha256(payload).hexdigest(),original_bytes=len(raw)))
source_names=set(tasks.fingerprint()['source_sha256'])
source_names.update(['benchmarks/transfer_suite/image_tasks.md','tests/test_transfer_image_tasks.py'])
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tar:
 for name in sorted(source_names):
  payload=(repo/name).read_bytes(); info=tarfile.TarInfo(name); info.size=len(payload); info.mtime=0; info.mode=0o644
  tar.addfile(info,io.BytesIO(payload))
 for path in (Path('/tmp/pr36-transfer-images-ratios.py'),Path(__file__)):
  payload=path.read_bytes(); info=tarfile.TarInfo('calibration/'+path.name); info.size=len(payload); info.mtime=0; info.mode=0o644
  tar.addfile(info,io.BytesIO(payload))
source_payload=gzip.compress(buffer.getvalue(),mtime=0)
(root/'source.tar.gz').write_bytes(source_payload)
(root/'manifest.json').write_text(json.dumps(dict(files=manifest,source_archive_sha256=hashlib.sha256(source_payload).hexdigest(),
                                               source_sha256=tasks.fingerprint()['source_sha256'],reserved_evaluated=False),indent=2))
shutil.copyfile(repo/'benchmarks/transfer_suite/image_tasks.md',root/'README.md')
for path in Path('/tmp').glob('pr36-transfer-images-*.log'):
 shutil.copyfile(path,root/path.name)
print('Archived',len(manifest),'exact JSON payloads at',root)
