"""ROOT-only focused944 controls; Source-authored, not run by the author.

These controls do not claim realized 80-update prefix equality.  The one declared
four-update fixture is separately counted and the five full cases remain ROOT's
scientific operations.
"""
from __future__ import annotations
import argparse
import ast
from copy import deepcopy
import hashlib
import importlib.util
import json
import math
from types import SimpleNamespace
from pathlib import Path
import sys
import unittest

EXPECTED_CELLS = {
    "amsgrad_on_l2_off_80": (True, 0.0, 80),
    "amsgrad_on_l2_on_320": (True, 0.02, 320),
    "amsgrad_off_l2_on_320": (False, 0.02, 320),
    "amsgrad_on_l2_off_320": (True, 0.0, 320),
    "amsgrad_off_l2_off_320": (False, 0.0, 320),
}
CLOCKS80 = [4, 7, 10, 14, 17, 20, 24, 27, 30, 34, 37, 40,
            44, 47, 50, 54, 57, 60, 64, 67, 70, 74, 77, 80]
BASE_RECIPE_SHA256 = "d5f20a8c4a9a7a3e2f0ac6d4562ae0a364677ffe73611ff9f9b7432434024b95"
PARENT_TASK_SHA256 = "55ac2d3883ba6c173da304fa7f10648a0b559c202fc35b451b1d0c8870f61cf5"
RESOURCES = {"backend": "cpu", "cpu_threads": 1, "gpus": 0, "budget_seconds": 300}
CHECKS = (
    "fixed_five_cell_declarations",
    "declaration_unknown_keys_rejected",
    "fixed_seed_resources_base_recipe",
    "table_only_optimizer_and_objective_scope",
    "extended_cadence_preserves_first24",
    "numerical_update_and_evaluator_source_equivalence",
    "external_limit_and_noise_clock_boundaries",
    "distinct_task_and_cell_admission_identity",
    "initial_four_update_retained_prefix",
)
ZERO_OPERATIONS = (
    "extra_prior_samples", "extra_rng_draws", "extra_model_forwards",
    "extra_backward_calls", "extra_optimizer_steps", "extra_decision_evaluations",
    "state_getter_calls", "state_mutations", "foreign_device_initializations",
)


class FactorialControls(unittest.TestCase):
    driver = None
    checkout = None
    retained_saved = None
    pins = None

    def _fixture_controls(self):
        # Synthetic serializer input only; never written as the measured receipt.
        return {"schema": "forge_atlas944_factorial_control_result_v1", "status": "PASS",
                "checks": {name: "PASS" for name in CHECKS},
                "added_operations": {name: 0 for name in ZERO_OPERATIONS},
                "source_pins": deepcopy(self.pins),
                "software_fixture_updates": 4, "software_fixture_observations": 1}

    def _declaration(self, cell_id):
        controls = self._fixture_controls()
        pins = controls["source_pins"]
        return {"schema": "forge_atlas944_factorial_declaration_v1", "cell_id": cell_id,
                "plan": self.driver.plan_cell(cell_id), "source_pins": pins,
                "software_proof": self.driver.build_software_proof(cell_id, controls, pins),
                "attempt_id": "11111111111111111111111111111111"}

    def test_fixed_five_cell_declarations(self):
        self.assertEqual(dict(self.driver.CELLS), EXPECTED_CELLS)
        for cell_id in EXPECTED_CELLS:
            plan = self.driver.plan_cell(cell_id)
            self.assertEqual(self.driver.validate_declaration(self._declaration(cell_id)), plan)
            again = self.driver.plan_cell(cell_id)
            plan["UNSUPPORTED_MUTATION"] = True
            self.assertEqual(again, self.driver.plan_cell(cell_id))
            self.assertNotIn("UNSUPPORTED_MUTATION", again)

    def test_declaration_unknown_keys_rejected(self):
        for cell_id in EXPECTED_CELLS:
            good = self._declaration(cell_id)
            bad = deepcopy(good)
            bad["unknown_parameter"] = 1
            with self.assertRaises(ValueError):
                self.driver.validate_declaration(bad)
            for key in good:
                bad = deepcopy(good)
                del bad[key]
                with self.assertRaises(ValueError):
                    self.driver.validate_declaration(bad)
            for seed in (1, True, 0.0):
                bad = deepcopy(good)
                bad["plan"]["seed"] = seed
                with self.assertRaises(ValueError):
                    self.driver.validate_declaration(bad)
            for resources in ({**RESOURCES, "gpus": 1}, {**RESOURCES, "cpu_threads": 2},
                              {**RESOURCES, "budget_seconds": 299},
                              {**RESOURCES, "backend": "cuda"},
                              {**RESOURCES, "unknown_resource": 0}):
                bad = deepcopy(good)
                bad["plan"]["resources"] = resources
                with self.assertRaises(ValueError):
                    self.driver.validate_declaration(bad)
            bad = deepcopy(good)
            bad["software_proof"] = {"schema": "forge_atlas932_particle_l2_software_proof_v1",
                                      "status": "PASS"}
            with self.assertRaises(ValueError):
                self.driver.validate_declaration(bad)
        for retained_or_unknown in ("amsgrad_on_l2_on_80", "amsgrad_off_l2_on_80",
                                    "amsgrad_off_l2_off_80", "unknown", "", None, True):
            with self.assertRaises((ValueError, TypeError)):
                self.driver.plan_cell(retained_or_unknown)

    def test_fixed_seed_resources_base_recipe(self):
        parent_raw = (self.checkout / "configs/forge/tasks/two_pole.json").read_bytes()
        self.assertEqual(hashlib.sha256(parent_raw).hexdigest(), PARENT_TASK_SHA256)
        parent = json.loads(parent_raw)
        for cell_id in EXPECTED_CELLS:
            plan = self.driver.plan_cell(cell_id)
            self.assertIs(type(plan["seed"]), int)
            self.assertEqual(plan["seed"], 0)
            self.assertEqual(plan["resources"], RESOURCES)
            self.assertEqual(plan["base_recipe_sha256"], BASE_RECIPE_SHA256)
            self.assertIs(plan["scientific_credit"], False)
            self.assertIsNone(plan["horizon_variant"]["recipe_total_steps"])
            task = self.driver.task_spec(self.checkout, cell_id)
            self.assertEqual(task["execution"]["prior"], parent["execution"]["prior"])
            self.assertEqual(task["execution"]["fixed_initialization"],
                             parent["execution"]["fixed_initialization"])
            self.assertEqual(task["resources"], parent["resources"])
            for key in ("thresholds", "minimum_stable_checks", "scoring_weights",
                        "sampling_law", "eval_output_noise", "guards"):
                self.assertEqual(task["evaluation"][key], parent["evaluation"][key])

    def test_table_only_optimizer_and_objective_scope(self):
        for cell_id, (table_amsgrad, particle_l2, steps) in EXPECTED_CELLS.items():
            plan = self.driver.plan_cell(cell_id)
            self.assertEqual(plan["optimizer_variant"]["groups"], [
                {"optimizer": "generator", "group_index": 0, "role": "table", "amsgrad": table_amsgrad},
                {"optimizer": "generator", "group_index": 1, "role": "noise", "amsgrad": True},
                {"optimizer": "critic", "group_index": 0, "role": "critic", "amsgrad": True},
            ])
            self.assertEqual(plan["optimizer_variant"]["table_lr_clock"],
                             "completed_direct_adam_lr/base_lr")
            self.assertEqual(plan["objective_variant"]["parent_task_id"], "two_pole")
            self.assertEqual(plan["objective_variant"]["parent_task_sha256"], PARENT_TASK_SHA256)
            self.assertEqual(plan["objective_variant"]["training_term"],
                             "particle_l2 * particles.square().mean()")
            self.assertEqual(plan["objective_variant"]["particle_l2"], particle_l2)
            self.assertEqual(plan["objective_variant"]["reference_particle_l2"], 0.02)
            self.assertEqual(plan["horizon_variant"]["steps"], steps)

    def test_extended_cadence_preserves_first24(self):
        self.assertEqual(self.driver.observation_clocks(80), CLOCKS80)
        clocks = self.driver.observation_clocks(320)
        self.assertEqual(clocks, [math.ceil(i * 80 / 24) for i in range(1, 97)])
        self.assertEqual(len(clocks), 96)
        self.assertEqual(clocks[:24], CLOCKS80)
        self.assertEqual(clocks[-5:], [307, 310, 314, 317, 320])
        self.assertEqual(len(set(clocks)), 96)
        for invalid in (0, 79, 81, 160, 1000, True, 80.0, "320", None):
            with self.assertRaises((ValueError, TypeError)):
                self.driver.observation_clocks(invalid)

    def test_distinct_task_and_cell_admission_identity(self):
        plans = [self.driver.plan_cell(cell_id) for cell_id in EXPECTED_CELLS]
        self.assertEqual(len({plan["task_id"] for plan in plans}), 5)
        self.assertEqual(len({plan["candidate_id"] for plan in plans}), 5)
        self.assertNotIn("two_pole", {plan["task_id"] for plan in plans})
        for cell_id, (_, l2, steps) in EXPECTED_CELLS.items():
            plan = self.driver.plan_cell(cell_id)
            task = self.driver.task_spec(self.checkout, cell_id)
            self.assertEqual(task["id"], plan["task_id"])
            self.assertEqual(task["execution"]["steps"], steps)
            self.assertEqual(task["execution"]["host_definition"]["steps"], steps)
            self.assertEqual(task["execution"]["particle_l2"], l2)
            self.assertEqual(task["evaluation"]["observations"], len(plan["observation_clocks"]))
            declaration = self._declaration(cell_id)
            other_id = next(value for value in EXPECTED_CELLS if value != cell_id)
            declaration["cell_id"] = other_id
            with self.assertRaises(ValueError):
                self.driver.validate_declaration(declaration)

    def test_numerical_update_and_evaluator_source_equivalence(self):
        original = (self.checkout / self.driver.PARENT_OWNER_PATH).read_text()
        self.assertEqual(hashlib.sha256(original.encode()).hexdigest(),
                         self.driver.PARENT_OWNER_PIN["sha256"])
        original_nodes = ast.parse(original).body
        transformed = self.driver.derive_owner_source(original, "amsgrad_off_l2_off_320")
        transformed_nodes = ast.parse(transformed).body
        self.assertEqual(len(transformed_nodes), len(original_nodes))
        changed = {"make_particle_optimizer", "objective_receipt", "_PolicyNoise",
                   "construct_owner", "run_first_case"}
        for old, new in zip(original_nodes, transformed_nodes):
            if getattr(old, "name", None) not in changed:
                self.assertEqual(ast.dump(new), ast.dump(old))
                continue
            new = deepcopy(new)
            if old.name == "construct_owner":
                old_expected = next(n for n in old.body if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == "expected" for t in n.targets))
                new_expected = next(n for n in new.body if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == "expected" for t in n.targets))
                self.assertEqual(ast.unparse(new_expected.value),
                                 "resolve_binding(root, _CELL_CANDIDATE, _CELL_TASK, _CELL_PROTOCOL)")
                new_expected.value = deepcopy(old_expected.value)
            if old.name == "run_first_case":
                inserted = [n for n in new.body if ast.unparse(n) == "namespace['TOY_STEPS'] = STEPS"]
                self.assertEqual(len(inserted), 1)
                new.body.remove(inserted[0])
            class ReverseDeclaredConstants(ast.NodeTransformer):
                def visit_Name(self, node):
                    values = {"_CELL_AMSGRAD": False, "_CELL_L2": 0.0, "STEPS": 80}
                    if node.id in values:
                        return ast.copy_location(ast.Constant(values[node.id]), node)
                    return node
            new = ReverseDeclaredConstants().visit(new)
            self.assertEqual(ast.dump(new), ast.dump(old))
        for cell_id in EXPECTED_CELLS:
            self.assertEqual(self.driver.derive_owner_source(original, cell_id), transformed)
        with self.assertRaises(ValueError):
            self.driver.derive_owner_source(original + "\n", "amsgrad_off_l2_off_320")
        # The original verdict body remains exact after reversing only its
        # explicitly supplied expected-clock expression, name and argument.
        protocol_source = (self.checkout / "benchmarks/transfer_suite/protocol.py").read_text()
        old_grade = next(n for n in ast.parse(protocol_source).body
                         if isinstance(n, ast.FunctionDef) and n.name == "test_verdict")
        new_grade = ast.parse(self.driver._grade_source(self.checkout)).body[0]
        self.assertEqual(new_grade.name, "_grade")
        self.assertEqual(new_grade.args.args[-1].arg, "declared_clocks")
        new_grade.name = old_grade.name
        new_grade.args.args.pop()
        old_steps = next(n for n in old_grade.body if isinstance(n, ast.Assign)
                         and any(isinstance(t, ast.Name) and t.id == "steps" for t in n.targets))
        new_steps = next(n for n in new_grade.body if isinstance(n, ast.Assign)
                         and any(isinstance(t, ast.Name) and t.id == "steps" for t in n.targets))
        self.assertEqual(ast.unparse(new_steps.value), "list(declared_clocks)")
        new_steps.value = deepcopy(old_steps.value)
        self.assertEqual(ast.dump(new_grade), ast.dump(old_grade))
        clocks = self.driver.observation_clocks(320)
        packet = {"observations": [{"step": step, "mean_abs": 0.3, "grad_med": 1.0}
                                   for step in clocks],
                  "live": {"mean_abs": 0.3, "grad_med": 1.0},
                  "guards": {"all_finite": True, "hooks_exercised": True,
                             "unintended_rng_deviations": 0}}
        grade = self.driver.grade_result(self.checkout, "amsgrad_off_l2_off_320", packet)
        self.assertEqual(grade["status"], "PASS")
        self.assertIs(grade["scientific_credit"], False)
        bad = deepcopy(packet)
        bad["live"]["mean_abs"] = 0.299
        self.assertEqual(self.driver.grade_result(self.checkout, "amsgrad_off_l2_off_320", bad)["status"], "FAIL")
        bad = deepcopy(packet)
        bad["observations"] = bad["observations"][:24]
        self.assertFalse(self.driver.grade_result(self.checkout, "amsgrad_off_l2_off_320", bad)["passed"])
        bad = deepcopy(packet)
        bad["guards"]["hooks_exercised"] = False
        self.assertEqual(self.driver.grade_result(self.checkout, "amsgrad_off_l2_off_320", bad)["status"], "INVALID")

    def test_external_limit_and_noise_clock_boundaries(self):
        recipes = []
        for cell_id, (_, _, steps) in EXPECTED_CELLS.items():
            module = self.driver.load_owner(self.checkout, cell_id)
            self.assertEqual(module.STEPS, steps)
            self.assertEqual(module.CLOCKS, self.driver.observation_clocks(steps))
            self.assertEqual(module.binding["cell_plan"], self.driver.plan_cell(cell_id))
            self.assertIsNone(module.binding["recipe"]["total_steps"])
            self.assertEqual(self.driver.digest(module.binding["recipe"]), BASE_RECIPE_SHA256)
            self.assertEqual(len(module.binding["recipe"]), 79)
            recipes.append(module.binding["recipe"])
            # Exercise the actual derived external-clock wrapper, without a
            # model/controller call. Genuine numerical behavior is the ninth
            # four-update fixture, not inferred from this argument witness.
            calls = []
            class ArgumentWitness:
                def __init__(self, completed_steps):
                    self.completed_steps = completed_steps
                def begin_step(self, real, *, execution_limit):
                    calls.append((real, execution_limit))
            real = object()
            for completed in (0, 79):
                owner = SimpleNamespace(policy=ArgumentWitness(completed), real=real,
                                        calls={"begin_step": 0})
                noise = module._PolicyNoise(owner)
                noise.set_step(completed)
                self.assertIs(calls[-1][0], real)
                self.assertEqual(calls[-1][1], steps)
                self.assertEqual(owner.calls["begin_step"], 1)
                before = list(calls)
                with self.assertRaises(ValueError):
                    noise.set_step(completed + 1)
                self.assertEqual(calls, before)
            constructor = next(n for n in ast.parse(module.derived_source).body
                               if isinstance(n, ast.FunctionDef) and n.name == "construct_owner")
            bound = [n for n in ast.walk(constructor) if isinstance(n, ast.Call)
                     and isinstance(n.func, ast.Attribute) and n.func.attr == "bind_update_policy"]
            self.assertEqual(len(bound), 1)
            keyword = next(k for k in bound[0].keywords if k.arg == "external_max_steps")
            self.assertEqual(ast.unparse(keyword.value), "STEPS")
        for recipe in recipes[1:]:
            self.assertEqual(recipe, recipes[0])

    def test_initial_four_update_retained_prefix(self):
        self.assertEqual(len(self.retained_saved), 24)
        self.assertEqual(self.retained_saved[0]["step"], 4)
        import random
        import numpy as np
        import torch
        torch.set_num_threads(1)
        torch.manual_seed(0)
        np.random.seed(0)
        random.seed(0)
        report = self.driver.verify_initial_prefix(self.checkout,
            cell_id="amsgrad_off_l2_off_320", retained_saved=self.retained_saved)
        self.assertEqual(report["status"], "PASS")
        self.assertEqual(report["software_fixture_updates"], 4)
        self.assertEqual(report["software_fixture_observations"], 1)
        self.assertTrue(report["equal"])
        self.assertEqual(report["external_cap"], 320)
        self.assertIsNone(report["recipe_total_steps"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--retained-prefix", type=Path, required=True)
    parser.add_argument("--retained-prefix-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    checkout = args.checkout.resolve()
    if Path(__file__).resolve() != checkout / "tests/test_atlas944_factorial.py":
        raise ValueError("controls must execute from the declared copied root")
    raw = args.retained_prefix.read_bytes()
    expected = "dde1702b691a4aa666f412de37ef910095e99d682a679f6b8cb70f2067c05d45"
    if (args.retained_prefix_sha256 != expected or len(raw) != 106222
            or hashlib.sha256(raw).hexdigest() != expected):
        raise ValueError("protected932 retained prefix byte pin differs")
    bank = json.loads(raw)
    if (bank.get("schema") != "atlas944_retained_numerical_prefix_v1"
            or bank.get("original_authority_seq") != 932
            or bank.get("request_id") != "a7cfc6f48c5ec2f849476208"
            or bank.get("raw_result_pin") != {
                "sha256": "a42489439f18afee364e653da518c89745702e1c2ba7b7ff857d928c09335ea6",
                "bytes": 12685154}
            or [row["step"] for row in bank.get("saved", [])] != CLOCKS80):
        raise ValueError("retained932 bank identity or original clock order differs")
    sys.path.insert(0, str(checkout))
    driver_path = checkout / "experiments/forge/atlas944_factorial.py"
    driver_raw = driver_path.read_bytes()
    if (len(driver_raw) != 26634 or hashlib.sha256(driver_raw).hexdigest()
            != "d4e758e3dc9b48f132d031f0ccebf22d8ea766004c6052feadaf3c194fe8dbfe"):
        raise ValueError("reviewed944 driver Source pin differs")
    spec = importlib.util.spec_from_file_location("experiments.forge.atlas944_factorial", driver_path)
    driver = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = driver
    spec.loader.exec_module(driver)
    if tuple(driver.CHECKS) != CHECKS or tuple(driver.ZERO_OPERATIONS) != ZERO_OPERATIONS:
        raise ValueError("focused control roster differs")
    FactorialControls.driver, FactorialControls.checkout = driver, checkout
    FactorialControls.retained_saved = bank["saved"]
    FactorialControls.pins = driver.source_pins(checkout)
    names = tuple("test_" + name for name in CHECKS)
    suite = unittest.TestSuite(FactorialControls(name) for name in names)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if result.testsRun != 9 or not result.wasSuccessful():
        raise SystemExit(1)
    report = {"schema": "forge_atlas944_factorial_control_result_v1", "status": "PASS",
              "checks": {name: "PASS" for name in CHECKS},
              "added_operations": {name: 0 for name in ZERO_OPERATIONS},
              "source_pins": driver.source_pins(checkout),
              "software_fixture_updates": 4, "software_fixture_observations": 1,
              "retained_prefix_pin": {"sha256": expected, "bytes": len(raw)},
              "numerical_prefix_scope": "first4 updates/one scored read only; full80 prefixes pending"}
    with args.output.open("x") as stream:
        json.dump(report, stream, sort_keys=True, separators=(",", ":"), allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()
