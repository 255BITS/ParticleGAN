"""Five preregistered944 cells; inert import, isolated pinned932 numerical owner.

ROOT runs the CLI in one fresh CPU1 process per cell under its separately fitted
300-second allocation. No shared registry, Recipe, recorder or default is edited.
The optional four-update fixture is software evidence, never another case grade.
"""
from __future__ import annotations

import argparse
import ast
from copy import deepcopy
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
from types import ModuleType

DRIVER_PATH = 'experiments/forge/atlas944_factorial.py'
TEST_PATH = 'tests/test_atlas944_factorial.py'
PARENT_OWNER_PATH = 'experiments/forge/atlas932_two_pole_owner.py'
PARENT_OWNER_PIN = {'sha256': 'ced28b3fe73d1fa74a000b1f10552ada7bc0f703cd8c94c6fff6ce8d04841a07', 'bytes': 76162}
BASE_RECIPE_SHA256 = 'd5f20a8c4a9a7a3e2f0ac6d4562ae0a364677ffe73611ff9f9b7432434024b95'
PARENT_TASK_SHA256 = '55ac2d3883ba6c173da304fa7f10648a0b559c202fc35b451b1d0c8870f61cf5'
CELLS = {
    'amsgrad_on_l2_off_80': (True, 0.0, 80),
    'amsgrad_on_l2_on_320': (True, 0.02, 320),
    'amsgrad_on_l2_off_320': (True, 0.0, 320),
    'amsgrad_off_l2_on_320': (False, 0.02, 320),
    'amsgrad_off_l2_off_320': (False, 0.0, 320),
}
CONTROL_SCHEMA = 'forge_atlas944_factorial_control_result_v1'
PROOF_SCHEMA = 'forge_atlas944_factorial_software_proof_v1'
DECLARATION_SCHEMA = 'forge_atlas944_factorial_declaration_v1'
CHECKS = ('fixed_five_cell_declarations', 'declaration_unknown_keys_rejected',
    'fixed_seed_resources_base_recipe', 'table_only_optimizer_and_objective_scope',
    'extended_cadence_preserves_first24', 'numerical_update_and_evaluator_source_equivalence',
    'external_limit_and_noise_clock_boundaries', 'distinct_task_and_cell_admission_identity',
    'initial_four_update_retained_prefix')
ZERO_OPERATIONS = ('extra_prior_samples', 'extra_rng_draws', 'extra_model_forwards',
    'extra_backward_calls', 'extra_optimizer_steps', 'extra_decision_evaluations',
    'state_getter_calls', 'state_mutations', 'foreign_device_initializations')


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def observation_clocks(horizon):
    if type(horizon) is not int or horizon not in (80, 320):
        raise ValueError('only external80 or320 is preregistered')
    return [(i * 80 + 23) // 24 for i in range(1, horizon * 24 // 80 + 1)]


def plan_cell(cell_id):
    if type(cell_id) is not str or cell_id not in CELLS:
        raise ValueError('unknown or already-run factorial cell')
    amsgrad, l2, steps = CELLS[cell_id]
    return dict(schema='forge_atlas944_factorial_cell_v1', cell_id=cell_id,
        candidate_id='atlas944-factorial-' + cell_id.replace('_', '-') + '-v1',
        task_id='two_pole_factorial944_' + cell_id, seed=0,
        resources=dict(backend='cpu', cpu_threads=1, gpus=0, budget_seconds=300),
        base_recipe_sha256=BASE_RECIPE_SHA256,
        optimizer_variant=dict(schema='forge_atlas944_optimizer_variant_v1',
            base_recipe_sha256=BASE_RECIPE_SHA256,
            groups=[dict(optimizer='generator', group_index=0, role='table', amsgrad=amsgrad),
                    dict(optimizer='generator', group_index=1, role='noise', amsgrad=True),
                    dict(optimizer='critic', group_index=0, role='critic', amsgrad=True)],
            table_lr_clock='completed_direct_adam_lr/base_lr'),
        objective_variant=dict(schema='forge_atlas944_objective_variant_v1',
            parent_task_id='two_pole', parent_task_sha256=PARENT_TASK_SHA256,
            training_term='particle_l2 * particles.square().mean()',
            particle_l2=l2, reference_particle_l2=0.02),
        horizon_variant=dict(schema='forge_atlas944_external_horizon_v1', steps=steps,
            recipe_total_steps=None, clock_base_steps=80, clock_base_reads=24,
            minimum_stable_checks=5),
        observation_clocks=observation_clocks(steps), scientific_credit=False)


def _pin(raw):
    return dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def _read(root, relative, expected=None):
    root = Path(root).resolve()
    path = root / relative
    if not path.is_file() or path.is_symlink() or path.resolve() != path:
        raise ValueError('missing or aliased Source: ' + relative)
    raw = path.read_bytes()
    if expected is not None and _pin(raw) != expected:
        raise ValueError('Source drift: ' + relative)
    return raw


def _literal(source, name):
    for node in ast.parse(source).body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return ast.literal_eval(node.value)
    raise ValueError('missing pinned declaration: ' + name)


def source_pins(root):
    source = _read(root, PARENT_OWNER_PATH, PARENT_OWNER_PIN).decode()
    pins = _literal(source, 'SOURCE_PINS')
    for relative, pin in pins.items():
        _read(root, relative, pin)
    pins[PARENT_OWNER_PATH] = deepcopy(PARENT_OWNER_PIN)
    for relative in (DRIVER_PATH, TEST_PATH):
        pins[relative] = _pin(_read(root, relative))
    if Path(__file__).resolve() != Path(root).resolve() / DRIVER_PATH:
        raise ValueError('944 driver must execute from the declared copied root')
    return pins


def task_spec(root, cell_id):
    plan = plan_cell(cell_id)
    source = _read(root, PARENT_OWNER_PATH, PARENT_OWNER_PIN).decode()
    task = _literal(source, 'ORIGINAL_TASK_DECLARATION')
    pins = _literal(source, 'SOURCE_PINS')
    if json.loads(_read(root, 'configs/forge/tasks/two_pole.json', pins['configs/forge/tasks/two_pole.json'])) != task:
        raise ValueError('protected original Task differs')
    task['id'] = plan['task_id']
    task['task_cohort'] = 'atlas944_factorial_' + cell_id
    task['execution']['steps'] = plan['horizon_variant']['steps']
    task['execution']['host_definition']['steps'] = plan['horizon_variant']['steps']
    task['execution']['particle_l2'] = plan['objective_variant']['particle_l2']
    task['evaluation']['observations'] = len(plan['observation_clocks'])
    task['evaluation']['evaluator'] = 'experiments.forge.atlas944_factorial:grade_result'
    task['diagnostic_variant'] = deepcopy(plan)
    return task


def derive_owner_source(source, cell_id):
    """Fail-closed, enumerated substitutions in the pinned owner, never core."""
    plan_cell(cell_id)
    if _pin(source.encode()) != PARENT_OWNER_PIN:
        raise ValueError('only the reviewed932 owner is a numerical preimage')
    tree = ast.parse(source)
    replacements = {}
    counts = {}
    def replace_function(name, transform):
        node = next(n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name == name)
        changed = deepcopy(node)
        transform(changed)
        replacements[name] = (node, ast.unparse(ast.fix_missing_locations(changed)))
    def constants(node, old, expression):
        class Replace(ast.NodeTransformer):
            def visit_Constant(self, item):
                if type(item.value) is type(old) and item.value == old:
                    counts[expression] = counts.get(expression, 0) + 1
                    return ast.copy_location(ast.Name(id=expression, ctx=ast.Load()), item)
                return item
        Replace().visit(node)
    def optimizer(node):
        target = next(n for n in ast.walk(node) if isinstance(n, ast.Dict) and any(
            isinstance(k, ast.Constant) and k.value == 'amsgrad' for k in n.keys))
        index = next(i for i, k in enumerate(target.keys) if isinstance(k, ast.Constant) and k.value == 'amsgrad')
        if not isinstance(target.values[index], ast.Constant) or target.values[index].value is not False:
            raise ValueError('table override preimage changed')
        target.values[index] = ast.Name(id='_CELL_AMSGRAD', ctx=ast.Load())
    replace_function('make_particle_optimizer', optimizer)
    replace_function('objective_receipt', lambda node: constants(node, 0.0, '_CELL_L2'))
    replace_function('_PolicyNoise', lambda node: constants(node, 80, 'STEPS'))
    def constructor(node):
        expected = next(n for n in node.body if isinstance(n, ast.Assign)
            and any(isinstance(t, ast.Name) and t.id == 'expected' for t in n.targets))
        if not isinstance(expected.value, ast.Call) or getattr(expected.value.func, 'id', None) != 'resolve_binding':
            raise ValueError('original constructor binding guard changed')
        expected.value = ast.parse('resolve_binding(root, _CELL_CANDIDATE, _CELL_TASK, _CELL_PROTOCOL)', mode='eval').body
        assignment = next(n for n in node.body if isinstance(n, ast.Assign)
            and isinstance(n.targets[0], ast.Tuple) and any(
                isinstance(t, ast.Attribute) and t.attr == 'particle_l2' for t in n.targets[0].elts))
        if (not isinstance(assignment.value, ast.Tuple)
                or not isinstance(assignment.value.elts[-1], ast.Constant)
                or assignment.value.elts[-1].value != 0.0):
            raise ValueError('original direct L2 coefficient assignment changed')
        assignment.value.elts[-1] = ast.Name(id='_CELL_L2', ctx=ast.Load())
        counts['_CELL_L2'] = counts.get('_CELL_L2', 0) + 1
        constants(node, 80, 'STEPS')
    replace_function('construct_owner', constructor)
    def runner(node):
        constants(node, 80, 'STEPS')
        position = next(i for i, n in enumerate(node.body) if isinstance(n, ast.Assign)
            and any(isinstance(t, ast.Name) and t.id == 'namespace' for t in n.targets))
        node.body.insert(position + 1, ast.parse("namespace['TOY_STEPS'] = STEPS").body[0])
    replace_function('run_first_case', runner)
    if counts != {'_CELL_L2': 2, 'STEPS': 8}:
        raise ValueError('numerical overlay substitution boundary changed: ' + repr(counts))
    lines = source.splitlines(keepends=True)
    for node, changed in sorted(replacements.values(), key=lambda pair: pair[0].lineno, reverse=True):
        lines[node.lineno - 1:node.end_lineno] = [changed + '\n']
    return ''.join(lines)


def build_software_proof(cell_id, controls, pins):
    plan = plan_cell(cell_id)
    if (controls.get('schema') != CONTROL_SCHEMA or controls.get('status') != 'PASS'
            or controls.get('checks') != {name: 'PASS' for name in CHECKS}
            or controls.get('source_pins') != pins
            or controls.get('software_fixture_updates') != 4
            or controls.get('software_fixture_observations') != 1
            or set(controls.get('added_operations', {})) != set(ZERO_OPERATIONS)
            or any(type(controls['added_operations'][name]) is not int or controls['added_operations'][name] != 0
                   for name in ZERO_OPERATIONS)):
        raise ValueError('fresh944 nine controls and explicit four-update fixture required')
    return dict(schema=PROOF_SCHEMA, status='PASS', cell_id=cell_id, plan_sha256=digest(plan),
        source_pins=deepcopy(pins), control_sha256=digest(controls), controls=deepcopy(controls))


def validate_declaration(declaration):
    if not isinstance(declaration, dict) or set(declaration) != {
            'schema', 'cell_id', 'plan', 'source_pins', 'software_proof', 'attempt_id'}:
        raise ValueError('unknown declaration keys')
    plan = plan_cell(declaration['cell_id'])
    if declaration['schema'] != DECLARATION_SCHEMA or canonical(declaration['plan']) != canonical(plan):
        raise ValueError('forged fixed cell/seed/resources/objective/optimizer/horizon')
    attempt = declaration['attempt_id']
    if type(attempt) is not str or len(attempt) != 32 or any(c not in '0123456789abcdef' for c in attempt):
        raise ValueError('fresh physical attempt identity required')
    proof = declaration['software_proof']
    if not isinstance(proof, dict) or proof != build_software_proof(declaration['cell_id'], proof.get('controls', {}), declaration['source_pins']):
        raise ValueError('old or unbound software proof')
    return plan


def load_owner(root, cell_id):
    """ROOT-only late isolated namespace; all original scientific defs reused."""
    plan = plan_cell(cell_id)
    pins = source_pins(root)
    original = _read(root, PARENT_OWNER_PATH, PARENT_OWNER_PIN).decode()
    derived = derive_owner_source(original, cell_id)
    module = ModuleType('experiments.forge._atlas944_' + cell_id)
    module.__file__ = str(Path(root).resolve() / PARENT_OWNER_PATH)
    module.__package__ = 'experiments.forge'
    exec(compile(derived, module.__file__ + ':944-isolated-overlay', 'exec'), module.__dict__)
    parent_candidate = json.loads(module._source(root, 'configs/forge/ideas/atlas-two-pole-l2-off932-v1.json'))
    parent_task = json.loads(module._source(root, module.TASK_PATH))
    protocol = json.loads(module._source(root, module.PROTOCOL_PATH))
    parent_binding = module.resolve_binding(root, parent_candidate, parent_task, protocol)
    task = task_spec(root, cell_id)
    candidate = dict(id=plan['candidate_id'], diagnostic_variant=deepcopy(plan))
    binding = deepcopy(parent_binding)
    binding.update(schema='forge_atlas944_factorial_owner_binding_v1',
        task_sha256=digest(task), cell_plan=deepcopy(plan), cell_plan_sha256=digest(plan),
        effective_optimizer_variant=deepcopy(plan['optimizer_variant']),
        effective_optimizer_variant_sha256=digest(plan['optimizer_variant']),
        effective_objective_variant=deepcopy(plan['objective_variant']),
        effective_objective_variant_sha256=digest(plan['objective_variant']),
        effective_horizon_variant=deepcopy(plan['horizon_variant']),
        effective_horizon_variant_sha256=digest(plan['horizon_variant']),
        derived_owner_source_sha256=hashlib.sha256(derived.encode()).hexdigest(),
        driver_sha256=pins[DRIVER_PATH]['sha256'])
    contract = binding['source_contract']
    contract.update(schema='forge_atlas944_factorial_public_owner_contract_v1', files=deepcopy(pins),
        task_id=task['id'], external_max_steps=plan['horizon_variant']['steps'],
        objective=dict(gan='Recipe.make_loss', particle_l2=plan['objective_variant']['particle_l2'], pairing='live_all12_rows'),
        effective_optimizer_variant=deepcopy(plan['optimizer_variant']),
        effective_optimizer_variant_sha256=digest(plan['optimizer_variant']),
        effective_objective_variant=deepcopy(plan['objective_variant']),
        effective_objective_variant_sha256=digest(plan['objective_variant']),
        effective_horizon_variant=deepcopy(plan['horizon_variant']),
        derived_owner_source_sha256=binding['derived_owner_source_sha256'],
        driver_sha256=binding['driver_sha256'], cell_plan_sha256=digest(plan),
        schedule='Recipe.total_steps=None; fixed original80/24 lattice continued forward')
    contract['observation'].update(observations=plan['observation_clocks'], final_five=plan['observation_clocks'][-5:])
    contract['inapplicable']['prior_reg'] = 'no latent prior; diagnostic direct-coordinate L2 is explicitly declared'
    binding['source_contract_sha256'] = digest(contract)
    def guard():
        if source_pins(root) != pins:
            raise ValueError('current copied Source changed')
    def resolve(root_arg, candidate_arg, task_arg, protocol_arg):
        if (Path(root_arg).resolve() != Path(root).resolve()
                or canonical(candidate_arg) != canonical(candidate) or canonical(task_arg) != canonical(task)
                or canonical(protocol_arg) != canonical(protocol)):
            raise ValueError('944 requires the exact isolated cell/task/protocol binding')
        guard()
        return deepcopy(binding)
    module.__dict__.update(STEPS=plan['horizon_variant']['steps'], CLOCKS=plan['observation_clocks'],
        SCHEMA=binding['schema'], TASK_ID=task['id'], OWNER_SCHEMA='forge_atlas944_initial_owner_v1',
        OPTIMIZER_VARIANT=plan['optimizer_variant'], OBJECTIVE_VARIANT=plan['objective_variant'],
        _CELL_AMSGRAD=plan['optimizer_variant']['groups'][0]['amsgrad'],
        _CELL_L2=plan['objective_variant']['particle_l2'], _CELL_CANDIDATE=candidate,
        _CELL_TASK=task, _CELL_PROTOCOL=protocol, resolve_binding=resolve,
        binding=binding, task=task, candidate=candidate, protocol=protocol, guard=guard,
        source_pins=deepcopy(pins), derived_source=derived)
    return module


def _atomic(path, value):
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('x') as stream:
        stream.write(canonical(value) + '\n'); stream.flush(); os.fsync(stream.fileno())
    os.replace(temporary, path)


class _Fresh:
    def __init__(self, module, output=None):
        self.module, self.output, self.owner, self.initialization = module, output, None, None
    def construct(self, factory, reader):
        if self.owner is not None or self.initialization is not None or reader is not self.module.owner_initial_receipt:
            raise ValueError('one fresh actual constructor per cell')
        self.module.guard()
        owner = factory()
        self.initialization = reader(owner)
        self.owner = owner
        if self.output is not None:
            _atomic(self.output / 'INITIALIZATION.json', self.initialization)
        return owner


def _export(module, result):
    retained = result.pop('retained_goal_states')
    result.pop('complete_state')
    observations = {row['step']: row for row in result['evidence']['observations']}
    purity = {row['step']: row for row in result['evidence']['measurement_purity']}
    if [row['step'] for row in retained] != module.CLOCKS:
        raise ValueError('captured bank clock mismatch')
    result['evidence']['saved_particle_observations'] = [dict(step=row['step'],
        particles=row['particles'].tolist(), critic_gradient=row['gradient'].tolist(), target=row['target'].tolist(),
        metrics=deepcopy(observations[row['step']]), purity=deepcopy(purity[row['step']])) for row in retained]
    return result


def _grade_source(root):
    parent = _read(root, PARENT_OWNER_PATH, PARENT_OWNER_PIN).decode()
    pin = _literal(parent, 'SOURCE_PINS')['benchmarks/transfer_suite/protocol.py']
    tree = ast.parse(_read(root, 'benchmarks/transfer_suite/protocol.py', pin).decode())
    node = deepcopy(next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'test_verdict'))
    steps = next(n for n in node.body if isinstance(n, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == 'steps' for t in n.targets))
    if ast.unparse(steps.value) != 'sorted({math.ceil(i * spec[\'steps\'] / 24) for i in range(1, 25)})':
        raise ValueError('pinned24-clock grader boundary changed')
    steps.value = ast.parse('list(declared_clocks)', mode='eval').body
    node.args.args.append(ast.arg(arg='declared_clocks'))
    node.name = '_grade'
    return ast.unparse(ast.fix_missing_locations(node)) + '\n'


def grade_result(root, cell_id, result):
    """Original grader, only its expected-clock expression explicitly supplied."""
    from benchmarks.transfer_suite import protocol
    parent = _literal(_read(root, PARENT_OWNER_PATH, PARENT_OWNER_PIN).decode(), 'SOURCE_PINS')
    for relative in ('benchmarks/transfer_suite/protocol.py', 'benchmarks/locked_shared/observation.py', 'benchmarks/locked_shared/baseline.py'):
        _read(root, relative, parent[relative])
    if Path(protocol.__file__).resolve() != Path(root).resolve() / 'benchmarks/transfer_suite/protocol.py':
        raise ValueError('foreign grader import')
    namespace = dict(vars(protocol))
    exec(compile(_grade_source(root), '<944-original-grader-explicit-clock>', 'exec'), namespace)
    plan = plan_cell(cell_id)
    packet = result.get('evidence', result) if result is not None else None
    grade = namespace['_grade'](dict(steps=plan['horizon_variant']['steps'],
        thresholds=[['mean_abs', '>=', 0.3], ['grad_med', '<=', 1.0]]), packet, plan['observation_clocks'])
    if result is not None and not all((packet.get('guards', {}).get('all_finite') is True,
            packet.get('guards', {}).get('hooks_exercised') is True,
            packet.get('guards', {}).get('unintended_rng_deviations') == 0)):
        grade.update(status='INVALID', passed=False)
    grade.update(cell_id=cell_id, diagnostic=True, scientific_credit=False)
    return grade


def _numerical_row(row):
    return dict(step=row['step'], particles=row['particles'], target=row['target'],
        critic_gradient=row['critic_gradient'], metrics={key: row['metrics'][key] for key in ('mean_abs', 'grad_med')})


def compare_prefix(current_saved, retained_saved):
    if len(current_saved) < 24 or len(retained_saved) != 24:
        raise ValueError('full original24 prefix banks required')
    differing = [a['step'] for a, b in zip(current_saved[:24], retained_saved)
        if canonical(_numerical_row(a)) != canonical(_numerical_row(b))]
    return dict(equal=not differing, observations=24, differing_steps=differing,
        scope='ordered particles/targets/critic_gradient and two original metric values; whole-state UNKNOWN')


def verify_initial_prefix(root, *, cell_id='amsgrad_off_l2_off_320', retained_saved):
    """ROOT-only software fixture: original first4 updates, one original read."""
    if cell_id != 'amsgrad_off_l2_off_320' or len(retained_saved) != 24 or retained_saved[0]['step'] != 4:
        raise ValueError('only preregistered first4 retained932 numerical fixture')
    module = load_owner(root, cell_id)
    owner = _Fresh(module).construct(lambda: module.construct_owner(root, module.binding, source_guard=module.guard), module.owner_initial_receipt)
    from benchmarks.locked_shared import two_pole
    namespace = dict(vars(two_pole))
    namespace.update(TOY_STEPS=4, checkpoint=owner.checkpoint, schedule_optimizer=owner.schedule_optimizer,
        _capture_gradient=owner.capture_gradient)
    import inspect
    gradient = inspect.getsource(two_pole._grad_median)
    marker = '    return float(grad.flatten().abs().median())'
    if gradient.count(marker) != 1:
        raise ValueError('original capture boundary changed')
    exec(compile(gradient.replace(marker, '    _capture_gradient(grad)\n' + marker), '<944-first4-original-capture>', 'exec'), namespace)
    exec(compile(module.derive_host_function(module._source(root, module.HOST_PATH).decode()), '<944-first4-original-update>', 'exec'), namespace)
    namespace['_owned_train'](owner)
    if owner.policy.completed_steps != 4 or len(owner.retained) != 1 or owner.retained[0]['step'] != 4:
        raise ValueError('first4 fixture did not complete exactly4/one read')
    row = owner.retained[0]
    actual = dict(step=4, particles=row['particles'].tolist(), target=row['target'].tolist(),
        critic_gradient=row['gradient'].tolist(), metrics=owner.observations[0])
    # JSON preserves every finite float32 value exactly; compare typed tensor bytes too.
    import torch
    retained = retained_saved[0]
    exact = all(row[name].numpy().tobytes() == torch.tensor(retained[key], dtype=torch.float32).numpy().tobytes()
        for name, key in (('particles', 'particles'), ('gradient', 'critic_gradient'), ('target', 'target')))
    if not exact or canonical(_numerical_row(actual)) != canonical(_numerical_row(retained)):
        raise ValueError('actual first4 numerical prefix differs from protected932')
    module.guard()
    return dict(status='PASS', cell_id=cell_id, software_fixture_updates=4,
        software_fixture_observations=1, external_cap=320, recipe_total_steps=None,
        equal=True, comparison_scope='three float32 ordered banks and original two metric values')


def run_cell(root, declaration, output):
    """One new CPU process, one fresh owner, full declared horizon, no early stop."""
    plan = validate_declaration(declaration)
    if source_pins(root) != declaration['source_pins']:
        raise ValueError('declaration/proof copied Source drift')
    output = Path(output)
    if output.exists() or output.resolve().parent != output.parent.resolve() or output.name in ('', '.', '..'):
        raise ValueError('a new owned output directory is required')
    output.mkdir(mode=0o700)
    _atomic(output / 'DECLARATION.json', declaration)
    import torch
    import numpy as np
    import random
    torch.set_num_threads(1)
    torch.manual_seed(0); np.random.seed(0); random.seed(0)
    started = time.monotonic()
    try:
        module = load_owner(root, plan['cell_id'])
        fresh = _Fresh(module, output)
        request = dict(candidate=module.candidate, task=module.task, protocol=module.protocol, binding=module.binding)
        result = module.run_first_case(root, request, source_guard=module.guard, fresh_repeat_guard=fresh)
        _export(module, result)
        result['applied'].update(initialization=fresh.initialization, factorial_plan=plan,
            factorial_binding=module.binding, diagnostic=True, scientific_credit=False)
        result['cost'] = dict(wall_seconds=time.monotonic() - started)
        _atomic(output / 'raw-result.json', result)
        grade = grade_result(root, plan['cell_id'], result)
        _atomic(output / 'grade.json', grade)
        if grade['status'] not in ('PASS', 'FAIL'):
            raise ValueError('complete independent original-gate certification required')
        _atomic(output / 'terminal.json', dict(schema='forge_atlas944_factorial_terminal_v1',
            status='COMPLETE', grade=grade['status'], attempt_id=declaration['attempt_id'], cell_id=plan['cell_id'],
            declaration_sha256=digest(declaration), source_digest=digest(declaration['source_pins']),
            binding_sha256=digest(module.binding), raw_result_pin=_pin((output / 'raw-result.json').read_bytes()),
            grade_pin=_pin((output / 'grade.json').read_bytes()), wall_seconds=time.monotonic() - started,
            scientific_credit=False))
        return result, grade
    except Exception as error:
        _atomic(output / 'ERROR.json', dict(status='ERROR', error_type=type(error).__name__,
            message=str(error), wall_seconds=time.monotonic() - started, attempt_id=declaration['attempt_id']))
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--declaration', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    run_cell(root, json.loads(Path(args.declaration).read_text()), Path(args.output))


if __name__ == '__main__':
    main()
