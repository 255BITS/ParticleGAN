"""Capture fidelity evidence without changing training or its random streams."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import torch

from .accuracy import PROTOCOL, evaluate_accuracy
from .accuracy_gate import HOLDOUT_N, HOLDOUT_SEED_OFFSETS
from .gate import MIN_STABLE_CHECKS
from .models import sample_evaluation
from .problems import sample_real


class AccuracyEvidence:
    def __init__(self, config: dict, output: Path, eval_steps: list[int], target):
        self.config = config
        # Forge receipts use named sampling laws; toy100 run configs use a
        # boolean switch. Preserve both schemas and reject undeclared laws.
        law = config.get("eval_output_noise", False)
        if type(law) is str and law in ("clean", "training_noise"):
            law = law == "training_noise"
        if type(law) is not bool:
            raise ValueError("eval_output_noise must be a boolean or a declared sampling law")
        self.eval_output_noise = law
        self.output = Path(output)
        self.check_steps = eval_steps[-MIN_STABLE_CHECKS:]
        self.target = target[:config["eval_samples"]].detach().cpu().numpy()
        self.pending: dict[int, dict[str, np.ndarray]] = {}
        (self.output / "quality_checks").mkdir(exist_ok=True)

    def observe(self, step: int, model: str, samples, coverage_metrics: dict) -> dict:
        values = samples[:self.config["eval_samples"]]
        accuracy = evaluate_accuracy(values, self.config["problem"], gate_metrics=coverage_metrics)
        if step in self.check_steps:
            models = self.pending.setdefault(step, {})
            models[model] = values.detach().cpu().numpy()
            if set(models) == {"live", "ema"}:
                np.savez_compressed(
                    self.output / "quality_checks" / f"step_{step:06d}.npz",
                    **models, target=self.target,
                )
                del self.pending[step]
        return accuracy

    def finish(self, trainer) -> tuple[dict, dict]:
        if self.pending:
            raise RuntimeError("incomplete terminal accuracy samples")
        config = self.config
        device = torch.device(config["device"])
        generator = lambda offset: torch.Generator(device=device).manual_seed(config["seed"] + offset)
        cuda_devices = [device.index if device.index is not None else torch.cuda.current_device()] if device.type == "cuda" else []
        arrays = {}
        metrics = {}
        with torch.random.fork_rng(devices=cuda_devices):
            torch.manual_seed(config["seed"] + HOLDOUT_SEED_OFFSETS["noise"])
            for model in ("live", "ema"):
                draws = sample_evaluation(
                    trainer, HOLDOUT_N, ema=model == "ema",
                    eval_output_noise=self.eval_output_noise,
                    generator=generator(HOLDOUT_SEED_OFFSETS["latent"]),
                )
                arrays[model] = draws.detach().cpu().numpy()
            arrays["target"] = sample_real(
                config["problem"], HOLDOUT_N, device=device,
                generator=generator(HOLDOUT_SEED_OFFSETS["target"]),
            ).detach().cpu().numpy()
            for model, points in arrays.items():
                metrics[model] = evaluate_accuracy(points, config["problem"])
        np.savez_compressed(self.output / "holdout_samples.npz", **arrays)
        metadata = {"protocol": PROTOCOL, "check_steps": self.check_steps,
                    "sample_count": config["eval_samples"], "holdout_samples": HOLDOUT_N,
                    "holdout_seed_offsets": HOLDOUT_SEED_OFFSETS}
        return metadata, metrics
