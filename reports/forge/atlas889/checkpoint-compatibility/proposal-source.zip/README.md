This is an uninstalled Source proposal. Author work is UNMEASURED; all seven
controls are AUTHORED_NOT_RUN. It grants no installation, Source amendment,
scientific retry, new candidate or budget. The original889 ERROR/INVALID case
and its full300 charge remain intact. No numerical result or grade was obtained.

The original strict owner hashes `complete_state()` before each scored read.
Its first scheduled checkpoint is update4. The passive recorder adds functions
as instance attributes on `SettleTest.observe` and
`OptimizerSurprise.group_q/decide`. Their original state serializers deepcopy
the entire instance dictionary. Consequently the owner sees a function-valued
state leaf and rejects it before the first measurement. The synthetic M11
graph comparator skipped functions and did not exercise this strict checkpoint.
The reported failure is consistent with the first update4 checkpoint; the
actual completed-update count is not inferred from a missing scored bank.

The proposed recorder wraps the already-existing `policy.state_dict` call.
Before any change, it verifies the identities of exactly the three installed
wrappers whose dictionaries are serialized. It exposes each original absent or
previous instance attribute, invokes the original getter once, and restores the
same wrapper objects in `finally`. A changed wrapper is left visible and marks
the diagnostic UNKNOWN. An unexpected write by the original getter is retained,
not overwritten. No arbitrary callable, state leaf or original exception is
discarded. The owner's strict typed digest, checkpoint, tensors, aliases, RNG,
measurement code, Recipe and original80/24 schedule remain unchanged. The owner
companion changes only its protected observer SHA/byte pin.

The original state getter can release/reapply served weights. Those existing
effects are retained, and the OFF/ON control compares them. The passive event
capture still adds no state getter. This wrapper intercepts an existing call;
it does not create another getter call or numerical operation.

Seven proposed ROOT-paid controls cover:

1. The old recorder's actual strict checkpoint failure before any measure.
2. Populated original CPU policy state through unchanged real
   `TwoPoleOwner.complete_state`, `state_sha256` and checkpoint4, with identical
   OFF/ON typed hashes, values, alias/version/RNG graph and original getter count.
3. Strict rejection of an unrelated callable leaf, with installed wrappers restored.
4. Original getter exception identity and exact hook restoration.
5. Original measurement exception identity and the owner reading flag cleanup.
6. A tampered hook remaining visible, rejected and marked UNKNOWN.
7. An unexpected original hook write remaining visible rather than silently restored.

The controls reuse the exact historical52f synthetic fixture and actual pinned
CPU core classes with populated moments. They hydrate the real owner's methods
with synthetic fields and extract only its original hashing definitions from
the pinned constructor Source. They do not invoke the scientific constructor,
original target or scored evaluator. They deliberately avoid `_spy`, whose
own controller method attributes would cause a separate serialization leak.
These controls supplement the original11; their result is not a request-bound
software proof, scientific admission or claim of full ambient purity.

ROOT may execute this command only inside an authorized paid software phase,
with a full-fitting bound and matching child timeout (for example30 seconds).
No command has been run by the Source author:

```sh
python /ml2/hypergan/pg-atlas889-checkpoint-compatibility-proposal-source-20261006/v1/tests/test_checkpoint_compatibility.py \
  --checkout /ml2/hypergan/ParticleGAN-atlas-original-two-pole-passive889-20261006 \
  --controls-json ROOT_PRIVATE/checkpoint-compatibility-controls.json
```

The external test is loaded from this sealed Source package and checks its own
module pins. `--checkout` supplies original pinned CPU dependencies and the
stored HostCritic Source. It does not install the two proposed modules. A future
scientific use would require explicitly authorized distinct candidate/Source/
revision/request, coherent protected maps, independent noninterference review,
actual full-checkpoint controls and a fresh full-request proof. It cannot reuse
the admitted889 proof or imply a corrected travel outcome.
