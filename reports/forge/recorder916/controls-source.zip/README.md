This is the Source-only Ember916 software-control selection kit. Author work is
UNMEASURED and all18 controls are AUTHORED_NOT_RUN. ROOT alone applies the exact
previously reviewed observer/owner pair in its owned isolated checkout and runs
the controls inside the separately authorized finite120 software/setup/reporting
window. There is no scientific admission, retry, old request/proof rebind, core
change, default change or merge in this kit. The sealed889 INVALID/full300 case
and its local amendment/error history remain intact.

The two reviewed subject copies are unchanged:

- `subjects/experiments/forge/atlas889_two_pole_observer.py`: SHA256
  `0c2070cbaa5da9f056ded548b629165ace50746472aa45e0dc8abd20a4e2a646`, 23311 bytes.
- `subjects/experiments/forge/atlas889_two_pole_owner.py`: SHA256
  `fa49bc9705f7caecf8cd63314fa1328ad64f4c13cc008573073056c15f9d0d50`, 58663 bytes.

Their checkpoint-compatibility review remains the e35e kit's independent review
`26ff22ca72cfe41a5d94adf8b12323a3fa9e548ae7b940f078b6867fc835061a`.
This kit changes only how software controls select those installed subjects.

The original11 test remains byte-identical52f82/29610, including every method,
fixture, cache-mutation negative and assertion. It has no obsolete observer hash
or `_subject` helper. Its existing `setUpClass` already loads the recorder from
the checkout. `run_original11.py` adds an external `_subject` pin check for the
installed observer, owner, unchanged contract and unchanged original test. It
then invokes that original test's main function and retains its reporter and
exit behavior. Its origin check requires the original test's own ROOT to equal
`--checkout`. No fixture namespace, assertion or test method is rewritten.

The seven checkpoint controls retain every method/helper/assertion and their
reviewed subject hashes. Only `_load` selects the two positive `repo/` subjects
from `--checkout`. The old7037 recorder is loaded exclusively from the sealed
preimage for the deliberate failure negative. The old52f fixture also stays in
the Source kit; it verifies actual original CPU dependencies in `--checkout`.
No historical subject supplies the positive checkpoint result.

ROOT must apply only the two approved subject modules and retain the original
test52f in its checkout before running the following commands. These are manual
entrypoints, to be called inside active paid phases with full-fitting bounds and
matching process timeouts. Actual time and results are ROOT-supplied, not inferred
by this Source author. Use one fresh CPU process for each command:

```sh
python /ABS/KIT/run_original11.py \
  --checkout /ABS/OWNED_CHECKOUT \
  --controls-json /ABS/PRIVATE/original11-repaired-subject-controls.json

python /ABS/KIT/tests/test_checkpoint_compatibility.py \
  --checkout /ABS/OWNED_CHECKOUT \
  --controls-json /ABS/PRIVATE/installed-checkpoint7-controls.json
```

Here `/ABS/KIT` is this package's extracted root. Its relative layout and frozen
preimages must remain intact. Both commands verify exact Source hashes before
loading subjects. The original11 reporter is unchanged. The separate seven
reporter remains a software result, not an admission proof. Its JSON writer
appends a real newline. ROOT should retain both genuine outputs and all errors.

The primary checkpoint assertion remains the unchanged strict full-state digest
and the owner's real measurement boundary. The synthetic graph comparison adds
live numeric/alias/version/RNG coverage but skips callables; it cannot replace
the strict callable negatives or prove aliases within returned checkpoint
copies, full ambient closure purity, a scientific result, or travel recovery.
No proposal file or external control belongs to the old admitted Source/proof
merely because it appears in this handoff.
