"""ROOT-paid pin-only selection of unchanged original11 controls.

Source author status AUTHORED_NOT_RUN. No installation or scientific admission.
Run this caller only inside ROOT's authorized bounded software phase.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
from pathlib import Path
import sys

SUBJECT_PINS = {
    'experiments/forge/atlas889_two_pole_observer.py':
        ('0c2070cbaa5da9f056ded548b629165ace50746472aa45e0dc8abd20a4e2a646', 23311),
    'experiments/forge/atlas889_two_pole_owner.py':
        ('fa49bc9705f7caecf8cd63314fa1328ad64f4c13cc008573073056c15f9d0d50', 58663),
    'experiments/forge/atlas889_contract.py':
        ('e4850919918d913600dce641f1c1e421c4e1fe483a4dedac74a520c03458043d', 5520),
    'tests/test_atlas889_two_pole_observer.py':
        ('52f82b6b0bd5bc313ee341466463cee415d61e9804658dfc554280931d144145', 29610),
}


def _subject(checkout):
    for relative, expected in SUBJECT_PINS.items():
        path = checkout / relative
        if path.resolve() != path:
            raise ValueError('foreign installed control Source alias: ' + relative)
        raw = path.read_bytes()
        if (hashlib.sha256(raw).hexdigest(), len(raw)) != expected:
            raise ValueError('installed control Source drift: ' + relative)
    return checkout / 'tests/test_atlas889_two_pole_observer.py'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkout', type=Path, required=True)
    parser.add_argument('--controls-json', type=Path, required=True)
    args = parser.parse_args()
    checkout = args.checkout.resolve()
    path = _subject(checkout)
    sys.path.insert(0, str(checkout))
    name = '_atlas916_unchanged_original11_controls'
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    if module.ROOT != checkout:
        raise ValueError('original11 control checkout origin mismatch')
    argv = sys.argv
    try:
        sys.argv = [str(path), '--controls-json', str(args.controls_json)]
        # Preserve the original test runner, M11 reporter and exit behavior.
        module.main()
    finally:
        sys.argv = argv


if __name__ == '__main__':
    main()
