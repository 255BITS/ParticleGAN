"""Proposed ROOT-paid controls; author status AUTHORED_NOT_RUN.

These synthetic controls execute the unchanged real owner checkpoint and strict
digest. They do not run the original target, evaluator or scientific initializer.
The older M11 call graph is retained separately and remains necessary.
"""
from __future__ import annotations

import argparse
import ast
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import unittest

PROPOSAL = Path(__file__).resolve().parents[1]
CHECKOUT = None
PINS = {
    'preimages/tests/test_atlas889_two_pole_observer.py':
        ('52f82b6b0bd5bc313ee341466463cee415d61e9804658dfc554280931d144145', 29610),
    'preimages/experiments/forge/atlas889_two_pole_observer.py':
        ('7037d2aecd8e6305fb25adeb753ceeff679bd1e27ef45e4171c9d9daca31c0db', 21116),
    'repo/experiments/forge/atlas889_two_pole_observer.py':
        ('0c2070cbaa5da9f056ded548b629165ace50746472aa45e0dc8abd20a4e2a646', 23311),
    'repo/experiments/forge/atlas889_two_pole_owner.py':
        ('fa49bc9705f7caecf8cd63314fa1328ad64f4c13cc008573073056c15f9d0d50', 58663),
}


def _load(relative, name):
    # Positive subjects are the exact installed Source in --checkout.
    # Historical fixture/negative preimages remain in this sealed Source kit.
    path = (CHECKOUT / relative.removeprefix('repo/')) if relative.startswith(
        'repo/experiments/forge/') else PROPOSAL / relative
    raw = path.read_bytes()
    if path.resolve() != path or (hashlib.sha256(raw).hexdigest(), len(raw)) != PINS[relative]:
        raise ValueError('foreign control Source: ' + relative)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class CheckpointControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if CHECKOUT is None:
            raise ValueError('ROOT must pass the exact original-core --checkout')
        import torch
        torch.set_num_threads(1)
        cls.fixture = _load('preimages/tests/test_atlas889_two_pole_observer.py',
                            '_atlas889_checkpoint_fixture')
        cls.fixture.ROOT = CHECKOUT
        cls.old_observer = _load('preimages/experiments/forge/atlas889_two_pole_observer.py',
                                 '_atlas889_checkpoint_original_observer')
        cls.observer = _load('repo/experiments/forge/atlas889_two_pole_observer.py',
                             '_atlas889_checkpoint_proposed_observer')
        cls.owner_module = _load('repo/experiments/forge/atlas889_two_pole_owner.py',
                                 '_atlas889_checkpoint_original_owner_methods')

    def _owner(self):
        fixture = self.fixture._fixture()  # Populated actual original CPU classes.
        owner = self.owner_module.TwoPoleOwner()
        vars(owner).update(vars(fixture))
        owner.binding = {'schema': 'INERT_SYNTHETIC_CHECKPOINT_CONTROL',
                         'recipe': deepcopy(self.fixture.RECIPE)}
        owner.observations, owner.purity, owner.retained = [], [], []
        owner.noisy_observations, owner._reading_step = [], None
        # Execute only the two exact original hashing definitions, extracted
        # from construct_owner. No constructor, initializer or source admission
        # is substituted, invoked or certified by this synthetic fixture.
        source = Path(self.owner_module.__file__).read_text()
        constructor = next(n for n in ast.parse(source).body
                           if isinstance(n, ast.FunctionDef) and n.name == 'construct_owner')
        nodes = []
        for node in constructor.body:
            if isinstance(node, ast.FunctionDef) and node.name == 'tensor_bytes':
                nodes.append(node)
            elif isinstance(node, ast.Assign) and len(node.targets) == 1:
                target = node.targets[0]
                if (isinstance(target, ast.Attribute) and isinstance(target.value, ast.Name)
                        and target.value.id == 'owner' and target.attr in ('tensor_bytes', 'global_sha256')):
                    nodes.append(node)
        if len(nodes) != 3:
            raise ValueError('original owner hashing definition drift')
        import numpy as np
        import random
        namespace = dict(owner=owner, torch=owner.torch, np=np, random=random,
                         typed_digest=self.owner_module.typed_digest)
        exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])),
                     '<exact-original-owner-hashing-only>', 'exec'), namespace)
        return owner

    def _advance_four(self, owner):
        counts = {'backwards': 0}
        # No _spy: its function-valued controller attributes would themselves
        # contaminate the original vars-based checkpoint dictionaries.
        for _ in range(4):
            self.fixture._synthetic_update(owner, counts)
        self.assertEqual(owner.policy.completed_steps, 4)
        self.assertEqual(owner.policy._phase, 'ready')
        self.assertEqual(counts['backwards'], 8)

    def _hooks(self, recorder):
        return tuple((attributes, name, attributes[name])
                     for attributes, name, previous, wrapped in recorder.serialized_hooks)

    def _assert_hooks(self, saved):
        for attributes, name, wrapped in saved:
            self.assertIs(attributes[name], wrapped)

    def test_original_failure_precedes_first_measure(self):
        owner = self._owner()
        recorder = self.old_observer.PassiveTwoPoleRecorder(owner).install()
        self._advance_four(owner)
        measured = []
        try:
            with self.assertRaisesRegex(TypeError, '^unknown policy state leaf: function$'):
                owner.checkpoint(4, lambda: measured.append(True))
            self.assertEqual(measured, [])
            self.assertEqual(owner.observations, [])
            self.assertEqual(owner.purity, [])
            self.assertIsNone(owner._reading_step)
        finally:
            recorder.uninstall()

    def test_populated_complete_state_digest_and_real_checkpoint_off_on(self):
        def arm(enabled):
            owner = self._owner()
            getter_count = [0]
            original_getter = owner.policy.state_dict
            # This explicit-key policy serializer does not serialize its own
            # instance methods; do not spy on SettleTest or OptimizerSurprise.
            def counted_getter(*args, **kwargs):
                getter_count[0] += 1
                return original_getter(*args, **kwargs)
            owner.policy.state_dict = counted_getter
            recorder = self.observer.PassiveTwoPoleRecorder(owner).install() if enabled else None
            try:
                self._advance_four(owner)
                saved = self._hooks(recorder) if recorder is not None else ()
                complete = owner.complete_state()
                complete_digest = self.owner_module.typed_digest(complete, owner.tensor_bytes)
                state_digest = owner.state_sha256()
                self.assertEqual(complete_digest, state_digest)
                getter_before = getter_count[0]
                measured = []
                values = {'mean_abs': .125, 'grad_med': .5}
                def measure():
                    measured.append(owner.policy.completed_steps)
                    self.assertEqual(owner._reading_step, 4)
                    self._assert_hooks(saved)
                    return values
                owner.checkpoint(4, measure)
                self.assertEqual(getter_count[0] - getter_before, 2)
                self.assertEqual(measured, [4])
                self.assertEqual(owner.observations, [dict(values, step=4)])
                self.assertTrue(owner.purity[0]['pure'])
                self.assertEqual(owner.purity[0]['before_sha256'], owner.purity[0]['after_sha256'])
                self._assert_hooks(saved)
                if recorder is not None:
                    self.assertEqual(recorder.unknown, [])
                    self.assertEqual(recorder.scope_unknown, [])
                    self.assertEqual(recorder.purity_failures, 0)
                return (complete_digest, state_digest, self.fixture._snapshot(owner),
                        owner.observations, owner.purity, getter_count[0])
            finally:
                if recorder is not None:
                    recorder.uninstall()
        self.assertEqual(arm(False), arm(True))

    def test_unrelated_callable_state_still_rejected(self):
        owner = self._owner()
        recorder = self.observer.PassiveTwoPoleRecorder(owner).install()
        self._advance_four(owner)
        saved = self._hooks(recorder)
        alien = lambda: None
        owner.policy.surprise.unrelated_state = alien
        measured = []
        try:
            with self.assertRaisesRegex(TypeError, '^unknown policy state leaf: function$'):
                owner.checkpoint(4, lambda: measured.append(True))
            self.assertEqual(measured, [])
            self.assertIs(owner.policy.surprise.unrelated_state, alien)
            self._assert_hooks(saved)
        finally:
            del owner.policy.surprise.unrelated_state
            recorder.uninstall()

    def test_original_getter_exception_identity_and_wrapper_restoration(self):
        owner = self._owner()
        error = RuntimeError('INERT original getter exception')
        calls = []
        def raises(*args, **kwargs):
            calls.append(True)
            raise error
        owner.policy.state_dict = raises
        recorder = self.observer.PassiveTwoPoleRecorder(owner).install()
        saved = self._hooks(recorder)
        try:
            with self.assertRaises(RuntimeError) as raised:
                owner.complete_state()
            self.assertIs(raised.exception, error)
            self.assertEqual(calls, [True])
            self._assert_hooks(saved)
        finally:
            recorder.uninstall()
        self.assertIs(owner.policy.state_dict, raises)

    def test_measure_exception_keeps_original_owner_behavior(self):
        owner = self._owner()
        recorder = self.observer.PassiveTwoPoleRecorder(owner).install()
        self._advance_four(owner)
        saved = self._hooks(recorder)
        error = RuntimeError('INERT original measure exception')
        def raises():
            raise error
        try:
            with self.assertRaises(RuntimeError) as raised:
                owner.checkpoint(4, raises)
            self.assertIs(raised.exception, error)
            self.assertIsNone(owner._reading_step)
            self.assertEqual(owner.observations, [])
            self.assertEqual(owner.purity, [])
            self._assert_hooks(saved)
        finally:
            recorder.uninstall()

    def test_prevalidation_does_not_hide_changed_hook(self):
        owner = self._owner()
        recorder = self.observer.PassiveTwoPoleRecorder(owner).install()
        self._advance_four(owner)
        saved = self._hooks(recorder)
        attributes, name, wrapped = saved[0]
        alien = lambda: None
        attributes[name] = alien
        try:
            with self.assertRaisesRegex(TypeError, '^unknown policy state leaf: function$'):
                owner.state_sha256()
            self.assertIs(attributes[name], alien)
            self._assert_hooks(saved[1:])
            self.assertTrue(any('checkpoint hook identity mismatch' in item for item in recorder.unknown))
        finally:
            attributes[name] = wrapped  # Synthetic negative's own restoration.
            recorder.uninstall()

    def test_unexpected_original_hook_write_is_not_overwritten(self):
        owner = self._owner()
        original_getter = owner.policy.state_dict
        tester = owner.policy.lr_settle.testers[0][0]
        alien = lambda: None
        def writes(*args, **kwargs):
            value = original_getter(*args, **kwargs)
            tester.observe = alien
            return value
        owner.policy.state_dict = writes
        recorder = self.observer.PassiveTwoPoleRecorder(owner).install()
        saved = self._hooks(recorder)
        try:
            owner.complete_state()
            self.assertIs(tester.observe, alien)
            self._assert_hooks(saved[1:])
            self.assertTrue(any('checkpoint hook changed during original getter' in item
                                for item in recorder.unknown))
        finally:
            saved[0][0][saved[0][1]] = saved[0][2]
            recorder.uninstall()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkout', type=Path, required=True)
    parser.add_argument('--controls-json', type=Path, required=True)
    args = parser.parse_args()
    global CHECKOUT
    CHECKOUT = args.checkout.resolve()
    sys.path.insert(0, str(CHECKOUT))
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(CheckpointControls)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    output = dict(schema='forge_atlas889_checkpoint_compatibility_controls_v1',
                  status='PASS' if result.wasSuccessful() and result.testsRun == 7 else 'FAIL',
                  tests_run=result.testsRun, errors=len(result.errors), failures=len(result.failures),
                  software_only=True, original_target_run=False,
                  fresh_scientific_admission=False)
    # ROOT alone runs this writer inside a paid, bounded software phase.
    args.controls_json.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    raise SystemExit(0 if output['status'] == 'PASS' else 1)


if __name__ == '__main__':
    main()
