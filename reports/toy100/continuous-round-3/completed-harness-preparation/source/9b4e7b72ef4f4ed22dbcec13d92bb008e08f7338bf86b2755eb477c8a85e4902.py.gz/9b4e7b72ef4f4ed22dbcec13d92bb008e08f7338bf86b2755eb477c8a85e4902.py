"""Harness checks for the continuous qualification evaluator.

These tests do not qualify a candidate. The CUDA host smoke is a separate command.
"""

from benchmarks.toy100.continuous_qualification import run_self_tests


def test_continuous_qualification_harness():
    rows = run_self_tests()
    failed = [row for row in rows if row["status"] != "PASS"]
    assert not failed, failed
    assert [row["gate"] for row in rows] == [
        "protocol_windows",
        "absolute_versus_incremental",
        "event_ordering",
        "rng_preservation",
        "update_accounting",
        "witness_identity",
        "fail_closed_provenance",
        "schedule_horizon",
        "prefix_scoring",
    ]
