# Search direction: continuous learning from K3P

Start from the exact selected K3P bundle in current-research-base.json. Preserve
it as the measured parent: 22/22 declared GPU toys, ring hold 1200/1200 and
extension 300/300, but target-shift recovery only 28/81 deadline checks. Every
modified formulation earns its own scores. This brief configures a search;
the invocation of the launcher supplies its time/proposal/worker budgets.

Research loop: solve the failing problem, verify promising candidates against
their own frozen gates, then promote only a fully verified winner before using
it as the next shared search base. Partial recovery scores or successful hold
alone do not authorize changing the base. Keep independent search lanes on the
last verified formulation; unverified leads can receive separate qualification.

## The question

Can K3P retain precision and stability while remaining responsive to new data,
without knowing the training horizon or defining a one-way "late training"
phase? The desired direction is a reversible controller driven by training
signals. Constant-rate learning is a useful control, not a requirement. Neither
is established by the parent. Search time limits bound research compute; they
must not become inputs to the learned formulation's schedule.

K3P never deliberately freezes on convergence. Its selected floors leave G/D
rates at 1% of their initial rates and the prior at 5%. The EMA critic and Adam
updates continue. Its handover is nevertheless schedule-dependent: the mixing
weight reads the critic's last applied LR divided by its maximum observed LR.
It stays entirely on the early penalty until that ratio falls below 0.5, then
reaches capped gradients plus the EMA anchor at ratio 0.01. The native network
schedule has a 1600-update horizon cap; prior/noise schedules also use a horizon.

**Do not merely set learning-rate floors to one:** with the existing handover,
constant critic LR keeps the ratio at one, the mixing weight at one, and the
EMA gradient anchor inactive. A constant-rate candidate must explicitly state
how it decouples the critic constraint from that LR clock.

The current recovery failure does not identify a sole cause. Step size, critic
anchoring and their interaction are hypotheses to test, not established facts.
EMA decay and guard-estimator warmup are memory/estimation choices; they are
different from a rule that must know the final training step to become stable.

## Candidate requirements

- Retain the K3P lineage, learned particle prior, direct response and bounded
  sparse-latent rule unless the assigned lane explicitly declares a change.
  Start from copied, hashed candidate files; never edit the pinned parent.
- A continuous-policy candidate must not read the total training budget,
  evaluation scores, convergence detection, target identities, shift times or
  known target centers. No timed restart/reset at the test's target change.
  Rates or damping may respond reversibly to ordinary training/optimizer
  signals. Audit actual applied rates and critic mixing weights.
  Check that changing the declared training horizon leaves an otherwise
  identical training prefix unchanged; report every remaining budget dependency.
- Declare every LR, penalty, anchor, guard and noise rule. Horizon-dependent
  noise left from K3P is still a scheduled component: retain it only as a
  labeled intermediate ablation, not as a horizon-independent final result.
- Keep architecture, data, existing seeds, optimizer-step budgets, auxiliary
  host losses and canonical quality thresholds fixed. No seed sweeps or
  coefficient grids. Compare equal-step and added-compute costs honestly.
- Keep all training and history tensors CUDA FP32 in the qualified deterministic
  environment. Each attempt owns its output directories, source copies and logs.
  Use the existing frozen runtime and fixtures from the gap-fill manifest.

## Gate order and evidence

1. Run the candidate's own standard hold with its 300-update extension **and**
   the target-shift recovery test. Use the existing drivers and fixed verdicts;
   record both outcomes even if one fails. A passing recovery needs its own
   matched frozen control. The driver returns UNCONFIRMED when all live quality
   windows pass; immediately run the control to confirm it, rather than waiting
   for a raw PASS that the live driver cannot produce on its own. Audit optimizer updates and actual rates after the
   shift so stationary output cannot masquerade as active adaptation.
2. Screen the sensitive transfer problems: mode_hold, unequal mass, unequal
   width and stripes. Only survivors advance through their own full 22 gates,
   including full 7000-update coverage AND accuracy for all three natives.
   Reuse parent evidence for comparison, never as a modified candidate's pass.
3. For survivors, run a separately declared long-hold/delayed-change stress
   check and a second target change in the same uninterrupted state. Freeze the
   protocol before observing results; keep canonical scores separate. The
   learner cannot read the stress test's change times. Repeated timely recovery
   is stronger evidence than one successful target shift, but is still a finite
   test rather than a claim of indefinite learning.

Use the existing hold/shift drivers first, not a replacement benchmark platform.
Additional stress checks may extend them locally without altering the canonical
tasks or thresholds. Do not cherry-pick cycle troughs or move the recovery
deadline. Keep model, optimizer, critic EMA, response/latent history and RNG
continuous; fresh-process restart equivalence is not yet qualified for K3P.

Rank results by **hold + extension + timely recovery**, then retained toy passes.
Report worst HQ, passing/failing checks, recovery delay, repeated-change results,
rate/mixing traces and added critic evaluations. Keep FAIL/ERROR/NOT_RUN visible
and distinguish diagnostic screens from qualification. A higher LR alone is not
a successful formulation if it trades stability or precision for faster motion.

Current allocation: one Codex and seven Grok attempts, no Claude. This supersedes
the historical first and second rounds' three Codex/five Grok launch mix. Each owns
a distinct lane and isolated checkout, with at most four workers per GPU. Use
reports/toy100/continuous-round-3/launch.py, which enforces live capacity.
Attempt defaults: at most three mechanism proposals per lane, 45 minutes
and one benchmark worker per lane; explicit invocation budgets override the
time/proposal defaults. No nested agents, seed repeats,
pushes or comments from attempts. Those are caps, not quotas. Start candidate
training promptly, adapt from measured failures, and preserve a final leaderboard.
The selected parent has already been measured; do not spend the round rerunning
unchanged baselines. A useful negative result should identify the failed gate
and narrow the next mechanism choice.

Latest user completion rule: a winner must also earn **4/4 seeds on each of
three 100-Gaussian layouts**: grid100, rotated100 and staggered100, seeds1234–1237.
That is12 full7000-update runs, coverage AND accuracy. The22-toy matrix contains
seed1234 for each layout; the other9 runs are additional winner qualification.
This is an explicitly requested fixed matrix, not permission for seed search or
tuning. Require the declared30000-update long-term continuation in addition to
canonical and delayed/repeated tests. Once the same exact formulation passes
everything, stop the remaining search jobs and promote it in PR155. Until then
keep searching and verifying; do not promote a partial lead or merge the PR
automatically.


# Rolling search with reduced Codex usage

The user reduced concurrent search to **1 Codex + 7 Grok**, replacing the previous
3+5 allocation. Keep at most eight one-worker attempts, four per physical GPU.
No Claude or nested agents. The launcher reserves capacity across all live batches
and launches explicitly selected lanes as earlier attempts finish. Use this
launcher for future launches; old round launchers describe historical allocations.

K3P is still the selected shared base. A3 verification finished **4/22 PASS**;
all three 7000-update natives fail coverage and accuracy. A3 cannot be promoted.
The loop stays: solve the failing toy, verify promising winners on all gates,
then continue from a winner only after complete verification.

Read measured reports and the research notes before proposing a mechanism. Paper
results motivate hypotheses; they do not qualify this GAN. AP3's 1200+300 hold,
120/120 pre-hold and 72/81 recovery are a partial lead, not a verified base. Its
inherited noise still uses a horizon, and its forced reopen dwell loses precision.
No known change times, quality feedback, target centers or task-specific rules.

Run BOTH canonical hold+300 extension and shift for every meaningful proposal.
Do not spend the next proposal's budget before saving both results, even when
one fails. Three proposals is a cap, not a quota. Ledger each completed protocol
immediately in the attempt's tests.jsonl; all incomplete work stays NOT_RUN/ERROR.

A prospective winner needs own hold1200/1200 and extension300/300, all stationary
and continued-hold checks, and recovery81/81. The live driver returns UNCONFIRMED
when these pass: run its matched frozen control immediately to confirm PASS.
Preserve full provenance needed by match_frozen_control rather than dropping
fields in a result wrapper. Require identical pre-shift state and frozen0/81.
Then verify sensitive gates and all22, including original native budgets,
coverage AND accuracy. The same frozen formulation must earn every pass.

An explicitly assigned verification-only lane may screen an unchanged promising
partial lead before full shift success, to avoid spending further search on a
formulation that loses transfer gates. That diagnostic exception does not weaken
qualification, authorize promotion, or inherit any missing passes.

Audit substantial identical prefixes under differing declared horizons, including
model, optimizer, controller, EMA, RNG, applied rates/noise. A successful survivor
also needs separately declared late and repeated shifts on uninterrupted state.
Do not weaken canonical gates, borrow another candidate's scores, repeat seeds,
or run coefficient grids. Leave exact frozen sources and commands for unfinished
verification. Supervisor alone can promote after auditing all evidence.

The user's latest promotion bar additionally requires **4/4 seeds for each of
all three native layouts** (grid100, rotated100, staggered100), seeds1234–1237.
All12 runs must pass full7000-update coverage AND accuracy. Three seed1234 runs
are already in the22; the remaining9 are additional winner qualification explicitly
requested by the user, not exploratory seed experiments. Long-term qualification
uses long-term-stability-protocol.json: same uninterrupted state through30000,
including the original9000 stress windows and another late target change. Stop
all remaining searches and promote in PR155 only after the complete conjunction
passes. Do not stop or promote merely on81/81 recovery or partial toy gates.

Assigned lane:
Verification-tool work only;
do not propose a new learner or run full rejected-candidate qualification. The
ordinary match_frozen_control helper compares quality curves but accepts missing
matching fields and does not establish complete pre-shift learner identity.
RP1's original companion omitted some latent/response/controller state. Prepare
a strict canonical matched-control companion around the ACTUAL unchanged
candidate driver, retaining its hooks, fixture, frozen runtime, sampling and
update order. Reuse the existing short-prefix capture machinery where helpful:
/ml2/hypergan/gan-attempts/formulations-20260925T173446Z/k3p_extragradient/20260925T173446Z-3726843/repo/reports/toy100/rp1-independent-audit/audit_prefix.py
and main rp1-additional-evidence contains the flawed earlier frozen captures.
Require actual canonical windows (5 stationary,120 prehold,81 deadline), matching
nonmissing source/config/runtime/fixture metadata, live quality and frozen0/81.
Capture model parameters AND buffers, all optimizer state (including anchor_prev,
scalar step representation) and group settings, all EMAs, controller/helper
learner state, latent.stats, response membership/history, and CPU/CUDA/host RNG.
Normalize identities structurally; missing==missing is never complete proof.
Use an explicitly audited candidate-state contract; mark unknown helper state
unsupported rather than claiming generic completeness from a shallow _state dict.
Source-pin every imported local policy file. Preserve raw legacy results; a
strict companion may remain INCOMPLETE while the legacy helper says PASS.
Prove only SHORT deterministic actual-driver identity with instrumentation on/off,
plus negative checks for missing state/source metadata, changed latent history,
optimizer groups, and truncated canonical windows. No full RP1 replay, native
seed run,9000 or30000 episode. This is harness validation, never candidate PASS.
A Grok independently repairs the long-run evaluator in another worktree; do not
edit its files or duplicate its bootstrap rewrite. Own this separate canonical
companion and concise tests/report. Publish exact limitations and replay commands
for supervisor review. One benchmark worker, one scarce Codex slot, no nested
agents. Work in your isolated checkout; do not push or edit PR155.

Read-only evidence: reports/toy100/continuous-round-1/README.md;
reports/toy100/continuous-round-2/README.md and attempts/LANE/result.md;
reports/toy100/continuous-search-tools/research-notes.md;
/ml2/hypergan/gan-attempts/formulations-20260925T165310Z/.
Pinned source/runtime/fixtures: reports/toy100/gap-fill-20260925/manifest.json.
Do not modify previous attempts. Keep canonical results in this attempt/tests.jsonl.

Runtime instructions for this fresh, independent attempt:
- Read AGENTS.md. Work only in /ml2/hypergan/gan-attempts/formulations-20260925T190502Z/audit_canonical_control/20260925T190502Z-3834938/repo; do not modify other checkouts.
- Assigned focus: audit_canonical_control
- Time budget: 45 minutes, hard stop approximately 2026-09-25 19:50:02 UTC.
- Candidate budget: at most 1 distinct proposals; at most 1 parallel GPU
  benchmark workers, one CPU thread each. These are workers, not extra agents.
- Benchmark Python: /tmp/pr38-default-env/bin/python; physical GPU GPU-cb4ce47d-d968-bffd-5646-e830a9fa1c69 is visible as cuda:0.
  CUDA_VISIBLE_DEVICES=GPU-cb4ce47d-d968-bffd-5646-e830a9fa1c69, CUBLAS_WORKSPACE_CONFIG=:4096:8, one CPU thread.
  Use FP32, deterministic algorithms and TF32 off as in the committed CUDA controls.
  CPU initialization is allowed; model training, gradients and optimizer state must be CUDA.
  Explicitly set CUDA_VISIBLE_DEVICES=GPU-cb4ce47d-d968-bffd-5646-e830a9fa1c69 and the above thread/determinism variables
  on benchmark subprocesses; do not assume the agent tool server inherited them.
- No nested agents or extra agent sessions (Codex, Claude or Grok), detached jobs,
  GitHub pushes or comments. You are the only agent on this attempt.
- Write concise progress and /ml2/hypergan/gan-attempts/formulations-20260925T190502Z/audit_canonical_control/20260925T190502Z-3834938/result.md with exact code/artifact paths,
  measured results, test totals, replay commands and remaining failures.
- Append each executed gate to /ml2/hypergan/gan-attempts/formulations-20260925T190502Z/audit_canonical_control/20260925T190502Z-3834938/tests.jsonl using candidate, gate,
  status (PASS/FAIL/ERROR/SKIPPED), seconds, metrics and artifact fields. Label
  warm-screen success as PASS on a clearly named warm_probe gate; it does not
  qualify cold acquisition or own-state stability. Record regression tests as
  candidate=regression. Do not count setup metadata as executed candidates.
- Before EACH experiment batch, read /ml2/hypergan/gan-attempts/formulations-20260925T190502Z/audit_canonical_control/20260925T190502Z-3834938/supervisor.md if it exists.
  This is the user's local supervisor steering the task. Follow its latest
  priorities; if it says STOP, save results and stop promptly.
- Fixed seeds, no seed sweeps. No metric weakening or frozen host/budget edits.
  Start from the selected research formulation, keeping its declared decay and auxiliary
  AE/token host losses. A focused formulation brief may authorize declared changes
  to adversarial losses, critic regularizers or optimizers. Do not introduce a
  non-GAN target fitter or metric feedback.
  The focused brief governs declared changes to schedules/noise and supersedes
  historical porting or constant-rate-only constraints.
- Start a real candidate test within five minutes. Candidate counts are caps, not quotas.
  Gate on measured failures before broad tests. Keep commands and logs easy to inspect.
