"""Scoped ring-host evaluator for the declared continuous protocols.

The frozen host in ``benchmarks.toy100.continuous_probe`` still owns the
canonical one-shift run. This module only adds evaluator instrumentation:
absolute target offsets, the declared windows, optimizer accounting, and a
pre-shift witness. It does not change the host gradient or optimizer step.

Episode length is not a schedule input. Noise and the host controller keep
the canonical 1,200-update horizon. A candidate config may still carry its
own ``network_lr_horizon_cap``; that value is passed through unchanged and
cannot see the stress or 30,000-update length.

Smoke output is harness validation. It is not a candidate qualification.

A candidate run selects the K3P frozen runtime from the gap-fill manifest,
checks every pinned hash, loads the pinned initialization fixture, and calls
``latent.begin/end`` and ``response.begin/end`` around Adam in that order.
Episode length remains outside the learned schedule. Passing this harness does
not qualify a candidate: the 9,000-update and 30,000-update protocols stay
unrun until a later lane executes them.
"""

from __future__ import annotations

import argparse
from contextlib import ExitStack, contextmanager
from copy import deepcopy
import hashlib
import importlib
import inspect
import json
import math
import os
from pathlib import Path
import sys
import time
import traceback
from types import SimpleNamespace

import torch


ROOT = Path(__file__).resolve().parents[2]
PROTOCOL_DIR = ROOT / "reports/toy100/continuous-round-3"
FROZEN_HORIZON = 1200
PINS = {
    "stress": (
        PROTOCOL_DIR / "stress-protocol.json",
        "e5cb3e7cbb48943ab33fcf1cba0d3943f7f65ef40b5843d7d6734d91b76cd798",
    ),
    "long-term": (
        PROTOCOL_DIR / "long-term-stability-protocol.json",
        "8c5f2e27c0e0f9b93b7a1f1a36ff09f1c5fb0d7bc398f6fc520d0a7e8d9dc9fe",
    ),
}
CANDIDATE_FILES = ("config.json", "mechanism.py", "response.py", "latent.py")
WITNESS_SECTIONS = (
    "model", "adam", "ema", "controller", "latent_stats",
    "response", "rng", "target_before_shift",
)
FORBIDDEN_LEARNER_KEYS = frozenset({
    "absolute_offset", "after_update", "deadline_checks", "deadline_updates",
    "live_modes", "min_live_hq", "quality_at_every_required_check",
    "target_center", "target_changes", "total_updates",
})
HOST_FILES = (
    "benchmarks/toy100/continuous_probe.py",
    "benchmarks/locked_shared/mode_hold.py",
    "benchmarks/locked_shared/baseline.py",
    "benchmarks/locked_shared/observation.py",
    "benchmarks/transfer_suite/compare_defaults.py",
    "benchmarks/transfer_suite/legacy_noise_adapters.py",
    "benchmarks/toy100/schedule.py",
)


class QualificationError(RuntimeError):
    """The evaluator refused to start or to treat evidence as complete."""


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def digest_tensor(tensor: torch.Tensor) -> str:
    """Hash raw tensor bytes. Flatten first so a 0-dim Adam step can change dtype.

    ``view(torch.uint8)`` on a 0-dim float rejects the dtype change because a
    scalar has no dimension to expand. Optimizer state stores ``step`` that way.
    """
    flat = tensor.detach().reshape(-1).contiguous()
    raw = flat.view(torch.uint8).cpu().numpy().tobytes()
    return sha256_bytes(raw)


def source_hashes() -> dict:
    files = ("benchmarks/toy100/continuous_qualification.py",) + HOST_FILES
    return {name: sha256_file(ROOT / name) for name in files}


def schedule_binding(config: dict, episode_length: int) -> dict:
    """Return the horizons the host controller and noise policy actually receive.

    ``episode_length`` is accepted so callers can show it is ignored.
    """
    if type(episode_length) is not int or episode_length <= 0:
        raise QualificationError("episode_length must be a positive integer")
    cap = config.get("network_lr_horizon_cap")
    return {
        "episode_length_is_schedule_input": False,
        "episode_length": episode_length,
        "controller_total_steps": FROZEN_HORIZON,
        "noise_horizon": FROZEN_HORIZON,
        "network_lr_horizon_cap": cap,
        "config_total_steps": config.get("total_steps"),
        "retained_schedule": (
            "Noise and the ring controller stay on the canonical 1200-update "
            "horizon. The stress length and a candidate total_steps field are "
            "not substituted for that horizon."
        ),
    }


def learner_schedule_view(completed_updates: int) -> dict:
    """Arguments this evaluator adds for a learner. The host step counter only."""
    if type(completed_updates) is not int or completed_updates < 0:
        raise QualificationError("completed_updates must be a nonnegative integer")
    view = {"completed_updates": completed_updates}
    leaked = FORBIDDEN_LEARNER_KEYS & set(view)
    if leaked:
        raise QualificationError("learner view contains " + ", ".join(sorted(leaked)))
    return view


def _window(spec: dict) -> dict:
    try:
        first, last, stride = spec["first"], spec["last"], spec["stride"]
    except KeyError as exc:
        raise QualificationError("window is missing first, last, or stride") from exc
    if type(first) is not int or type(last) is not int or type(stride) is not int:
        raise QualificationError("window bounds must be integers")
    if stride <= 0 or first <= 0 or last < first or (last - first) % stride:
        raise QualificationError(f"invalid window {first}:{last}:{stride}")
    steps = list(range(first, last + 1, stride))
    if "count" in spec and spec["count"] != len(steps):
        raise QualificationError(
            f"declared count {spec['count']} does not match {len(steps)} steps")
    return {"first": first, "last": last, "stride": stride,
            "count": len(steps), "steps": steps}


def _offset(value) -> tuple[float, float]:
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise QualificationError("offset must be two coordinates")
    pair = (float(value[0]), float(value[1]))
    if not all(math.isfinite(item) for item in pair):
        raise QualificationError("offset coordinates must be finite")
    return pair


def _events(changes, total: int) -> list[dict]:
    if not isinstance(changes, list) or not changes:
        raise QualificationError("protocol has no target changes")
    events = []
    previous = 0
    for row in changes:
        after = row.get("after_update")
        if type(after) is not int or not previous < after < total:
            raise QualificationError("target changes must increase and finish inside the run")
        deadline_updates = row.get("deadline_updates")
        if type(deadline_updates) is not int or deadline_updates <= 0:
            raise QualificationError("deadline_updates must be a positive integer")
        deadline = _window(row["deadline_checks"])
        if deadline["steps"][0] != after + deadline_updates:
            raise QualificationError("deadline window does not start at after_update + deadline_updates")
        if deadline["steps"][-1] > total:
            raise QualificationError("deadline window extends past the run")
        events.append({
            "after_update": after,
            "absolute_offset": _offset(row["absolute_offset"]),
            "deadline_updates": deadline_updates,
            "deadline": deadline,
        })
        previous = after
    return events


def _quality(raw: dict) -> dict:
    try:
        modes, hq = raw["live_modes"], raw["min_live_hq"]
    except KeyError as exc:
        raise QualificationError("quality rule is incomplete") from exc
    if type(modes) is not int or isinstance(hq, bool) or not isinstance(hq, (int, float)):
        raise QualificationError("quality rule has the wrong types")
    if not math.isfinite(float(hq)):
        raise QualificationError("min_live_hq must be finite")
    return {"live_modes": modes, "min_live_hq": float(hq)}


def _stable(rows, total: int) -> list[dict]:
    windows = [_window(row) for row in rows]
    for window in windows:
        if window["last"] > total:
            raise QualificationError("stable window extends past the run")
    return windows


def compile_stress(document: dict, *, sha256: str | None = None) -> dict:
    """Compile one uninterrupted stress plan. The input document is not modified."""
    document = deepcopy(document)
    total = document.get("total_updates")
    if type(total) is not int or total <= 0:
        raise QualificationError("total_updates must be a positive integer")
    if _offset(document.get("initial_target_offset", [0.0, 0.0])) != (0.0, 0.0):
        raise QualificationError("the ring host starts from offset [0, 0]")
    events = _events(document["target_changes"], total)
    stable = _stable(document["required_stable_windows"], total)
    quality = _quality(document["quality_at_every_required_check"])
    steps = []
    for window in stable:
        steps.extend(window["steps"])
    for event in events:
        steps.extend(event["deadline"]["steps"])
    if len(steps) != len(set(steps)):
        raise QualificationError("protocol windows overlap")
    return {
        "kind": "stress",
        "name": document.get("name"),
        "pinned": sha256 is not None,
        "sha256": sha256,
        "total_updates": total,
        "events": events,
        "stable_windows": stable,
        "quality": quality,
        "prefix_steps": steps,
        "extension_steps": [],
        "extension_windows": [],
        "extension_deadlines": [],
    }


def compile_long_term(document: dict, stress: dict, *, sha256: str | None = None) -> dict:
    """Attach the 30,000-update extension without rewriting the 9,000-update prefix."""
    document = deepcopy(document)
    if stress.get("total_updates") != 9000:
        raise QualificationError("the long-term prefix is the 9000-update stress plan")
    total = document.get("total_updates")
    if type(total) is not int or total <= stress["total_updates"]:
        raise QualificationError("long-term total_updates must extend the stress plan")
    third = document.get("third_target_change")
    if not isinstance(third, dict):
        raise QualificationError("third_target_change is missing")
    extra_events = _events([third], total)
    if extra_events[0]["after_update"] <= stress["total_updates"]:
        raise QualificationError("the added change must land after the 9000 prefix")
    extension_windows = _stable(document["additional_stable_windows"], total)
    for window in extension_windows:
        if window["first"] <= stress["total_updates"]:
            raise QualificationError("extension windows must stay outside the 9000 prefix")
    quality = _quality(document["quality_at_every_required_check"])
    if quality != stress["quality"]:
        raise QualificationError("long-term quality rule differs from the stress prefix")
    extension_steps = []
    for window in extension_windows:
        extension_steps.extend(window["steps"])
    extension_steps.extend(extra_events[0]["deadline"]["steps"])
    if len(extension_steps) != len(set(extension_steps)):
        raise QualificationError("extension windows overlap")
    if set(extension_steps) & set(stress["prefix_steps"]):
        raise QualificationError("extension checks overlap the 9000 prefix")
    return {
        "kind": "long-term",
        "name": document.get("name"),
        "pinned": sha256 is not None,
        "sha256": sha256,
        "prefix_sha256": stress.get("sha256"),
        "total_updates": total,
        "events": [*stress["events"], *extra_events],
        "stable_windows": [*stress["stable_windows"], *extension_windows],
        "quality": quality,
        "prefix_steps": list(stress["prefix_steps"]),
        "extension_steps": extension_steps,
        "extension_windows": extension_windows,
        "extension_deadlines": [extra_events[0]["deadline"]],
        "prefix_total_updates": stress["total_updates"],
    }


def load_pinned_plans() -> tuple[dict, dict]:
    stress_path, stress_hash = PINS["stress"]
    long_path, long_hash = PINS["long-term"]
    stress_bytes = stress_path.read_bytes()
    long_bytes = long_path.read_bytes()
    if sha256_bytes(stress_bytes) != stress_hash:
        raise QualificationError("stress-protocol.json does not match the pinned bytes")
    if sha256_bytes(long_bytes) != long_hash:
        raise QualificationError("long-term-stability-protocol.json does not match the pinned bytes")
    stress = compile_stress(json.loads(stress_bytes), sha256=stress_hash)
    long_term = compile_long_term(json.loads(long_bytes), stress, sha256=long_hash)
    return stress, long_term


class OffsetClock:
    """Apply protocol offsets as absolute target positions, after the named update."""

    def __init__(self, events: list[dict]):
        self._targets = {event["after_update"]: event["absolute_offset"] for event in events}
        if len(self._targets) != len(events):
            raise QualificationError("duplicate target-change updates")
        self.offset = (0.0, 0.0)
        self.applied = []

    def complete(self, step: int) -> dict:
        seen = self.offset
        target = self._targets.get(step)
        if target is None:
            return {"shifted": False, "seen": seen, "after_update": step}
        delta = (target[0] - seen[0], target[1] - seen[1])
        self.offset = target
        row = {
            "shifted": True,
            "after_update": step,
            "seen": list(seen),
            "absolute_offset": list(target),
            "delta": list(delta),
        }
        self.applied.append(row)
        return row


def simulate_offsets(events: list[dict], total: int) -> list[tuple[float, float]]:
    """Offset visible to each 1-based update. The change lands after that update."""
    clock = OffsetClock(events)
    seen = []
    for step in range(1, total + 1):
        seen.append(clock.offset)
        clock.complete(step)
    return seen


def passes_quality(point: dict, quality: dict) -> bool:
    return (point.get("modes") == quality["live_modes"]
            and isinstance(point.get("hq"), (int, float))
            and not isinstance(point.get("hq"), bool)
            and math.isfinite(point["hq"])
            and point["hq"] >= quality["min_live_hq"])


def score_steps(points: dict[int, dict], steps: list[int], quality: dict) -> dict:
    missing = [step for step in steps if step not in points]
    rows = [points[step] for step in steps if step in points]
    failing = [point["step"] for point in rows if not passes_quality(point, quality)]
    suffix = 0
    flags = [step not in missing and passes_quality(points[step], quality) for step in steps]
    while suffix < len(flags) and flags[len(flags) - 1 - suffix]:
        suffix += 1
    stable_from = steps[len(steps) - suffix] if suffix else None
    return {
        "checks": len(steps),
        "observed": len(rows),
        "missing_steps": missing,
        "passing_checks": len(rows) - len(failing),
        "failing_steps": failing,
        "min_modes": min((point["modes"] for point in rows), default=None),
        "min_hq": min((point["hq"] for point in rows), default=None),
        "passing_suffix": suffix,
        "stable_from_step": stable_from,
        "pass_all": not missing and not failing and len(rows) == len(steps) and bool(steps),
    }


def score_plan(plan: dict, points: dict[int, dict]) -> dict:
    """Score the 9,000-update prefix separately from a longer extension."""
    quality = plan["quality"]
    prefix_windows = []
    if plan["kind"] == "stress":
        stable = plan["stable_windows"]
        deadlines = [event["deadline"] | {"after_update": event["after_update"]}
                     for event in plan["events"]]
    else:
        prefix_count = plan["prefix_total_updates"]
        stable = [window for window in plan["stable_windows"] if window["last"] <= prefix_count]
        deadlines = [event["deadline"] | {"after_update": event["after_update"]}
                     for event in plan["events"]
                     if event["deadline"]["last"] <= prefix_count]
    for window in stable:
        prefix_windows.append({"role": "stable", **{k: window[k] for k in ("first", "last", "stride", "count")},
                                **score_steps(points, window["steps"], quality)})
    deadline_rows = []
    for window in deadlines:
        scored = score_steps(points, window["steps"], quality)
        delay = None if scored["stable_from_step"] is None else scored["stable_from_step"] - window["after_update"]
        deadline_rows.append({
            "role": "deadline",
            "after_update": window["after_update"],
            "first": window["first"],
            "last": window["last"],
            "count": window["count"],
            "delay_updates": delay,
            **scored,
        })
    extension = None
    if plan["kind"] == "long-term":
        extension = {
            "stable": [
                {"role": "stable", **{k: window[k] for k in ("first", "last", "stride", "count")},
                 **score_steps(points, window["steps"], quality)}
                for window in plan["extension_windows"]
            ],
            "deadlines": [],
        }
        for event in plan["events"]:
            if event["deadline"]["last"] <= plan["prefix_total_updates"]:
                continue
            scored = score_steps(points, event["deadline"]["steps"], quality)
            delay = None if scored["stable_from_step"] is None else scored["stable_from_step"] - event["after_update"]
            extension["deadlines"].append({
                "role": "deadline",
                "after_update": event["after_update"],
                "delay_updates": delay,
                "count": event["deadline"]["count"],
                **scored,
            })
    return {"prefix": {"stable": prefix_windows, "deadlines": deadline_rows}, "extension": extension}


def qualification_status(*, mechanics_ok: bool, witness_complete: bool,
                         score: dict, kind: str) -> str:
    """A partial witness cannot become a quality pass."""
    if kind != "qualification":
        raise QualificationError("qualification status is only for a declared protocol run")
    if not mechanics_ok or not witness_complete:
        return "ERROR"
    rows = list(score["prefix"]["stable"]) + list(score["prefix"]["deadlines"])
    extension = score.get("extension") or {}
    rows.extend(extension.get("stable") or [])
    rows.extend(extension.get("deadlines") or [])
    if rows and all(row["pass_all"] for row in rows):
        return "PASS"
    return "FAIL"


def updates_advanced(before: list[dict], after: list[dict]) -> bool:
    if not before or len(before) != len(after):
        return False
    left = sorted(before, key=lambda row: row["role"])
    right = sorted(after, key=lambda row: row["role"])
    for earlier, later in zip(left, right):
        if earlier["role"] != later["role"]:
            return False
        if not (later["updates"] > earlier["updates"] and later["calls"] > earlier["calls"]):
            return False
        if later["delegate_calls"] != later["calls"]:
            return False
    return True


def _tensor_record(tensor: torch.Tensor, *, require_cuda: bool) -> dict:
    partial = bool(require_cuda and (tensor.device.type != "cuda" or tensor.dtype != torch.float32))
    return {
        "shape": list(tensor.shape),
        "dtype": str(tensor.dtype),
        "device": tensor.device.type,
        "sha256": digest_tensor(tensor),
        "partial": partial,
    }


_GROUP_KEYS = (
    "lr", "betas", "weight_decay", "eps", "amsgrad", "foreach", "fused",
    "maximize", "capturable", "differentiable",
    "_comparison_prior", "_comparison_output_scale",
)


def _json_value(value):
    if isinstance(value, tuple):
        return [_json_value(item) for item in value]
    if isinstance(value, (int, float, str, bool)) or value is None:
        if isinstance(value, float) and not math.isfinite(value):
            return {"unsupported": "nonfinite"}
        return value
    return {"unsupported": type(value).__name__}


def _group_hyperparameters(group: dict) -> dict:
    return {key: _json_value(group[key]) for key in _GROUP_KEYS if key in group}


def _state_entry(value, *, require_cuda: bool) -> tuple[dict, bool]:
    """Record every optimizer-state entry. Scalar steps keep dtype and device."""
    if isinstance(value, torch.Tensor):
        record = _tensor_record(value, require_cuda=require_cuda)
        if value.ndim == 0:
            record["value"] = float(value.item()) if value.dtype.is_floating_point else int(value.item())
        return record, bool(record["partial"])
    if isinstance(value, (int, float, str, bool)) or value is None:
        return {"kind": "scalar", "value": _json_value(value), "partial": False}, False
    return {"kind": "unsupported", "type": type(value).__name__, "partial": True}, True


def _walk_adam(opt_g, opt_d, *, require_cuda: bool) -> tuple[list[dict], list[dict], dict]:
    rows = []
    groups = []
    id_index = {id(opt_g): "g", id(opt_d): "d"}
    for role, opt in (("g", opt_g), ("d", opt_d)):
        for group_index, group in enumerate(opt.param_groups):
            hyperparameters = _group_hyperparameters(group)
            unsupported = any(isinstance(item, dict) and "unsupported" in item
                              for item in hyperparameters.values())
            groups.append({
                "role": role,
                "index": group_index,
                "hyperparameters": hyperparameters,
                "partial": unsupported,
            })
            for index, param in enumerate(group["params"]):
                path = f"{role}/{group_index}/{index}"
                id_index[id(param)] = path
                state = opt.state.get(param, {})
                encoded = {}
                partial = unsupported
                for key in sorted(state, key=str):
                    encoded[str(key)], bad = _state_entry(state[key], require_cuda=require_cuda)
                    partial = partial or bad
                moments = None
                if "exp_avg" in encoded and "exp_avg_sq" in encoded and "step" in encoded:
                    moments = {
                        "step": encoded["step"].get("value"),
                        "step_tensor": encoded["step"],
                        "exp_avg": encoded["exp_avg"],
                        "exp_avg_sq": encoded["exp_avg_sq"],
                    }
                    if "max_exp_avg_sq" in encoded:
                        moments["max_exp_avg_sq"] = encoded["max_exp_avg_sq"]
                else:
                    partial = True
                rows.append({
                    "path": path,
                    "group": group_index,
                    "parameter": _tensor_record(param, require_cuda=require_cuda),
                    "state": encoded,
                    "moments": moments,
                    "partial": partial or bool(encoded and any(
                        item.get("partial") for item in encoded.values() if isinstance(item, dict))),
                })
    return rows, groups, id_index


def _module_record(module, *, require_cuda: bool) -> dict:
    return {
        "parameters": [_tensor_record(param, require_cuda=require_cuda) for param in module.parameters()],
        "buffers": [_tensor_record(buf, require_cuda=require_cuda) for buf in module.buffers()],
    }


def _encode_controller_value(value, id_index: dict):
    if isinstance(value, bool) or value is None or isinstance(value, str):
        return value, False
    if isinstance(value, float):
        return value, not math.isfinite(value)
    if isinstance(value, int):
        if value in id_index:
            return {"kind": "reference", "path": id_index[value]}, False
        return value, False
    if isinstance(value, torch.Tensor):
        return {"kind": "tensor", **_tensor_record(value, require_cuda=False)}, False
    if isinstance(value, torch.optim.Optimizer):
        path = id_index.get(id(value))
        if path is None:
            return {"kind": "unsupported", "type": "Optimizer"}, True
        return {"kind": "reference", "path": path}, False
    if isinstance(value, list):
        if not value:
            return [], False
        if all(isinstance(item, torch.Tensor) for item in value):
            return {"kind": "tensors", "parts": [_tensor_record(item, require_cuda=False) for item in value]}, False
        if all(isinstance(item, (int, float, str, bool)) or item is None for item in value):
            return list(value), False
    return {"kind": "unsupported", "type": type(value).__name__}, True


def capture_witness(frame: dict, sources, *, completed_step: int, offset: tuple[float, float],
                    require_cuda: bool) -> dict:
    """Hash normalized identities. A missing lineage field stays partial."""
    required = ("generator", "critic", "prior", "opt_g", "opt_d", "ema_g", "ema_z", "stream", "means")
    if any(name not in frame for name in required):
        raise QualificationError("frozen host locals changed; refusing a partial host capture")
    generator, critic, prior = frame["generator"], frame["critic"], frame["prior"]
    opt_g, opt_d = frame["opt_g"], frame["opt_d"]
    means = frame["means"]
    model = {
        "generator": _module_record(generator, require_cuda=require_cuda),
        "critic": _module_record(critic, require_cuda=require_cuda),
        "prior": _module_record(prior, require_cuda=require_cuda),
    }
    model_partial = False
    for record in model.values():
        if not record["parameters"]:
            model_partial = True
        if any(item["partial"] for item in record["parameters"] + record["buffers"]):
            model_partial = True
    adam_rows, adam_groups, id_index = _walk_adam(opt_g, opt_d, require_cuda=require_cuda)
    adam_partial = (not adam_rows or any(row["partial"] for row in adam_rows)
                    or any(group["partial"] for group in adam_groups)
                    or (completed_step > 0 and any(row["moments"] is None for row in adam_rows)))
    if require_cuda:
        for row in adam_rows:
            if row["parameter"]["device"] != "cuda" or row["parameter"]["dtype"] != "torch.float32":
                adam_partial = True
            step_tensor = (row["moments"] or {}).get("step_tensor")
            if step_tensor is None or step_tensor.get("device") != "cuda" or step_tensor.get("dtype") != "torch.float32":
                adam_partial = True
    ema_g = list(frame["ema_g"])
    ema_partial = len(ema_g) != len(model["generator"]["parameters"])
    ema = {
        "generator": [_tensor_record(param, require_cuda=require_cuda) for param in ema_g],
        "prior": _tensor_record(frame["ema_z"], require_cuda=require_cuda),
    }
    if ema["prior"]["partial"] or any(row["partial"] for row in ema["generator"]):
        ema_partial = True
    if not hasattr(prior, "z") or tuple(frame["ema_z"].shape) != tuple(prior.z.shape):
        ema_partial = True
    sections = {
        "model": {"partial": model_partial, **model},
        "adam": {"partial": adam_partial, "groups": adam_groups, "parameters": [
            {"path": row["path"], "group": row["group"],
             "parameter_sha256": row["parameter"]["sha256"],
             "shape": row["parameter"]["shape"], "dtype": row["parameter"]["dtype"],
             "device": row["parameter"]["device"], "state": row["state"],
             "moments": row["moments"]}
            for row in adam_rows
        ]},
        "ema": {"partial": ema_partial, **ema},
    }
    missing = []
    controller_partial = True
    if sources is None or not hasattr(sources, "mechanism") or not hasattr(sources.mechanism, "_state"):
        missing.append("controller")
    else:
        encoded = {}
        controller_partial = False
        for key in sorted(sources.mechanism._state, key=str):
            encoded_value, bad = _encode_controller_value(sources.mechanism._state[key], id_index)
            encoded[str(key)] = encoded_value
            controller_partial = controller_partial or bad
        sections["controller"] = {"partial": controller_partial, "present": True, "state": encoded}
    if sources is None or not hasattr(sources, "latent") or not hasattr(sources.latent, "stats"):
        missing.append("latent_stats")
    else:
        rows = []
        unmapped = 0
        for key, value in sources.latent.stats.items():
            path = id_index.get(key)
            if path is None or not isinstance(value, (list, tuple)) or len(value) != 2:
                unmapped += 1
                continue
            rows.append({"path": path, "observed_row_steps": int(value[0]), "total_row_steps": int(value[1])})
        rows.sort(key=lambda row: row["path"])
        sections["latent_stats"] = {
            "present": True,
            "partial": unmapped > 0,
            "unmapped": unmapped,
            "entries": len(rows),
            "rows": rows,
        }
    if (sources is None or not hasattr(sources, "response")
            or not hasattr(sources.response, "prior_ids")
            or not hasattr(sources.response, "previous")):
        missing.append("response")
    else:
        membership = sorted(id_index[item] for item in sources.response.prior_ids if item in id_index)
        unmapped_members = len(sources.response.prior_ids) - len(membership)
        history = []
        unmapped_history = 0
        optimizers = {"g": opt_g, "d": opt_d}
        optimizer_ids = {id(opt_g): "g", id(opt_d): "d"}
        for key, value in sources.response.previous.items():
            if not isinstance(key, tuple) or len(key) != 2 or not isinstance(value, torch.Tensor):
                unmapped_history += 1
                continue
            role = optimizer_ids.get(key[0])
            if role is None or type(key[1]) is not int:
                unmapped_history += 1
                continue
            history.append({"optimizer": role, "group": key[1], **_tensor_record(value, require_cuda=require_cuda)})
        history.sort(key=lambda row: (row["optimizer"], row["group"]))
        sections["response"] = {
            "present": True,
            "partial": unmapped_members > 0 or unmapped_history > 0,
            "prior_membership": membership,
            "prior_member_count": len(membership),
            "unmapped_members": unmapped_members,
            "history": history,
            "optimizer_roles": sorted(optimizers),
        }
    stream = frame["stream"]
    rng_partial = False
    rng = {"host_stream_sha256": digest_tensor(stream.get_state()),
           "host_stream_device": str(stream.device),
           "cpu_sha256": digest_tensor(torch.get_rng_state())}
    if require_cuda:
        if stream.device.type != "cuda" or not torch.cuda.is_available():
            rng_partial = True
        else:
            rng["cuda_sha256"] = digest_tensor(torch.cuda.get_rng_state())
    elif torch.cuda.is_available() and stream.device.type == "cuda":
        rng["cuda_sha256"] = digest_tensor(torch.cuda.get_rng_state())
    sections["rng"] = {"partial": rng_partial, **rng}
    sections["target_before_shift"] = {
        "partial": False,
        "offset": list(offset),
        "sha256": digest_tensor(means),
    }
    if sources is not None:
        unknown = audit_policy_modules(sources)
        sections["policy_modules"] = {
            "partial": bool(unknown),
            "unknown": unknown,
            "captured": [
                "mechanism._state", "latent.stats", "response.previous", "response.prior_ids",
                "optimizer.state", "optimizer.hyperparameters", "parameters", "buffers",
            ],
            "diagnostic_ignored": ["mechanism.receipt", "latent.receipt", "response.receipt"],
            "harness_bookkeeping": ["checkpoint.optimizers", "checkpoint.frames"],
        }
    partial_sections = [name for name, section in sections.items() if section.get("partial")]
    complete = not missing and not partial_sections
    body = {
        "complete": complete,
        "missing_sections": missing,
        "partial_sections": partial_sections,
        "sections": sections,
    }
    encoded = json.dumps(body, sort_keys=True, allow_nan=False)
    digest = sha256_bytes(encoded.encode())
    body["identity_sha256"] = digest if complete else None
    body["partial_sha256"] = None if complete else digest
    return body


def verify_candidate(path: Path) -> dict:
    """Fail closed before import when the candidate manifest is incomplete."""
    path = Path(path)
    manifest_path = path / "provenance.json"
    if not manifest_path.is_file():
        raise QualificationError("candidate provenance.json is missing")
    manifest = json.loads(manifest_path.read_text())
    files = manifest.get("files")
    if not isinstance(files, dict):
        raise QualificationError("provenance files map is missing")
    missing = [name for name in CANDIDATE_FILES if name not in files]
    if missing:
        raise QualificationError("provenance omits " + ", ".join(missing))
    for name, expected in files.items():
        if not isinstance(name, str) or "/" in name or name.startswith("."):
            raise QualificationError("provenance file name is not a local file")
        if not isinstance(expected, str) or len(expected) != 64:
            raise QualificationError(f"provenance hash for {name} is malformed")
        file_path = path / name
        if not file_path.is_file():
            raise QualificationError(f"missing candidate file {name}")
        observed = sha256_file(file_path)
        if observed != expected:
            raise QualificationError(f"hash mismatch for {name}")
    local = imported_local_policies(path, CANDIDATE_FILES)
    missing_local = [name for name in local if name not in files]
    if missing_local:
        raise QualificationError("provenance omits imported policy " + ", ".join(missing_local))
    return manifest


def require_candidate_surface(modules) -> None:
    if not hasattr(modules.latent, "stats"):
        raise QualificationError("latent.stats is not installed")
    if not hasattr(modules.response, "prior_ids") or not hasattr(modules.response, "previous"):
        raise QualificationError("response history or prior membership is not installed")
    if not hasattr(modules.mechanism, "_state"):
        raise QualificationError("controller state is not installed")


@contextmanager
def installed_candidate(path: Path):
    verify_candidate(path)
    token = str(Path(path).resolve())
    sys.path.insert(0, token)
    imported = []
    try:
        for name in ("mechanism", "response", "latent"):
            sys.modules.pop(name, None)
            imported.append(importlib.import_module(name))
        checkpoint_mod = None
        if "checkpoint.py" in json.loads((Path(path) / "provenance.json").read_text())["files"]:
            sys.modules.pop("checkpoint", None)
            checkpoint_mod = importlib.import_module("checkpoint")
        modules = SimpleNamespace(
            mechanism=imported[0], response=imported[1], latent=imported[2], checkpoint=checkpoint_mod)
        require_candidate_surface(modules)
        yield modules
    finally:
        if token in sys.path:
            sys.path.remove(token)
        for name in ("mechanism", "response", "latent", "checkpoint"):
            sys.modules.pop(name, None)


def assert_execution_environment() -> None:
    if os.environ.get("CUBLAS_WORKSPACE_CONFIG") != ":4096:8":
        raise QualificationError("CUBLAS_WORKSPACE_CONFIG must be :4096:8")
    if not os.environ.get("CUDA_VISIBLE_DEVICES"):
        raise QualificationError("CUDA_VISIBLE_DEVICES is unset")
    for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS"):
        if os.environ.get(name) != "1":
            raise QualificationError(f"{name} must be 1")


def _rng_snapshot(stream, cuda: bool) -> dict:
    snap = {"cpu": torch.get_rng_state().clone(), "stream": stream.get_state().clone()}
    if cuda:
        snap["cuda"] = torch.cuda.get_rng_state().clone()
    return snap


def _rng_same(before: dict, stream, cuda: bool) -> bool:
    if not torch.equal(before["cpu"], torch.get_rng_state()):
        return False
    if not torch.equal(before["stream"], stream.get_state()):
        return False
    if cuda and not torch.equal(before["cuda"], torch.cuda.get_rng_state()):
        return False
    return True


def _optimizer_counts(tracked: dict) -> list[dict]:
    rows = []
    for role, row in tracked.items():
        moments = []
        for state in row["optimizer"].state.values():
            if "step" not in state:
                continue
            value = state["step"]
            moments.append(int(value.item() if isinstance(value, torch.Tensor) else value))
        if not moments:
            raise QualificationError("Adam moment counters are missing")
        if min(moments) != max(moments):
            raise QualificationError("Adam moment counters disagree within an optimizer")
        rows.append({
            "role": role,
            "calls": row["calls"],
            "delegate_calls": row["delegate_calls"],
            "updates": moments[0],
        })
    return sorted(rows, key=lambda row: row["role"])


def _fingerprint(generator, critic, prior) -> str:
    digest = hashlib.sha256()
    for param in list(generator.parameters()) + list(critic.parameters()) + list(prior.parameters()):
        digest.update(digest_tensor(param).encode())
    return digest.hexdigest()


_RUNTIME_RECEIPT = None
PARENT_SOURCE_KEYS = {
    "config.json": "config_sha256",
    "mechanism.py": "mechanism_sha256",
    "latent.py": "latent_sha256",
    "response.py": "response_sha256",
    "checkpoint.py": "checkpoint_sha256",
}


def gap_manifest() -> dict:
    path = ROOT / "reports/toy100/gap-fill-20260925/manifest.json"
    return json.loads(path.read_text())


def research_base() -> dict:
    path = ROOT / "reports/toy100/current-research-base.json"
    return json.loads(path.read_text())


def k3p_source_dir() -> Path:
    return ROOT / "reports/toy100/gap-fill-20260925/sources/k3p"


def select_frozen_runtime() -> dict:
    """The runtime K3P jobs name in the gap-fill manifest, hash-checked."""
    global _RUNTIME_RECEIPT
    if _RUNTIME_RECEIPT is not None:
        return _RUNTIME_RECEIPT
    manifest = gap_manifest()
    repos = []
    for job in manifest["jobs"]:
        if job.get("candidate") != "k3p" or "--repo" not in job["command"]:
            continue
        repos.append(job["command"][job["command"].index("--repo") + 1])
    unique = sorted(set(repos))
    if len(unique) != 1:
        raise QualificationError("K3P jobs do not share one frozen runtime")
    root = Path(unique[0]).resolve()
    pins = json.loads((ROOT / "reports/toy100/gap-fill-20260925/runtime-hashes.json").read_text())
    if str(root) not in pins and unique[0] not in pins:
        raise QualificationError("frozen runtime is absent from runtime-hashes.json")
    pin = pins.get(str(root), pins.get(unique[0]))
    check_runtime_files(root, pin)
    _RUNTIME_RECEIPT = {"root": root, "files": len(pin), "verified": True}
    return _RUNTIME_RECEIPT


def check_runtime_files(root: Path, pin: dict) -> None:
    bad = []
    for rel, expected in pin.items():
        path = root / rel
        if not path.is_file() or sha256_file(path) != expected:
            bad.append(rel)
        if len(bad) > 8:
            break
    if bad:
        raise QualificationError("frozen runtime mismatch: " + ", ".join(bad))


def assert_from_runtime(root: Path, *modules) -> None:
    root = root.resolve()
    for module in modules:
        path = Path(module.__file__).resolve()
        if root not in path.parents:
            raise QualificationError(
                f"{module.__name__} loaded from {path}, not the pinned runtime {root}")


def frozen_runtime_selected(root: Path) -> bool:
    root = Path(root).resolve()
    loaded = sys.modules.get("benchmarks")
    if loaded is not None and getattr(loaded, "__file__", None):
        return root in Path(loaded.__file__).resolve().parents
    return bool(sys.path) and Path(sys.path[0]).resolve() == root


def relaunch_on_frozen_runtime(argv: list[str]) -> None:
    """Import host modules from the pinned tree, not from this worktree."""
    runtime = select_frozen_runtime()
    root = runtime["root"]
    if frozen_runtime_selected(root):
        return
    script = str(Path(__file__).resolve())
    launcher = r"""
import importlib.util, os, sys
from pathlib import Path
root = Path(sys.argv[1]).resolve()
script = Path(sys.argv[2]).resolve()
worktree = script.parents[2].resolve()
os.chdir(root)
kept = []
for entry in sys.path:
    if not entry:
        continue
    resolved = Path(entry).resolve()
    if resolved == root or resolved == worktree or worktree in resolved.parents:
        continue
    kept.append(entry)
sys.path[:] = [str(root), *kept]
name = "continuous_qualification_entry"
spec = importlib.util.spec_from_file_location(name, script)
mod = importlib.util.module_from_spec(spec)
sys.modules[name] = mod
spec.loader.exec_module(mod)
raise SystemExit(mod.main(sys.argv[3:]))
"""
    os.execv(sys.executable, [sys.executable, "-c", launcher, str(root), script, *argv])


def verify_named_fixture(path: Path, expected: str) -> str:
    if not isinstance(expected, str) or len(expected) != 64:
        raise QualificationError("fixture pin is malformed")
    if not path.is_file():
        raise QualificationError(f"initialization fixture is missing: {path}")
    observed = sha256_file(path)
    if observed != expected:
        raise QualificationError("initialization fixture hash mismatch")
    return observed


def load_pinned_fixture(task: str = "mode_hold") -> tuple[list, dict]:
    row = gap_manifest()["fixtures"][task]
    path = Path(row["path"])
    observed = verify_named_fixture(path, row["sha256"])
    values = torch.load(path, map_location="cpu", weights_only=True)
    if not isinstance(values, list) or not values:
        raise QualificationError("initialization fixture is empty")
    return values, {"task": task, "path": str(path), "sha256": observed, "optimizers": len(values)}


_POLICY_CAPTURED = {
    "mechanism": {"_state"},
    "latent": {"stats"},
    "response": {"previous", "prior_ids"},
}
_POLICY_DIAGNOSTIC = {"receipt"}
_HARNESS_BOOKKEEPING = {"checkpoint": {"optimizers", "frames"}}


def _mutable_container(value) -> bool:
    return isinstance(value, (dict, list, set, torch.Tensor))


def audit_policy_modules(sources) -> list[str]:
    """Names that hold mutable state outside the audited capture contract."""
    unknown = []
    for name in ("mechanism", "latent", "response", "checkpoint"):
        module = getattr(sources, name, None)
        if module is None:
            continue
        allowed = set(_POLICY_CAPTURED.get(name, ())) | _POLICY_DIAGNOSTIC | set(_HARNESS_BOOKKEEPING.get(name, ()))
        for key, value in vars(module).items():
            if key.startswith("__") or not _mutable_container(value):
                continue
            if key not in allowed:
                unknown.append(f"{name}.{key}")
    return sorted(unknown)


def _local_import_roots(source: str) -> set[str]:
    import ast
    found = set()
    tree = ast.parse(source)
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                found.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            found.add(node.module.split(".")[0])
    return found


def imported_local_policies(root: Path, seeds: tuple[str, ...]) -> list[str]:
    """Candidate-local modules reachable from the policy seeds, including the seeds."""
    pending = list(seeds)
    seen: list[str] = []
    while pending:
        name = pending.pop(0)
        if name in seen:
            continue
        path = root / name
        if not path.is_file():
            continue
        seen.append(name)
        for imported in sorted(_local_import_roots(path.read_text())):
            sibling = f"{imported}.py"
            if (root / sibling).is_file() and sibling not in seen and sibling not in pending:
                pending.append(sibling)
    return seen


def load_worktree_device():
    """Device policy lives in this worktree. The pinned host tree has no device.py."""
    name = "cq_worktree_device"
    loaded = sys.modules.get(name)
    if loaded is not None:
        return loaded
    path = ROOT / "benchmarks/toy100/device.py"
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise QualificationError("worktree device policy could not be loaded")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def require_training_hooks(sources) -> None:
    if sources is None:
        raise QualificationError("candidate hooks are not installed")
    for name in ("latent", "response"):
        module = getattr(sources, name, None)
        if module is None:
            raise QualificationError(f"{name} is not installed")
        for method in ("begin", "end"):
            if not callable(getattr(module, method, None)):
                raise QualificationError(f"{name}.{method} hook is missing")
    if not hasattr(sources, "mechanism") or not hasattr(sources.mechanism, "_state"):
        raise QualificationError("controller state is not installed")


def bind_hooks(sources):
    """Count every begin/end call. A zero tensor effect must not hide a skip."""
    require_training_hooks(sources)
    counts = {"latent_begin": 0, "latent_end": 0, "response_begin": 0, "response_end": 0}

    def latent_begin(opt):
        counts["latent_begin"] += 1
        return sources.latent.begin(opt)

    def latent_end(saved):
        counts["latent_end"] += 1
        return sources.latent.end(saved)

    def response_begin(opt):
        counts["response_begin"] += 1
        return sources.response.begin(opt)

    def response_end(saved):
        counts["response_end"] += 1
        return sources.response.end(saved)

    hooks = SimpleNamespace(
        latent_begin=latent_begin, latent_end=latent_end,
        response_begin=response_begin, response_end=response_end,
    )
    return counts, hooks


def assert_hook_accounting(counts: dict, adam_calls: int) -> None:
    if adam_calls <= 0:
        raise QualificationError("no Adam updates were delegated")
    for key, value in counts.items():
        if value != adam_calls:
            raise QualificationError(f"{key} calls {value} != Adam steps {adam_calls}")


def reset_learner_state(sources) -> None:
    """Clear mutable learner memory without reimporting hook registrations."""
    if sources is None:
        return
    if hasattr(sources.latent, "stats"):
        sources.latent.stats.clear()
    if hasattr(sources.response, "previous"):
        sources.response.previous.clear()
    if hasattr(sources.response, "prior_ids"):
        sources.response.prior_ids.clear()
    state = getattr(sources.mechanism, "_state", None)
    if isinstance(state, dict):
        state.clear()
        state.update(ema=None, critic=None, pending=False, lr_max=0.0,
                     lr_last=None, depth=0, clips=[], critic_ref=None)
    checkpoint_mod = getattr(sources, "checkpoint", None)
    if checkpoint_mod is not None:
        checkpoint_mod.optimizers.clear()
        if hasattr(checkpoint_mod, "frames"):
            checkpoint_mod.frames.clear()


def load_pinned_k3p():
    """Import the selected parent. Hashes come from the research base; files stay put."""
    base = research_base()
    root = k3p_source_dir()
    if base.get("candidate") != "k3p":
        raise QualificationError("research base is not K3P")
    for name, key in PARENT_SOURCE_KEYS.items():
        expected = base[key]
        observed = sha256_file(root / name)
        if observed != expected:
            raise QualificationError(f"pinned K3P {name} hash mismatch")
    local = imported_local_policies(root, tuple(PARENT_SOURCE_KEYS))
    unpinned = [name for name in local if name not in PARENT_SOURCE_KEYS]
    if unpinned:
        raise QualificationError("unpinned local policy import " + ", ".join(unpinned))
    token = str(root.resolve())
    if token not in sys.path:
        sys.path.insert(0, token)
    imported = []
    for name in ("mechanism", "response", "latent", "checkpoint"):
        sys.modules.pop(name, None)
        imported.append(importlib.import_module(name))
    modules = SimpleNamespace(
        mechanism=imported[0], response=imported[1], latent=imported[2], checkpoint=imported[3],
        source_dir=str(root),
        sha256={name: base[key] for name, key in PARENT_SOURCE_KEYS.items()},
    )
    require_candidate_surface(modules)
    require_training_hooks(modules)
    return modules


def bootstrap_adam_state(opt) -> None:
    """Match the canonical driver: CUDA FP32 moments before the first Adam step."""
    for group in opt.param_groups:
        for value in group["params"]:
            if value.grad is None or opt.state[value]:
                continue
            opt.state[value]["step"] = torch.zeros((), dtype=torch.float32, device=value.device)
            opt.state[value]["exp_avg"] = torch.zeros_like(value, memory_format=torch.preserve_format)
            opt.state[value]["exp_avg_sq"] = torch.zeros_like(value, memory_format=torch.preserve_format)
            if group.get("amsgrad", False):
                opt.state[value]["max_exp_avg_sq"] = torch.zeros_like(
                    value, memory_format=torch.preserve_format)


def assert_adam_cuda_fp32(opt) -> None:
    seen = False
    for state in opt.state.values():
        if "step" not in state:
            continue
        seen = True
        step_value = state["step"]
        if not isinstance(step_value, torch.Tensor) or step_value.ndim != 0:
            raise QualificationError("Adam step is not a scalar tensor")
        if step_value.device.type != "cuda" or step_value.dtype != torch.float32:
            raise QualificationError("Adam step is not CUDA FP32")
        for key in ("exp_avg", "exp_avg_sq"):
            tensor = state[key]
            if tensor.device.type != "cuda" or tensor.dtype != torch.float32:
                raise QualificationError(f"Adam {key} is not CUDA FP32")
    if not seen:
        raise QualificationError("Adam bootstrap did not create a CUDA FP32 step")


def scalar_step_hashes(frame: dict) -> list[str]:
    rows = []
    for role in ("opt_d", "opt_g"):
        opt = frame[role]
        for state in opt.state.values():
            step_value = state.get("step")
            if isinstance(step_value, torch.Tensor):
                rows.append(digest_tensor(step_value))
    return rows


def make_fixture_init(original_init, fixture: list, checkpoint_mod, proof: list):
    initial_values = []

    def init(opt, *args, **kwargs):
        kwargs = dict(kwargs)
        kwargs.setdefault("foreach", False)
        kwargs.setdefault("fused", False)
        original_init(opt, *args, **kwargs)
        if checkpoint_mod is not None:
            checkpoint_mod.optimizers.append(opt)
        values = [v for group in opt.param_groups for v in group["params"]]
        if len(initial_values) >= len(fixture):
            raise QualificationError("more optimizers were constructed than the fixture records")
        expected = fixture[len(initial_values)]
        if len(expected) != len(values):
            raise QualificationError(
                f"fixture optimizer {len(initial_values)} width {len(expected)} != host {len(values)}")
        with torch.no_grad():
            for parameter, value in zip(values, expected):
                if parameter.shape != value.shape or parameter.dtype != value.dtype:
                    raise QualificationError("fixture parameter shape or dtype mismatch")
                parameter.copy_(value.to(dtype=parameter.dtype))
        initial_values.append(len(values))
        proof.append({"index": len(initial_values) - 1, "parameters": len(values)})
    return init


def prefix_plan(updates: int) -> dict:
    """Short host plan with no target change. Not a declared protocol."""
    if type(updates) is not int or updates <= 0:
        raise QualificationError("prefix updates must be a positive integer")
    return {
        "kind": "stress",
        "name": "identity_prefix",
        "pinned": False,
        "sha256": None,
        "total_updates": updates,
        "events": [],
        "stable_windows": [],
        "quality": {"live_modes": 8, "min_live_hq": 0.9},
        "prefix_steps": [],
        "extension_steps": [],
    }


def run_frozen_host(plan: dict, config: dict, *, sources=None, require_complete_witness: bool,
                    log=None, instrument: bool = True, capture_at: int | None = None) -> dict:
    """Run one uninterrupted ring episode. The learner is not given the plan."""
    assert_execution_environment()
    from benchmarks.learned_lr_evaluation import control_host_schedules
    from benchmarks.locked_shared import baseline, mode_hold
    from benchmarks.smart_descent import evaluate
    from benchmarks.toy100.continuous_probe import _noise_policy
    device_mod = load_worktree_device()
    apply_device_policy = device_mod.apply_device_policy
    rng_fork_devices = device_mod.rng_fork_devices
    from benchmarks.transfer_suite.compare_defaults import candidate, optimizer_defaults
    from benchmarks.transfer_suite.toy100_compatibility import declared_recipe
    from benchmarks.transfer_suite import vector_tasks

    runtime = select_frozen_runtime()
    assert_from_runtime(
        runtime["root"], mode_hold, baseline, evaluate, vector_tasks,
        sys.modules["benchmarks.toy100.continuous_probe"],
        sys.modules["benchmarks.learned_lr_evaluation"],
        sys.modules["benchmarks.transfer_suite.compare_defaults"],
        sys.modules["benchmarks.transfer_suite.toy100_compatibility"],
    )
    for name in ("train_mode_hold", "ring_means", "checkpoint", "ModeHoldRecipe"):
        if not hasattr(mode_hold, name):
            raise QualificationError(f"frozen ring host is missing {name}")
    if baseline.BUDGETS["mode_hold"] != FROZEN_HORIZON:
        raise QualificationError("frozen mode_hold budget is no longer 1200")
    binding = schedule_binding(config, plan["total_updates"])
    if binding["controller_total_steps"] != FROZEN_HORIZON or binding["noise_horizon"] != FROZEN_HORIZON:
        raise QualificationError("schedule binding tried to use the episode length")
    reset_learner_state(sources)
    hook_counts = None
    hooks = None
    if sources is not None:
        hook_counts, hooks = bind_hooks(sources)
    fixture, fixture_receipt = load_pinned_fixture("mode_hold")
    checkpoint_mod = getattr(sources, "checkpoint", None) if sources is not None else None
    device_receipt = apply_device_policy("cuda", log=False)
    if device_receipt.get("device") != "cuda:0":
        raise QualificationError("CUDA device policy did not select cuda:0")
    torch.set_num_threads(1)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass
    recipe, noise, _ = declared_recipe(deepcopy(config))
    policy = _noise_policy(noise, FROZEN_HORIZON)
    steps = plan["total_updates"]
    quality_steps = set(plan["prefix_steps"]) | set(plan["extension_steps"])
    clock = OffsetClock(plan["events"])
    original_recipe = mode_hold.ModeHoldRecipe
    original_means = mode_hold.ring_means
    original_checkpoint = mode_hold.checkpoint
    original_init = torch.optim.Adam.__init__
    delegate = torch.optim.Adam.step
    fixture_proof = []
    fixture_init = make_fixture_init(original_init, fixture, checkpoint_mod, fixture_proof)
    tracked = {}
    ring = {"tensor": None, "initial": None}
    diagnostic = []
    offset_checks = []
    witnesses = []
    captured = []
    captured_steps = []
    events = []
    pending_move = None
    rng_preserved = True
    cuda = True

    def extended_recipe(**kwargs):
        return original_recipe(steps=steps, **kwargs)

    def retain_ring(*args, **kwargs):
        if ring["tensor"] is not None:
            raise QualificationError("ring target was constructed more than once")
        tensor = original_means(*args, **kwargs)
        ring["tensor"] = tensor
        ring["initial"] = tensor.detach().clone()
        return tensor

    def step_optimizer(opt, *args, **kwargs):
        role = next((key for key, row in tracked.items() if row["optimizer"] is opt), None)
        if role is None:
            if len(tracked) >= 2:
                raise QualificationError("the ring host stepped an unexpected optimizer")
            role = "d" if "d" not in tracked else "g"
            tracked[role] = {"optimizer": opt, "calls": 0, "delegate_calls": 0}
        values = [v for group in opt.param_groups for v in group["params"]]
        if any(v.device.type != "cuda" or v.dtype != torch.float32 for v in values):
            raise QualificationError("Adam parameters left CUDA FP32")
        if any(v.grad is not None and v.grad.device != v.device for v in values):
            raise QualificationError("Adam gradients left the parameter device")
        tracked[role]["calls"] += 1
        bootstrap_adam_state(opt)
        latent_saved = response_saved = None
        if hooks is not None:
            latent_saved = hooks.latent_begin(opt)
            response_saved = hooks.response_begin(opt)
        result = delegate(opt, *args, **kwargs)
        tracked[role]["delegate_calls"] += 1
        if hooks is not None:
            hooks.response_end(response_saved)
            hooks.latent_end(latent_saved)
        if tracked[role]["calls"] == 1:
            assert_adam_cuda_fp32(opt)
        if checkpoint_mod is not None:
            checkpoint_mod.remember()
        return result

    def capture_now(values, step):
        if capture_at is None or step != capture_at:
            return
        witness = capture_witness(
            values, sources, completed_step=step, offset=tuple(clock.offset), require_cuda=True)
        captured.append(witness)
        captured_steps.append(scalar_step_hashes(values))

    def observe(step, measure):
        nonlocal pending_move, rng_preserved
        frame = inspect.currentframe().f_back
        if frame is None or frame.f_code.co_name != "train_mode_hold":
            raise QualificationError("checkpoint was not called by the frozen ring host")
        values = frame.f_locals
        stream = values["stream"]
        before = _rng_snapshot(stream, cuda)
        original_checkpoint(step, measure)
        if not _rng_same(before, stream, cuda):
            rng_preserved = False
            raise QualificationError("host checkpoint measurement changed training RNG")
        if ring["tensor"] is None:
            raise QualificationError("mode-hold target was not captured")
        current = clock.offset
        shift = torch.tensor(current, dtype=ring["initial"].dtype, device=ring["initial"].device)
        matches = torch.equal(ring["tensor"], ring["initial"] + shift)
        offset_checks.append({"step": step, "offset": list(current), "matches_absolute": bool(matches)})
        if not matches:
            raise QualificationError("ring target does not match the absolute offset")
        if pending_move is not None:
            now = _fingerprint(values["generator"], values["critic"], values["prior"])
            pending_move["displacement_observed"] = now != pending_move.pop("fingerprint")
            pending_move["updates_after"] = _optimizer_counts(tracked)
            pending_move["advanced"] = updates_advanced(
                pending_move["updates_at"], pending_move["updates_after"])
            pending_move = None
        if step in quality_steps:
            snap = _rng_snapshot(stream, cuda)
            with torch.random.fork_rng(devices=rng_fork_devices()):
                measured = measure()
            if not _rng_same(snap, stream, cuda):
                rng_preserved = False
                raise QualificationError("quality measurement changed training RNG")
            point = {"step": step, "modes": measured["modes"], "hq": measured["hq"]}
            diagnostic.append(point)
            if log is not None:
                log({"event": "checkpoint", "step": step, "modes": point["modes"], "hq": point["hq"]})
        change = clock.complete(step)
        if change["shifted"]:
            witness = capture_witness(
                values, sources, completed_step=step, offset=tuple(change["seen"]),
                require_cuda=True,
            )
            witnesses.append({"after_update": step, "witness": witness})
            counts = _optimizer_counts(tracked)
            event_row = {**change, "updates_at": counts, "witness_complete": witness["complete"],
                         "missing_sections": witness["missing_sections"],
                         "fingerprint": _fingerprint(values["generator"], values["critic"], values["prior"])}
            events.append(event_row)
            pending_move = event_row
            with torch.no_grad():
                absolute = torch.tensor(change["absolute_offset"], dtype=ring["initial"].dtype,
                                        device=ring["initial"].device)
                ring["tensor"].copy_(ring["initial"] + absolute)
            if log is not None:
                log({"event": "shift", "step": step, "absolute_offset": change["absolute_offset"],
                     "delta": change["delta"]})
        learner_schedule_view(step)
        capture_now(values, step)

    def observe_plain(step, measure):
        frame = inspect.currentframe().f_back
        if frame is None or frame.f_code.co_name != "train_mode_hold":
            raise QualificationError("checkpoint was not called by the frozen ring host")
        values = frame.f_locals
        stream = values["stream"]
        before = _rng_snapshot(stream, cuda)
        original_checkpoint(step, measure)
        if not _rng_same(before, stream, cuda):
            raise QualificationError("host checkpoint measurement changed training RNG")
        capture_now(values, step)

    started = time.perf_counter()
    applied = []
    with ExitStack() as stack:
        stack.enter_context(patch_budgets(baseline, steps))
        stack.enter_context(torch_patch(mode_hold, "ModeHoldRecipe", extended_recipe))
        if instrument:
            stack.enter_context(torch_patch(mode_hold, "ring_means", retain_ring))
            stack.enter_context(torch_patch(mode_hold, "checkpoint", observe))
        else:
            stack.enter_context(torch_patch(mode_hold, "checkpoint", observe_plain))
        # Fixture init must be the __init__ optimizer_defaults captures.
        stack.enter_context(torch_patch(torch.optim.Adam, "__init__", fixture_init))
        stack.enter_context(torch_patch(torch.optim.Adam, "step", step_optimizer))
        stack.enter_context(optimizer_defaults(
            recipe, applied,
            network_lr_horizon_cap=config.get("network_lr_horizon_cap"),
            network_lr_floor=config.get("network_lr_floor"),
        ))
        control = evaluate.FixedControl(vector_tasks.fixed_policy("cosine"), FROZEN_HORIZON)
        if control.total_steps != FROZEN_HORIZON:
            raise QualificationError("controller received a horizon other than 1200")
        stack.enter_context(control_host_schedules(control))
        result = baseline.run_toy("mode_hold", candidate(recipe), noise_policy=policy)
    if policy.total_steps != FROZEN_HORIZON:
        raise QualificationError("noise policy horizon left the canonical 1200 updates")
    if pending_move is not None:
        raise QualificationError("a target change has no following update to account")
    receipt = policy.receipt()
    if receipt["step_calls"] != steps:
        raise QualificationError("the host did not complete the requested updates")
    final_counts = _optimizer_counts(tracked)
    adam_calls = sum(row["calls"] for row in final_counts)
    if hook_counts is not None:
        assert_hook_accounting(hook_counts, adam_calls)
    if capture_at is not None and len(captured) != 1:
        raise QualificationError("pre-shift state was not captured once")
    if not fixture_proof:
        raise QualificationError("initialization fixture was not applied")
    mechanics_ok = bool(
        rng_preserved
        and offset_checks
        and all(row["matches_absolute"] for row in offset_checks)
        and all(row["delegate_calls"] == row["calls"] == row["updates"] == steps for row in final_counts)
        and len(final_counts) == 2
        and events
        and all(event["advanced"] and event["displacement_observed"] for event in events)
        and control.total_steps == FROZEN_HORIZON
    )
    points = {point["step"]: point for point in diagnostic}
    score = score_plan(plan, points)
    witness_complete = bool(witnesses) and all(item["witness"]["complete"] for item in witnesses)
    if require_complete_witness and not witness_complete:
        mechanics_ok = False
    status = "HARNESS" if not plan.get("pinned") else qualification_status(
        mechanics_ok=mechanics_ok, witness_complete=witness_complete, score=score,
        kind="qualification")
    return {
        "qualification": bool(plan.get("pinned")) and status == "PASS",
        "kind": "qualification" if plan.get("pinned") else "harness_smoke",
        "status": status,
        "plan": {"name": plan.get("name"), "kind": plan["kind"], "pinned": plan.get("pinned"),
                 "total_updates": steps, "sha256": plan.get("sha256")},
        "schedule": binding,
        "controller_total_steps": control.total_steps,
        "noise": {"step_calls": receipt["step_calls"], "horizon": receipt["total_steps"]},
        "device": device_receipt,
        "offset_checks": offset_checks,
        "events": _public_events(events),
        "optimizer_final": final_counts,
        "witnesses": witnesses,
        "witness_complete": witness_complete,
        "score": _compact_score(score),
        "diagnostic": diagnostic,
        "rng_preserved": rng_preserved,
        "mechanics_ok": mechanics_ok,
        "seconds": time.perf_counter() - started,
        "host_seconds": result.get("seconds"),
        "instrument": instrument,
        "hooks": None if hook_counts is None else dict(hook_counts),
        "adam_calls": adam_calls,
        "fixture": fixture_receipt,
        "fixture_applied": fixture_proof,
        "frozen_runtime": {"root": str(runtime["root"]), "files": runtime["files"]},
        "captured_witness": captured[0] if captured else None,
        "captured_step_hashes": captured_steps[0] if captured_steps else [],
        "candidate_qualification_ready": False,
    }


def _public_events(events: list[dict]) -> list[dict]:
    public = []
    for event in events:
        public.append({
            "after_update": event["after_update"],
            "seen": event["seen"],
            "absolute_offset": event["absolute_offset"],
            "delta": event["delta"],
            "updates_at": event["updates_at"],
            "updates_after": event.get("updates_after"),
            "advanced": event.get("advanced"),
            "displacement_observed": event.get("displacement_observed"),
            "witness_complete": event["witness_complete"],
            "missing_sections": event["missing_sections"],
        })
    return public


def _compact_score(score: dict) -> dict:
    def shrink(row):
        keep = ("role", "first", "last", "stride", "count", "after_update", "checks",
                "observed", "passing_checks", "failing_steps", "min_modes", "min_hq",
                "passing_suffix", "stable_from_step", "delay_updates", "pass_all",
                "missing_steps")
        return {key: row[key] for key in keep if key in row}
    prefix = {"stable": [shrink(row) for row in score["prefix"]["stable"]],
              "deadlines": [shrink(row) for row in score["prefix"]["deadlines"]]}
    extension = score["extension"]
    if extension is not None:
        extension = {"stable": [shrink(row) for row in extension["stable"]],
                     "deadlines": [shrink(row) for row in extension["deadlines"]]}
    return {"prefix": prefix, "extension": extension}


@contextmanager
def patch_budgets(baseline, steps: int):
    from unittest.mock import patch
    with patch.dict(baseline.BUDGETS, {"mode_hold": steps}):
        yield


@contextmanager
def torch_patch(module, name, value):
    from unittest.mock import patch
    with patch.object(module, name, value):
        yield


def smoke_plan() -> dict:
    """Three host updates. This plan is not a declared protocol."""
    document = {
        "name": "harness_smoke_v1",
        "total_updates": 3,
        "initial_target_offset": [0.0, 0.0],
        "target_changes": [
            {"after_update": 1, "absolute_offset": [1.0, 0.0], "deadline_updates": 1,
             "deadline_checks": {"first": 2, "last": 2, "stride": 1, "count": 1}},
            {"after_update": 2, "absolute_offset": [1.0, 1.0], "deadline_updates": 1,
             "deadline_checks": {"first": 3, "last": 3, "stride": 1, "count": 1}},
        ],
        "required_stable_windows": [{"first": 1, "last": 1, "stride": 1}],
        "quality_at_every_required_check": {"live_modes": 8, "min_live_hq": 0.9},
    }
    plan = compile_stress(document)
    plan["pinned"] = False
    plan["kind"] = "stress"
    return plan


def _point(step: int, modes: int = 8, hq: float = 0.95) -> dict:
    return {"step": step, "modes": modes, "hq": hq}


def run_self_tests() -> list[dict]:
    """CPU checks. None of these qualify a candidate."""
    rows = []

    def check(gate: str, fn):
        started = time.perf_counter()
        try:
            metrics = fn()
            status = "PASS"
            error = None
        except Exception as exc:
            metrics = {}
            status = "ERROR"
            error = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
        rows.append({
            "candidate": "regression",
            "gate": gate,
            "status": status,
            "seconds": round(time.perf_counter() - started, 6),
            "metrics": metrics,
            "error": error,
        })

    def protocol_windows():
        stress, long_term = load_pinned_plans()
        stable_counts = [window["count"] for window in stress["stable_windows"]]
        deadline_counts = [event["deadline"]["count"] for event in stress["events"]]
        extension_counts = [window["count"] for window in long_term["extension_windows"]]
        third = long_term["extension_deadlines"][0]["count"]
        expected = {
            "stable": [5, 480, 60],
            "deadlines": [81, 81],
            "extension": [1800, 180],
            "third": 81,
            "prefix": 707,
            "extension_checks": 2061,
        }
        if stable_counts != expected["stable"] or deadline_counts != expected["deadlines"]:
            raise QualificationError(f"stress windows {stable_counts} {deadline_counts}")
        if extension_counts != expected["extension"] or third != expected["third"]:
            raise QualificationError(f"extension windows {extension_counts} {third}")
        if len(stress["prefix_steps"]) != expected["prefix"]:
            raise QualificationError("prefix check count changed")
        if len(long_term["extension_steps"]) != expected["extension_checks"]:
            raise QualificationError("extension check count changed")
        if long_term["prefix_steps"] != stress["prefix_steps"]:
            raise QualificationError("long-term prefix steps differ from the stress plan")
        if set(long_term["extension_steps"]) & set(long_term["prefix_steps"]):
            raise QualificationError("prefix and extension overlap")
        return {"stress_checks": expected["prefix"], "extension_checks": expected["extension_checks"],
                "stable": stable_counts, "deadlines": deadline_counts,
                "extension": extension_counts, "third_deadline": third}

    def absolute_versus_incremental():
        stress, long_term = load_pinned_plans()
        stress_seen = simulate_offsets(stress["events"], stress["total_updates"])
        long_seen = simulate_offsets(long_term["events"], 27001)
        if stress_seen[5999] != (0.0, 0.0) or stress_seen[6000] != (1.0, 0.0):
            raise QualificationError("first absolute change is not applied after update 6000")
        if stress_seen[7799] != (1.0, 0.0) or stress_seen[8999] != (1.0, 1.0):
            raise QualificationError("second absolute change is not [1, 1]")
        if long_seen[26999] != (1.0, 1.0) or long_seen[27000] != (0.0, 1.0):
            raise QualificationError("third absolute change is not [0, 1]")
        incremental = (0.0, 0.0)
        for event in long_term["events"]:
            incremental = (incremental[0] + event["absolute_offset"][0],
                           incremental[1] + event["absolute_offset"][1])
        if incremental == long_seen[-1]:
            raise QualificationError("absolute and incremental offsets were not distinguished")
        clock = OffsetClock(stress["events"])
        for step in range(1, 9001):
            clock.complete(step)
        deltas = [tuple(row["delta"]) for row in clock.applied]
        if deltas != [(1.0, 0.0), (0.0, 1.0)]:
            raise QualificationError(f"stress deltas {deltas}")
        return {"stress_final": list(stress_seen[-1]), "long_term_at_27001": list(long_seen[-1]),
                "incremental_final": list(incremental), "stress_deltas": [list(item) for item in deltas]}

    def event_ordering():
        stress, _long_term = load_pinned_plans()
        actions = []
        clock = OffsetClock(stress["events"])
        for step in (5999, 6000, 6001, 7799, 7800, 7801):
            actions.append(("measure", step, clock.offset))
            change = clock.complete(step)
            if change["shifted"]:
                actions.append(("shift", step, tuple(change["absolute_offset"])))
        expected = [
            ("measure", 5999, (0.0, 0.0)),
            ("measure", 6000, (0.0, 0.0)),
            ("shift", 6000, (1.0, 0.0)),
            ("measure", 6001, (1.0, 0.0)),
            ("measure", 7799, (1.0, 0.0)),
            ("measure", 7800, (1.0, 0.0)),
            ("shift", 7800, (1.0, 1.0)),
            ("measure", 7801, (1.0, 1.0)),
        ]
        if actions != expected:
            raise QualificationError("event order changed")
        return {"actions": len(actions)}

    def rng_preservation():
        torch.manual_seed(1234)
        stream = torch.Generator().manual_seed(7)
        before_cpu = torch.get_rng_state().clone()
        before_stream = stream.get_state().clone()
        with torch.random.fork_rng(devices=[]):
            torch.randn(8)
            torch.randn(4, generator=torch.Generator().manual_seed(99))
        if not torch.equal(before_cpu, torch.get_rng_state()):
            raise QualificationError("fork_rng changed the CPU RNG")
        if not torch.equal(before_stream, stream.get_state()):
            raise QualificationError("an isolated generator draw changed the host stream")
        torch.randn(1)
        if torch.equal(before_cpu, torch.get_rng_state()):
            raise QualificationError("the unisolated draw did not advance the CPU RNG")
        return {"fork_preserves_cpu": True, "fork_preserves_host_stream": True}

    def update_accounting():
        before = [{"role": "d", "calls": 4, "delegate_calls": 4, "updates": 4},
                  {"role": "g", "calls": 4, "delegate_calls": 4, "updates": 4}]
        after = [{"role": "g", "calls": 5, "delegate_calls": 5, "updates": 5},
                 {"role": "d", "calls": 5, "delegate_calls": 5, "updates": 5}]
        stalled = [{"role": "d", "calls": 5, "delegate_calls": 4, "updates": 4},
                   {"role": "g", "calls": 5, "delegate_calls": 4, "updates": 4}]
        if not updates_advanced(before, after):
            raise QualificationError("continued Adam updates were rejected")
        if updates_advanced(before, before) or updates_advanced(before, stalled):
            raise QualificationError("stalled or skipped updates were accepted")
        return {"advanced": True, "stalled_rejected": True}

    def witness_identity():
        generator = torch.nn.Linear(2, 2, bias=False)
        critic = torch.nn.Linear(2, 2, bias=False)
        prior = torch.nn.Linear(2, 2, bias=False)
        prior.z = prior.weight
        opt_g = torch.optim.Adam(list(generator.parameters()) + list(prior.parameters()), lr=0.01)
        opt_d = torch.optim.Adam(critic.parameters(), lr=0.01)
        for param in list(generator.parameters()) + list(prior.parameters()):
            param.grad = torch.ones_like(param)
        opt_g.step()
        for param in critic.parameters():
            param.grad = torch.ones_like(param)
        opt_d.step()
        sources = SimpleNamespace(
            latent=SimpleNamespace(stats={id(prior.weight): [2, 4]}),
            response=SimpleNamespace(
                prior_ids={id(prior.weight)},
                previous={(id(opt_g), 0): torch.arange(3, dtype=torch.float32)},
            ),
            mechanism=SimpleNamespace(_state={
                "pending": False,
                "depth": 1,
                "lr_max": 0.01,
                "lr_last": 0.005,
                "critic": id(opt_d),
                "ema": [critic.weight.detach().clone()],
                "clips": [],
            }),
        )
        frame = {
            "generator": generator, "critic": critic, "prior": prior,
            "opt_g": opt_g, "opt_d": opt_d,
            "ema_g": [param.detach().clone() for param in generator.parameters()],
            "ema_z": prior.z.detach().clone(),
            "stream": torch.Generator().manual_seed(1),
            "means": torch.zeros(2, 2),
        }
        full = capture_witness(frame, sources, completed_step=1, offset=(0.0, 0.0), require_cuda=False)
        again = capture_witness(frame, sources, completed_step=1, offset=(0.0, 0.0), require_cuda=False)
        if not full["complete"] or full["identity_sha256"] is None:
            raise QualificationError("complete witness was labeled partial: "
                                     + json.dumps(full["missing_sections"] + full["partial_sections"]))
        if full["identity_sha256"] != again["identity_sha256"] or full["partial_sha256"] is not None:
            raise QualificationError("witness hash is unstable or double-labeled")
        text = json.dumps(full)
        for raw in (id(prior.weight), id(opt_d), id(opt_g)):
            if str(raw) in text:
                raise QualificationError("witness leaked a python id")
        if full["sections"]["controller"]["state"]["pending"] is not False:
            raise QualificationError("controller pending was dropped")
        if full["sections"]["controller"]["state"]["depth"] != 1:
            raise QualificationError("controller depth was dropped")
        if full["sections"]["latent_stats"]["rows"][0]["path"] != "g/0/1":
            raise QualificationError("latent stats were not normalized")
        if full["sections"]["response"]["prior_membership"] != ["g/0/1"]:
            raise QualificationError("prior membership was not normalized")
        bare = capture_witness(frame, None, completed_step=1, offset=(0.0, 0.0), require_cuda=False)
        if bare["complete"] or bare["identity_sha256"] is not None:
            raise QualificationError("partial witness was labeled complete")
        if set(bare["missing_sections"]) != {"controller", "latent_stats", "response"}:
            raise QualificationError("partial witness hid which sections are missing")
        cuda_required = capture_witness(frame, sources, completed_step=1, offset=(0.0, 0.0), require_cuda=True)
        if cuda_required["complete"]:
            raise QualificationError("CPU tensors were accepted as a CUDA witness")
        bad_sources = SimpleNamespace(
            latent=SimpleNamespace(stats={0: [1, 1]}),
            response=sources.response,
            mechanism=sources.mechanism,
        )
        unmapped = capture_witness(frame, bad_sources, completed_step=1, offset=(0.0, 0.0), require_cuda=False)
        if unmapped["complete"] or "latent_stats" not in unmapped["partial_sections"]:
            raise QualificationError("unmapped latent stats were treated as complete")
        return {"complete_sha256": full["identity_sha256"], "partial_labeled": True,
                "cpu_rejected_for_cuda": True}

    def fail_closed_provenance():
        import tempfile
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            payloads = {
                "config.json": b'{"name":"fake"}\n',
                "mechanism.py": b"_state = {'pending': False, 'depth': 0}\n",
                "response.py": b"prior_ids=set()\nprevious={}\n",
                "latent.py": b"stats = {}\n",
            }
            for name, payload in payloads.items():
                (root / name).write_bytes(payload)
            files = {name: sha256_bytes(payload) for name, payload in payloads.items()}
            (root / "provenance.json").write_text(json.dumps({"candidate": "fake", "files": files}) + "\n")
            with installed_candidate(root):
                pass
            broken = json.loads((root / "provenance.json").read_text())
            broken["files"]["mechanism.py"] = "0" * 64
            (root / "provenance.json").write_text(json.dumps(broken) + "\n")
            try:
                verify_candidate(root)
            except QualificationError:
                pass
            else:
                raise QualificationError("hash mismatch was accepted")
            (root / "provenance.json").unlink()
            try:
                verify_candidate(root)
            except QualificationError:
                pass
            else:
                raise QualificationError("missing provenance was accepted")
        try:
            load_pinned_plans()
        except QualificationError as exc:
            raise QualificationError("pinned protocols failed to load") from exc
        return {"hash_mismatch_rejected": True, "missing_manifest_rejected": True}

    def schedule_horizon():
        config = {"network_lr_horizon_cap": 1600, "total_steps": 7000}
        short = schedule_binding(config, 9000)
        long = schedule_binding(config, 30000)
        if short["controller_total_steps"] != FROZEN_HORIZON or long["noise_horizon"] != FROZEN_HORIZON:
            raise QualificationError("episode length entered the schedule")
        short_body = {key: value for key, value in short.items() if key != "episode_length"}
        long_body = {key: value for key, value in long.items() if key != "episode_length"}
        if short_body != long_body or short["episode_length"] != 9000 or long["episode_length"] != 30000:
            raise QualificationError("episode length changed the schedule binding")
        if short["controller_total_steps"] != long["controller_total_steps"]:
            raise QualificationError("declared horizon changed the controller")
        if short["network_lr_horizon_cap"] != 1600 or short["episode_length_is_schedule_input"] is not False:
            raise QualificationError("retained cap was rewritten")
        leaked = dict(learner_schedule_view(12))
        leaked["total_updates"] = 30000
        try:
            leaked_keys = FORBIDDEN_LEARNER_KEYS & set(leaked)
            if not leaked_keys:
                raise QualificationError("forbidden key set missed total_updates")
        except QualificationError:
            raise
        view = learner_schedule_view(12)
        if set(view) != {"completed_updates"}:
            raise QualificationError("learner view carries more than the host step")
        return {"controller_total_steps": short["controller_total_steps"],
                "noise_horizon": short["noise_horizon"],
                "network_lr_horizon_cap": 1600,
                "episode_lengths_recorded": [9000, 30000]}

    def prefix_scoring():
        stress, long_term = load_pinned_plans()
        points = {step: _point(step) for step in long_term["prefix_steps"] + long_term["extension_steps"]}
        clean = score_plan(long_term, points)
        if not all(row["pass_all"] for row in clean["prefix"]["stable"] + clean["prefix"]["deadlines"]):
            raise QualificationError("intact prefix did not pass")
        if not all(row["pass_all"] for row in clean["extension"]["stable"] + clean["extension"]["deadlines"]):
            raise QualificationError("intact extension did not pass")
        broken = dict(points)
        broken[6400] = _point(6400, modes=0, hq=0.0)
        broken[27400] = _point(27400, modes=1, hq=0.2)
        scored = score_plan(long_term, broken)
        prefix_deadline = scored["prefix"]["deadlines"][0]
        extension_deadline = scored["extension"]["deadlines"][0]
        if prefix_deadline["pass_all"] or 6400 not in prefix_deadline["failing_steps"]:
            raise QualificationError("prefix failure was hidden")
        if extension_deadline["pass_all"] or 27400 not in extension_deadline["failing_steps"]:
            raise QualificationError("extension failure was hidden")
        if not all(row["pass_all"] for row in scored["prefix"]["stable"]):
            raise QualificationError("a deadline miss failed an unrelated stable window")
        status = qualification_status(mechanics_ok=True, witness_complete=False, score=scored,
                                      kind="qualification")
        if status != "ERROR":
            raise QualificationError("incomplete witness produced a non-error status")
        passed = qualification_status(mechanics_ok=True, witness_complete=True, score=clean,
                                      kind="qualification")
        if passed != "PASS":
            raise QualificationError("complete matching windows did not pass")
        return {"prefix_failure_step": 6400, "extension_failure_step": 27400,
                "partial_witness_status": status}

    check("protocol_windows", protocol_windows)
    check("absolute_versus_incremental", absolute_versus_incremental)
    check("event_ordering", event_ordering)
    check("rng_preservation", rng_preservation)
    check("update_accounting", update_accounting)
    check("witness_identity", witness_identity)
    check("fail_closed_provenance", fail_closed_provenance)
    check("schedule_horizon", schedule_horizon)
    check("prefix_scoring", prefix_scoring)
    return rows


def _write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def append_ledger(path: Path, row: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(row, sort_keys=True, allow_nan=False) + "\n")


def _ledger_from_tests(rows: list[dict], artifact: str | None) -> list[dict]:
    emitted = []
    for row in rows:
        item = {
            "candidate": "regression",
            "gate": row["gate"],
            "status": row["status"],
            "seconds": row["seconds"],
            "metrics": row["metrics"],
            "artifact": artifact,
        }
        if row.get("error"):
            item["metrics"] = {**row["metrics"], "error": row["error"]}
        emitted.append(item)
    return emitted


def run_smoke_host(config_path: Path, log=None) -> dict:
    config = json.loads(config_path.read_bytes())
    plan = smoke_plan()
    result = run_frozen_host(plan, config, sources=None, require_complete_witness=False, log=log)
    # The move check is recorded by mutation of pending_move, which is not copied
    # onto events. Re-read mechanics from offset checks, counts, and witnesses.
    mechanics = {
        "rng_preserved": result["rng_preserved"],
        "absolute_matches": [row["matches_absolute"] for row in result["offset_checks"]],
        "optimizer_final": result["optimizer_final"],
        "controller_total_steps": result["controller_total_steps"],
        "noise_horizon": result["noise"]["horizon"],
        "noise_steps": result["noise"]["step_calls"],
        "witness_complete": result["witness_complete"],
        "missing_sections": result["witnesses"][0]["witness"]["missing_sections"] if result["witnesses"] else [],
        "events": result["events"],
        "quality_pass_all": all(
            row["pass_all"] for row in result["score"]["prefix"]["stable"] + result["score"]["prefix"]["deadlines"]
        ),
    }
    expected_offsets = {1: [0.0, 0.0], 2: [1.0, 0.0], 3: [1.0, 1.0]}
    offsets_ok = all(row["offset"] == expected_offsets[row["step"]] and row["matches_absolute"]
                     for row in result["offset_checks"])
    counts_ok = (
        len(result["optimizer_final"]) == 2
        and all(row["calls"] == row["delegate_calls"] == row["updates"] == 3
                for row in result["optimizer_final"])
    )
    deltas = [event["delta"] for event in result["events"]]
    witness_partial = (
        result["witnesses"]
        and all(not item["witness"]["complete"] for item in result["witnesses"])
        and all(item["witness"]["identity_sha256"] is None for item in result["witnesses"])
        and all(set(item["witness"]["missing_sections"]) == {"controller", "latent_stats", "response"}
                for item in result["witnesses"])
        and all(not item["witness"]["partial_sections"] for item in result["witnesses"])
    )
    moved = all(event.get("advanced") and event.get("displacement_observed") for event in result["events"])
    mechanics_ok = bool(
        result["rng_preserved"] and offsets_ok and counts_ok and moved
        and deltas == [[1.0, 0.0], [0.0, 1.0]]
        and result["controller_total_steps"] == FROZEN_HORIZON
        and result["noise"]["horizon"] == FROZEN_HORIZON
        and result["noise"]["step_calls"] == 3
        and witness_partial
        and result["qualification"] is False
    )
    result["smoke_mechanics_ok"] = mechanics_ok
    result["smoke_metrics"] = {
        "qualification": False,
        "quality_pass_all": mechanics["quality_pass_all"],
        "rng_preserved": result["rng_preserved"],
        "absolute_offsets": [row["offset"] for row in result["offset_checks"]],
        "deltas": deltas,
        "advanced_after_changes": [bool(event.get("advanced")) for event in result["events"]],
        "displacement_after_changes": [bool(event.get("displacement_observed")) for event in result["events"]],
        "optimizer_final": result["optimizer_final"],
        "controller_total_steps": result["controller_total_steps"],
        "noise_horizon": result["noise"]["horizon"],
        "witness_complete": False,
        "missing_sections": mechanics["missing_sections"],
        "schedule": result["schedule"],
    }
    result["status"] = "PASS" if mechanics_ok else "FAIL"
    return result


def _expect_qualification_error(fn, label: str) -> None:
    try:
        fn()
    except QualificationError:
        return
    raise QualificationError(label + " was accepted")


def run_installation_checks() -> list[dict]:
    """CPU checks that the repaired entry point fails closed. No training."""
    rows = []

    def check(gate: str, fn):
        started = time.perf_counter()
        try:
            metrics = fn()
            status = "PASS"
            error = None
        except Exception as exc:
            metrics = {}
            status = "ERROR"
            error = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
        rows.append({
            "candidate": "regression",
            "gate": gate,
            "status": status,
            "seconds": round(time.perf_counter() - started, 6),
            "metrics": metrics,
            "error": error,
        })

    def scalar_tensor_hash():
        scalar = torch.zeros((), dtype=torch.float32)
        try:
            scalar.view(torch.uint8)
        except RuntimeError:
            rejected = True
        else:
            raise QualificationError("a 0-dim float accepted view(torch.uint8)")
        digest = digest_tensor(scalar)
        same = digest_tensor(torch.zeros(1, dtype=torch.float32))
        other = digest_tensor(torch.ones((), dtype=torch.float32))
        step = torch.tensor(3.0)
        if digest != same or digest == other:
            raise QualificationError("scalar hash does not follow the flattened bytes")
        if digest_tensor(step) != digest_tensor(torch.tensor([3.0])):
            raise QualificationError("scalar and length-1 hashes diverged")
        return {"direct_view_rejected": rejected, "zero_sha256": digest}

    def reject_missing_hooks():
        sources = SimpleNamespace(
            latent=SimpleNamespace(stats={}),
            response=SimpleNamespace(prior_ids=set(), previous={}),
            mechanism=SimpleNamespace(_state={"pending": False}),
        )
        _expect_qualification_error(lambda: require_training_hooks(sources), "missing begin/end hooks")
        return {"missing_hooks_rejected": True}

    def reject_missing_fixture():
        missing = Path("/tmp/cq-missing-initialization-fixture.pt")
        if missing.exists():
            raise QualificationError("negative fixture path already exists")
        _expect_qualification_error(
            lambda: verify_named_fixture(missing, "ab" * 32), "missing fixture")
        import tempfile
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "initial-values.pt"
            path.write_bytes(b"not-a-fixture")
            _expect_qualification_error(
                lambda: verify_named_fixture(path, "0" * 64), "fixture hash mismatch")
        real, receipt = load_pinned_fixture("mode_hold")
        if not real or receipt["sha256"] != gap_manifest()["fixtures"]["mode_hold"]["sha256"]:
            raise QualificationError("pinned mode_hold fixture did not verify")
        return {"missing_fixture_rejected": True, "hash_mismatch_rejected": True,
                "pinned_fixture_sha256": receipt["sha256"], "optimizers": receipt["optimizers"]}

    def reject_runtime_mismatch():
        runtime = select_frozen_runtime()
        root = runtime["root"]

        def mismatch():
            check_runtime_files(root, {"benchmarks/locked_shared/mode_hold.py": "0" * 64})

        _expect_qualification_error(mismatch, "frozen runtime hash mismatch")
        return {"root": str(root), "files": runtime["files"], "mismatch_rejected": True,
                "verified": True}

    def witness_state_sensitivity():
        generator = torch.nn.Linear(2, 2, bias=False)
        generator.register_buffer("mark", torch.zeros(2))
        critic = torch.nn.Linear(2, 2, bias=False)
        prior = torch.nn.Linear(2, 2, bias=False)
        prior.z = prior.weight
        opt_g = torch.optim.Adam(list(generator.parameters()) + list(prior.parameters()), lr=0.01)
        opt_d = torch.optim.Adam(critic.parameters(), lr=0.01)
        for param in list(generator.parameters()) + list(prior.parameters()) + list(critic.parameters()):
            param.grad = torch.ones_like(param)
        opt_g.step()
        opt_d.step()
        anchor = prior.weight
        opt_g.state[anchor]["anchor_prev"] = torch.zeros_like(anchor)
        sources = SimpleNamespace(
            latent=SimpleNamespace(stats={id(anchor): [1, 2]}, receipt={}),
            response=SimpleNamespace(prior_ids={id(anchor)}, previous={}, receipt={}),
            mechanism=SimpleNamespace(_state={"pending": False, "depth": 0}, receipt={}),
            checkpoint=SimpleNamespace(optimizers=[], frames={}),
        )

        def frame():
            return {
                "generator": generator, "critic": critic, "prior": prior,
                "opt_g": opt_g, "opt_d": opt_d,
                "ema_g": [param.detach().clone() for param in generator.parameters()],
                "ema_z": prior.z.detach().clone(),
                "stream": torch.Generator().manual_seed(1),
                "means": torch.zeros(2, 2),
            }

        base = capture_witness(frame(), sources, completed_step=1, offset=(0.0, 0.0), require_cuda=False)
        if not base["complete"]:
            raise QualificationError(
                "sensitivity baseline was partial: "
                + ",".join(base["missing_sections"] + base["partial_sections"]))
        if not any("anchor_prev" in (row.get("state") or {})
                   for row in base["sections"]["adam"]["parameters"]):
            raise QualificationError("anchor_prev was omitted from optimizer state")
        step = next(row["state"]["step"] for row in base["sections"]["adam"]["parameters"]
                    if row["path"].startswith("g/"))
        if step.get("dtype") != "torch.float32" or "device" not in step or "sha256" not in step:
            raise QualificationError("step tensor dtype/device was dropped")
        opt_g.state[anchor]["anchor_prev"].fill_(1)
        changed = capture_witness(frame(), sources, completed_step=1, offset=(0.0, 0.0), require_cuda=False)
        if changed["identity_sha256"] == base["identity_sha256"]:
            raise QualificationError("anchor_prev mutation left the witness unchanged")
        opt_g.state[anchor]["anchor_prev"].zero_()
        opt_g.param_groups[0]["weight_decay"] = 0.5
        decayed = capture_witness(frame(), sources, completed_step=1, offset=(0.0, 0.0), require_cuda=False)
        if decayed["identity_sha256"] == base["identity_sha256"]:
            raise QualificationError("weight_decay mutation left the witness unchanged")
        opt_g.param_groups[0]["weight_decay"] = 0.0
        generator.mark.fill_(1)
        buffered = capture_witness(frame(), sources, completed_step=1, offset=(0.0, 0.0), require_cuda=False)
        if buffered["identity_sha256"] == base["identity_sha256"]:
            raise QualificationError("buffer mutation left the witness unchanged")
        unknown_sources = SimpleNamespace(
            latent=sources.latent, response=sources.response, checkpoint=sources.checkpoint,
            mechanism=SimpleNamespace(_state=sources.mechanism._state, receipt={}, extra={"hidden": 1}),
        )
        unknown = capture_witness(frame(), unknown_sources, completed_step=1, offset=(0.0, 0.0),
                                  require_cuda=False)
        if unknown["complete"] or "policy_modules" not in unknown["partial_sections"]:
            raise QualificationError("unknown policy state was accepted")
        return {"anchor_prev_changes_hash": True, "weight_decay_changes_hash": True,
                "buffer_changes_hash": True, "unknown_state_rejected": True,
                "step_dtype": step["dtype"], "step_device": step["device"]}

    check("scalar_tensor_hash", scalar_tensor_hash)
    check("reject_missing_hooks", reject_missing_hooks)
    check("reject_missing_fixture", reject_missing_fixture)
    check("frozen_runtime_pin", reject_runtime_mismatch)
    check("witness_state_sensitivity", witness_state_sensitivity)
    return rows


def _learner_calls(sources) -> dict:
    return {
        "latent_calls": int(sources.latent.receipt.get("calls", 0)),
        "latent_scoped_calls": int(sources.latent.receipt.get("scoped_calls", 0)),
        "response_calls": int(sources.response.receipt.get("calls", 0)),
    }


def _section_sha(witness: dict) -> dict:
    return {
        name: sha256_bytes(json.dumps(section, sort_keys=True, allow_nan=False).encode())
        for name, section in witness["sections"].items()
    }


def run_identity_prefix(updates: int = 2, log=None) -> dict:
    """Same fixture, source, and RNG. Instrumentation on and off, before any shift."""
    assert_execution_environment()
    runtime = select_frozen_runtime()
    sources = load_pinned_k3p()
    config = json.loads((k3p_source_dir() / "config.json").read_bytes())
    plan = prefix_plan(updates)
    arms = {}
    previous = _learner_calls(sources)
    for instrument in (False, True):
        if log is not None:
            log({"event": "identity_arm", "instrument": instrument, "updates": updates})
        before = _learner_calls(sources)
        result = run_frozen_host(
            plan, config, sources=sources, require_complete_witness=False,
            log=log, instrument=instrument, capture_at=updates)
        after = _learner_calls(sources)
        witness = result["captured_witness"]
        arms[str(instrument)] = {
            "instrument": instrument,
            "hooks": result["hooks"],
            "adam_calls": result["adam_calls"],
            "optimizer_final": result["optimizer_final"],
            "schedule": result["schedule"],
            "controller_total_steps": result["controller_total_steps"],
            "noise": result["noise"],
            "fixture": result["fixture"],
            "frozen_runtime": result["frozen_runtime"],
            "offset_checks": result["offset_checks"],
            "events": result["events"],
            "captured_step_hashes": result["captured_step_hashes"],
            "witness_complete": bool(witness and witness.get("complete")),
            "identity_sha256": None if not witness else witness.get("identity_sha256"),
            "missing_sections": [] if not witness else witness.get("missing_sections"),
            "partial_sections": [] if not witness else witness.get("partial_sections"),
            "section_sha256": {} if not witness else _section_sha(witness),
            "learner_call_delta": {key: after[key] - before[key] for key in after},
            "qualification": result["qualification"],
            "seconds": result["seconds"],
        }
        previous = after
    off = arms["False"]
    on = arms["True"]
    failures = []
    if not off["witness_complete"] or not on["witness_complete"]:
        failures.append("witness incomplete")
    if off["identity_sha256"] is None or off["identity_sha256"] != on["identity_sha256"]:
        failures.append("pre-shift identity diverged")
    if not off["captured_step_hashes"] or off["captured_step_hashes"] != on["captured_step_hashes"]:
        failures.append("CUDA scalar Adam steps diverged")
    if off["hooks"] != on["hooks"] or not off["hooks"]:
        failures.append("hook counts diverged")
    else:
        for key, value in off["hooks"].items():
            if value != off["adam_calls"] or value <= 0:
                failures.append(f"hook accounting {key}")
                break
    if off["events"] or on["events"]:
        failures.append("target change happened inside the prefix")
    if on["offset_checks"] and any(row["offset"] != [0.0, 0.0] for row in on["offset_checks"]):
        failures.append("instrumented prefix moved the target")
    if off["controller_total_steps"] != FROZEN_HORIZON or on["noise"]["horizon"] != FROZEN_HORIZON:
        failures.append("episode length entered the schedule")
    if off["qualification"] or on["qualification"]:
        failures.append("prefix was labeled as candidate qualification")
    if off["frozen_runtime"]["root"] != str(runtime["root"]):
        failures.append("host was not the pinned runtime")
    status = "PASS" if not failures else "FAIL"
    return {
        "qualification": False,
        "candidate_qualification_ready": False,
        "kind": "identity_prefix",
        "status": status,
        "failures": failures,
        "updates": updates,
        "arms": arms,
        "learner_calls_after_both": previous,
        "note": (
            "Hook wrappers are counted on every Adam step. A matching hash alone "
            "does not pass: begin/end must be invoked even when their first-step "
            "tensor effect is zero. Stress and 30000 qualification were not run."
        ),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--installation-checks", action="store_true")
    parser.add_argument("--identity-prefix", action="store_true")
    parser.add_argument("--smoke-host", action="store_true")
    parser.add_argument("--protocol", choices=("stress", "long-term"))
    parser.add_argument("--candidate", type=Path)
    parser.add_argument("--check-candidate", type=Path)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--ledger", type=Path)
    argv = list(sys.argv[1:] if argv is None else argv)
    args = parser.parse_args(argv)
    modes = sum(bool(item) for item in (
        args.self_test, args.installation_checks, args.identity_prefix,
        args.smoke_host, args.protocol, args.check_candidate))
    if modes != 1:
        parser.error("choose one of --self-test, --installation-checks, --identity-prefix, "
                     "--smoke-host, --check-candidate, or --protocol")
    if args.smoke_host or args.identity_prefix or args.protocol:
        relaunch_on_frozen_runtime(argv)
    if args.self_test:
        rows = run_self_tests()
        payload = {"qualification": False, "kind": "harness_self_test", "tests": rows,
                   "source_sha256": source_hashes(),
                   "status": "PASS" if all(row["status"] == "PASS" for row in rows) else "FAIL"}
        artifact = None
        if args.output:
            artifact = str(args.output)
            _write_json(args.output, payload)
        if args.ledger:
            for row in _ledger_from_tests(rows, artifact):
                append_ledger(args.ledger, row)
        print(json.dumps({"event": "self_test", "status": payload["status"],
                          "passed": sum(row["status"] == "PASS" for row in rows),
                          "total": len(rows)}, sort_keys=True), flush=True)
        return 0 if payload["status"] == "PASS" else 1
    if args.check_candidate:
        manifest = verify_candidate(args.check_candidate)
        print(json.dumps({"event": "candidate", "status": "PASS", "files": sorted(manifest["files"])},
                         sort_keys=True), flush=True)
        return 0
    if args.installation_checks:
        rows = run_installation_checks()
        payload = {"qualification": False, "candidate_qualification_ready": False,
                   "kind": "installation_checks", "tests": rows,
                   "status": "PASS" if all(row["status"] == "PASS" for row in rows) else "FAIL"}
        artifact = None
        if args.output:
            artifact = str(args.output)
            _write_json(args.output, payload)
        if args.ledger:
            for row in _ledger_from_tests(rows, artifact):
                append_ledger(args.ledger, row)
        print(json.dumps({"event": "installation_checks", "status": payload["status"],
                          "passed": sum(row["status"] == "PASS" for row in rows),
                          "total": len(rows)}, sort_keys=True), flush=True)
        return 0 if payload["status"] == "PASS" else 1
    if args.identity_prefix:
        if args.output is None:
            parser.error("--identity-prefix requires --output")
        started = time.perf_counter()

        def log(row):
            print(json.dumps(row, sort_keys=True, allow_nan=False), flush=True)

        try:
            result = run_identity_prefix(log=log)
            result["evaluator_sha256"] = sha256_file(Path(__file__).resolve())
            _write_json(args.output, result)
            status = result["status"]
            metrics = {
                "qualification": False,
                "candidate_qualification_ready": False,
                "failures": result["failures"],
                "identity_sha256": result["arms"]["False"]["identity_sha256"],
                "hooks": result["arms"]["False"]["hooks"],
                "adam_calls": result["arms"]["False"]["adam_calls"],
                "step_hashes": len(result["arms"]["False"]["captured_step_hashes"]),
                "learner_call_delta_off": result["arms"]["False"]["learner_call_delta"],
                "learner_call_delta_on": result["arms"]["True"]["learner_call_delta"],
                "frozen_runtime": result["arms"]["False"]["frozen_runtime"],
                "fixture": result["arms"]["False"]["fixture"]["sha256"],
                "stress_protocol_9000": "NOT_RUN",
                "long_term_30000": "NOT_RUN",
            }
        except Exception as exc:
            status = "ERROR"
            metrics = {"qualification": False, "candidate_qualification_ready": False,
                       "error": f"{type(exc).__name__}: {exc}"}
            _write_json(args.output, {"qualification": False, "candidate_qualification_ready": False,
                                      "kind": "identity_prefix", "status": "ERROR",
                                      "error": metrics["error"] + "\n" + traceback.format_exc()})
        if args.ledger:
            append_ledger(args.ledger, {
                "candidate": "regression",
                "gate": "identity_prefix",
                "status": status,
                "seconds": round(time.perf_counter() - started, 6),
                "metrics": metrics,
                "artifact": str(args.output),
            })
        print(json.dumps({"event": "identity_prefix", "status": status, "qualification": False,
                          "candidate_qualification_ready": False}, sort_keys=True), flush=True)
        return 0 if status == "PASS" else 1
    if args.smoke_host:
        if args.output is None:
            parser.error("--smoke-host requires --output")
        config_path = args.config or (ROOT / "reports/toy100/gap-fill-20260925/sources/k3p/config.json")
        started = time.perf_counter()

        def log(row):
            print(json.dumps(row, sort_keys=True, allow_nan=False), flush=True)

        try:
            result = run_smoke_host(config_path, log=log)
            result["source_sha256"] = source_hashes()
            result["config_path"] = str(config_path)
            result["config_sha256"] = sha256_file(config_path)
            _write_json(args.output, result)
            status = result["status"]
            metrics = result["smoke_metrics"]
            error = None
        except Exception as exc:
            status = "ERROR"
            metrics = {"qualification": False, "error": f"{type(exc).__name__}: {exc}"}
            error = metrics["error"]
            _write_json(args.output, {"qualification": False, "kind": "harness_smoke",
                                      "status": "ERROR", "error": error,
                                      "source_sha256": source_hashes()})
        if args.ledger:
            append_ledger(args.ledger, {
                "candidate": "regression",
                "gate": "smoke_host_mechanics",
                "status": status,
                "seconds": round(time.perf_counter() - started, 6),
                "metrics": metrics,
                "artifact": str(args.output),
            })
        print(json.dumps({"event": "smoke_host", "status": status, "qualification": False},
                         sort_keys=True), flush=True)
        return 0 if status == "PASS" else 1
    if args.candidate is None or args.output is None:
        parser.error("--protocol requires --candidate and --output")
    stress, long_term = load_pinned_plans()
    plan = stress if args.protocol == "stress" else long_term
    with installed_candidate(args.candidate) as modules:
        config_path = args.config or (args.candidate / "config.json")
        if config_path.resolve() != (args.candidate / "config.json").resolve():
            raise QualificationError("qualification config must be the candidate config.json")
        config = json.loads(config_path.read_bytes())

        def log(row):
            print(json.dumps(row, sort_keys=True, allow_nan=False), flush=True)

        result = run_frozen_host(plan, config, sources=modules, require_complete_witness=True, log=log)
    result["source_sha256"] = source_hashes()
    result["qualification"] = result["status"] == "PASS" and result["witness_complete"]
    _write_json(args.output, result)
    print(json.dumps({"event": "qualification", "status": result["status"],
                      "qualification": result["qualification"]}, sort_keys=True), flush=True)
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
