"""GR1: K3P critic penalty unchanged, plus a moving generator/prior restoring reference.

The reference is a per-tensor (and per prior-row) EMA of accepted parameters. It does not
read the training budget, the critic LR, evaluation scores, or a shift time. For the first
WARMUP generator steps the reference tracks and the pull is zero, so early Adam matches K3P.
After that, a large fast-vs-slow gap or a gradient above its own baseline speeds the
reference and drops the pull, which is how acquisition and a real distribution change keep
moving. A quiet gap restores a fraction ALPHA_MAX of the distance to the slow reference.
Prior rows with an exact-zero gradient are left alone so unused particles are not dragged.
K3P rates, critic mixing, guard, anchor, noise, latent rule, and response are unchanged.
Inherited K3P noise and LR schedules still depend on the declared horizon; that schedule is
an intermediate, not part of this restoring rule.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
# Generator/prior restoring reference. One declaration, not a searched grid.
WARMUP = 200
FAST_BETA = 0.2
SLOW_BETA = 0.01
ALPHA_MAX = 0.002
REL = 0.05
G_BASE = 0.98
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'rule': 'gr1_moving_reference', 'floor': FLOOR,
           'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
           'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [], 'anchor_decay': ANCHOR_DECAY,
           'anchor_started_call': None, 'prox_trace': [],
           'restore_warmup': WARMUP, 'restore_fast_beta': FAST_BETA, 'restore_slow_beta': SLOW_BETA,
           'restore_alpha_max': ALPHA_MAX, 'restore_rel': REL, 'restore_g_base': G_BASE,
           'restore_steps': 0, 'restore_trace': [],
           'restore_trace_columns': ['step', 'warmup', 'gen_alpha', 'prior_alpha', 'gen_rel', 'prior_rel',
                                     'prior_active_fraction', 'adam_disp_rms', 'accepted_disp_rms', 'pull_rms', 'group_lrs'],
           'reads_total_steps': False, 'reads_shift_or_scores': False,
           'horizon_dependent_intermediate': ['k3p_network_lr_schedule', 'k3p_prior_lr_schedule', 'k3p_input_noise', 'k3p_output_noise'],
           'critic_decoupling': 'critic penalty and mixing stay on the K3P LR handover; the restoring pull does not read that ratio'}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0, 'clips': [], 'critic_ref': None,
          'restore': {}, 'restore_steps': 0}


def handover_weight():
    if _state['lr_last'] is None or _state['lr_max'] <= 0.0:
        return 1.0
    r = _state['lr_last'] / _state['lr_max']
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _blank_rows(rows):
    return rows.detach().clone()


def _restore(opt):
    """Proximal map toward a finite-memory parameter reference. Adam moments and step counters stay as the optimizer left them."""
    _state['restore_steps'] += 1
    step = _state['restore_steps']
    receipt['restore_steps'] = step
    warmup = step <= WARMUP
    stats = {'gen_alpha': [], 'prior_alpha': [], 'gen_rel': [], 'prior_rel': [], 'prior_active': [], 'prior_rows': [],
             'pre_sq': [], 'post_sq': [], 'pull_sq': []}
    with torch.no_grad():
        for group_index, group in enumerate(opt.param_groups):
            role = 'prior' if group_index else 'generator'
            for parameter in group['params']:
                per_row = role == 'prior' and parameter.ndim >= 2
                rows = parameter.detach().reshape(parameter.shape[0], -1) if per_row else parameter.detach().reshape(1, -1)
                grad = None if parameter.grad is None else parameter.grad.detach().reshape(rows.shape)
                slot = _state['restore'].get(id(parameter))
                if slot is None:
                    slot = {'fast': _blank_rows(rows), 'slow': _blank_rows(rows), 'prev': _blank_rows(rows),
                            'g_ema': rows.new_zeros(rows.shape[0])}
                    _state['restore'][id(parameter)] = slot
                    continue
                if grad is None:
                    active = torch.zeros(rows.shape[0], dtype=torch.bool, device=rows.device)
                    g_row = rows.new_zeros(rows.shape[0])
                else:
                    g_row = grad.pow(2).mean(dim=1).sqrt()
                    active = g_row > 0
                g_ema = slot['g_ema']
                fresh = active & (g_ema == 0)
                hot = active & ~fresh & (g_row > g_ema)
                grad_gate = torch.ones_like(g_row)
                grad_gate = torch.where(hot, g_ema / g_row.clamp_min(1e-12), grad_gate)
                updated = torch.where(fresh, g_row, G_BASE * g_ema + (1.0 - G_BASE) * g_row)
                slot['g_ema'] = torch.where(active, updated, g_ema)
                adam = rows.detach().clone()
                fast_beta = torch.where(active, adam.new_full(g_row.shape, FAST_BETA), torch.zeros_like(g_row))
                slot['fast'].mul_(1.0 - fast_beta[:, None]).add_(adam * fast_beta[:, None])
                rel = (slot['fast'] - slot['slow']).pow(2).mean(dim=1).sqrt() / adam.pow(2).mean(dim=1).sqrt().clamp_min(1e-8)
                gap_gate = REL / (REL + rel)
                if warmup:
                    alpha = torch.zeros_like(g_row)
                    beta = torch.where(active, adam.new_full(g_row.shape, FAST_BETA), torch.zeros_like(g_row))
                else:
                    alpha = torch.where(active, ALPHA_MAX * gap_gate * grad_gate, torch.zeros_like(g_row))
                    follow = torch.maximum(1.0 - gap_gate, 1.0 - grad_gate)
                    beta = torch.where(active, SLOW_BETA + (FAST_BETA - SLOW_BETA) * follow, torch.zeros_like(g_row))
                accepted = adam + (slot['slow'] - adam) * alpha[:, None]
                parameter.copy_(accepted.reshape(parameter.shape))
                slot['slow'].mul_(1.0 - beta[:, None]).add_(accepted * beta[:, None])
                pre = adam - slot['prev']
                post = accepted - slot['prev']
                stats['pre_sq'].append(pre.pow(2).sum())
                stats['post_sq'].append(post.pow(2).sum())
                stats['pull_sq'].append((accepted - adam).pow(2).sum())
                weight = float(adam.numel())
                if role == 'generator':
                    stats['gen_alpha'].append(alpha.detach().mean() * weight)
                    stats['gen_rel'].append(rel.detach().mean() * weight)
                else:
                    stats['prior_alpha'].append(alpha.detach().mean() * weight)
                    stats['prior_rel'].append(rel.detach().mean() * weight)
                    stats['prior_active'].append(float(active.sum()))
                    stats['prior_rows'].append(float(adam.shape[0]))
                slot['prev'] = accepted.detach().clone()
    if step == 1 or step % 50 == 0:
        numel_g = float(sum(p.numel() for p in opt.param_groups[0]['params'])) if opt.param_groups else 1.0
        numel_p = float(sum(p.numel() for group in opt.param_groups[1:] for p in group['params'])) or 1.0
        def _sum_item(chunks, denom):
            if not chunks:
                return 0.0
            return float(torch.stack(chunks).sum() / denom)
        pre_n = float(torch.stack(stats['pre_sq']).sum().sqrt()) if stats['pre_sq'] else 0.0
        post_n = float(torch.stack(stats['post_sq']).sum().sqrt()) if stats['post_sq'] else 0.0
        pull_n = float(torch.stack(stats['pull_sq']).sum().sqrt()) if stats['pull_sq'] else 0.0
        count = sum(p.numel() for g in opt.param_groups for p in g['params']) or 1
        prior_rows = sum(stats['prior_rows'])
        prior_active = sum(stats['prior_active'])
        receipt['restore_trace'].append([
            step, int(warmup),
            round(_sum_item(stats['gen_alpha'], numel_g), 6),
            round(_sum_item(stats['prior_alpha'], numel_p), 6),
            round(_sum_item(stats['gen_rel'], numel_g), 6),
            round(_sum_item(stats['prior_rel'], numel_p), 6),
            round(prior_active / prior_rows, 6) if prior_rows else 0.0,
            pre_n / count ** 0.5, post_n / count ** 0.5, pull_n / count ** 0.5,
            [float(g['lr']) for g in opt.param_groups],
        ])


def _record(opt, args, kwargs):
    if _state['critic'] is not None and id(opt) != _state['critic']:
        _restore(opt)
        return
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
