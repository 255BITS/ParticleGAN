Continue the assigned focused attempt. Preserve failures and read this file before each new batch.
