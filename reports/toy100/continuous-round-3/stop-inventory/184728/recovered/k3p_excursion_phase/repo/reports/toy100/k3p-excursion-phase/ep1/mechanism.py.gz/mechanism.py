"""ep1: full partial rate through growth, floor only after contraction calms.

PX3 held the ring and scored 71/81. It treated a lull in |velocity| as calm
while its 0.01 smoother was still rising, so the 0.2 cap closed before the
reference gap had peaked. A lull is not a completed excursion.

Cold path matches that candidate: pure a_r1r2 and peak rates until
critic-gradient RMS stays under a quarter of its post-warmup peak for 250
critic steps, then the mixing gain decays at 0.99. After the mixing gain first
hits 0 it stays 0. The early penalty does not return, and the critic constraint
does not read the learning-rate clock.

After the latch the reference step is 0.001. The quiet baseline still updates
only while prox/quiet is under 4. Above 4, a 0.01 smoother tracks prox.
Growth means the smoother is at its crest. Contraction means it has fallen
below that crest. Mobility stays at the 0.2 cap through growth, including a
slow crest, and through contraction until both of these are true: the smoother
has given back a quarter of the rise from the excursion base, and the downward
speed has fallen to a quarter of the fastest downward speed in that descent.
The same quarter is the one PX3 used for its speed test. It is not fit to a
deadline.

Reopen requires the raw gap above four times the smoothed level at which the
contraction calmed, and a positive smoother velocity. PX3 already saw floor-rate
prox wander by about 2.5x without a new target, so a smaller bump is not a new
episode. Once released, dipping through ratio 4 does not forget that settlement.

Input/output noise remain the driver schedule on noise horizon 1200. That
inherited noise is a labeled ablation, not a horizon-free rule. Rates, mixing,
and this phase rule ignore step, horizon, and anneal. Guard stays 5x Adam RMS
after 200 steps.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
PRIOR_FLOOR = 0.05
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ALPHA = 0.001
WARMUP = 200
PEAK_DECAY = 0.9997
FAST_DECAY = 0.9
SLOW_DECAY = 0.99
QUIET_LEVEL = 0.25
REOPEN_LEVEL = 0.5
QUIET_DWELL = 250
CLOSE_DECAY = 0.99
SURPRISE_RATIO = 3.0
SURPRISE_DWELL = 3
REOPEN_CAP = 0.2
PHASE_FRACTION = 0.25
REOPEN_PROX = 4.0
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
           'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
           'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'ep1_growth_contraction',
           'alpha': ALPHA, 'anchor_started_call': None, 'prox_trace': [],
           'phase_trace': [], 'signal': 'smoothed_prox_growth_versus_contraction', 'cosine_used': False,
           'generator_energy_used': False, 'adam_step_innovation_used': False,
           'peak_decay': PEAK_DECAY, 'quiet_level': QUIET_LEVEL, 'reopen_level': REOPEN_LEVEL,
           'quiet_dwell': QUIET_DWELL, 'close_decay': CLOSE_DECAY, 'surprise_ratio': SURPRISE_RATIO,
           'reopen_cap': REOPEN_CAP, 'warmup': WARMUP, 'fixed_reopen_dwell': None,
           'release_fraction': PHASE_FRACTION, 'phase_fraction': PHASE_FRACTION,
           'reopen_prox': REOPEN_PROX,
           'noise': 'inherited K3P horizon ablation via the driver, noise_horizon=1200',
           'rate_rule': 'after latch, gain=0.2 during growth and until a quarter-retrace contraction slows to a quarter of its own peak downward speed; else floor',
           'mix_rule': 's follows mixing gain until it first hits 0; later prox gaps leave s at 0',
           'reference_rule': 'alpha fixed at 0.001; not slowed when the gap is open; quiet baseline does not leak while ratio>4',
           'prox_open_ratio': 10.0, 'prox_close_ratio': 4.0,
           'horizon_inputs': 'none in the phase rule; driver noise_horizon=1200 still schedules input/output noise',
           'ignored_horizon_calls': 0}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0, 'clips': [],
          'critic_ref': None, 'rate_gain': 1.0, 'mix_gain': 1.0, 'peak': None, 'fast': None, 'slow': None,
          'quiet': 0, 'shock': 0, 'closed': False, 'level': 1.0, 'surprise': 1.0, 'warm': False,
          'ever_anchored': False, 'alpha': ALPHA, 'prox': None, 'quiet_prox': None,
          'quiet_prox_n': 0, 'prox_ratio': None, 'activity': 0.0, 'peak_prox': None,
          'unrecovered': 1.0, 'mobility': 0.0, 'rel': None, 'prev_prox': None,
          'prox_s': None, 'vel': 0.0, 'peak_vel': 0.0, 'released': False, 'calm_level': None,
          'peak_s': None, 'excursion_base': None, 'peak_growth': 0.0, 'peak_contract': 0.0,
          'phase': 'cold'}


def handover_weight():
    """K3P map on the mixing gain. Does not read learning rates."""
    r = _state['mix_gain']
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def _multipliers_from_gain():
    gain = _state['rate_gain']
    if gain >= 1.0:
        return 1.0, 1.0
    return (FLOOR + (1.0 - FLOOR) * gain,
            PRIOR_FLOOR + (1.0 - PRIOR_FLOOR) * gain)


def phase_multipliers(completed_step, *args, **kwargs):
    """Drop-in for schedule.policy_multipliers. Ignores step, horizon, and anneal."""
    receipt['ignored_horizon_calls'] += 1
    key = completed_step if type(completed_step) is int else ('other', completed_step)
    if _latch['step'] != key:
        _latch['step'] = key
        _latch['network'], _latch['prior'] = _multipliers_from_gain()
    return _latch['network'], _latch['prior']


def _install_phase_rates():
    from benchmarks.toy100 import schedule
    original = schedule.policy_multipliers
    schedule.policy_multipliers = phase_multipliers
    for module in list(sys.modules.values()):
        if module is None:
            continue
        name = getattr(module, '__name__', '')
        if not name.startswith(('particlegan', 'benchmarks')):
            continue
        for attr, value in list(vars(module).items()):
            if value is original:
                setattr(module, attr, phase_multipliers)


_install_phase_rates()
_latch = {'step': None, 'network': 1.0, 'prior': 1.0}


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _grad_rms(opt):
    total = None
    count = 0
    for group in opt.param_groups:
        for parameter in group['params']:
            if parameter.grad is None:
                continue
            term = parameter.grad.detach().square().sum()
            total = term if total is None else total + term
            count += parameter.grad.numel()
    if total is None or count == 0:
        return None
    return float(torch.sqrt(total / count))


def _reference_alpha():
    return ALPHA


def _smooth_prox(prox):
    peak_prox = _state['peak_prox']
    if peak_prox is None or prox > peak_prox:
        peak_prox = prox
    _state['peak_prox'] = peak_prox
    prev_s = _state['prox_s']
    if prev_s is None:
        prox_s = prox
        vel = 0.0
    else:
        prox_s = 0.99 * prev_s + 0.01 * prox
        vel = (prox_s - prev_s) / peak_prox if peak_prox > 0.0 else 0.0
    _state['prox_s'] = prox_s
    _state['vel'] = vel
    _state['peak_vel'] = max(_state['peak_vel'], abs(vel))
    return prox_s, vel


def _open_excursion(prox, prox_s, vel, ratio):
    """Growth keeps the cap. Floor only after a real contraction slows."""
    growth = max(0.0, vel)
    contract = max(0.0, -vel)
    if _state['released']:
        calm_level = _state['calm_level']
        if (calm_level is not None and calm_level > 0.0 and prox > REOPEN_PROX * calm_level
                and vel > 0.0):
            _state['released'] = False
            _state['calm_level'] = None
            _state['peak_s'] = prox_s
            _state['excursion_base'] = prox_s
            _state['peak_growth'] = growth
            _state['peak_contract'] = 0.0
            _state['phase'] = 'growth'
            mobility = 1.0
        else:
            _state['phase'] = 'settled'
            mobility = 0.0
    else:
        peak_s = _state['peak_s']
        if peak_s is None or prox_s >= peak_s:
            _state['peak_s'] = prox_s
            _state['peak_contract'] = 0.0
            _state['peak_growth'] = max(_state['peak_growth'], growth)
            _state['phase'] = 'growth'
            mobility = 1.0
        else:
            _state['phase'] = 'contraction'
            peak_contract = max(_state['peak_contract'], contract)
            _state['peak_contract'] = peak_contract
            base = _state['excursion_base']
            rise = 0.0 if base is None else peak_s - base
            retraced = rise > 0.0 and (peak_s - prox_s) >= PHASE_FRACTION * rise
            slowed = peak_contract > 0.0 and contract <= PHASE_FRACTION * peak_contract
            if retraced and slowed and vel <= 0.0:
                _state['released'] = True
                _state['calm_level'] = prox_s
                _state['phase'] = 'settled'
                mobility = 0.0
            else:
                mobility = 1.0
    if ratio >= 10.0:
        activity = 1.0
    else:
        activity = (ratio - 4.0) / 6.0
    peak_prox = _state['peak_prox']
    _state['unrecovered'] = 1.0 if not peak_prox or peak_prox <= 0.0 else prox / peak_prox
    _state['mobility'] = mobility
    _state['activity'] = activity
    _state['rate_gain'] = REOPEN_CAP * activity * mobility


def _update_phase(rms):
    if rms is None or not rms > 0.0:
        return
    if _state['fast'] is None:
        _state['fast'] = rms
        _state['slow'] = rms
        _state['level'] = 1.0
        _state['surprise'] = 1.0
        return
    fast = FAST_DECAY * _state['fast'] + (1.0 - FAST_DECAY) * rms
    slow = SLOW_DECAY * _state['slow'] + (1.0 - SLOW_DECAY) * rms
    _state['fast'] = fast
    _state['slow'] = slow
    _state['surprise'] = fast / slow if slow > 0.0 else 1.0
    if receipt['critic_steps'] < WARMUP:
        return
    if not _state['warm']:
        _state['peak'] = slow
        _state['warm'] = True
        _state['quiet'] = 0
        _state['shock'] = 0
        _state['closed'] = False
        _state['rate_gain'] = 1.0
        _state['mix_gain'] = 1.0
    peak = max(_state['peak'] * PEAK_DECAY, rms)
    level = rms / peak if peak > 0.0 else 1.0
    surprise = _state['surprise']
    _state['peak'] = peak
    _state['level'] = level
    if surprise >= SURPRISE_RATIO:
        _state['shock'] += 1
    else:
        _state['shock'] = 0
    if not _state['ever_anchored']:
        reopen = level >= REOPEN_LEVEL or _state['shock'] >= SURPRISE_DWELL
        if reopen:
            _state['quiet'] = 0
            _state['rate_gain'] = 1.0
            _state['mix_gain'] = 1.0
            _state['closed'] = False
            return
        if level < QUIET_LEVEL:
            _state['quiet'] += 1
            if _state['quiet'] >= QUIET_DWELL:
                _state['closed'] = True
        if _state['closed']:
            _state['rate_gain'] = max(0.0, _state['rate_gain'] * CLOSE_DECAY)
            _state['mix_gain'] = _state['rate_gain']
            if _state['mix_gain'] <= FLOOR:
                _state['mix_gain'] = 0.0
                _state['ever_anchored'] = True
        return
    _state['mix_gain'] = 0.0
    prox = _state['prox']
    if prox is None or not prox >= 0.0:
        _state['activity'] = 0.0
        _state['mobility'] = 0.0
        _state['rate_gain'] = 0.0
        _state['phase'] = 'no_prox'
        return
    quiet = _state['quiet_prox']
    if quiet is None or not quiet > 0.0:
        _state['quiet_prox'] = prox if prox > 0.0 else 1e-8
        _state['quiet_prox_n'] = 1
        _state['prox_ratio'] = 1.0
        _state['prev_prox'] = prox
        _state['peak_prox'] = prox
        _state['prox_s'] = prox
        _state['peak_s'] = prox
        _state['excursion_base'] = prox
        _state['activity'] = 0.0
        _state['mobility'] = 0.0
        _state['unrecovered'] = 1.0
        _state['rate_gain'] = 0.0
        _state['phase'] = 'baseline'
        return
    ratio = prox / quiet
    _state['prox_ratio'] = ratio
    prev = _state['prev_prox']
    _state['rel'] = None if prev is None or not prev > 0.0 else (prox - prev) / prev
    _state['prev_prox'] = prox
    prox_s, vel = _smooth_prox(prox)
    if ratio < 4.0:
        _state['quiet_prox'] = 0.99 * quiet + 0.01 * prox
        _state['quiet_prox_n'] += 1
    if _state['quiet_prox_n'] < 50 or ratio <= 4.0:
        _state['unrecovered'] = 1.0
        _state['mobility'] = 0.0
        _state['activity'] = 0.0
        _state['rate_gain'] = 0.0
        _state['phase'] = 'quiet'
        if not _state['released']:
            _state['peak_prox'] = prox
            _state['peak_s'] = prox_s
            _state['excursion_base'] = prox_s
            _state['vel'] = 0.0
            _state['peak_vel'] = 0.0
            _state['peak_growth'] = 0.0
            _state['peak_contract'] = 0.0
            _state['calm_level'] = None
        return
    _open_excursion(prox, prox_s, vel, ratio)


def _phase_row():
    net, prior = _multipliers_from_gain()
    return dict(critic_steps=receipt['critic_steps'], calls=receipt['calls'],
                rate_gain=round(_state['rate_gain'], 6), mix_gain=round(_state['mix_gain'], 6),
                s=round(handover_weight(), 6), alpha=round(_state['alpha'], 6),
                level=None if _state['level'] is None else round(_state['level'], 6),
                surprise=None if _state['surprise'] is None else round(_state['surprise'], 6),
                quiet=_state['quiet'], shock=_state['shock'], closed=_state['closed'], warm=_state['warm'],
                ever_anchored=_state['ever_anchored'], activity=round(_state['activity'], 6),
                mobility=round(_state['mobility'], 6),
                unrecovered=None if _state['unrecovered'] is None else round(_state['unrecovered'], 6),
                prox=None if _state['prox'] is None else round(_state['prox'], 8),
                peak_prox=None if _state['peak_prox'] is None else round(_state['peak_prox'], 8),
                prox_ratio=None if _state['prox_ratio'] is None else round(_state['prox_ratio'], 4),
                prox_s=None if _state['prox_s'] is None else round(_state['prox_s'], 8),
                vel=round(_state['vel'], 6), peak_vel=round(_state['peak_vel'], 6),
                released=_state['released'],
                calm_level=None if _state['calm_level'] is None else round(_state['calm_level'], 8),
                phase=_state['phase'],
                peak_s=None if _state['peak_s'] is None else round(_state['peak_s'], 8),
                excursion_base=None if _state['excursion_base'] is None else round(_state['excursion_base'], 8),
                peak_growth=round(_state['peak_growth'], 6),
                peak_contract=round(_state['peak_contract'], 6),
                rel=None if _state['rel'] is None else round(_state['rel'], 6),
                network_multiplier=net, prior_multiplier=prior, lr_last=_state['lr_last'])


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    receipt['extra_critic_forwards'] += 1
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        _state['prox'] = float(prox.detach())
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        row = _phase_row()
        receipt['s_trace'].append([receipt['calls'], row['s']])
        receipt['phase_trace'].append(row)
        print(json.dumps(dict(phase=row)), flush=True)
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            alpha = _reference_alpha()
            _state['alpha'] = alpha
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(1.0 - alpha).add_(p.detach(), alpha=alpha)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
        _update_phase(_grad_rms(opt))
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_rate_gain'] = _state['rate_gain']
    receipt['final_mix_gain'] = _state['mix_gain']
    receipt['final_alpha'] = _state['alpha']
    receipt['final_ever_anchored'] = _state['ever_anchored']
    receipt['final_closed'] = _state['closed']
    receipt['final_level'] = _state['level']
    receipt['final_surprise'] = _state['surprise']
    receipt['final_mobility'] = _state['mobility']
    receipt['final_unrecovered'] = _state['unrecovered']
    receipt['final_prox_ratio'] = _state['prox_ratio']
    receipt['final_phase'] = _state['phase']
    receipt['final_released'] = _state['released']
    receipt['final_calm_level'] = _state['calm_level']
    net, prior = _multipliers_from_gain()
    receipt['final_network_multiplier'] = net
    receipt['final_prior_multiplier'] = prior
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
