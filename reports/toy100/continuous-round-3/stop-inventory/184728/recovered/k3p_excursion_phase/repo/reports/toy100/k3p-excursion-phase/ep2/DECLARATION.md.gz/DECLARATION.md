# ep2_reversible_contraction

Same copied K3P parent as ep1. config `a1475108…`, latent `197df635…`, response `7e71d60a…`.

ep1 held 1200/1200 and 300/300, pre-shift 5/5 and 120/120, but the deadline was 16/81. The ring was already 8 modes at HQ 0.95–0.98 from step 2500 through 2950 while gain stayed 0.2. The one-way floor then armed on a quarter retrace while prox/quiet was still about 18, and HQ fell to 0.567 with modes down to 5.

ep2 does not latch that floor. Growth, meaning the smoother is on its crest, keeps the 0.2 cap. Contraction, meaning the smoother is below that crest, sets mobility to the unrecovered fraction of the rise from the excursion base back toward that crest. A later rise below the old crest raises mobility again. A new crest restores the full cap. Ratio at or below 4 still forces the floor and does not open a fresh full-rate episode: activity is 0 at 4 and 1 only at 10. The hold never entered that gate.

Mixing still follows the cold-path gain until it hits 0, then stays 0. It does not read the critic learning rate. Phase multipliers ignore step, horizon, and anneal. Inherited driver noise on horizon 1200 remains a labeled ablation.
