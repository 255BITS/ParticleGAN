#!/bin/bash
# ep1 canonical hold+extension, then target shift. One GPU worker, sequential.
set -u
export CUDA_VISIBLE_DEVICES=GPU-72c1b506-891d-b8bc-b353-e020585e1c47
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
PY=/tmp/pr38-default-env/bin/python
REPO=/ml2/hypergan/gan-attempts/claude-pool-20260925T041936Z/qualify_a2_bounded_damp/20260925T041936Z-2509885/repo/reports/toy100/qualify-a2-attempt/prepared/repos/cuda
FIX=/ml2/hypergan/ParticleGAN-epsilon-gan-followup/reports/toy100/direct-particle-base/initialization-fixtures/mode_hold/initial-values.pt
SRC=/ml2/hypergan/gan-attempts/formulations-20260925T184728Z/k3p_excursion_phase/20260925T184728Z-3812316/repo/reports/toy100/gap-fill-20260925/sources/k3p
BASE=/ml2/hypergan/gan-attempts/formulations-20260925T184728Z/k3p_excursion_phase/20260925T184728Z-3812316/repo/reports/toy100/k3p-excursion-phase
EP="$BASE/ep1"
mkdir -p "$EP" "$BASE/logs"
for f in config.json latent.py response.py probe.py native100.py hold.py shift.py shift_frozen.py checkpoint.py convergence_gate.py; do
  if [ ! -f "$EP/$f" ]; then
    cp "$SRC/$f" "$EP/$f"
  fi
done
echo "HASHES $(date -u +%H:%M:%S)"
"$PY" - <<PY
import hashlib
from pathlib import Path
src = Path("$SRC")
dst = Path("$EP")
names = ["config.json","latent.py","response.py","probe.py","native100.py","hold.py","shift.py","shift_frozen.py","checkpoint.py","convergence_gate.py"]
for name in names:
    a = hashlib.sha256((src/name).read_bytes()).hexdigest()
    b = hashlib.sha256((dst/name).read_bytes()).hexdigest()
    print(name, b, "MATCH" if a==b else "MISMATCH")
    if a != b:
        raise SystemExit(1)
print("mechanism", hashlib.sha256((dst/"mechanism.py").read_bytes()).hexdigest())
PY
echo "CUDA $(date -u +%H:%M:%S)"
"$PY" -c "import torch; print('cuda', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'none')"
echo "START hold $(date -u +%H:%M:%S)"
START=$(date +%s)
"$PY" -u "$EP/hold.py" --repo "$REPO" --config "$EP/config.json" \
  --task mode_hold --backend cuda --initial-state "$FIX" \
  --output "$BASE/runs/ep1-hold" --network-floor 0.01 --prior-floor 0.05 --anneal-start 0.6 \
  > "$BASE/logs/ep1-hold.log" 2>&1
HOLD_EC=$?
END=$(date +%s)
echo "HOLD_EXIT $HOLD_EC elapsed $((END-START))"
"$PY" "$BASE/score_gate.py" ring_hold_extension ep1_growth_contraction "$BASE/runs/ep1-hold/result.json" "$((END-START))" || true
echo "START shift $(date -u +%H:%M:%S)"
START=$(date +%s)
"$PY" -u "$EP/shift.py" --repo "$REPO" --config "$EP/config.json" \
  --task mode_hold --backend cuda --initial-state "$FIX" \
  --output "$BASE/runs/ep1-shift" --network-floor 0.01 --prior-floor 0.05 --anneal-start 0.6 \
  > "$BASE/logs/ep1-shift.log" 2>&1
SHIFT_EC=$?
END=$(date +%s)
echo "SHIFT_EXIT $SHIFT_EC elapsed $((END-START))"
"$PY" "$BASE/score_gate.py" target_shift_recovery ep1_growth_contraction "$BASE/runs/ep1-shift/result.json" "$((END-START))" || true
echo DONE
