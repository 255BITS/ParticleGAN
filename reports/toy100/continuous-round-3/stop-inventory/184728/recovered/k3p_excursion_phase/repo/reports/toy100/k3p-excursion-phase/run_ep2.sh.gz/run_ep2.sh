#!/bin/bash
# ep2 canonical hold+extension, then target shift. One GPU worker, sequential.
set -u
export CUDA_VISIBLE_DEVICES=GPU-72c1b506-891d-b8bc-b353-e020585e1c47
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
PY=/tmp/pr38-default-env/bin/python
REPO=/ml2/hypergan/gan-attempts/claude-pool-20260925T041936Z/qualify_a2_bounded_damp/20260925T041936Z-2509885/repo/reports/toy100/qualify-a2-attempt/prepared/repos/cuda
FIX=/ml2/hypergan/ParticleGAN-epsilon-gan-followup/reports/toy100/direct-particle-base/initialization-fixtures/mode_hold/initial-values.pt
BASE=/ml2/hypergan/gan-attempts/formulations-20260925T184728Z/k3p_excursion_phase/20260925T184728Z-3812316/repo/reports/toy100/k3p-excursion-phase
EP="$BASE/ep2"
mkdir -p "$BASE/logs"
echo "START hold $(date -u +%H:%M:%S)"
START=$(date +%s)
"$PY" -u "$EP/hold.py" --repo "$REPO" --config "$EP/config.json" \
  --task mode_hold --backend cuda --initial-state "$FIX" \
  --output "$BASE/runs/ep2-hold" --network-floor 0.01 --prior-floor 0.05 --anneal-start 0.6 \
  > "$BASE/logs/ep2-hold.log" 2>&1
HOLD_EC=$?
END=$(date +%s)
echo "HOLD_EXIT $HOLD_EC elapsed $((END-START))"
"$PY" "$BASE/score_gate.py" ring_hold_extension ep2_reversible_contraction "$BASE/runs/ep2-hold/result.json" "$((END-START))" || true
echo "START shift $(date -u +%H:%M:%S)"
START=$(date +%s)
"$PY" -u "$EP/shift.py" --repo "$REPO" --config "$EP/config.json" \
  --task mode_hold --backend cuda --initial-state "$FIX" \
  --output "$BASE/runs/ep2-shift" --network-floor 0.01 --prior-floor 0.05 --anneal-start 0.6 \
  > "$BASE/logs/ep2-shift.log" 2>&1
SHIFT_EC=$?
END=$(date +%s)
echo "SHIFT_EXIT $SHIFT_EC elapsed $((END-START))"
"$PY" "$BASE/score_gate.py" target_shift_recovery ep2_reversible_contraction "$BASE/runs/ep2-shift/result.json" "$((END-START))" || true
echo DONE
