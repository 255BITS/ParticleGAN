# ep1_growth_contraction

Copied K3P parent. config `a1475108…`, latent `197df635…`, response `7e71d60a…`. Learned particle prior, direct response, and bounded sparse-latent damping are unchanged. Architecture, seeds, floors 0.01/0.05, and auxiliary host losses are unchanged.

PX3 held 1200+300 and recovered 71/81 because its speed test floored on a lull while the smoothed reference gap was still rising. ep1 keeps that latch and the 0.2 cap, and splits the excursion into growth and contraction. Growth is the smoother sitting on its crest. Contraction is the smoother below that crest. The cap stays on through growth. The floor arms only after the smoother has given back a quarter of the rise from the excursion base and the downward speed has fallen to a quarter of that descent's fastest speed. Reopen needs raw prox above four times the calmed smoother and a positive smoother velocity, so a stationary wander is not a new episode.

Mixing weight `s` follows the cold-path mixing gain until it first hits 0, then stays 0. It does not read the critic's learning rate. The phase multipliers ignore step, horizon, and anneal. Reference EMA step stays 0.001.

Inherited driver noise on horizon 1200 is still a labeled ablation. It is the remaining budget dependence: input noise 0.5 over the first 0.1 of `noise_horizon`, output noise warming to 0.029 over 0.2 of that horizon, and the unused network horizon cap of 1600 left in the config. The learned schedule does not read those.
