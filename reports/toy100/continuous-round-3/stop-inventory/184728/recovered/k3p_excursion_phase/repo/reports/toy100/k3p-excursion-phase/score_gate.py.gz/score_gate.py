"""Append one canonical gate row to the attempt ledger."""
import json
import sys
from pathlib import Path

LEDGER = Path('/ml2/hypergan/gan-attempts/formulations-20260925T184728Z/k3p_excursion_phase/20260925T184728Z-3812316/tests.jsonl')


def ok(point):
    return point['modes'] == 8 and point['hq'] >= 0.9


def main():
    kind, candidate, artifact, seconds = sys.argv[1:]
    path = Path(artifact)
    seconds = float(seconds)
    if not path.is_file():
        row = dict(candidate=candidate, gate=kind, status='ERROR', seconds=seconds,
                   metrics={'note': 'result json missing'}, artifact=str(path))
    else:
        rec = json.loads(path.read_text())
        if kind == 'ring_hold_extension':
            row = score_hold(candidate, rec, seconds, path)
        elif kind == 'target_shift_recovery':
            row = score_shift(candidate, rec, seconds, path)
        else:
            raise SystemExit(f'unknown gate {kind}')
    with LEDGER.open('a') as handle:
        handle.write(json.dumps(row, default=str) + '\n')
    metrics = row.get('metrics') or {}
    print(json.dumps(dict(candidate=row['candidate'], gate=row['gate'], status=row['status'],
                          raw_status=metrics.get('raw_status'),
                          hold_passing=metrics.get('hold_passing'),
                          extension_passing=metrics.get('extension_passing'),
                          deadline_passing=metrics.get('deadline_passing'),
                          delay_updates=metrics.get('delay_updates'),
                          note=metrics.get('note')), default=str), flush=True)


def score_hold(candidate, rec, seconds, path):
    if rec.get('status') == 'ERROR' or 'gate' not in rec:
        return dict(candidate=candidate, gate='ring_hold_extension', status='ERROR', seconds=seconds,
                    metrics={'error': rec.get('error'), 'raw_status': rec.get('status')}, artifact=str(path))
    gate = rec['gate']
    conv = gate.get('converged_step')
    hold_n = gate.get('hold_checks') or 0
    dense = rec.get('dense') or []
    held = [p for p in dense if conv is not None and conv < p['step'] <= conv + hold_n]
    ext = [p for p in dense if conv is not None and p['step'] > conv + hold_n]
    hold_pass = gate.get('status') == 'PASS' and len(held) == 1200 and all(ok(p) for p in held)
    ext_pass = len(ext) == 300 and all(ok(p) for p in ext)
    metrics = dict(raw_status=rec.get('status'), gate_status=gate.get('status'),
                   converged_step=conv, settling_failures=gate.get('settling_failures'),
                   hold_checks=len(held), hold_budget=1200, hold_passing=sum(ok(p) for p in held),
                   hold_min_hq=min((p['hq'] for p in held), default=None),
                   hold_min_modes=min((p['modes'] for p in held), default=None),
                   extension_checks=len(ext), extension_passing=sum(ok(p) for p in ext),
                   extension_min_hq=min((p['hq'] for p in ext), default=None),
                   extension_min_modes=min((p['modes'] for p in ext), default=None),
                   last_live=rec.get('last_live'),
                   extra_critic_forwards=(rec.get('regularizer_receipt') or {}).get('extra_critic_forwards'),
                   final_rate_gain=(rec.get('regularizer_receipt') or {}).get('final_rate_gain'),
                   final_phase=(rec.get('regularizer_receipt') or {}).get('final_phase'),
                   final_alpha=(rec.get('regularizer_receipt') or {}).get('final_alpha'))
    return dict(candidate=candidate, gate='ring_hold_extension',
                status='PASS' if hold_pass and ext_pass else 'FAIL',
                seconds=seconds, metrics=metrics, artifact=str(path))


def score_shift(candidate, rec, seconds, path):
    if rec.get('status') == 'ERROR' or 'shift_recovery' not in rec:
        return dict(candidate=candidate, gate='target_shift_recovery', status='ERROR', seconds=seconds,
                    metrics={'error': rec.get('error'), 'raw_status': rec.get('status')}, artifact=str(path))
    sr = rec['shift_recovery'] or {}
    late = sr.get('deadline_window') or {}
    stat = rec.get('stationary') or {}
    cont = rec.get('continued_hold') or {}
    receipt = rec.get('regularizer_receipt') or {}
    raw = rec.get('status')
    if raw == 'UNCONFIRMED':
        status = 'FAIL'
        note = 'UNCONFIRMED live pass. Frozen control is required before any PASS. Quality windows are not a failure.'
    elif raw == 'PASS':
        status = 'PASS'
        note = 'Driver PASS.'
    else:
        status = 'FAIL'
        note = 'Live shift missed stationary, continued hold, or the deadline window.'
    metrics = dict(raw_status=raw, note=note,
                   stationary_passing=stat.get('passing_checks'), stationary_checks=stat.get('checks'),
                   stationary_min_hq=stat.get('min_hq'), stationary_pass=stat.get('pass_all'),
                   continued_hold_passing=cont.get('passing_checks'), continued_hold_checks=cont.get('checks'),
                   continued_hold_min_hq=cont.get('min_hq'), continued_hold_pass=cont.get('pass_all'),
                   deadline_passing=late.get('passing_checks'), deadline_checks=late.get('checks'),
                   deadline_pass=sr.get('deadline_pass'), deadline_min_modes=late.get('min_modes'),
                   deadline_min_hq=late.get('min_hq'), delay_updates=sr.get('delay_updates'),
                   stable_from_step=sr.get('stable_from_step'),
                   final=rec.get('final'), ema=rec.get('ema'),
                   optimizer_final=rec.get('optimizer_final'),
                   final_rate_gain=receipt.get('final_rate_gain'),
                   final_phase=receipt.get('final_phase'),
                   final_released=receipt.get('final_released'),
                   final_alpha=receipt.get('final_alpha'),
                   final_mobility=receipt.get('final_mobility'),
                   final_prox_ratio=receipt.get('final_prox_ratio'),
                   extra_critic_forwards=receipt.get('extra_critic_forwards'),
                   rate_ranges={k: {kk: vv for kk, vv in v.items() if kk != 'values'}
                                if isinstance(v, dict) else v
                                for k, v in (rec.get('rate_ranges') or {}).items()})
    return dict(candidate=candidate, gate='target_shift_recovery', status=status,
                seconds=seconds, metrics=metrics, artifact=str(path))


if __name__ == '__main__':
    main()
