"""pd1: horizon-free rates from a training-batch projected quantile residual.

Compare sorted projections of the even-index real training minibatch with the
even-index generated minibatch. The same-count odd-index real split is the
sampling-variation reference. Directions are a fixed formula, not a torch draw.
The signal is the ratio of mean 1D Wasserstein-1 values, plus a logged max.

Acquisition: the multiplier stays at 1 until that smoothed ratio has once
fallen to PRECISE. Sustained error: above PRECISE the target rises linearly
and reaches 1 at OPEN, whether or not the raw gradient is quiet. Return to
precision: at or below PRECISE the target is PRECISION_M, approached more
slowly than a reopen. After the first precise reading the map is reversible.

Critic mixing is the K3P map of this network multiplier, not last/max LR.
total_steps, the horizon cap, anneal start, and the host floors are recorded
and ignored. K3P input/output noise remains on the driver's noise horizon of
1200; that schedule is a labeled intermediate, not this controller.
"""
from benchmarks.toy100 import schedule

PROJECTIONS = 8
PRECISE = 1.25
OPEN = 2.0
PRECISION_M = 0.10
FULL_M = 1.0
RISE = 0.20
FALL = 0.05
RATIO_EMA = 0.98
EPS = 1e-6
MIX_FLOOR = 0.01

state = {
    'ema': None,
    'raw': None,
    'raw_max': None,
    'model': None,
    'ref': None,
    'm': 1.0,
    'target': 1.0,
    'precision_seen': False,
    'phase': 'acquire',
    'observe_calls': 0,
    'skipped': 0,
    'cache': {},
    'trace': [],
    'last': (1.0, 1.0),
    'directions': {},
    'direction_digest': None,
    'ignored_total_steps': None,
    'ignored_cap': None,
    'ignored_floor': None,
    'ignored_anneal': None,
}


def _directions(dimension, like):
    cached = state['directions'].get(dimension)
    if cached is not None and cached.device == like.device and cached.dtype == like.dtype:
        return cached
    # Coordinate axes first, then Weyl signs. Fixed formula, no training RNG.
    phi = (1.0 + 5.0 ** 0.5) / 2.0
    rows = []
    for axis in range(min(PROJECTIONS, dimension)):
        raw = [0.0] * dimension
        raw[axis] = 1.0
        rows.append(raw)
    k = 0
    while len(rows) < PROJECTIONS:
        raw = []
        for i in range(dimension):
            x = ((i + 1) * phi + (k + 1) * phi * phi) % 1.0
            sign = 1.0 if x >= 0.5 else -1.0
            spike = 2.0 if i == (k % dimension) else 0.0
            raw.append(sign + spike)
        norm = sum(v * v for v in raw) ** 0.5
        rows.append([v / norm for v in raw])
        k += 1
    import torch
    tensor = torch.tensor(rows, device=like.device, dtype=like.dtype)
    state['directions'][dimension] = tensor
    if state['direction_digest'] is None:
        flat = tuple(round(v, 6) for row in rows for v in row[:min(4, dimension)])
        state['direction_digest'] = {'k': PROJECTIONS, 'dimension': dimension, 'prefix': flat}
    return tensor


def _w1(left, right, directions):
    projected_left = left.matmul(directions.t()).sort(dim=0).values
    projected_right = right.matmul(directions.t()).sort(dim=0).values
    return (projected_left - projected_right).abs().mean(dim=0)


def mixing_weight(multiplier=None):
    m = state['m'] if multiplier is None else float(multiplier)
    return max(0.0, min(1.0, 2.0 * m) - 2.0 * MIX_FLOOR) / (1.0 - 2.0 * MIX_FLOOR)


def _target(ratio):
    if ratio <= PRECISE:
        return PRECISION_M
    if ratio >= OPEN:
        return FULL_M
    span = (ratio - PRECISE) / (OPEN - PRECISE)
    return PRECISION_M + span * (FULL_M - PRECISION_M)


def observe_batch(real, fake):
    import torch
    if not torch.is_tensor(real) or not torch.is_tensor(fake):
        state['skipped'] += 1
        return
    if real.shape[0] != fake.shape[0] or real.shape[0] < 16:
        state['skipped'] += 1
        return
    with torch.no_grad():
        flat_real = real.detach().flatten(1)
        flat_fake = fake.detach().flatten(1)
        assert flat_real.is_cuda and flat_real.dtype == torch.float32
        assert flat_fake.is_cuda and flat_fake.dtype == torch.float32
        half = flat_real.shape[0] // 2
        real_even = flat_real[0::2][:half]
        real_odd = flat_real[1::2][:half]
        fake_even = flat_fake[0::2][:half]
        directions = _directions(flat_real.shape[1], flat_real)
        model = _w1(real_even, fake_even, directions)
        reference = _w1(real_even, real_odd, directions)
        per = model / (reference + EPS)
        model_mean = float(model.mean())
        reference_mean = float(reference.mean())
        # Ratio of means: one low-reference direction cannot dominate the mean of ratios.
        ratio = model_mean / (reference_mean + EPS)
        ratio_max = float(per.max())
    state['observe_calls'] += 1
    state['raw'] = ratio
    state['raw_max'] = ratio_max
    state['model'] = model_mean
    state['ref'] = reference_mean
    if state['ema'] is None:
        state['ema'] = ratio
    else:
        state['ema'] = RATIO_EMA * state['ema'] + (1.0 - RATIO_EMA) * ratio
    ema = state['ema']
    if ema <= PRECISE:
        state['precision_seen'] = True
    if not state['precision_seen']:
        target = FULL_M
        state['phase'] = 'acquire'
    else:
        target = _target(ema)
        if ema <= PRECISE:
            state['phase'] = 'precision'
        elif ema >= OPEN:
            state['phase'] = 'acquire'
        else:
            state['phase'] = 'sustained'
    state['target'] = target
    rate = RISE if target > state['m'] else FALL
    state['m'] = (1.0 - rate) * state['m'] + rate * target
    call = state['observe_calls']
    if call == 1 or call % 50 == 0:
        _trace(call)


def _trace(call):
    state['trace'].append({
        'call': call,
        'phase': state['phase'],
        'ema': state['ema'],
        'raw': state['raw'],
        'raw_max': state['raw_max'],
        'model': state['model'],
        'ref': state['ref'],
        'm': state['m'],
        'target': state['target'],
        's': mixing_weight(),
        'precision_seen': state['precision_seen'],
    })


def multipliers(completed_step, total_steps, anneal_start, floor, network_lr_horizon_cap=None, *, network_lr_floor=None):
    if type(completed_step) is not int:
        raise ValueError('completed_step must be an int memo key')
    cached = state['cache'].get(completed_step)
    if cached is not None:
        return cached
    result = (float(state['m']), float(state['m']))
    state['cache'][completed_step] = result
    state['last'] = result
    state['ignored_total_steps'] = total_steps
    state['ignored_cap'] = network_lr_horizon_cap
    state['ignored_floor'] = floor
    state['ignored_anneal'] = anneal_start
    return result


def snapshot():
    return {
        'rule': 'pd1_projected_quantile',
        'projections': PROJECTIONS,
        'precise': PRECISE,
        'open': OPEN,
        'precision_m': PRECISION_M,
        'rise': RISE,
        'fall': FALL,
        'ratio_ema': RATIO_EMA,
        'mix_floor': MIX_FLOOR,
        'phase': state['phase'],
        'precision_seen': state['precision_seen'],
        'observe_calls': state['observe_calls'],
        'skipped': state['skipped'],
        'ema': state['ema'],
        'raw': state['raw'],
        'raw_max': state['raw_max'],
        'model': state['model'],
        'ref': state['ref'],
        'm': state['m'],
        'target': state['target'],
        'last_multiplier': state['last'],
        'final_s': mixing_weight(),
        'direction_digest': state['direction_digest'],
        'ignored_total_steps': state['ignored_total_steps'],
        'ignored_cap': state['ignored_cap'],
        'ignored_floor': state['ignored_floor'],
        'ignored_anneal': state['ignored_anneal'],
        'noise': 'inherited K3P input 0.5 anneal-end 0.1 and output 0.029 warmup 0.2 on driver noise_horizon 1200; labeled intermediate',
        'trace': state['trace'],
    }


schedule.policy_multipliers = multipliers
