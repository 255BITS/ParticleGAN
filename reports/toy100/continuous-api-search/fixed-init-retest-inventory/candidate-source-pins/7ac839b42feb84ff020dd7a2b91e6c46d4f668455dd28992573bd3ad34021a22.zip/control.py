"""Reversible loss-deficit controller; no training horizon or benchmark inputs."""
import sys
import torch
from particlegan import recipes
from particlegan.gan_loss import GANLoss
from benchmarks.toy100 import models, schedule
state = {'u': None, 'q': None, 'calls': 0}
receipt = {'rule': 'loss_envelope', 'rows': [], 'applied_rates': [], 'history_devices': []}

def mix():
    u = 1.0 if state['u'] is None else float(state['u'])
    return max(0.0,min(.98,2.0*u-.02))/.98

def multipliers(*args, **kwargs):
    u = 1.0 if state['u'] is None else float(state['u'])
    return .01+.99*u*u, .05+.95*u*u

def constant_rate(*args, **kwargs): return 1.0
def no_input_noise(*args, **kwargs): return 0.0
def constant_output_noise(peak, *args, **kwargs): return float(peak)
_original_loss = GANLoss.d_loss

def d_loss(self, real_logits, fake_logits):
    with torch.no_grad():
        q = (real_logits.detach().mean()-fake_logits.detach().mean()).clamp(0.,1.)
        if state['u'] is None: state['u'] = torch.ones_like(q)
        u = state['u']; alpha = torch.where(q>u, .01, .001)
        u.add_(alpha*(q-u)); state['q']=q; state['calls']+=1
        assert u.device.type=='cuda' and u.dtype==torch.float32
        if state['calls']==1 or state['calls']%50==0:
            row=dict(call=state['calls'],q=float(q),u=float(u),s=mix(),multipliers=multipliers())
            receipt['rows'].append(row)
            import json
            print(json.dumps(dict(controller=row)),flush=True)
    return _original_loss(self,real_logits,fake_logits)
GANLoss.d_loss=d_loss
replacements=[(recipes.learning_rate_scale,constant_rate),(schedule.policy_multipliers,multipliers),(models.linear_input_noise,no_input_noise),(models.linear_output_noise,constant_output_noise)]
for module in list(sys.modules.values()):
    if module is None or not getattr(module,'__name__','').startswith(('particlegan','benchmarks')): continue
    for name,value in list(vars(module).items()):
        for original,replacement in replacements:
            if value is original: setattr(module,name,replacement)

def begin(opt):
    # Hosts install policy multipliers; capture pre-response rates without modifying them.
    return [float(g['lr']) for g in opt.param_groups]

def end(opt, saved):
    if state['calls']==1 or state['calls']%50==0:
        receipt['applied_rates'].append(dict(call=state['calls'],optimizer_parameters=[sum(p.numel() for p in g['params']) for g in opt.param_groups],rates=saved))
    receipt['history_devices']=[str(state['u'].device)] if state['u'] is not None else []
