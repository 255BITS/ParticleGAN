"""SN3: noise burn-in from SN2, rate cosine after that burn-in, no noise reopen.

SN2's absolute-deviation burn-in did shut input noise off (about step 250) and
reached 7 live modes at HQ 1. The grad-RMS leak never started: g_fast stayed
above 0.15 of a peak that full-rate training itself kept high. Noise reopen
(cap 0.08) pulsed input noise back on and the ring collapsed off those pulses.
Score-gap deviation stays O(0.1) even on a sharp ring, so it is not a floor
or a shift detector.

Noise, unchanged burn-in, reopen removed:
  q_noise = 0.8 q_noise + 0.2 q
  dev = |q - q_noise| before the update
  after 10 penalties, dev <= 0.08 multiplies noise_base by 0.955; larger dev pauses
  input std = 0.5 * noise_base
  output std = 0.029 * (1 - noise_base)
  no reopen

Rate, not read from total_steps. The first time noise_base < 0.05 marks
settle. For the next 800 critic steps heat stays 1. The following 600 steps
are a cosine from 1 to 0. After that heat stays 0 unless the reopen below
fires. Network multiplier = 0.01 + 0.99*heat. Prior = 0.05 + 0.95*heat.
800 and 600 are estimator lengths measured off SN2's burn-in (~250) so the
cosine lands near the parent ring window. They are not the task budget.

Reopen, only after the cosine: g_base = 0.995 g_base + 0.005 grad_rms, and
g_base falls. Thirty consecutive steps with grad_rms > 2.5 * g_base add 0.01
to heat, capped at 0.18. Otherwise heat leaks by 0.99 back toward 0.
anchor_heat increases only while heat > 0.5, else *= 0.995. s is the K3P
handover of r = 0.01 + 0.99*anchor_heat, so a 0.18 reopen leaves the anchor on.

Host schedules are called and discarded. Guard 5x after 200, anchor decay 0.999.
"""
import atexit, json, math, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
PRIOR_FLOOR = 0.05
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
INPUT_PEAK = 0.5
OUTPUT_PEAK = 0.029
PLATEAU = 800
COSINE = 600
REOPEN_CAP = 0.18
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'extra_score_forwards': 0,
           'floor': FLOOR, 'prior_floor': PRIOR_FLOOR, 'guard_c': GUARD_C,
           'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
           'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [],
           'rule': 'sn3_settle_cosine', 'anchor_decay': ANCHOR_DECAY,
           'anchor_started_call': None, 'prox_trace': [],
           'handover': 's from anchor_heat; anchor_heat rises only while heat > 0.5',
           'noise_rule': 'noise_base *= 0.955 when |q-q_noise|<=0.08 else pause; no reopen',
           'optimizer_policy': 'heat=1 for 800 steps after noise_base<0.05, cosine over 600, then local-RMS reopen cap 0.18'}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0,
          'clips': [], 'critic_ref': None}
_ctrl = {'q_noise': None, 'dev': None, 'noise_base': 1.0, 'heat': 1.0, 'anchor_heat': 1.0,
         'settle_step': None, 'g_base': None, 'pending_rms': None, 'rate_hi': 0,
         'input_std': INPUT_PEAK, 'output_std': 0.0, 'last_q': None, 'trace': []}


def handover_weight():
    r = FLOOR + (1.0 - FLOOR) * float(_ctrl['anchor_heat'])
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def network_multiplier():
    return FLOOR + (1.0 - FLOOR) * float(_ctrl['heat'])


def prior_multiplier():
    return PRIOR_FLOOR + (1.0 - PRIOR_FLOOR) * float(_ctrl['heat'])


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _update_noise(q):
    q = q.detach().to(dtype=torch.float32)
    _ctrl['last_q'] = float(q)
    if _ctrl['q_noise'] is None:
        _ctrl['q_noise'] = q.clone()
        _ctrl['dev'] = q.new_zeros(())
        return
    dev = (q - _ctrl['q_noise']).abs()
    _ctrl['q_noise'] = _ctrl['q_noise'] * 0.8 + q * 0.2
    _ctrl['dev'] = dev
    if receipt['calls'] <= 10:
        return
    if float(dev) <= 0.08:
        _ctrl['noise_base'] *= 0.955
    _ctrl['noise_base'] = min(1.0, max(0.0, float(_ctrl['noise_base'])))
    if _ctrl['settle_step'] is None and _ctrl['noise_base'] < 0.05 and receipt['critic_steps'] > 0:
        _ctrl['settle_step'] = receipt['critic_steps']
    base = float(_ctrl['noise_base'])
    _ctrl['input_std'] = INPUT_PEAK * base
    _ctrl['output_std'] = OUTPUT_PEAK * (1.0 - base)


def _scheduled_heat(age):
    if age < PLATEAU:
        return 1.0
    if age < PLATEAU + COSINE:
        fraction = (age - PLATEAU) / float(COSINE)
        return 0.5 * (1.0 + math.cos(math.pi * fraction))
    return 0.0


def _update_rate():
    rms = _ctrl['pending_rms']
    if rms is None or _ctrl['settle_step'] is None:
        return
    rms_f = float(rms)
    if _ctrl['g_base'] is None:
        _ctrl['g_base'] = rms_f
    else:
        _ctrl['g_base'] = 0.995 * _ctrl['g_base'] + 0.005 * rms_f
    age = receipt['critic_steps'] - _ctrl['settle_step']
    scheduled = _scheduled_heat(age)
    if age >= PLATEAU + COSINE and rms_f > 2.5 * max(_ctrl['g_base'], 1e-8):
        _ctrl['rate_hi'] += 1
    else:
        _ctrl['rate_hi'] = 0
    if age < PLATEAU + COSINE:
        _ctrl['heat'] = scheduled
    elif _ctrl['rate_hi'] >= 30:
        _ctrl['heat'] = min(REOPEN_CAP, _ctrl['heat'] + 0.01)
    else:
        _ctrl['heat'] = min(scheduled, _ctrl['heat'] * 0.99)
    _ctrl['heat'] = min(1.0, max(0.0, float(_ctrl['heat'])))
    if _ctrl['heat'] > 0.5:
        _ctrl['anchor_heat'] = min(1.0, _ctrl['anchor_heat'] + 0.005)
    else:
        _ctrl['anchor_heat'] *= 0.995


def anchored_gradient_gap(D, x_real, g, dimension):
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    receipt['extra_critic_forwards'] += 1
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    with torch.no_grad():
        q = D(x_real.detach()).mean() - D(x_fake.detach()).mean()
    receipt['extra_score_forwards'] += 2
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    receipt['calls'] += 1
    _update_noise(q)
    s = handover_weight()
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(float(_ctrl['heat']), 6),
                                   round(float(_ctrl['noise_base']), 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    parts = [p.grad.detach().reshape(-1) for group in opt.param_groups for p in group['params'] if p.grad is not None]
    if parts:
        _ctrl['pending_rms'] = torch.cat(parts).square().mean().sqrt()
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        _update_rate()
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
        if receipt['critic_steps'] == 1 or receipt['critic_steps'] % 50 == 0:
            dev = None if _ctrl['dev'] is None else round(float(_ctrl['dev']), 6)
            row = [receipt['critic_steps'], round(lr, 8), round(network_multiplier(), 6),
                   round(prior_multiplier(), 6), round(handover_weight(), 6),
                   round(float(_ctrl['heat']), 6), round(float(_ctrl['anchor_heat']), 6),
                   round(float(_ctrl['noise_base']), 6), round(_ctrl['input_std'], 6),
                   round(_ctrl['output_std'], 6),
                   None if _ctrl['last_q'] is None else round(_ctrl['last_q'], 6), dev,
                   None if _ctrl['g_base'] is None else round(float(_ctrl['g_base']), 6),
                   _ctrl['settle_step'], _ctrl['rate_hi']]
            _ctrl['trace'].append(row)
            print(json.dumps({'sn3': row}), flush=True)
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_heat'] = float(_ctrl['heat'])
    receipt['final_anchor_heat'] = float(_ctrl['anchor_heat'])
    receipt['final_noise_base'] = float(_ctrl['noise_base'])
    receipt['final_input_std'] = _ctrl['input_std']
    receipt['final_output_std'] = _ctrl['output_std']
    receipt['settle_step'] = _ctrl['settle_step']
    receipt['lr_trace'] = _ctrl['trace']
    receipt['trace_columns'] = ['critic_step', 'applied_critic_lr', 'network_mult', 'prior_mult', 's',
                                'heat', 'anchor_heat', 'noise_base', 'input_std', 'output_std', 'q', 'dev',
                                'g_base', 'settle_step', 'rate_hi']
    receipt['budget_dependencies'] = [
        'Applied rates and noise do not read total_steps, noise_horizon, network_lr_horizon_cap, or evaluation scores.',
        'The frozen linear_* and policy_multipliers functions are called and their returns are discarded.',
        'Noise burn-in is signal-braked (absolute score-gap deviation), not a horizon fraction.',
        'The 800-step plateau and 600-step cosine start at the noise-settle event. They are fixed estimator lengths, not the declared training budget.',
        'A paired two-horizon prefix is still required before calling the schedule horizon-free in the training state.',
        'Direct-response gain still multiplies direct particle steps and restores the base rate.',
        'Guard warmup of 200 critic steps is the parent estimator constant.',
    ]
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


def _install_rules():
    import benchmarks.toy100.models as models
    import benchmarks.toy100.schedule as schedule
    original_input = models.linear_input_noise
    original_output = models.linear_output_noise
    original_policy = schedule.policy_multipliers

    def input_noise(peak, completed_steps, total_steps, end_fraction):
        original_input(peak, completed_steps, total_steps, end_fraction)
        return float(_ctrl['input_std'])

    def output_noise(peak, completed_steps, total_steps, warmup_fraction=0.0):
        original_output(peak, completed_steps, total_steps, warmup_fraction)
        return float(_ctrl['output_std'])

    def policy_multipliers(completed_step, total_steps, anneal_start, floor,
                           network_lr_horizon_cap=None, *, network_lr_floor=None):
        original_policy(completed_step, total_steps, anneal_start, floor,
                        network_lr_horizon_cap, network_lr_floor=network_lr_floor)
        return (network_multiplier(), prior_multiplier())

    models.linear_input_noise = input_noise
    models.linear_output_noise = output_noise
    schedule.policy_multipliers = policy_multipliers
    for mod in list(sys.modules.values()):
        if mod is None:
            continue
        for name, value in list(vars(mod).items()):
            if value is original_input:
                setattr(mod, name, input_noise)
            elif value is original_output:
                setattr(mod, name, output_noise)
            elif value is original_policy:
                setattr(mod, name, policy_multipliers)


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
_install_rules()
atexit.register(_write_receipt)
