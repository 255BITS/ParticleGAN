"""Reversible movement feedback. Noise also responds to training signals; no horizon input."""
import sys,json,math
import torch
from particlegan import recipes
from benchmarks.toy100 import schedule, models
state = {'prev':None,'fast':None,'slow':None,'ratio':None,'target':None,'u':None,'s':None,'calls':0,'noise_scale':None,'noise_ratio':None}
receipt = {'rule':'directed_motion','rows':[],'applied_rates':[],'history_devices':[]}

def mix(): return 1.0 if state['s'] is None else float(state['s'])
def multipliers(*args,**kwargs):
    u=1.0 if state['u'] is None else float(state['u'])
    return .01+.99*u,.05+.95*u

def constant_rate(*args,**kwargs): return 1.0

@torch.no_grad()
def observe(opt):
    params=[p for g in opt.param_groups for p in g['params']]
    rates=[float(g['lr']) for g in opt.param_groups for p in g['params']]
    state['calls']+=1
    if state['prev'] is None:
        state['prev']=[p.detach().clone() for p in params]
        for k in ('u','s','target'): state[k]=params[0].new_ones(())
        return
    motion=params[0].new_zeros(())
    for p,prev,rate in zip(params,state['prev'],rates):
        motion.add_(((p.detach()-prev)/max(rate,1e-30)).square().sum());prev.copy_(p)
    motion=motion.sqrt()
    if state['fast'] is None:
        state['fast']=motion.clone();state['slow']=motion.clone();state['ratio']=motion.new_ones(())
    else:
        state['fast'].lerp_(motion,.2);state['slow'].lerp_(motion,.005)
        state['ratio'].lerp_(state['fast']/state['slow'].clamp_min(1e-30),.1)
        r=state['ratio'];target=state['target']
        target.copy_(torch.where(r<.5,torch.zeros_like(target),torch.where(r>1.25,torch.maximum(target,((r-1.25)/1.25).clamp(0,1)),target)))
        state['s'].lerp_(target,.06);state['u'].lerp_(target,.005)
    if state['calls']==2 or state['calls']%50==0:
        row=dict(call=state['calls'],motion=float(motion),ratio=float(state['ratio']),target=float(state['target']),u=float(state['u']),s=mix(),multipliers=multipliers(),applied_d_lr=rates[0],input_sigma=input_noise(.5),output_sigma=.029,noise_ratio=None if state['noise_ratio'] is None else float(state['noise_ratio']))
        receipt['rows'].append(row);print(json.dumps(dict(controller=row)),flush=True)
    receipt['history_devices']=sorted({str(v.device) for v in state.values() if isinstance(v,torch.Tensor)})
    assert all(v.dtype==torch.float32 and v.device.type=='cuda' for v in state.values() if isinstance(v,torch.Tensor))

def record_applied(opt):
    if state['calls']<=2 or state['calls']%50==0:
        receipt['applied_rates'].append(dict(call=state['calls'],parameters=[sum(p.numel() for p in g['params']) for g in opt.param_groups],rates=[float(g['lr']) for g in opt.param_groups]))

@torch.no_grad()
def noise_update(ratio):
    # The same pre-guard gradient/moment ratio already computed by K3P.
    state['noise_ratio']=ratio.detach().clone()
    state['noise_scale']=((ratio.detach()-1.)/4.).clamp(0.,1.)

def input_noise(peak,*args,**kwargs):
    return float(peak)*(1.0 if state['noise_scale'] is None else float(state['noise_scale']))

def output_noise(peak,*args,**kwargs): return float(peak)

# Native and dense transfer hosts set rates at the actual step. Their observation
# receipt verifies the multiplier sampled for that step (the controller advances
# after D, so recomputing its current value would compare different states).
expected={}
def step_with_policy(trainer,real,*,network_lr_horizon_cap=None,network_lr_floor=None,**step_kwargs):
    def set_d(opt,args,kwargs):
        n,p=multipliers();rates=[trainer.initial_lrs[1][0]*n]
        opt.param_groups[0]['lr']=rates[0];expected[id(opt)]=(rates,n,p)
    def set_g(opt,args,kwargs):
        n,p=multipliers();rates=[trainer.initial_lrs[0][0]*n,trainer.initial_lrs[0][1]*p]
        for g,r in zip(opt.param_groups,rates):g['lr']=r
        expected[id(opt)]=(rates,n,p)
    dh=trainer.opt_d.register_step_pre_hook(set_d);gh=trainer.opt_g.register_step_pre_hook(set_g)
    try:return trainer.step(real,**step_kwargs)
    finally:dh.remove();gh.remove()

def policy_rate_action(trainer,completed_step,*,network_lr_horizon_cap=None,network_lr_floor=None):
    assert completed_step==trainer.completed_steps
    for opt in (trainer.opt_d,trainer.opt_g):
        rates,n,p=expected[id(opt)]
        assert all(math.isclose(float(g['lr']),r,rel_tol=1e-12,abs_tol=1e-15) for g,r in zip(opt.param_groups,rates))
    return dict(lr_g=trainer.opt_g.param_groups[0]['lr'],lr_prior=trainer.opt_g.param_groups[1]['lr'],lr_d=trainer.opt_d.param_groups[0]['lr'],network_multiplier=expected[id(trainer.opt_g)][1],prior_multiplier=expected[id(trainer.opt_g)][2],network_lr_horizon_cap=network_lr_horizon_cap,network_lr_floor=network_lr_floor,controller='directed_motion')

replacements=[(recipes.learning_rate_scale,constant_rate),(schedule.policy_multipliers,multipliers),(schedule.step_with_policy,step_with_policy),(schedule.policy_rate_action,policy_rate_action),(models.linear_input_noise,input_noise),(models.linear_output_noise,output_noise)]
for module in list(sys.modules.values()):
    if module is None or not getattr(module,'__name__','').startswith(('particlegan','benchmarks')):continue
    for name,value in list(vars(module).items()):
        for original,replacement in replacements:
            if value is original:setattr(module,name,replacement)
