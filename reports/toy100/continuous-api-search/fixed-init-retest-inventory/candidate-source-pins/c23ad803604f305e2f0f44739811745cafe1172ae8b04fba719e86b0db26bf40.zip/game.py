"""Bounded network reversal damping using previous raw Adam displacement. No extra gradients or optimizer steps."""
import torch, json, atexit, sys
from pathlib import Path
pending={}; history={}; rows=[]
def begin(opt):
 import response
 items=[]
 for group in opt.param_groups:
  if group.get('_comparison_prior',False): continue
  for p in group['params']:
   if p.grad is not None and id(p) not in response.prior_ids:
    items.append((p,p.detach().clone(),float(group['lr'])))
 pending[id(opt)]=items
@torch.no_grad()
def finish(opt):
 items=pending.pop(id(opt),None)
 if items is None:return
 norm=0.; corr=0.
 for p,before,lr in items:
  delta=p.detach()-before
  old=history.get(id(p))
  correction=torch.zeros_like(delta)
  if old is not None:
   # Remove half of only the component opposing the previous raw Adam direction.
   projection=(delta*old).sum()/old.square().sum().clamp_min(1e-30)
   correction=-.5*projection.clamp_max(0.)*old
  p.add_(correction)
  history[id(p)]=delta.clone()
  assert delta.device.type=='cuda' and delta.dtype==torch.float32
  norm+=float(delta.square().sum()); corr+=float(correction.square().sum())
 rows.append(dict(optimizer=id(opt),lrs=sorted({lr for p,b,lr in items}),adam_displacement_l2=norm**.5,correction_l2=corr**.5))
def write():
 if '--output' in sys.argv:
  out=Path(sys.argv[sys.argv.index('--output')+1])
  if out.is_dir():(out/'game-trace.json').write_text(json.dumps(dict(rule='delta - .5*min(dot(delta,previous)/norm(previous)^2,0)*previous; per parameter tensor, networks only',rows=rows,history_devices=sorted({str(v.device) for v in history.values()}),history_dtypes=sorted({str(v.dtype) for v in history.values()}))))
atexit.register(write)
