"""Bound extra real R1 pressure by the original Rp/bcap critic gradient.

No input/target statistics or evaluation are consulted. All gradient comparisons
are detached FP32 CUDA scalar reductions. The pre-Adam reference descent
component is retained by at least one half; Adam itself is unchanged.
"""
import torch
from particlegan.grad_regularizers import GradientPenalty
from particlegan.gan_loss import GANLoss
ORIGINAL = GradientPenalty.penalty
ORIGINAL_D_LOSS = GANLoss.d_loss
LAST_D_LOSS = None
RECEIPT = {'calls': 0, 'extra_critic_forwards': 0, 'extra_input_backwards': 0,
           'extra_parameter_gradient_evaluations': 0, 'mix_sum': 0.0,
           'mix_min': 1.0, 'mix_max': 0.0, 'limited_steps': 0}


def budget_mix(reference, extra):
    reference_norm2 = sum(g.square().sum() for g in reference if g is not None)
    dot = sum((a*b).sum() for a,b in zip(reference,extra) if a is not None and b is not None)
    if not isinstance(dot, torch.Tensor):
        dot = torch.zeros_like(reference_norm2)
    return torch.where(dot < 0, (0.5*reference_norm2 / (-dot).clamp_min(1e-12)).clamp(max=1.0), torch.ones_like(reference_norm2)).detach()


def install(budget):
    assert type(budget) is int and budget > 0
    RECEIPT['frozen_budget'] = budget
    def capture(self, real_logits, fake_logits):
        global LAST_D_LOSS
        LAST_D_LOSS = ORIGINAL_D_LOSS(self, real_logits, fake_logits)
        return LAST_D_LOSS
    GANLoss.d_loss = capture
    def penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
        assert self.arm == 'b_cap' and self.lazy_k == 1 and self.method == 'autograd'
        assert LAST_D_LOSS is not None
        nr2 = self._grad_norm(D, x_real, squared=True)
        nr = (nr2 + 1e-12).sqrt()
        nf = self._grad_norm(D, x_fake, squared=False)
        cap_real = (nr-self.kappa).relu().square().mean()
        cap_fake = (nf-self.kappa).relu().square().mean()
        base_penalty = (self.coeff / 2.0) * (cap_real + cap_fake)
        extra_penalty = (self.coeff / 2.0) * (nr2.mean() - cap_real)
        parameters = tuple(p for p in D.parameters() if p.requires_grad)
        reference = torch.autograd.grad(LAST_D_LOSS + base_penalty, parameters, retain_graph=True, allow_unused=True)
        extra = torch.autograd.grad(extra_penalty, parameters, retain_graph=True, allow_unused=True)
        mix = budget_mix(reference, extra)
        value = base_penalty + mix * extra_penalty
        mix_value = float(mix)
        RECEIPT['calls'] += 1
        RECEIPT['extra_parameter_gradient_evaluations'] += 2
        RECEIPT['first_step'] = RECEIPT.get('first_step', step)
        RECEIPT['last_step'] = step
        RECEIPT['first_mix'] = RECEIPT.get('first_mix', mix_value)
        RECEIPT['last_mix'] = mix_value
        RECEIPT['mix_sum'] += mix_value
        RECEIPT['mix_min'] = min(RECEIPT['mix_min'], mix_value)
        RECEIPT['mix_max'] = max(RECEIPT['mix_max'], mix_value)
        RECEIPT['limited_steps'] += int(mix_value < 1.0)
        RECEIPT['fake_cap'] = self.kappa
        return value, ({'applied': True, 'pen': float(value.detach()), 'mix': mix_value, 'fake_cap': self.kappa} if collect_stats else {})
    GradientPenalty.penalty = penalty
