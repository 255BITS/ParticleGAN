from particlegan.grad_regularizers import GradientPenalty
ORIGINAL = GradientPenalty.penalty
RECEIPT = {'calls': 0, 'extra_critic_forwards': 0, 'extra_input_backwards': 0}

def install(budget):
    assert type(budget) is int and budget > 0
    RECEIPT['frozen_budget'] = budget
    def penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
        assert self.arm == 'b_cap' and self.lazy_k == 1 and self.method == 'autograd'
        real_cap = self.kappa * max(0.0, 1.0 - step / budget)
        nr = self._grad_norm(D, x_real, squared=False)
        nf = self._grad_norm(D, x_fake, squared=False)
        value = (self.coeff / 2.0) * ((nr-real_cap).relu().square().mean() + (nf-self.kappa).relu().square().mean())
        RECEIPT['calls'] += 1
        RECEIPT['first_step'] = RECEIPT.get('first_step', step)
        RECEIPT['last_step'] = step
        RECEIPT['first_real_cap'] = RECEIPT.get('first_real_cap', real_cap)
        RECEIPT['last_real_cap'] = real_cap
        RECEIPT['fake_cap'] = self.kappa
        return value, ({'applied': True, 'pen': float(value.detach()), 'real_cap': real_cap, 'fake_cap': self.kappa} if collect_stats else {})
    GradientPenalty.penalty = penalty
