"""Condition-coordinate R1 plus data-coordinate cap; unconditional retained hybrid."""
import torch
from particlegan.grad_regularizers import GradientPenalty, _score_scalar
from benchmarks.transfer_suite.legacy_noise_adapters import _InputAdapter
_original_penalty = GradientPenalty.penalty
_original_forward = _InputAdapter.forward
_capture = None
receipts = {"conditional_penalties": 0, "unconditional_penalties": 0,
            "condition_inputs": 0, "gradient_calls": 0}

def forward(self, *args, **kwargs):
    if _capture is None:
        return _original_forward(self, *args, **kwargs)
    args = list(args)
    for i, value in enumerate(args):
        if i != self.data_index and isinstance(value, torch.Tensor) and value.is_floating_point():
            args[i] = value.detach().requires_grad_(True)
            _capture.append(args[i])
    return _original_forward(self, *args, **kwargs)

def gradients(D, x):
    global _capture
    x = x.detach().clone().requires_grad_(True)
    conditions = []
    previous = _capture
    _capture = conditions
    try:
        logits = D(x)
    finally:
        _capture = previous
    grads = torch.autograd.grad(_score_scalar(logits), [x] + conditions,
                                create_graph=True, allow_unused=True)
    receipts["gradient_calls"] += 1
    squared = grads[0].square().flatten(1).sum(1)
    condition_squared = sum(g.square().flatten(1).sum(1) for g in grads[1:] if g is not None)
    return squared, condition_squared, len(conditions)

def penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != "a_r1r2" or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    coeff = self.coeff * self.lazy_k
    real_sq, condition_sq, n = gradients(D, x_real)
    fake_sq, _, nf = gradients(D, x_fake)
    assert n == nf
    fake_cap = (torch.sqrt(fake_sq + 1e-12) - self.kappa).relu().square()
    if n:
        real_term = condition_sq + (torch.sqrt(real_sq + 1e-12) - self.kappa).relu().square()
        receipts["conditional_penalties"] += 1
        receipts["condition_inputs"] += n
    else:
        real_term = real_sq
        receipts["unconditional_penalties"] += 1
    value = (coeff / 2) * (real_term.mean() + fake_cap.mean())
    return value, ({"applied": True, "pen": float(value.detach())} if collect_stats else {})

_InputAdapter.forward = forward
GradientPenalty.penalty = penalty
