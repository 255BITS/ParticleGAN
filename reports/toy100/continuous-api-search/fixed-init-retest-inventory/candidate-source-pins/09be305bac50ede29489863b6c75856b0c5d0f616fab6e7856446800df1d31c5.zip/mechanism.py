"""K3P: K3 plus an anchored R1 that damps the critic without biasing its equilibrium.

pen = s * a_r1r2 + (1 - s) * (b_cap + prox),  prox = mean ||grad_x D(x_r) - grad_x Dbar(x_r)||^2 / d  (RMS units, reals),
Dbar = EMA of the critic's parameters (decay ANCHOR_DECAY per critic step, started at the first blended call).
Zero-centered R1 anchors the critic's input gradient to 0 (damped but flat at data: imprecise centers); b_cap is inactive
below kappa, so at the floor the critic is unregularized and undamped. prox anchors the gradient to the critic's own recent
average instead: zero at a stationary critic, restoring during oscillation. At s == 1 this is bit-exact a_r1r2 (toys).
Rest of the K3 description:

pen = s * a_r1r2 + (1 - s) * b_cap, both from the same input gradients, with
  a_r1r2 = R1 on reals + one-sided fake cap, RMS units (the session mechanism, bit-exact at s == 1)
  b_cap  = relu(||g|| - kappa)^2 on reals and fakes, L2 units (GradRegularizer 'b_cap', exact at s == 0)
  s = max(0, min(1, 2r) - 2f) / (1 - 2f),  r = critic's applied LR on its last Adam step / max applied LR,
  f = FLOOR, the declared network LR floor, so s == 0 exactly at the floor.
Critic guard: before each critic Adam step, a tensor with >= GUARD_MIN_STEPS prior steps whose gradient RMS
exceeds GUARD_C * sqrt(mean bias-corrected v) is scaled down to that ratio (no-op multiply by 1.0 otherwise).
The critic is the first optimizer stepped after a penalty call. No host or task identity is read.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
FIGHT_EMA = 0.9
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'extra_penalty_backwards': 0,
           'rule': 'pb1_fight_reopen', 'floor': FLOOR,
           'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
           'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [], 'anchor_decay': ANCHOR_DECAY,
           'anchor_started_call': None, 'prox_trace': [],
           'control': 'fight_reopen',
           'fight_ema_decay': FIGHT_EMA,
           'rate_rule': 'm = m_k3p + (1-m_k3p)*fight_ema for network and prior; fight_ema starts at 0',
           'mix_rule': 'K3P handover of the applied critic LR; fight raises LR and therefore s, which releases the anchor',
           'horizon_note': 'K3P LR schedule and noise still read the declared horizon; fight_ema does not. Intermediate ablation.',
           'decomposition': 'g_tot = g_adv + coeff * g_pen; g_pen = d(penalty)/d(critic) via autograd.grad, not written into .grad; one Adam step per role',
           'penalty_detached_calls': 0, 'decompose_errors': 0, 'pen_coeff_not_one': 0,
           'matched_params': None, 'optimizer_params': None, 'unmatched_numel': None, 'matched_numel': None,
           'multiplier_calls': 0}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0, 'clips': [], 'critic_ref': None,
          'g_pen': None, 'pen_coeff': None, 'last_s': None, 'mdepth': 0, 'queue': [], 'trace_path': None, 'last_force': None,
          'fight_ema': None, 'gain': 0.0}


def _trace_file():
    if _state['trace_path'] is None and '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        _state['trace_path'] = out / 'force-trace.jsonl'
    return _state['trace_path']


def _capture_penalty_grad(penalty, D):
    """Extra penalty backward. Does not write .grad and does not step."""
    _state['g_pen'] = None
    _state['pen_coeff'] = None
    _state['last_s'] = handover_weight()
    if not getattr(penalty, 'requires_grad', False):
        receipt['penalty_detached_calls'] += 1
        return
    params = [p for p in D.parameters() if p.requires_grad]
    try:
        grads = torch.autograd.grad(penalty, params, retain_graph=True, allow_unused=True)
    except RuntimeError as exc:
        receipt['decompose_errors'] += 1
        receipt['decompose_error'] = str(exc)
        return
    receipt['extra_penalty_backwards'] += 1
    stored = {}
    for p, g in zip(params, grads):
        stored[id(p)] = None if g is None else g.detach()
    _state['g_pen'] = stored

    def _coeff(upstream):
        _state['pen_coeff'] = None if upstream is None else upstream.detach()
        return None

    penalty.register_hook(_coeff)


def _flush_force(final=False):
    queue = _state['queue']
    if not queue:
        return
    path = _trace_file()
    if path is None:
        _state['queue'] = []
        return
    rows = []
    for item in queue:
        An, Pn, Nn, dot, coeff = [float(v.detach().cpu()) for v in item['tensors']]
        denom = An * Pn
        cos = dot / denom if denom > 1e-20 else 0.0
        fight = max(0.0, -cos) * (2.0 * denom) / (An * An + Pn * Pn + 1e-20)
        row = dict(step=item['step'], s=item['s'], lr=item['lr'], calls=item['calls'],
                   An=An, Pn=Pn, Nn=Nn, cos=cos, fight=fight, gain=item['gain'], coeff=coeff,
                   matched=item['matched'], opt_params=item['opt_params'], pen_only=item['pen_only'])
        rows.append(row)
    with path.open('a') as handle:
        for row in rows:
            handle.write(json.dumps(row) + '\n')
    last = rows[-1]
    if last['step'] % 100 < 25 or final:
        print(json.dumps(dict(force=True, **{k: last[k] for k in ('step', 's', 'lr', 'An', 'Pn', 'Nn', 'cos', 'fight', 'gain', 'coeff')})), flush=True)
    _state['queue'] = []


def _measure(opt, args, kwargs):
    _state['mdepth'] += 1
    if _state['mdepth'] != 1 or _state['g_pen'] is None:
        return
    if _state['critic'] is not None and id(opt) != _state['critic']:
        return
    if _state['critic'] is None and not _state['pending']:
        return
    stored = _state['g_pen']
    coeff_t = _state['pen_coeff']
    sample = next((v for v in stored.values() if v is not None), None)
    coeff = torch.ones((), device=sample.device if sample is not None else torch.device('cpu'))
    if coeff_t is not None:
        coeff = coeff_t.reshape(()).to(dtype=torch.float32)
        if abs(float(coeff.detach().cpu()) - 1.0) > 1e-5:
            receipt['pen_coeff_not_one'] += 1
    a2 = []
    p2 = []
    n2 = []
    dot = []
    matched = 0
    opt_params = 0
    for group in opt.param_groups:
        for p in group['params']:
            opt_params += 1
            g = p.grad
            if g is None:
                continue
            gp = stored.get(id(p))
            if gp is None:
                gp = torch.zeros_like(g)
            else:
                matched += 1
                gp = gp.to(dtype=g.dtype)
            ga = g - coeff * gp
            a2.append(ga.detach().square().sum())
            p2.append((coeff * gp).detach().square().sum())
            n2.append(g.detach().square().sum())
            dot.append((ga.detach() * (coeff * gp).detach()).sum())
    if not a2:
        return
    receipt['matched_params'] = matched
    receipt['optimizer_params'] = opt_params
    if receipt['unmatched_numel'] is None:
        unmatched = []
        matched_n = 0
        seen = set()
        for group in opt.param_groups:
            for p in group['params']:
                seen.add(id(p))
                gp = stored.get(id(p))
                if gp is None:
                    unmatched.append(int(p.numel()))
                else:
                    matched_n += int(p.numel())
        receipt['unmatched_numel'] = unmatched
        receipt['matched_numel'] = matched_n
    pen_only = sum(1 for v in stored.values() if v is not None) - matched
    _state['last_force'] = dict(
        tensors=(torch.stack(a2).sum().sqrt(), torch.stack(p2).sum().sqrt(), torch.stack(n2).sum().sqrt(),
                 torch.stack(dot).sum(), coeff.detach()),
        matched=matched, opt_params=opt_params, pen_only=pen_only)


def handover_weight():
    if _state['lr_last'] is None or _state['lr_max'] <= 0.0:
        return 1.0
    r = _state['lr_last'] / _state['lr_max']
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        _state['g_pen'] = None
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    _capture_penalty_grad(penalty, D)
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    try:
        if _state['critic'] is None:
            if not _state['pending']:
                return
            _state['critic'] = id(opt)
            _state['critic_ref'] = opt
            receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
            _state['depth'] = 1
        if id(opt) != _state['critic']:
            return
        if _state['depth'] == 1:
            if _state['ema'] is not None:
                with torch.no_grad():
                    for e, p in zip(_state['ema'], _critic_params()):
                        e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
            lr = max(float(g['lr']) for g in opt.param_groups)
            _state['lr_last'] = lr
            _state['lr_max'] = max(_state['lr_max'], lr)
            receipt['critic_steps'] += 1
            force = _state.get('last_force')
            if force is not None:
                An, Pn, _Nn, dot, _coeff = force['tensors']
                denom = An * Pn
                fight = torch.relu(-dot / denom.clamp_min(1e-20)) * (2.0 * denom) / (An * An + Pn * Pn + 1e-20)
                fight_value = float(fight.detach())
                prev = _state['fight_ema']
                ema = fight_value if prev is None else FIGHT_EMA * prev + (1.0 - FIGHT_EMA) * fight_value
                _state['fight_ema'] = ema
                _state['gain'] = min(1.0, max(0.0, ema))
                _state['queue'].append(dict(step=receipt['critic_steps'], s=_state['last_s'], lr=lr,
                                             calls=receipt['calls'], gain=_state['gain'], **force))
                _state['last_force'] = None
                if len(_state['queue']) >= 25:
                    _flush_force()
        _state['depth'] = max(0, _state['depth'] - 1)
    finally:
        _state['mdepth'] = max(0, _state['mdepth'] - 1)


def _write_receipt():
    _flush_force(final=True)
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


def _phase_multipliers(*args, **kwargs):
    """K3P schedule, then a reversible raise from the adversarial/penalty fight."""
    base_net, base_prior = _ORIGINAL_POLICY(*args, **kwargs)
    gain = float(_state['gain'])
    receipt['multiplier_calls'] += 1
    return (base_net + (1.0 - base_net) * gain, base_prior + (1.0 - base_prior) * gain)


def _install_phase_rates():
    global _ORIGINAL_POLICY
    from benchmarks.toy100 import schedule
    _ORIGINAL_POLICY = schedule.policy_multipliers
    if _ORIGINAL_POLICY is _phase_multipliers:
        return
    schedule.policy_multipliers = _phase_multipliers
    for module in list(sys.modules.values()):
        if module is None:
            continue
        name = getattr(module, '__name__', '')
        if not name.startswith(('particlegan', 'benchmarks')):
            continue
        for attr, value in list(vars(module).items()):
            if value is _ORIGINAL_POLICY:
                setattr(module, attr, _phase_multipliers)


_ORIGINAL_POLICY = None
GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_measure)
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
_install_phase_rates()
atexit.register(_write_receipt)
