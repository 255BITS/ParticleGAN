"""CUDA Adam step state with the retained noncapturable arithmetic."""
import torch
_original_init_group = torch.optim.Adam._init_group
receipts = {"relocated_step_tensors": 0}
def init_group(self, group, params_with_grad, grads, exp_avgs, exp_avg_sqs,
               max_exp_avg_sqs, state_steps):
    value = _original_init_group(self, group, params_with_grad, grads, exp_avgs,
                                 exp_avg_sqs, max_exp_avg_sqs, state_steps)
    for i, parameter in enumerate(params_with_grad):
        state = self.state[parameter]
        if state["step"].device != parameter.device:
            state["step"] = state["step"].to(parameter.device)
            state_steps[i] = state["step"]
            receipts["relocated_step_tensors"] += 1
    return value

torch.optim.Adam._init_group = init_group
