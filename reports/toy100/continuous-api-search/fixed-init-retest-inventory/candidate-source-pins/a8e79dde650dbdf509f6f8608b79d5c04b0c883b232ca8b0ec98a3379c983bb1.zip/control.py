"""Reversible fast/slow gradient-energy LR control; no schedule inputs."""
import atexit,json,sys
from pathlib import Path
import torch
state={}
trace=[]
def register(opt):
    for group in opt.param_groups:
        state[id(group)]=dict(base=None,n=0,fast=None,slow=None,means=None)
@torch.no_grad()
def apply(opt):
    for i,group in enumerate(opt.param_groups):
        st=state[id(group)]
        if st['base'] is None: st['base']=float(group['lr'])
        st['n']+=1
        grads=[p.grad.detach() for p in group['params'] if p.grad is not None]
        assert grads and all(g.is_cuda and g.dtype==torch.float32 for g in grads)
        energy=sum(g.square().sum() for g in grads)
        if st['fast'] is None:
            st['fast']=torch.zeros_like(energy)
            st['slow']=torch.zeros_like(energy)
            st['means']=[torch.zeros_like(g) for g in grads]
        st['fast'].lerp_(energy,.05)
        st['slow'].lerp_(energy,.001)
        fast=st['fast']/(1-.95**st['n'])
        slow=st['slow']/(1-.999**st['n'])
        ratio=fast/slow.clamp_min(1e-30)
        for m,g in zip(st['means'],grads):m.lerp_(g,.05)
        coherence=(sum(m.square().sum() for m in st['means']) / (st['fast']*(1-.95**st['n'])).clamp_min(1e-30)).clamp(0,1)
        innovation=((ratio-1)/4).clamp(0,1)
        import response
        is_prior=group.get('_comparison_prior',False) or all(id(p) in response.prior_ids for p in group['params'])
        floor=.05 if is_prior else .01
        factor=floor+(1-floor)*float(torch.maximum(coherence,innovation))
        group['lr']=st['base']*factor
        trace.append(dict(optimizer=id(opt),group=i,step=st['n'],base=st['base'],factor=factor,lr=group['lr'],coherence=float(coherence),innovation=float(innovation),fast_slow_ratio=float(ratio),fast_energy=float(fast),slow_energy=float(slow)))
def write():
    if '--output' not in sys.argv:return
    out=Path(sys.argv[sys.argv.index('--output')+1])
    if out.is_dir():
        ids=list(dict.fromkeys(x['optimizer'] for x in trace))
        for v in trace:v['optimizer']=ids.index(v['optimizer'])
        (out/'controller-trace.json').write_text(json.dumps(trace)+'\n')
atexit.register(write)

# Adapt the existing schedule audit to verify and expose this declared rate rule.
# Only policy plumbing changes; no metric, architecture, data or host-budget edits.
from benchmarks.toy100 import schedule
from benchmarks.transfer_suite import public_default_verification as verify

def step_with_control(trainer, real, *, network_lr_horizon_cap=None, network_lr_floor=None, **kwargs):
    return trainer.step(real, **kwargs)

def rate_action(trainer, completed_step, **kwargs):
    rates=[float(g['lr']) for o in (trainer.opt_g,trainer.opt_d) for g in o.param_groups]
    groups=[g for o in (trainer.opt_g,trainer.opt_d) for g in o.param_groups]
    assert len(groups)==3
    for g,v in zip(groups,rates):
        assert abs(v-state[id(g)]['applied_lr'])<1e-15
    return dict(step=completed_step,lr_g=rates[0],lr_prior=rates[1],lr_d=rates[2],
                network_multiplier=rates[0]/state[id(groups[0])]['base'],
                prior_multiplier=rates[1]/state[id(groups[1])]['base'],
                policy='candidate_controller',multiplier=rates[0]/state[id(groups[0])]['base'])
schedule.step_with_policy=step_with_control
schedule.policy_rate_action=rate_action
verify.rate_action=rate_action
