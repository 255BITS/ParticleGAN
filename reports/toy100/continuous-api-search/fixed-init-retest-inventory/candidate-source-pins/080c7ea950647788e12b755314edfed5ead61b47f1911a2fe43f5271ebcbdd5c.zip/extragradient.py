"""Shared-sample simultaneous Adam game predictor/corrector. No host signals read."""
import atexit, copy, json, sys
from pathlib import Path
import torch
import mechanism, latent, response
RAW_STEP=torch.optim.Adam.step
receipt={'rule':'shared_sample_simultaneous_adam_extragradient', 'updates':0,
         'predictor_optimizer_evaluations':0, 'corrector_optimizer_commits':0,
         'critic_forwards':{'predictor':0,'corrector':0}, 'trace':[], 'checks':{}}
phase='idle'

def clone(x):
    if torch.is_tensor(x):return x.detach().clone()
    if isinstance(x,dict):return {k:clone(v) for k,v in x.items()}
    if isinstance(x,list):return [clone(v) for v in x]
    if isinstance(x,tuple):return tuple(clone(v) for v in x)
    return x

def rng_save(streams):
    return (torch.get_rng_state(),torch.cuda.get_rng_state(),[s.get_state() for s in streams])
def rng_load(state,streams):
    torch.set_rng_state(state[0]);torch.cuda.set_rng_state(state[1])
    for s,v in zip(streams,state[2]):s.set_state(v)
def rng_equal(a,b):
    return torch.equal(a[0],b[0]) and torch.equal(a[1],b[1]) and all(torch.equal(x,y) for x,y in zip(a[2],b[2]))
def aux_save():
    state=dict(mechanism._state)
    state['ema']=clone(state['ema']);state['clips']=list(state['clips'])
    return (state,clone(response.previous),copy.deepcopy(latent.stats),
            copy.deepcopy(mechanism.receipt),copy.deepcopy(response.receipt),copy.deepcopy(latent.receipt))
def aux_load(a):
    for dest,src in zip((mechanism._state,response.previous,latent.stats,mechanism.receipt,response.receipt,latent.receipt),a):
        dest.clear();dest.update(src)
def initialize(opt):
    for group in opt.param_groups:
        for p in group['params']:
            if not opt.state[p]:
                opt.state[p].update(step=torch.zeros((),device=p.device,dtype=torch.float32),
                                    exp_avg=torch.zeros_like(p),exp_avg_sq=torch.zeros_like(p))
def temporary_step(opt):
    initialize(opt)
    ls=latent.begin(opt);rs=response.begin(opt)
    try:RAW_STEP(opt)
    finally:response.end(rs);latent.end(ls)
def assign(opt,grads):
    for p,g in zip((p for group in opt.param_groups for p in group['params']),grads):p.grad=g

def update(losses,opts,modules,stream,noise):
    global phase
    if not hasattr(modules[0],'_eg_counter'):
        def count(*unused):
            if phase in receipt['critic_forwards']:receipt['critic_forwards'][phase]+=1
        modules[0]._eg_counter=modules[0].register_forward_hook(count)
    streams=[stream]
    if noise is not None:
        streams += [v for v in vars(noise).values() if isinstance(v,torch.Generator)]
    streams=list({id(s):s for s in streams}.values())
    params=[[p for g in opt.param_groups for p in g['params']] for opt in opts]
    assert all(p.is_cuda and p.dtype==torch.float32 for ps in params for p in ps)
    base=[[p.detach().clone() for p in ps] for ps in params]
    states=[{p:clone(st) for p,st in opt.state.items()} for opt in opts]
    groups=[[{k:clone(v) for k,v in g.items() if k!='params'} for g in opt.param_groups] for opt in opts]
    buffers=[(b,b.detach().clone()) for m in modules for b in m.buffers()]
    aux=aux_save();rng=rng_save(streams)
    noise_counts=copy.deepcopy(noise._counts) if noise is not None else None
    def restore_aux():
        aux_load(clone_aux(aux))
        for opt,st,gs in zip(opts,states,groups):
            opt.state.clear();opt.state.update({p:clone(v) for p,v in st.items()})
            for g,saved in zip(opt.param_groups,gs):
                for k in list(g):
                    if k!='params':del g[k]
                g.update(saved)
        with torch.no_grad():
            for b,v in buffers:b.copy_(v)
    def evaluate():
        d,g=losses()
        return [torch.autograd.grad(d,params[0],allow_unused=True),torch.autograd.grad(g,params[1],allow_unused=True)]
    phase='predictor'
    first=evaluate();rng_after=rng_save(streams)
    for opt,grad in zip(opts,first):assign(opt,grad);temporary_step(opt)
    receipt['predictor_optimizer_evaluations']+=len(opts)
    predicted=[[p.detach().clone() for p in ps] for ps in params]
    restore_aux();rng_load(rng,streams)
    if noise is not None:noise._counts=copy.deepcopy(noise_counts)
    phase='corrector'
    second=evaluate();rng_corrector=rng_save(streams)
    n=receipt['updates']+1
    if n<=3:
        assert rng_equal(rng_after,rng_corrector),'predictor/corrector sampling diverged'
        for opt,st in zip(opts,states):
            for p,values in st.items():
                for k,v in values.items():
                    if torch.is_tensor(v):assert torch.equal(opt.state[p][k],v)
        receipt['checks'][str(n)]={'rng_replay':True,'optimizer_rollback':True,'cuda_fp32':True}
    with torch.no_grad():
        for ps,values in zip(params,base):
            for p,v in zip(ps,values):p.copy_(v)
    phase='idle'
    for opt,grad in zip(opts,second):assign(opt,grad);opt.step()
    receipt['corrector_optimizer_commits']+=len(opts);receipt['updates']=n
    if n<=3 or n%50==0:
        row={'update':n,'rates':[[g['lr'] for g in opt.param_groups] for opt in opts],
             'mixing':mechanism.handover_weight(),
             'predictor_rms':[float(torch.cat([(p-v).flatten() for p,v in zip(ps,bs)]).square().mean().sqrt()) for ps,bs in zip(predicted,base)],
             'committed_rms':[float(torch.cat([(p.detach()-v).flatten() for p,v in zip(ps,bs)]).square().mean().sqrt()) for ps,bs in zip(params,base)],
             'moment_steps':[[float(next(iter(opt.state.values()))['step'])] if opt.state else [] for opt in opts]}
        receipt['trace'].append(row)
        if n%200==0:print(json.dumps({'extragradient':row}),flush=True)

def clone_aux(a):
    state=dict(a[0]);state['ema']=clone(state['ema']);state['clips']=list(state['clips'])
    return (state,clone(a[1]),copy.deepcopy(a[2]),copy.deepcopy(a[3]),copy.deepcopy(a[4]),copy.deepcopy(a[5]))
def install():
    from benchmarks.locked_shared import mode_hold
    source=Path(__file__).with_name('ring_host.py')
    mode_hold.__dict__['extragradient']=sys.modules[__name__]
    exec(compile(source.read_text(),str(source),'exec'),mode_hold.__dict__)
def save():
    if '--output' in sys.argv:
        out=Path(sys.argv[sys.argv.index('--output')+1])
        if out.is_dir():(out/'extragradient-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
atexit.register(save)
