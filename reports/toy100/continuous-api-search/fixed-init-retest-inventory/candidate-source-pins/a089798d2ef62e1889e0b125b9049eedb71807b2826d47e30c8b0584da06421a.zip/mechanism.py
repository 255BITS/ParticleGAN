"""jt3 growth trust: same projection as jt2, with the cap held above acquisition.

kbu1 at full rate and s=1 reached 8 modes by update 500 and lost them at 1600,
when critic relative displacement jumped to 0.147. Its generator peak during
acquisition was 0.168 at update 160, and the critic peak before update 500 was
0.095. jt2's hard cap of 0.10 sat under that generator peak, so the path left
kbu1 before update 20 and never reached 8 modes.

  cap = min(0.50, 2 * ema)
  ema starts at 0.25, so the first cap is 0.50.
  ema = 0.995*ema + 0.005*max realized relative displacement of critic,
  generator, and prior, using the post-projection value.
A step of 0.168 at update 160 stays inside the cap. After motion falls to the
measured hold range (critic at most 0.017 from updates 500-1500), ema falls
and the cap tightens, so the update-1600 jump is projected down. While a shock
stays over the cap, the cap grows about 0.5% per critic step. It does not
spring back to 0.50.

Mixing stays s=1. The EMA anchor is inactive. Host floors are 1. The growth
cap is the critic constraint. Guard, latent damping, and direct response are
unchanged. Noise horizon 1200 is an inherited intermediate and is not read.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
ABS_MAX = 0.50
GROWTH = 2.0
EMA_DECAY = 0.995
_original_penalty = GradientPenalty.penalty
receipt = {
    'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
    'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0,
    'blend_calls': 0, 'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None,
    'critic_steps': 0, 'critic_parameters': None, 'lr_max': None, 'lr_last': None,
    's_trace': [], 'rule': 'jt3_late_growth', 'anchor_decay': ANCHOR_DECAY,
    'anchor_started_call': None, 'prox_trace': [],
    'mixing_signal': 'fixed_s_1_early_penalty',
    'lr_clock_decoupled': True,
    'anchor_inactive': True,
    'abs_max': ABS_MAX, 'growth': GROWTH, 'ema_decay': EMA_DECAY,
    'adam_moments': 'unchanged by the projection; parameters only',
    'inactive_rows': 'uniform group scale; a zero displacement stays zero',
    'joint_roles': ['g', 'd', 'prior'], 'rate_trace': [], 'rho_summary': {},
    'clipped_groups': 0, 'unclipped_groups': 0,
    'noise_note': 'driver noise_horizon=1200 remains; not an input to the cap or s',
    'budget_note': 'cap and s do not read total_steps, network_lr_horizon_cap, scores, or the shift',
    'why_not_jt2': 'jt2 cap 0.10 clipped the measured acquisition generator peak 0.168',
}
_state = {
    'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None,
    'depth': 0, 'clips': [], 'critic_ref': None,
    'motion_ema': 0.25, 'role_realized': {}, 'saved': {}, 'tick': 0,
    'last_cap': ABS_MAX, 'last_peak': None,
}


def handover_weight():
    return 1.0


def current_cap():
    return min(ABS_MAX, GROWTH * _state['motion_ema'])


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _optimizer_role(opt):
    if _state['critic'] is None:
        return 'd' if _state['pending'] else 'g'
    if id(opt) == _state['critic']:
        return 'd'
    return 'g'


def _group_role(group, optimizer_role):
    if group.get('_comparison_prior'):
        return 'prior'
    return optimizer_role


def _group_relative(parameters, before):
    delta = None
    base = None
    count = 0
    for current, previous in zip(parameters, before):
        difference = (current.detach() - previous).square().sum()
        magnitude = previous.detach().square().sum()
        delta = difference if delta is None else delta + difference
        base = magnitude if base is None else base + magnitude
        count += current.numel()
    if count == 0:
        return 0.0
    return float((delta / count).sqrt() / (base / count).clamp_min(1e-30).sqrt())


def _update_motion():
    peaks = [value for value in _state['role_realized'].values() if value is not None and value > 0.0]
    if not peaks:
        return
    peak = max(peaks)
    _state['last_peak'] = peak
    _state['motion_ema'] = EMA_DECAY * _state['motion_ema'] + (1.0 - EMA_DECAY) * peak
    receipt['final_motion_ema'] = _state['motion_ema']
    receipt['final_cap'] = current_cap()
    receipt['final_s'] = 1.0


def _snapshot(opt, args, kwargs):
    _state['tick'] += 1
    bundles = []
    for group in opt.param_groups:
        bundles.append((group, [p.detach().clone() for p in group['params']], float(group['lr'])))
    _state['saved'][id(opt)] = bundles


def _project(opt, args, kwargs):
    bundles = _state['saved'].pop(id(opt), None)
    if not bundles:
        return
    optimizer_role = _optimizer_role(opt)
    cap = current_cap()
    _state['last_cap'] = cap
    group_realized = {}
    for group, before, seen_lr in bundles:
        role = _group_role(group, optimizer_role)
        rel = _group_relative(group['params'], before)
        scale = 1.0 if rel <= cap or rel < 1e-12 else cap / rel
        if scale < 1.0:
            receipt['clipped_groups'] += 1
            with torch.no_grad():
                for current, previous in zip(group['params'], before):
                    current.data.mul_(scale).add_(previous, alpha=1.0 - scale)
            realized_rel = _group_relative(group['params'], before)
        else:
            receipt['unclipped_groups'] += 1
            realized_rel = rel
        group_realized[role] = max(group_realized.get(role, 0.0), realized_rel)
        summary = receipt['rho_summary'].setdefault(role, {
            'min_scale': scale, 'max_scale': scale, 'last_scale': scale,
            'min_cap': cap, 'max_cap': cap, 'last_cap': cap,
            'max_attempted_rel': rel, 'last_attempted_rel': rel, 'calls': 0,
        })
        summary['min_scale'] = min(summary['min_scale'], scale)
        summary['max_scale'] = max(summary['max_scale'], scale)
        summary['last_scale'] = scale
        summary['min_cap'] = min(summary['min_cap'], cap)
        summary['max_cap'] = max(summary['max_cap'], cap)
        summary['last_cap'] = cap
        summary['max_attempted_rel'] = max(summary['max_attempted_rel'], rel)
        summary['last_attempted_rel'] = rel
        summary['calls'] += 1
        if summary['calls'] <= 5 or summary['calls'] % 20 == 0:
            receipt['rate_trace'].append([
                role, summary['calls'], round(cap, 6), round(rel, 8), round(realized_rel, 8),
                round(scale, 6), round(_state['motion_ema'], 6), round(seen_lr, 8),
            ])
        if role == 'd' and (summary['calls'] <= 3 or summary['calls'] % 100 == 0):
            print(json.dumps(dict(jt3=dict(
                call=summary['calls'], cap=cap, motion_ema=_state['motion_ema'],
                attempted_rel=rel, realized_rel=realized_rel, scale=scale,
                seen_lr=seen_lr, s=1.0, role_realized=dict(_state['role_realized']),
            ))), flush=True)
    for role, realized in group_realized.items():
        _state['role_realized'][role] = realized
    if optimizer_role == 'd':
        _update_motion()


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = 1.0
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    real_squared = self._grad_norm(D, x_real, squared=True) / dimension
    fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
    fake_cap = (fake_norm - self.kappa).relu().square()
    penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
    receipt['pure_a_calls'] += 1
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], 1.0, round(current_cap(), 6), round(_state['motion_ema'], 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['lr_last'] = lr
        receipt['lr_max'] = _state['lr_max']
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = 1.0
    receipt['final_cap'] = current_cap()
    receipt['final_motion_ema'] = _state['motion_ema']
    receipt['final_role_realized'] = _state['role_realized']
    receipt['host_lr_note'] = (
        'lr_last is the critic group lr after the step. Host floors are 1, so this stays '
        'at the recipe rate. The trust scale is rate_trace column 5, not the learning rate. '
        'Columns: role, call, cap, attempted_rel, realized_rel, scale, motion_ema, group_lr.'
    )
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_snapshot)
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_project)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
