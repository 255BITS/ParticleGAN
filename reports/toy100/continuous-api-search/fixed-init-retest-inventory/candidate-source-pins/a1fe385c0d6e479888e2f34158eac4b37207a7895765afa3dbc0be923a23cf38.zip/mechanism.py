"""rcm1: K3P penalties with a reversible gradient-agreement mix.

The scalar penalties, anchor memory, guard and particle hooks are K3P's.
Only the mixing weight changes. It does not read the learning rate, the step
index, the training horizon, evaluation scores, or the target.

pen = 0.5 * (s * A + (1 - s) * (B + P))
  A = mean(||grad D(real)||^2 / d) + mean(relu(||grad D(fake)|| / sqrt(d) - 1)^2)
  B = mean(relu(||grad D(real)|| - 1)^2) + mean(relu(||grad D(fake)|| - 1)^2)
  P = mean(||grad D(real) - grad D_ema(real)||^2 / d)
  D_ema decay = 0.999 per critic step, cloned on first use, updated after critic Adam.
  s >= 1 uses A only and does not evaluate the anchor. That is the initial state.

Controller, from the critic parameter gradient g that Adam just applied:
  g_mem <- 0.995 * g_mem + 0.005 * g          (compared against the pre-update memory)
  direction_gap = (1 - cos(g, g_mem)) / 2     (0 agree, 1 opposite; 0 if |g| ~ 0)
  peak <- max(0.999 * peak, |g|)              (forgetting peak, not a lifetime max)
  significance = min(1, |g| / peak)
  m_act <- 0.99 * m_act + 0.01 * significance (starts at 1)
  m_gap <- 0.90 * m_gap + 0.10 * direction_gap (starts at 0)
  target starts at 1 and then:
    m_gap >= 0.30 and significance >= 0.20 -> target = 1   (direction changed)
    elif m_act <= 0.18                     -> target = 0   (activity has faded)
    elif m_act >= 0.70                     -> target = 1   (activity is back)
  s <- 0.92 * s + 0.08 * target             (starts at 1)

Inherited K3P schedules, not inputs to s, still horizon-dependent:
  network LR cosine on min(total_steps, 1600) to floor 0.01
  prior LR cosine on total_steps to floor 0.05
  base LR 0.00425, prior multiplier 2, anneal start 0.6
  input/output noise horizon 1200 from the unmodified hold/shift drivers
Guard: after 200 critic steps, grad RMS above 5 * Adam RMS is scaled to that ratio.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
MEM_DECAY = 0.995
PEAK_DECAY = 0.999
ACT_DECAY = 0.99
GAP_DECAY = 0.90
OPEN_GAP = 0.30
OPEN_SIG = 0.20
CLOSE_ACT = 0.18
OPEN_ACT = 0.70
S_SMOOTH = 0.08
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
           'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
           'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'rcm1',
           'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None, 'prox_trace': [],
           'anchor_forwards': 0, 'anchor_penalty_calls': 0, 'anchor_weight_sum': 0.0,
           'first_close_step': None, 'first_reopen_step': None, 'mix_trace': [],
           'controller': {
               'name': 'gradient_agreement',
               'mem_decay': MEM_DECAY, 'peak_decay': PEAK_DECAY, 'act_decay': ACT_DECAY,
               'gap_decay': GAP_DECAY, 'open_gap': OPEN_GAP, 'open_significance': OPEN_SIG,
               'close_activity': CLOSE_ACT, 'open_activity': OPEN_ACT, 's_smooth': S_SMOOTH,
               'initial_s': 1.0, 'initial_target': 1.0, 'initial_m_act': 1.0, 'initial_m_gap': 0.0,
               'reads_learning_rate': False, 'reads_horizon': False, 'reads_step_index': False,
               'reads_metrics': False, 'reads_target': False,
           },
           'inherited_budget_dependencies': [
               'network LR cosine uses min(total_steps, network_lr_horizon_cap=1600) and network floor 0.01',
               'prior LR cosine uses total_steps and lr_floor 0.05',
               'input/output noise horizon is 1200 inside the unmodified hold/shift drivers',
           ]}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0,
          'clips': [], 'critic_ref': None, 's': 1.0, 'target': 1.0, 'g_mem': None, 'peak': None,
          'm_act': None, 'm_gap': None, 'last_sig': None, 'last_gap': None, 'last_rms': None}


def handover_weight():
    return _state['s']


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    receipt['anchor_forwards'] += 1
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def _sync_controller(opt):
    """Update s from critic-gradient agreement. Called once per critic Adam step, after that step."""
    params = [p for group in opt.param_groups for p in group['params']]
    live = [(p.grad.detach() if p.grad is not None else None) for p in params]
    if all(g is None for g in live):
        return
    if _state['g_mem'] is None or len(_state['g_mem']) != len(live):
        _state['g_mem'] = [g.clone() if g is not None else None for g in live]
        seed = next(g for g in live if g is not None)
        n2 = seed.new_zeros(())
        for g in live:
            if g is not None:
                n2 = n2 + g.pow(2).sum()
        rms = n2.sqrt()
        _state['peak'] = rms.clamp_min(1e-12)
        _state['m_act'] = rms.new_tensor(1.0)
        _state['m_gap'] = rms.new_zeros(())
        _state['last_sig'] = 1.0
        _state['last_gap'] = 0.0
        _state['last_rms'] = float(rms)
        _note_mix()
        return
    dot = n2 = m2 = None
    for g, mem in zip(live, _state['g_mem']):
        if g is None or mem is None:
            continue
        part = (g * mem).sum()
        g2 = g.pow(2).sum()
        h2 = mem.pow(2).sum()
        dot = part if dot is None else dot + part
        n2 = g2 if n2 is None else n2 + g2
        m2 = h2 if m2 is None else m2 + h2
        mem.mul_(MEM_DECAY).add_(g, alpha=1.0 - MEM_DECAY)
    if dot is None:
        return
    rms = n2.sqrt()
    rms_mem = m2.sqrt()
    if float(rms) < 1e-12:
        gap = rms.new_zeros(())
    elif float(rms_mem) < 1e-12:
        gap = rms.new_ones(())
    else:
        cos = (dot / (rms * rms_mem + 1e-12)).clamp(-1.0, 1.0)
        gap = (1.0 - cos) * 0.5
    peak = torch.maximum(_state['peak'] * PEAK_DECAY, rms)
    _state['peak'] = peak
    sig = (rms / peak.clamp_min(1e-12)).clamp(0.0, 1.0)
    m_act = _state['m_act'] * ACT_DECAY + sig * (1.0 - ACT_DECAY)
    m_gap = _state['m_gap'] * GAP_DECAY + gap * (1.0 - GAP_DECAY)
    _state['m_act'] = m_act
    _state['m_gap'] = m_gap
    sig_f, gap_f, act_f, mg_f = float(sig), float(gap), float(m_act), float(m_gap)
    _state['last_sig'] = sig_f
    _state['last_gap'] = gap_f
    _state['last_rms'] = float(rms)
    target = _state['target']
    if mg_f >= OPEN_GAP and sig_f >= OPEN_SIG:
        target = 1.0
    elif act_f <= CLOSE_ACT:
        target = 0.0
    elif act_f >= OPEN_ACT:
        target = 1.0
    if target == 0.0 and receipt['first_close_step'] is None:
        receipt['first_close_step'] = receipt['critic_steps']
    if target == 1.0 and receipt['first_close_step'] is not None and receipt['first_reopen_step'] is None:
        if receipt['critic_steps'] != receipt['first_close_step']:
            receipt['first_reopen_step'] = receipt['critic_steps']
    _state['target'] = target
    _state['s'] = (1.0 - S_SMOOTH) * _state['s'] + S_SMOOTH * target
    _note_mix()


def _note_mix():
    row = [receipt['critic_steps'], round(_state['s'], 6), round(_state['target'], 3),
           None if _state['m_act'] is None else round(float(_state['m_act']), 6),
           None if _state['m_gap'] is None else round(float(_state['m_gap']), 6),
           None if _state['last_sig'] is None else round(_state['last_sig'], 6),
           None if _state['last_gap'] is None else round(_state['last_gap'], 6),
           None if _state['last_rms'] is None else round(_state['last_rms'], 6),
           _state['lr_last']]
    receipt['mix_trace'].append(row)
    step = receipt['critic_steps']
    if step == 1 or step % 50 == 0:
        print(json.dumps({'rcm1': True, 'critic_step': step, 's': row[1], 'target': row[2],
                          'm_act': row[3], 'm_gap': row[4], 'significance': row[5],
                          'direction_gap': row[6], 'grad_rms': row[7], 'lr': row[8],
                          'anchor_forwards': receipt['anchor_forwards']}), flush=True)


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        receipt['anchor_penalty_calls'] += 1
        receipt['anchor_weight_sum'] += (1.0 - s)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(_state['target'], 3)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
        _sync_controller(opt)
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_target'] = _state['target']
    receipt['final_m_act'] = None if _state['m_act'] is None else float(_state['m_act'])
    receipt['final_m_gap'] = None if _state['m_gap'] is None else float(_state['m_gap'])
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
