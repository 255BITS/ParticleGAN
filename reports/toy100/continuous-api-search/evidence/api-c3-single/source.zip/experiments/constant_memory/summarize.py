"""Summarize the unchanged observation definition; never feed it to training."""
import argparse
import hashlib
import json
from pathlib import Path


def good(row):
    return row["modes"] == 8 and .90 <= row["hq"] <= 1.


def segment(rows, start, end):
    points = [r for r in rows if start < r["step"] <= end]
    first = next((r["step"] for r in points if good(r)), None)
    after = [r for r in points if first is not None and r["step"] >= first]
    suffix = []
    for r in reversed(points):
        if not good(r):
            break
        suffix.append(r)
    failures = [r["step"] for r in after if not good(r)]
    intervals = []
    for step in failures:
        if intervals and step == intervals[-1][-1] + 10:
            intervals[-1][-1] = step
        else:
            intervals.append([step, step])
    return {"start_after": start, "observed_through": end,
            "first_arrival": first, "arrival_delay": None if first is None else first - start,
            "passing_since_arrival": sum(map(good, after)), "checks_since_arrival": len(after),
            "departures": failures, "departure_intervals": intervals,
            "minimum_hq_since_arrival": min((r["hq"] for r in after), default=None),
            "minimum_modes_since_arrival": min((r["modes"] for r in after), default=None),
            "minimum_hq_whole_segment": min((r["hq"] for r in points), default=None),
            "final_stable_suffix_start": suffix[-1]["step"] if suffix else None,
            "final_stable_suffix_checks": len(suffix),
            "final": points[-1] if points else None}


def summarize(path, candidate, record=True):
    path = Path(path)
    rows = [json.loads(line) for line in (path / "metrics.jsonl").read_text().splitlines()]
    result = json.loads((path / "result.json").read_text())
    if result.get("protocol_name", "single_shift") != "single_shift":
        report = {"candidate": candidate, "protocol": result["protocol_name"],
                  "segments": result["segments"], "frozen_segments": result["frozen_segments"],
                  "seconds": result["seconds"], "lr_ranges": result["lr_ranges"]}
        passed = all(r["first_arrival"] is not None and not r["departures"] for r in report["segments"])
        report["screen_status"] = "PASS" if passed else "FAIL"
        (path / "assessment.json").write_text(json.dumps(report, indent=2) + "\n")
        (path / "artifacts.json").write_text(json.dumps({str(p.relative_to(path)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(path.rglob("*")) if p.is_file() and p.name != "artifacts.json"}, indent=2) + "\n")
        root = Path(__file__).resolve().parents[2]
        if record:
            with (root.parent / "tests.jsonl").open("a") as f:
                f.write(json.dumps({"candidate": candidate, "gate": result["protocol_name"],
                    "status": report["screen_status"], "seconds": result["seconds"], "metrics": report,
                    "artifact": str((path / "assessment.json").resolve())}) + "\n")
            with (root.parent / "result.md").open("a") as f:
                f.write(f"\n{candidate} {report['protocol']}: **{report['screen_status']}**. " +
                    "; ".join(f"segment {r['start_after']}–{r['observed_through']}: arrival {r['first_arrival']}, "
                    f"retention {r['passing_since_arrival']}/{r['checks_since_arrival']}, min HQ {r['minimum_hq_since_arrival']}, "
                    f"final suffix {r['final_stable_suffix_start']} ({r['final_stable_suffix_checks']} checks)" for r in report['segments']) +
                    f". Every departure: `{path.resolve()}/assessment.json`.\n")
        print(json.dumps(report, indent=2))
        return
    report = {"candidate": candidate, "execution": result["status"],
              "seconds": result["seconds"], "cold": segment(rows, 0, 2400),
              "prehold": result["prehold"], "shift": segment(rows, 2400, result["completed_steps"]),
              "frozen": result["frozen_control"], "at_3600": segment(rows, 2400, 3600),
              "lr_ranges": result["lr_ranges"]}
    report["screen_status"] = ("PASS" if all(report[k]["first_arrival"] is not None
        and not report[k]["departures"] for k in ("cold", "shift")) else "FAIL")
    initial = json.loads((path / "initial.json").read_text())
    root = Path(__file__).resolve().parents[2]
    retained = json.loads((root / "reports/ka2-default-candidate/constant-lr-api/evidence/constant/initial.json").read_text())
    report["initial_matches_retained"] = {k: initial[k] == retained[k] for k in
        ("models_sha256", "streams_sha256", "cpu_rng_sha256", "cuda_rng_sha256", "real_stream_sha256")}
    (path / "assessment.json").write_text(json.dumps(report, indent=2) + "\n")
    manifest = {str(p.relative_to(path)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in sorted(path.rglob("*")) if p.is_file() and p.name != "artifacts.json"}
    (path / "artifacts.json").write_text(json.dumps(manifest, indent=2) + "\n")
    if record:
        with (root.parent / "tests.jsonl").open("a") as f:
            f.write(json.dumps({"candidate": candidate, "gate": "cold_retention_single_shift",
                "status": report["screen_status"], "seconds": result["seconds"], "metrics": report,
                "artifact": str((path / "assessment.json").resolve())}) + "\n")
        c, s = report["cold"], report["shift"]
        with (root.parent / "result.md").open("a") as f:
            f.write(f"\n{candidate}: **{report['screen_status']}**. Cold arrival {c['first_arrival']}, "
                f"retention {c['passing_since_arrival']}/{c['checks_since_arrival']}; "
                f"prehold {report['prehold']['passing_checks']}/120. Shift arrival delay {s['arrival_delay']}, "
                f"then {s['passing_since_arrival']}/{s['checks_since_arrival']}, "
                f"minimum HQ {s['minimum_hq_since_arrival']}, "
                f"final suffix {s['final_stable_suffix_start']} ({s['final_stable_suffix_checks']} checks). "
                f"Every departure: `{path.resolve()}/assessment.json`. "
                f"Artifacts: `{path.resolve()}/artifacts.json`.\n")
    print(json.dumps({k: v for k, v in report.items() if k not in ("lr_ranges",)}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("path")
    parser.add_argument("candidate")
    args = parser.parse_args()
    summarize(args.path, args.candidate)
