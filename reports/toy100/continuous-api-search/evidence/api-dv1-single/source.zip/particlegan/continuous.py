"""Experimental horizon-free data innovation and game stability controller.

Real statistics control scalar mobility only. They never enter a loss, sample,
parameter assignment, or target fit. Fixed random nonlinear features see more
than changes of the mean. Generator gradient alignment is a distinct signal.
"""
from copy import deepcopy
import math
import torch


class DataDriftController:
    def __init__(self, variant="dv1"):
        self.variant = variant
        self.mobility = 1.0
        self.alignment = 0.0
        self.data_score = 0.0
        self.data_drive = 0.0
        self.last_cosine = 0.0
        self.previous_gradient = None
        self.location = self.scale = self.projection = None
        self.reference = self.variance = None
        self.updates = 0
        self.reopens = 0
        self.closed = False

    @torch.no_grad()
    def observe_real(self, real):
        x = real.flatten(1)
        if self.location is None:
            self.location = x.mean(0)
            self.scale = x.std(0, unbiased=False).clamp_min(1e-6)
            # Local stream: feature initialization never advances training RNG.
            stream = torch.Generator(device="cpu").manual_seed(1729)
            self.projection = (torch.randn(x.shape[1], 32, generator=stream)
                               / math.sqrt(x.shape[1])).to(x)
        u = ((x - self.location) / self.scale) @ self.projection
        features = torch.cat((u, torch.cos(u), torch.sin(u), torch.cos(2*u), torch.sin(2*u)), 1)
        mean = features.mean(0)
        var = features.var(0, unbiased=False).clamp_min(1e-6)
        if self.reference is None:
            self.reference, self.variance = mean.clone(), var.clone()
        variance_of_difference = (var + self.variance * (.01 / 1.99)) / len(x)
        self.data_score = float(((mean - self.reference).square() / variance_of_difference.clamp_min(1e-10)).mean().sqrt())
        self.reference.lerp_(mean, .01)
        self.variance.lerp_(var, .01)
        self.data_drive = min(1., max(0., (self.data_score - 3.) / 3.))
        target = max(self.data_drive, min(1., max(0., self.alignment / .2)))
        speed = .05 if target > self.mobility else .005
        self.mobility += speed * (target - self.mobility)
        if self.mobility < .1:
            self.closed = True
        elif self.mobility > .3 and self.closed:
            self.reopens += 1
            self.closed = False
        self.updates += 1
        return .01 + .99 * self.mobility, .05 + .95 * self.mobility

    @torch.no_grad()
    def observe_generator(self, generator):
        values = [p.grad.detach().flatten() for p in generator.parameters() if p.grad is not None]
        if not values:
            return
        gradient = torch.cat(values)
        if self.previous_gradient is not None:
            self.last_cosine = float(torch.dot(gradient, self.previous_gradient) /
                (gradient.norm() * self.previous_gradient.norm()).clamp_min(1e-20))
            self.alignment += .02 * (self.last_cosine - self.alignment)
        self.previous_gradient = gradient.clone()

    def diagnostics(self):
        return {k: getattr(self, k) for k in ("variant", "mobility", "alignment", "data_score", "data_drive", "last_cosine", "updates", "reopens", "closed")}

    def state_dict(self):
        return deepcopy(self.__dict__)

    def load_state_dict(self, state):
        if set(state) != set(self.__dict__) or state["variant"] != self.variant:
            raise ValueError("incompatible continuous controller state")
        self.__dict__.update(deepcopy(state))
