"""Optional displacement bound around the ordinary PyTorch Adam step."""
import torch


class AdamDisplacementLimit:
    """Cap coordinate displacement at the current group's nominal LR.

    Adam moments are left intact. The bound prevents moment lag from giving
    an individual coordinate more than its unit-normalized step. In the
    coordinate-only mode it preserves nonzero proposals and leaves untouched
    coordinates bit-identical. The experimental optimistic mode predicts
    ``2 * proposal - previous_proposal`` before bounding the result. Its
    history lives in Adam's per-parameter state; ``excluded`` keeps the sparse
    prior on the coordinate-only rule. Neither mode changes group rates.
    """

    def __init__(self, *, optimistic=False, excluded=None):
        self.optimistic = bool(optimistic)
        self.excluded = excluded
        self.steps = 0
        self.clipped_coordinates = 0
        self.last_clipped_coordinates = 0

    @torch.no_grad()
    def begin(self, optimizer):
        return [(optimizer, p, p.detach().clone(), float(group["lr"]))
                for group in optimizer.param_groups for p in group["params"]
                if p.grad is not None]

    @torch.no_grad()
    def end(self, token):
        counts = []
        for optimizer, parameter, old, limit in token:
            delta = parameter - old
            clipped = delta.abs() > limit
            if self.optimistic and parameter is not self.excluded:
                proposal = delta.clamp(-limit, limit)
                state = optimizer.state[parameter]
                previous = state.get("previous_displacement", proposal)
                corrected = 2.0 * proposal - previous
                clipped = clipped | (corrected.abs() > limit)
                parameter.copy_(old + corrected.clamp(-limit, limit))
                state["previous_displacement"] = proposal.clone()
            else:
                parameter.copy_(torch.where(clipped, old + delta.clamp(-limit, limit), parameter))
            counts.append(clipped.sum())
        self.last_clipped_coordinates = torch.stack(counts).sum() if counts else 0
        self.clipped_coordinates = self.clipped_coordinates + self.last_clipped_coordinates
        self.steps += 1

    def state_dict(self):
        state = {"steps": self.steps, "clipped_coordinates": int(self.clipped_coordinates),
                 "last_clipped_coordinates": int(self.last_clipped_coordinates)}
        if self.optimistic:
            state["optimistic"] = True
        return state

    def load_state_dict(self, state):
        if (not isinstance(state, dict) or set(state) != set(self.state_dict())
                or any(type(v) is not int or v < 0 for k,v in state.items() if k != "optimistic")
                or (self.optimistic and state.get("optimistic") is not True)):
            raise ValueError("invalid displacement limiter state")
        self.__dict__.update(state)
