"""Transactional joint predictor/corrector using the installed Adam optimizers.

Both fields in a stage see the same joint parameter state. A preview never
advances accepted optimizer/controller/EMA/RNG clocks. No evaluator inputs.
"""
from copy import deepcopy
import torch


@torch.no_grad()
def restore(pairs):
    for parameter, value in pairs:
        parameter.copy_(value)


def copies(parameters):
    return [(p, p.detach().clone()) for p in parameters]


class JointStage:
    def __init__(self, trainer, base, correction=False):
        self.trainer, self.base, self.correction = trainer, base, correction
        self.pending = None
        self.predicted_d = None

    def before(self, role):
        if self.correction:
            if role == 'd':
                self.predicted_d = copies(self.trainer.D.parameters())
            restore(self.base[role])

    def after(self, role):
        if role == 'd':
            self.pending = copies(self.trainer.D.parameters())
            restore(self.predicted_d if self.correction else self.base['d'])
        else:
            restore(self.pending)
            self.pending = None


def joint_step(trainer, real, generator_real, collect_stats):
    if callable(generator_real):
        generator_real = generator_real()
    checkpoint = trainer.state_dict()
    base = {'d': copies(trainer.D.parameters()),
            'g': copies(list(trainer.G.parameters()) + list(trainer.prior.parameters()))}
    trainer._game_stage = JointStage(trainer, base)
    try:
        trainer._ordinary_step(real, generator_real=generator_real, collect_stats=False)
        predicted = {role: copies([p for p, _ in pairs]) for role, pairs in base.items()}
        # Keep preview parameters, restore all other accepted state. Adam's
        # ordinary CPU scalar step metadata remains on CPU.
        for opt, state in zip((trainer.opt_g, trainer.opt_d), checkpoint['optimizers']):
            opt.load_state_dict(deepcopy(state))
        for name in ('ema_G', 'ema_prior'):
            getattr(trainer, name).load_state_dict(checkpoint['models'][name])
        for name in ('G', 'D', 'prior'):
            module = getattr(trainer, name)
            restore([(b, checkpoint['models'][name][key]) for key, b in module.named_buffers()])
        trainer.completed_steps = checkpoint['completed_steps']
        for name, state in checkpoint['streams'].items():
            getattr(trainer, name).set_state(state.cpu())
        torch.set_rng_state(checkpoint['cpu_rng'].cpu())
        if trainer.device.type == 'cuda':
            torch.cuda.set_rng_state(checkpoint['cuda_rng'].cpu(), trainer.device)
        trainer._game_stage = JointStage(trainer, base, correction=True)
        result = trainer._ordinary_step(real, generator_real=generator_real, collect_stats=collect_stats)
        telemetry = {'policy': 'joint_extragradient', 'field_evaluations': 2,
                     'accepted_updates': trainer.completed_steps, 'preview_moments_discarded': True}
        for role, pairs in base.items():
            preview = [q - b for (_, q), (_, b) in zip(predicted[role], pairs)]
            actual = [p.detach() - b for p, b in pairs]
            telemetry[role] = {'preview_l2': float(sum(x.square().sum() for x in preview).sqrt()),
                               'applied_l2': float(sum(x.square().sum() for x in actual).sqrt()),
                               'correction_l2': float(sum((x-y).square().sum() for x,y in zip(actual,preview)).sqrt())}
        trainer.game_stats = telemetry
        return result
    finally:
        trainer._game_stage = None
