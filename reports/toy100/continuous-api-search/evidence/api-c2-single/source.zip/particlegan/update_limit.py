"""Optional displacement bound around the ordinary PyTorch Adam step."""
import torch


class AdamDisplacementLimit:
    """Cap coordinate displacement at the current group's nominal LR.

    Adam moments are left intact. The bound prevents moment lag from giving
    an individual coordinate more than its unit-normalized step. It never
    zeros a nonzero proposed displacement and leaves untouched coordinates
    bit-identical. This is an update rule, not an LR schedule or a reset.
    """

    def __init__(self):
        self.steps = 0
        self.clipped_coordinates = 0
        self.last_clipped_coordinates = 0

    @torch.no_grad()
    def begin(self, optimizer):
        return [(p, p.detach().clone(), float(group["lr"]))
                for group in optimizer.param_groups for p in group["params"]
                if p.grad is not None]

    @torch.no_grad()
    def end(self, token):
        counts = []
        for parameter, old, limit in token:
            delta = parameter - old
            clipped = delta.abs() > limit
            parameter.copy_(torch.where(clipped, old + delta.clamp(-limit, limit), parameter))
            counts.append(clipped.sum())
        self.last_clipped_coordinates = torch.stack(counts).sum() if counts else 0
        self.clipped_coordinates = self.clipped_coordinates + self.last_clipped_coordinates
        self.steps += 1

    def state_dict(self):
        return {"steps": self.steps, "clipped_coordinates": int(self.clipped_coordinates),
                "last_clipped_coordinates": int(self.last_clipped_coordinates)}

    def load_state_dict(self, state):
        if (not isinstance(state, dict) or set(state) != set(self.state_dict())
                or any(type(v) is not int or v < 0 for v in state.values())):
            raise ValueError("invalid displacement limiter state")
        self.__dict__.update(state)
