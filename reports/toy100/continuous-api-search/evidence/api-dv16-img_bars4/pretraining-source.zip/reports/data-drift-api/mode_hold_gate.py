"""Frozen small ring, unchanged DV15 API, preserved shared data/latent order."""
from worker import ROOT,digest,rates
from pathlib import Path
import argparse,hashlib,json,os,time,zipfile,gzip,sys
import torch
from particlegan import GANTrainer,get_recipe
from particlegan.training import input_noise_std,output_noise_std
from benchmarks.locked_shared import mode_hold as host
from benchmarks.transfer_suite.protocol import test_verdict

O=Path(__file__).parent
p=argparse.ArgumentParser();p.add_argument('--candidate',default='dv15');p.add_argument('--output',type=Path,required=True);a=p.parse_args()
plan=ROOT/'benchmarks/transfer_suite/plans/default_comparison.json'
spec=next(j['spec'] for j in json.loads(plan.read_text()) if j['spec']['name']=='mode_hold')
recipe=get_recipe(total_steps=None,continuous_policy=a.candidate,input_noise_std=0.,output_noise_warmup=0.,num_particles=12,z_dim=4,batch_size=128)
ring=json.loads((O/'candidate-packages'/(a.candidate+'.json')).read_text())
for name,want in ring['source_sha256'].items():
 if name.startswith('particlegan/'):assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==want,name
fixture=json.loads((O/'mode-hold-fixture/receipt.json').read_text())
for name,entry in fixture.items():assert hashlib.sha256((O/'mode-hold-fixture'/name).read_bytes()).hexdigest()==entry['sha256']
sources=list((ROOT/'particlegan').glob('*.py'))+[Path(__file__),O/'worker.py',O/'mode-hold-declaration.json',plan]
sources += [p for p in (O/'mode-hold-fixture').iterdir() if p.is_file()]
for module in list(sys.modules.values()):
 file=getattr(module,'__file__',None)
 if file and Path(file).is_file() and Path(file).suffix=='.py' and Path(file).is_relative_to(ROOT):sources.append(Path(file))
sources={str(p.relative_to(ROOT)):p.read_bytes() for p in sorted(set(sources))}
external='runtimeTorch2.13.0cu126; original frozen imports snapshotted'
a.output.mkdir(parents=True,exist_ok=False)
decl=dict(candidate='API-'+a.candidate.upper(),gate='broader_mode_hold',spec=spec,recipe=recipe.to_dict(),serial_backward=True,fixture=fixture,source_sha256={k:hashlib.sha256(v).hexdigest() for k,v in sources.items()},external_imports=external)
(a.output/'declaration.json').write_text(json.dumps(decl,indent=2)+'\n')
with zipfile.ZipFile(a.output/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sources.items():z.writestr(name,data)
torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True;torch.backends.cudnn.allow_tf32=False;torch.backends.cuda.matmul.allow_tf32=False
torch.manual_seed(0)
checkpoint=torch.load(O/'mode-hold-fixture/initial-state.pt',map_location='cpu',weights_only=False)
original=checkpoint['trainer']
prior=recipe.make_prior(init_std=.5,generator=torch.Generator(device='cpu').manual_seed(0))
g=host.SimpleMLPGenerator(4,96,3,2);d=host.SimpleMLPDiscriminator(2,96,3,3)
for name,module in [('G',g),('D',d),('prior',prior)]:
 assert all(p.device.type=='cpu' for p in module.parameters())
 values=original['models'][name]
 with torch.no_grad():
  for key,value in values.items():module.state_dict()[key].copy_(value)
 assert digest({k:v for k,v in module.state_dict().items() if k not in ('log_width','shape_shear')})==digest(values)
with torch.device('cuda:0'):means=host.ring_means()
stream=torch.Generator(device='cuda:0').manual_seed(0)
t=GANTrainer(recipe,g.cuda(),d.cuda(),prior=prior.cuda(),seed=0,latent_generator=stream,serial_backward=True,optimizer_options={'foreach':False,'fused':False})
stream.set_state(checkpoint['data_rng']);torch.set_rng_state(original['cpu_rng']);torch.cuda.set_rng_state(original['cuda_rng'],0)
expected_models=json.loads((O/'mode-hold-fixture/initial.json').read_text())['models']
assert {k:digest({name:value for name,value in model.items() if name not in ('log_width','shape_shear')}) for k,model in t.state_dict()['models'].items()}==expected_models
expected_batches={r['step']:r for line in gzip.open(O/'mode-hold-fixture/batch-receipts.jsonl.gz','rt') if (r:=json.loads(line))}
initial=dict(trainer=t.state_dict(),data_rng=stream.get_state());torch.save(initial,a.output/'initial-state.pt')
(a.output/'initial.json').write_text(json.dumps({'backend':'canonical initialCUDA values loaded onCPU beforeCUDA training; exact original model hashes', 'canonical_original_models':expected_models,'complete':digest(initial),'models':{k:digest(v) for k,v in initial['trainer']['models'].items()}},indent=2)+'\n')
(a.output/'runtime.json').write_text(json.dumps({'torch':str(torch.__version__),'cuda':torch.version.cuda,'device':torch.cuda.get_device_name(0),'deterministic':True,'tf32':False,'threads':1,'environment':{k:os.environ.get(k) for k in ['CUDA_VISIBLE_DEVICES','CUBLAS_WORKSPACE_CONFIG','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']}},indent=2)+'\n')
def real_data(rng):
 with torch.device('cuda:0'):return host.sample_ring(means,128,host.SIGMA,rng)
@torch.no_grad()
def measure(ema=False):
 model,table=(t.ema_G,t.ema_prior) if ema else (t.G,t.prior)
 modes=[(m,m.training) for root in (model,table) for m in root.modules()]
 try:
  model.eval();table.eval()
  with torch.random.fork_rng(devices=[0]):
   torch.manual_seed(402+t.completed_steps)
   latent,indices=table.sample(4096,generator=torch.Generator(device='cuda:0').manual_seed(9))
   local_noise=torch.Generator(device='cuda:0').manual_seed(402+t.completed_steps+1901)
   fake=t._generate(model,latent,0.,local_noise,indices);sigma=output_noise_std(recipe,t.completed_steps)
   if sigma:fake=fake+sigma*torch.randn_like(fake)
   return host.diversity(fake,means)
 finally:
  for module,flag in modes:module.training=flag
started=time.monotonic();observations=[]
try:
 with (a.output/'metrics.jsonl').open('w',buffering=1) as obs,(a.output/'learning-rates.jsonl').open('w',buffering=1) as lr,(a.output/'batch-receipts.jsonl').open('w',buffering=1) as batches:
  for step in range(1,spec['steps']+1):
   real=real_data(stream)
   future=torch.Generator(device='cuda:0');future.set_state(stream.get_state())
   latent_d=prior.sample_indices(128,generator=future);latent_g=prior.sample_indices(128,generator=future)
   before_g_real=future.get_state();real_g=real_data(future);after_g_real=future.get_state()
   t.step(real,generator_real=real_g,collect_stats=step%50==0)
   assert torch.equal(stream.get_state(),before_g_real),'accepted latent stream did not consume exactly two frozen draws'
   stream.set_state(after_g_real)
   batch=dict(step=step,real_d=digest(real),latent_d=digest(latent_d),latent_g=digest(latent_g),real_g=digest(real_g),accepted_cursor=digest(stream.get_state()))
   assert batch==expected_batches[step], 'canonical batch/cursor mismatch'
   batches.write(json.dumps(batch)+'\n')
   lr.write(json.dumps(dict(step=step,**rates(t),input_noise=input_noise_std(recipe,step-1),output_noise=output_noise_std(recipe,step-1),policy=t.controller.diagnostics(),critic=t.penalty.diagnostics()))+'\n')
   if step%50==0:
    before=digest([t.state_dict(),stream.get_state()]);row=dict(step=step,**measure(),ema=measure(True));assert digest([t.state_dict(),stream.get_state()])==before
    observations.append(row);obs.write(json.dumps(row)+'\n');print(json.dumps(row),flush=True)
 verdict=test_verdict(spec,dict(live=observations[-1],observations=observations));assert verdict['convergence']['complete']
 status='PASS' if verdict['passed'] and verdict['convergence']['passing_suffix']>=5 else 'FAIL'
 metrics=dict(verdict=verdict,final=observations[-1],policy=t.controller.diagnostics(),updates=t.completed_steps)
 torch.save(dict(trainer=t.state_dict(),data_rng=stream.get_state()),a.output/'final-state.pt')
except Exception as e:status='ERROR';metrics={'error':repr(e)}
row=dict(candidate='API-'+a.candidate.upper(),gate='broader_mode_hold',status=status,seconds=time.monotonic()-started,metrics=metrics,artifact=str(a.output.resolve()))
(a.output/'result.json').write_text(json.dumps(row,indent=2)+'\n')
with (ROOT.parent/'tests.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
(a.output/'artifact-sha256.json').write_text(json.dumps({x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in a.output.iterdir() if x.is_file() and x.name!='artifact-sha256.json'},indent=2)+'\n')
print(json.dumps(row),flush=True)
