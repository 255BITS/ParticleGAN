"""Stateless input-activation metric for dense shared-generator gradients."""
import torch


class ActivationMetric:
    """Capture only the current G field, never evaluation or critic batches.

    For augmented layer inputs H, C=H.T@H/N and damping=trace(C)/dim.
    Right-precondition the weight/bias gradient with (C+damping I)^-1,
    then preserve its Frobenius norm. This is a gradient direction change
    before native Adam, with no target samples, persistent clock or RNG.
    Dense affine layers are supported; other layers keep ordinary gradients.
    """
    def __init__(self, model, policy):
        self.layers = [(n, m) for n, m in model.named_modules()
                       if policy == 'activation_metric' and isinstance(m, torch.nn.Linear)]
        self.moments = {}
        self.handles = []

    def __enter__(self):
        def record(module, inputs):
            with torch.no_grad():
                h = inputs[0].detach().reshape(-1, module.in_features)
                if module.bias is not None:
                    h = torch.cat((h, torch.ones_like(h[:, :1])), dim=1)
                gram = h.T @ h
                if module in self.moments:
                    old, n = self.moments[module]
                    gram = gram + old
                    self.moments[module] = (gram, n + len(h))
                else:
                    self.moments[module] = (gram, len(h))
        for _, layer in self.layers:
            self.handles.append(layer.register_forward_pre_hook(record))
        return self

    def __exit__(self, *args):
        for handle in self.handles:
            handle.remove()

    @torch.no_grad()
    def apply(self):
        stats = []
        for name, layer in self.layers:
            if layer not in self.moments or layer.weight.grad is None:
                continue
            gram, count = self.moments[layer]
            covariance = gram / count
            damping = covariance.diag().mean().clamp_min(torch.finfo(gram.dtype).tiny)
            gradient = layer.weight.grad
            bias_active = layer.bias is not None and layer.bias.grad is not None
            if layer.bias is not None:
                bg = layer.bias.grad if bias_active else torch.zeros_like(layer.bias)
                gradient = torch.cat((gradient, bg[:, None]), dim=1)
            metric = covariance + damping * torch.eye(len(covariance), device=gram.device, dtype=gram.dtype)
            corrected = torch.linalg.solve(metric, gradient.T).T
            norm = gradient.norm()
            corrected *= norm / corrected.norm().clamp_min(torch.finfo(gram.dtype).tiny)
            stats.append(dict(layer=name, count=count, width=len(covariance), damping=float(damping),
                gradient_norm=float(norm), corrected_norm=float(corrected.norm()),
                cosine=float((gradient*corrected).sum()/norm.square().clamp_min(torch.finfo(gram.dtype).tiny)),
                activation_effective_rank=float(covariance.trace().square()/covariance.square().sum().clamp_min(torch.finfo(gram.dtype).tiny))))
            layer.weight.grad.copy_(corrected[:, :layer.in_features])
            if bias_active:
                layer.bias.grad.copy_(corrected[:, -1])
        return stats
