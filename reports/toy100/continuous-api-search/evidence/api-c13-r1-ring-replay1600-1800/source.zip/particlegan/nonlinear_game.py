"""Bounded nonlinear residual correction at a fixed native-Adam macrostep.

Anderson multisecants are rebuilt from actual same-oracle nonlinear fields.
No macrostep shrinking, horizon, quality feedback, or persistent step schedule.
"""
from copy import deepcopy
import torch

from .game_update import (JointStage, check_transaction_hooks, copies, restore,
                          secant_resolvent)


class ProbeStage(JointStage):
    def before(self, role):
        if role == 'd':
            self.reference_before = deepcopy(self.trainer.ema_D.state_dict())
        super().before(role)

    def finalize(self):
        # The transaction commits once, after checking the implicit equation.
        pass


def rewind(trainer, checkpoint):
    for opt, state in zip((trainer.opt_g, trainer.opt_d), checkpoint['optimizers']):
        opt.load_state_dict(deepcopy(state))
    for name in ('ema_G', 'ema_prior'):
        getattr(trainer, name).load_state_dict(checkpoint['models'][name])
    for name in ('G', 'D', 'prior'):
        restore([(b, checkpoint['models'][name][key])
                 for key, b in getattr(trainer, name).named_buffers()])
    trainer.completed_steps = checkpoint['completed_steps']
    for name, state in checkpoint['streams'].items():
        getattr(trainer, name).set_state(state.cpu())
    torch.set_rng_state(checkpoint['cpu_rng'].cpu())
    if trainer.device.type == 'cuda':
        torch.cuda.set_rng_state(checkpoint['cuda_rng'].cpu(), trainer.device)


def nonlinear_residual_step(trainer, real, generator_real, collect_stats):
    check_transaction_hooks(trainer)
    if callable(generator_real):
        generator_real = generator_real()
    checkpoint = trainer.state_dict()
    base = {'d': copies(trainer.D.parameters()),
            'g': copies(list(trainer.G.parameters()) + list(trainer.prior.parameters()))}
    pairs = base['d'] + base['g']
    lengths = [len(base['d']), len(list(trainer.G.parameters())),
               len(list(trainer.prior.parameters()))]
    try:
        trainer._game_stage = ProbeStage(trainer, base)
        result = trainer._ordinary_step(real, generator_real=generator_real,
                                        collect_stats=collect_stats)
        native = [deepcopy(o.state_dict()) for o in (trainer.opt_g, trainer.opt_d)]
        # One accepted history update is defined at the base state. Staged
        # fields are numerical probes only: neither a rejected trial nor the
        # selected implicit displacement owns buffers or stochastic clocks.
        # This matches the explicit base-gradient choice for native moments.
        native_buffers = copies(b for name in ('G', 'D', 'prior')
                                for b in getattr(trainer, name).buffers())
        native_streams = {name: getattr(trainer, name).get_state()
                          for name in trainer._STREAMS}
        native_cpu_rng = torch.get_rng_state()
        native_cuda_rng = (torch.cuda.get_rng_state(trainer.device)
                           if trainer.device.type == 'cuda' else None)
        reference = trainer._game_stage.reference_before
        u = [p.detach().clone() - b for p, b in pairs]

        def field(displacement):
            rewind(trainer, checkpoint)
            restore([(p, b+d) for (p, b), d in zip(pairs, displacement)])
            trainer._game_stage = ProbeStage(trainer, base, correction=True)
            trainer._ordinary_step(real, generator_real=generator_real, collect_stats=False)
            return [p.detach().clone() - b for p, b in pairs]

        # Solve R(delta)=delta-F(base+delta)=0 at macrostep exactly one.
        # Native moments and RNG are rewound before every actual field call.
        # Six recent true residual differences form an Anderson inverse model;
        # the next residual is always evaluated, never inferred from that model.
        max_fields, memory = 16, 6
        flatten = lambda tensors: torch.cat([x.reshape(-1) for x in tensors])
        sizes = [x.numel() for x in u]
        def unpack(vector):
            return [x.reshape_as(template) for x, template in zip(vector.split(sizes), u)]
        uf = flatten(u)
        xs, rs = [torch.zeros_like(uf)], [-uf]
        trials = []
        best = None
        v = field(u)
        initial, secant = secant_resolvent(u, v)
        candidate = u
        values = v
        converged = False
        for evaluation in range(2, max_fields+1):
            x = flatten(candidate)
            residual = x - flatten(values)
            merit = float(residual.square().sum())
            ratios, start = {}, 0
            for role, length in zip(('D', 'G', 'prior'), lengths):
                d = candidate[start:start+length]
                w = values[start:start+length]
                numerator = sum((a-b).square().sum() for a,b in zip(d,w))
                denominator = sum(a.square().sum() for a in d).clamp_min(1e-30)
                ratios[role] = float((numerator/denominator).sqrt())
                start += length
            finite = bool(torch.isfinite(x).all() and torch.isfinite(residual).all())
            trials.append({'field_evaluations': evaluation, 'residual_squared': merit,
                           'relative_implicit_residual': ratios})
            if finite and (best is None or merit < best[0]):
                best = (merit, x.clone(), ratios, evaluation)
            if finite and all(value <= .5 for value in ratios.values()):
                best = (merit, x.clone(), ratios, evaluation)
                converged = True
                break
            if not finite or evaluation == max_fields:
                break
            xs.append(x); rs.append(residual)
            xs, rs = xs[-memory-1:], rs[-memory-1:]
            if evaluation == 2:
                candidate = initial
            else:
                dx = torch.stack([b-a for a,b in zip(xs[:-1],xs[1:])],dim=1)
                dr = torch.stack([b-a for a,b in zip(rs[:-1],rs[1:])],dim=1)
                gram = dr.T @ dr
                eigenvalues, vectors = torch.linalg.eigh(gram)
                cutoff = eigenvalues[-1].clamp_min(1e-30)*torch.finfo(x.dtype).eps*len(rs)
                inverse = torch.where(eigenvalues > cutoff, eigenvalues.clamp_min(1e-30).reciprocal(), 0.)
                coefficients = vectors @ (inverse*(vectors.T @ (dr.T @ residual)))
                candidate = unpack(x-residual-(dx-dr)@coefficients)
            values = field(candidate)
        if best is None:
            raise RuntimeError('nonlinear residual solve produced no finite displacement')
        delta = unpack(best[1])
        fraction = 1.0

        restore([(p, b+d) for (p, b), d in zip(pairs, delta)])
        # Native history comes from the actual starting-state gradient, once.
        for opt, state in zip((trainer.opt_g, trainer.opt_d), native):
            opt.load_state_dict(deepcopy(state))
        restore(native_buffers)
        for name, state in native_streams.items():
            getattr(trainer, name).set_state(state.cpu())
        torch.set_rng_state(native_cpu_rng.cpu())
        if native_cuda_rng is not None:
            torch.cuda.set_rng_state(native_cuda_rng.cpu(), trainer.device)
        trainer.ema_D.load_state_dict(reference)
        if trainer.opt_d.record.anchor_started:
            trainer.opt_d.anchor.update_()
        with torch.no_grad():
            for name, source in (('ema_G', trainer.G), ('ema_prior', trainer.prior)):
                target = getattr(trainer, name)
                target.load_state_dict(checkpoint['models'][name])
                for averaged, current in zip(target.parameters(), source.parameters()):
                    averaged.mul_(trainer.recipe.ema_decay).add_(current, alpha=1-trainer.recipe.ema_decay)
                for averaged, current in zip(target.buffers(), source.buffers()):
                    averaged.copy_(current)
        trainer.game_stats = {'policy': 'nonlinear_residual', 'field_evaluations': evaluation,
                              'accepted_updates': trainer.completed_steps, 'trials': trials,
                              'secant': secant, 'moment_source': 'base_gradient',
                              'loss_source': 'base_state', 'fraction': fraction,
                              'buffer_rng_source': 'one_base_field',
                              'converged': converged, 'max_field_evaluations': max_fields,
                              'anderson_memory': memory, 'selected_field': best[3],
                              'selected_residual_squared': best[0],
                              'relative_implicit_residual': best[2],
                              'nonconvergence': None if converged else 'accept_minimum_actual_residual_iterate'}
        start = 0
        for role, length in zip(('D', 'G', 'prior'), lengths):
            preview = u[start:start+length]
            actual = [p.detach()-b for p, b in pairs[start:start+length]]
            trainer.game_stats[role] = {
                'preview_l2': float(sum(x.square().sum() for x in preview).sqrt()),
                'applied_l2': float(sum(x.square().sum() for x in actual).sqrt()),
                'correction_l2': float(sum((x-y).square().sum() for x, y in zip(actual, preview)).sqrt())}
            start += length
        return result
    except Exception:
        trainer.load_state_dict(checkpoint)
        raise
    finally:
        trainer._game_stage = None
