"""Exact public-size replay and budget audit, separate from quality scoring."""
import argparse
import hashlib
import json
from pathlib import Path
import time
import zipfile

import torch

from worker import (ROOT, SEED, make_recipe, make_trainer, mode_hold, rates,
                    save_checkpoint, state_receipt, measure)


def record(candidate, gate, passed, seconds, metrics, path):
    with (ROOT.parent / "tests.jsonl").open("a") as f:
        f.write(json.dumps({"candidate": candidate, "gate": gate,
            "status": "PASS" if passed else "FAIL", "seconds": seconds,
            "metrics": metrics, "artifact": str(path.resolve())}) + "\n")


def run(args):
    args.output.mkdir(parents=True, exist_ok=False)
    candidate = json.loads((args.source / "declaration.json").read_text())["candidate"]
    declaration = {"candidate": candidate, "gate": "exact_checkpoint_continuation",
        "status": "DECLARED_BEFORE_EXECUTION", "deviation": "Own candidate replay under declared serial_backward=True; same worker observations and movement instrumentation; no scores inherited from shared fix.", "checkpoint": str(args.source / "state-1600.pt"),
        "checkpoint_sha256": hashlib.sha256((args.source / "state-1600.pt").read_bytes()).hexdigest(),
        "resume_from": 1600, "resume_through": 1800,
        "reference": "Existing uninterrupted own candidate single-shift state receipts; no borrowed quality passes",
        "prefix_audit": "Compare single-shift4600 and stationary7500 through first data difference at2400 when both are available",
        "source_sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in [*sorted((ROOT / "particlegan").glob("*.py")), Path(__file__), Path(__file__).with_name("worker.py"), Path(__file__).with_name("summarize.py")]}}
    (args.output / "declaration.json").write_text(json.dumps(declaration, indent=2) + "\n")
    with zipfile.ZipFile(args.output / "source.zip", "w", zipfile.ZIP_DEFLATED) as z:
        for name in declaration["source_sha256"]:
            z.write(ROOT/name,name)
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    start = time.monotonic()
    recipe = make_recipe("constant", 30000)
    trainer = make_trainer(recipe, "cuda:0")
    # Preserve stored devices, including normal CPU Adam scalar step metadata.
    checkpoint = torch.load(args.source / "state-1600.pt", weights_only=False)
    trainer.load_state_dict(checkpoint["trainer"])
    stream = torch.Generator(device="cuda:0")
    stream.set_state(checkpoint["real_stream"])
    means = checkpoint["means"]
    expected_histories = {r["step"]: r for line in (args.source / "learning-rates.jsonl").read_text().splitlines() if (r := json.loads(line))}
    telemetry_matches = []
    for step in range(1601, 1801):
        idx = torch.randint(0, 8, (recipe.batch_size,), device="cuda:0", generator=stream)
        real = means[idx] + mode_hold.SIGMA * torch.randn(recipe.batch_size, 2,
                                                        device="cuda:0", generator=stream)
        before = {name: [p.detach().clone() for p in module.parameters()]
                  for name, module in (("G", trainer.G), ("D", trainer.D), ("prior", trainer.prior))}
        trainer.step(real, collect_stats=step % 10 == 0)
        for name, module in (("G", trainer.G), ("D", trainer.D), ("prior", trainer.prior)):
            deltas = [p.detach() - old for p, old in zip(module.parameters(), before[name])]
            float(sum(d.square().sum() for d in deltas).sqrt())
            max(float(d.abs().max()) for d in deltas)
        int((deltas[0] != 0).any(dim=1).sum())
        telemetry_matches.append(trainer.game_stats == expected_histories[step]["game"])
        trainer.opt_d.record.state_dict()
        if step % 10 == 0:
            measure(trainer, means)
            measure(trainer, means, ema=True)
        if step % 100 == 0:
            state_receipt(trainer, stream, means)
        if step in (1740, 1750, 1800):
            save_checkpoint(args.output / f"state-{step}.pt", trainer, stream, means)
    actual = state_receipt(trainer, stream, means)
    expected = next(json.loads(line) for line in (args.source / "state-hashes.jsonl").read_text().splitlines()
                    if json.loads(line)["step"] == 1800)
    cuda_failures = []
    for opt in (trainer.opt_g, trainer.opt_d):
        for parameter, state in opt.state.items():
            if parameter.device.type != "cuda" or parameter.dtype != torch.float32:
                cuda_failures.append("parameter")
            if parameter.grad is not None and parameter.grad.device.type != "cuda":
                cuda_failures.append("gradient")
            for key, value in state.items():
                if isinstance(value, torch.Tensor) and key != "step" and value.device.type != "cuda":
                    cuda_failures.append(key)
    result = {"exact_receipt_match": actual == expected, "solver_telemetry_matches": sum(telemetry_matches), "solver_telemetry_checks": len(telemetry_matches), "actual": actual, "expected": expected,
              "cuda_failures": cuda_failures, "rates": rates(trainer),
              "policy": trainer.opt_d.record.state_dict(),
              "update_limits": [None if opt.update_limiter is None else opt.update_limiter.state_dict() for opt in (trainer.opt_g, trainer.opt_d)]}
    path = args.output / "continuation.json"
    path.write_text(json.dumps(result, indent=2) + "\n")
    save_checkpoint(args.output / "resumed-1800.pt", trainer, stream, means)
    record(candidate, "exact_checkpoint_continuation", actual == expected and not cuda_failures and all(telemetry_matches),
           time.monotonic() - start, result, path)

    if args.stationary is None:
        print(json.dumps({"continuation": actual == expected, "cuda_failures": cuda_failures}), flush=True)
        return
    start = time.monotonic()
    a, b = [[json.loads(line) for line in (p / "state-hashes.jsonl").read_text().splitlines()
             if json.loads(line)["step"] <= 2400] for p in (args.source, args.stationary)]
    recipe_equal = make_recipe("constant", 4600).to_dict() == make_recipe("constant", 7500).to_dict()
    prefix = {"budgets": [4600, 7500], "prefix_updates": 2400,
              "every_receipt_matches": a == b, "receipt_checks": len(a), "recipe_equal": recipe_equal,
              "initial_matches": json.loads((args.source / "initial.json").read_text()) ==
                                 json.loads((args.stationary / "initial.json").read_text()),
              "compared": "full trainer, models, optimizers including policy, EMA, all RNG, real stream and target"}
    passed = a == b and len(a) == 24 and recipe_equal and prefix["initial_matches"]
    path = args.output / "horizon-prefix.json"
    path.write_text(json.dumps(prefix, indent=2) + "\n")
    record(candidate, "identical_prefix_different_evaluator_budgets", passed,
           time.monotonic() - start, prefix, path)
    (args.output / "artifacts.json").write_text(json.dumps({p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in args.output.iterdir() if p.is_file()}, indent=2) + "\n")
    print(json.dumps({"continuation": result["exact_receipt_match"], "prefix": passed,
                      "cuda_failures": cuda_failures}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--stationary", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    run(parser.parse_args())
