"""Local same-oracle secant estimate; native Adam remains the proposal kernel."""
from copy import deepcopy
import torch
from .game_update import JointStage, copies, restore, secant_resolvent


class ProbeStage(JointStage):
    def before(self, role):
        if role == 'd':
            self.reference_before = deepcopy(self.trainer.ema_D.state_dict())
        super().before(role)

    def finalize(self):
        # Commit the accepted implicit response only after locality is checked.
        pass


def rewind(trainer, checkpoint):
    for opt, state in zip((trainer.opt_g, trainer.opt_d), checkpoint['optimizers']):
        opt.load_state_dict(deepcopy(state))
    for name in ('ema_G', 'ema_prior'):
        getattr(trainer, name).load_state_dict(checkpoint['models'][name])
    for name in ('G', 'D', 'prior'):
        restore([(b, checkpoint['models'][name][key])
                 for key, b in getattr(trainer, name).named_buffers()])
    trainer.completed_steps = checkpoint['completed_steps']
    for name, state in checkpoint['streams'].items():
        getattr(trainer, name).set_state(state.cpu())
    torch.set_rng_state(checkpoint['cpu_rng'].cpu())
    if trainer.device.type == 'cuda':
        torch.cuda.set_rng_state(checkpoint['cuda_rng'].cpu(), trainer.device)


def local_secant_step(trainer, real, generator_real, collect_stats):
    if callable(generator_real):
        generator_real = generator_real()
    checkpoint = trainer.state_dict()
    base = {'d': copies(trainer.D.parameters()),
            'g': copies(list(trainer.G.parameters()) + list(trainer.prior.parameters()))}
    pairs = base['d'] + base['g']
    try:
        trainer._game_stage = ProbeStage(trainer, base)
        result = trainer._ordinary_step(real, generator_real=generator_real, collect_stats=collect_stats)
        native = [deepcopy(o.state_dict()) for o in (trainer.opt_g, trainer.opt_d)]
        reference = trainer._game_stage.reference_before
        u = [p.detach().clone() - b for p,b in pairs]
        norm2 = sum(x.square().sum() for x in u).clamp_min(torch.finfo(u[0].dtype).tiny)
        trials = []
        for backtracks in range(17):
            eta = 2. ** -backtracks
            rewind(trainer, checkpoint)
            restore([(p,b+eta*x) for (p,b),x in zip(pairs,u)])
            trainer._game_stage = ProbeStage(trainer, base, correction=True)
            trainer._ordinary_step(real, generator_real=generator_real, collect_stats=False)
            v = [p.detach().clone() - b for p,b in pairs]
            ratio = float((sum((y-x).square().sum() for x,y in zip(u,v))/norm2).sqrt())
            trials.append({'probe_fraction':eta,'relative_field_change':ratio})
            if ratio <= .5:
                break
        else:
            raise RuntimeError('local secant probe failed locality after16 backtracks')
        # The derivative is with respect to the full native proposal u, even
        # though its oracle evaluation used the local displacement eta*u.
        local_response = None
        if trainer.recipe.game_update == 'local_extragradient':
            delta = [eta*y for y in v]
            secant = None
            local_response = {'predictor_l2':float(norm2.sqrt())*eta,
                              'correction_l2':float(sum((y-x).square().sum() for x,y in zip(u,v)).sqrt())*eta,
                              'native_alignment':float(sum((x*d).sum() for x,d in zip(u,delta))/norm2),
                              'probe_fraction':eta}
        else:
            derivative_field = [x + (y-x)/eta for x,y in zip(u,v)]
            delta, secant = secant_resolvent(u, derivative_field)
        restore([(p,b+d) for (p,b),d in zip(pairs,delta)])
        for opt,state in zip((trainer.opt_g,trainer.opt_d),native):
            opt.load_state_dict(deepcopy(state))
        trainer.ema_D.load_state_dict(reference)
        if trainer.opt_d.record.anchor_started:
            trainer.opt_d.anchor.update_()
        with torch.no_grad():
            for name,source in (('ema_G',trainer.G),('ema_prior',trainer.prior)):
                target=getattr(trainer,name)
                target.load_state_dict(checkpoint['models'][name])
                for averaged,current in zip(target.parameters(),source.parameters()):
                    averaged.mul_(trainer.recipe.ema_decay).add_(current,alpha=1-trainer.recipe.ema_decay)
                for averaged,current in zip(target.buffers(),source.buffers()):
                    averaged.copy_(current)
        trainer.game_stats={'policy':trainer.recipe.game_update,'field_evaluations':len(trials)+1,
                            'accepted_updates':trainer.completed_steps,'trials':trials,
                            'secant':secant,'local_response':local_response,'loss_source':'base_state','moment_source':'base_gradient'}
        for role,values in base.items():
            indices=range(0,len(base['d'])) if role=='d' else range(len(base['d']),len(pairs))
            actual=[p.detach()-b for p,b in values]
            preview=[u[i] for i in indices]
            trainer.game_stats[role]={'preview_l2':float(sum(x.square().sum() for x in preview).sqrt()),
                                     'applied_l2':float(sum(x.square().sum() for x in actual).sqrt()),
                                     'correction_l2':float(sum((x-y).square().sum() for x,y in zip(actual,preview)).sqrt())}
        return result
    except Exception:
        trainer.load_state_dict(checkpoint)
        raise
    finally:
        trainer._game_stage=None
