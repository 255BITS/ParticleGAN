"""Experimental reversible precision, driven only by game/update evidence."""
from copy import deepcopy
import math
import torch


class ReversiblePrecision:
    """A contraction must finish before reducing mobility; every close can reopen.

    The reference EMA and all smoothing windows have fixed update time constants.
    Neither training age nor an evaluator horizon selects a learning rate.
    """
    def __init__(self, critic, variant="rp1", *, generator=None):
        self.reference = deepcopy(critic).eval().requires_grad_(False)
        self.state = dict(variant=variant, open=True, gap=None, gap_s=None,
                          velocity=0., contraction_peak=0., contracting=0,
                          activity=None, activity_peak=0., quiet_gap=None,
                          quiet_activity=None, quiet=0, shock=0, updates=0,
                          openings=1, closings=0, event="initial_open")
        self.update_direction = None
        if variant == 'rp3':
            parameters = list(generator.parameters())
            self.update_direction = parameters[0].new_zeros(sum(p.numel() for p in parameters))
            self.state.update(coherence=1., direction_energy=0., direction_mass=0.,
                              quiet_coherence=None, close_reason=None, reopen_reason=None)

    def scales(self):
        gain = .2 if self.state['open'] else 0.
        return .01 + .99 * gain, .05 + .95 * gain

    @staticmethod
    def parameters(optimizer):
        return [p for g in optimizer.param_groups for p in g['params'] if p.grad is not None]

    @torch.no_grad()
    def update_activity(self, optimizer, before, *, roles=None):
        terms = []
        network = []
        for index, group in enumerate(optimizer.param_groups):
            for p in group['params']:
                if p.grad is not None and id(p) in before:
                    delta = ((p - before[id(p)]) / group['lr']).flatten()
                    terms.append(delta)
                else:
                    delta = torch.zeros_like(p).flatten() if self.update_direction is not None else None
                if self.update_direction is not None and roles[index] == 'generator':
                    network.append(delta)
        if self.update_direction is not None:
            # Directed displacement / path energy: stochastic or reversing
            # steps can stay large while doing little consistent work. Exclude
            # the sparse prior so row sampling cannot mimic cancellation.
            vector = torch.cat(network)
            s = self.state
            self.update_direction.mul_(.95).add_(vector, alpha=.05)
            s['direction_energy'] = .95 * s['direction_energy'] + .05 * float(vector.square().mean())
            s['direction_mass'] = .95 * s['direction_mass'] + .05
            s['coherence'] = min(1., float(self.update_direction.square().mean()) /
                                 max(s['direction_mass'] * s['direction_energy'], 1e-30))
        return float(torch.cat(terms).square().mean().sqrt())

    def observe(self, critic, real, activity):
        with torch.enable_grad():
            x = real.detach().clone().requires_grad_(True)
            y = critic(x)
            if isinstance(y, (tuple, list)):
                y = y[0]
            g = torch.autograd.grad(y.sum(), x)[0].detach()
            x = real.detach().clone().requires_grad_(True)
            y = self.reference(x)
            if isinstance(y, (tuple, list)):
                y = y[0]
            ref = torch.autograd.grad(y.sum(), x)[0].detach()
            gap = float((g - ref).square().mean())
        with torch.no_grad():
            for old, new in zip(self.reference.parameters(), critic.parameters()):
                old.lerp_(new, .001)
            for old, new in zip(self.reference.buffers(), critic.buffers()):
                old.copy_(new)
        self.advance(gap, activity)

    def advance(self, gap, activity):
        s = self.state
        if not all(math.isfinite(v) and v >= 0 for v in (gap, activity)):
            raise ValueError('nonfinite precision evidence')
        s['updates'] += 1
        s['event'] = None
        prev = gap if s['gap_s'] is None else s['gap_s']
        s['gap'] = gap
        s['gap_s'] = .99 * prev + .01 * gap
        s['velocity'] = s['gap_s'] - prev
        s['activity'] = activity if s['activity'] is None else .9 * s['activity'] + .1 * activity
        if s['open']:
            s['activity_peak'] = max(s['activity_peak'] * .9997, s['activity'])
            s['contracting'] = s['contracting'] + 1 if s['velocity'] < 0 else 0
            s['contraction_peak'] = max(s['contraction_peak'], -s['velocity'])
            magnitude_calm = s['activity'] < .5 * s['activity_peak']
            direction_calm = s['variant'] == 'rp3' and s['coherence'] < .1
            calm = (s['contracting'] >= 50 and s['contraction_peak'] > 0
                    and -s['velocity'] < .25 * s['contraction_peak']
                    and (magnitude_calm or direction_calm))
            s['quiet'] = s['quiet'] + 1 if calm else 0
            if s['quiet'] >= 25:
                s.update(open=False, quiet_gap=max(s['gap_s'], 1e-12),
                         quiet_activity=max(s['activity'], 1e-12), quiet=0,
                         shock=0, event='close')
                s['closings'] += 1
                if s['variant'] == 'rp3':
                    s.update(quiet_coherence=max(s['coherence'], 1e-6),
                             close_reason='magnitude' if magnitude_calm else 'cancellation')
        else:
            ratio = s['gap_s'] / s['quiet_gap']
            innovation = s['activity'] / s['quiet_activity']
            # Reference disagreement alone is ambiguous. Require active updates
            # and a growing excursion as well, with a short noise-rejection dwell.
            directed = (s['variant'] == 'rp3' and
                        s['coherence'] > max(.2, 2 * s['quiet_coherence']))
            shock = ratio > 4 and (innovation > 2 or directed) and s['velocity'] > 0
            s['shock'] = s['shock'] + 1 if shock else 0
            if ratio < 2 and innovation < 2:
                s['quiet_gap'] = .99 * s['quiet_gap'] + .01 * max(s['gap_s'], 1e-12)
                s['quiet_activity'] = .99 * s['quiet_activity'] + .01 * max(s['activity'], 1e-12)
                if s['variant'] == 'rp3' and not directed:
                    s['quiet_coherence'] = .99 * s['quiet_coherence'] + .01 * max(s['coherence'], 1e-6)
            if s['shock'] >= 5:
                s.update(open=True, contraction_peak=0., contracting=0,
                         activity_peak=s['activity'], quiet=0, shock=0, event='reopen')
                s['openings'] += 1
                if s['variant'] == 'rp3':
                    s['reopen_reason'] = 'magnitude' if innovation > 2 else 'direction'

    def state_dict(self):
        return deepcopy(dict(state=self.state, reference=self.reference.state_dict(),
                             **({'update_direction': self.update_direction}
                                if self.update_direction is not None else {})))

    def load_state_dict(self, value):
        if value.keys() != self.state_dict().keys() or value['state'].keys() != self.state.keys():
            raise ValueError('invalid precision checkpoint')
        if value['state']['variant'] != self.state['variant']:
            raise ValueError('precision variant differs')
        if self.update_direction is not None:
            direction = value['update_direction']
            if (not isinstance(direction, torch.Tensor) or direction.shape != self.update_direction.shape
                    or direction.dtype != self.update_direction.dtype
                    or direction.device != self.update_direction.device or not torch.isfinite(direction).all()):
                raise ValueError('invalid precision direction state')
            self.update_direction = direction.detach().clone()
        self.reference.load_state_dict(value['reference'])
        self.state = deepcopy(value['state'])
