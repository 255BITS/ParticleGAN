"""Fresh-process continuation and evaluator-budget audits of the actual API."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time
import zipfile

import torch
import worker as w


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', required=True)
    args = parser.parse_args()
    runs = w.ROOT / 'reports/data-drift-api/runs'
    single = runs / (args.candidate + '-single')
    stationary = runs / (args.candidate + '-stationary')
    out = runs / (args.candidate + '-api-checks')
    out.mkdir(exist_ok=False)
    source = json.loads((single / 'declaration.json').read_text())
    hashes = source['source_sha256']
    # Exact public learner bytes, not just matching recipe names.
    for path, expected in hashes.items():
        if path.startswith('particlegan/'):
            assert hashlib.sha256((w.ROOT / path).read_bytes()).hexdigest() == expected, path
    files = [w.ROOT / p for p in hashes] + [Path(__file__), Path(__file__).with_name('dv15_continue.py')]
    declaration = dict(candidate=args.candidate, checkpoint='change-2400-state.pt',
                       restore_at=2400, continue_to=2500, horizon_budgets=[4600,7500],
                       horizon_prefix=2400, serial_backward=True, seed=0,
                       process_id=os.getpid(), physical_gpu=os.environ['CUDA_VISIBLE_DEVICES'],
                       evaluator_shift=[1.,0.], source_sha256={str(p.relative_to(w.ROOT)):
                       hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
    (out/'declaration.json').write_text(json.dumps(declaration, indent=2)+'\n')
    with zipfile.ZipFile(out/'source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for name in declaration['source_sha256']:
            archive.write(w.ROOT/name,name)

    def record(gate, passed, started, metrics):
        artifact = out/(gate+'.json')
        artifact.write_text(json.dumps(metrics,indent=2)+'\n')
        row = dict(candidate='API-'+args.candidate.upper(), gate=gate,
                   status='PASS' if passed else 'FAIL', seconds=time.monotonic()-started,
                   metrics=metrics, artifact=str(artifact))
        with (w.ROOT.parent/'tests.jsonl').open('a') as f:
            f.write(json.dumps(row)+'\n')
        print(json.dumps(row),flush=True)

    started = time.monotonic()
    receipts = []
    for run in (single, stationary):
        receipts.append([r for line in (run/'state-hashes.jsonl').read_text().splitlines()
                         if (r:=json.loads(line))['step']<=2400])
    exact = receipts[0] == receipts[1] and len(receipts[0]) == 24
    record('horizon_prefix_2400', exact, started,
           dict(all_24_complete_receipts_equal=exact, budgets=[4600,7500],
                receipt_sha256=[w.digest(r) for r in receipts]))

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark=False
    torch.backends.cudnn.allow_tf32=False
    torch.backends.cuda.matmul.allow_tf32=False
    started = time.monotonic()
    checkpoint = torch.load(single/'change-2400-state.pt',weights_only=False)
    recipe = w.make_recipe(args.candidate,999999)  # intentionally ignored evaluator budget
    trainer = w.make_trainer(recipe,'cuda:0')
    trainer.load_state_dict(checkpoint['trainer'])
    from dv15_continue import placement
    restored = w.digest(trainer.state_dict()) == w.digest(checkpoint['trainer']) and placement(trainer.state_dict()) == placement(checkpoint['trainer'])
    stream = torch.Generator(device='cuda:0')
    stream.set_state(checkpoint['real_stream'])
    means = checkpoint['means'].clone() + checkpoint['means'].new_tensor([1.,0.])
    expected_points = {r['step']:r for line in (single/'metrics.jsonl').read_text().splitlines()
                       if (r:=json.loads(line))['step'] in range(2410,2501,10)}
    observations = []
    with (out/'continuation.jsonl').open('w',buffering=1) as log:
        for step in range(2401,2501):
            idx=torch.randint(0,8,(recipe.batch_size,),device='cuda:0',generator=stream)
            real=means[idx]+w.mode_hold.SIGMA*torch.randn(recipe.batch_size,2,device='cuda:0',generator=stream)
            trainer.step(real,collect_stats=step%10==0)
            if step%10==0:
                live,ema = w.measure(trainer,means),w.measure(trainer,means,ema=True)
                expected = expected_points[step]
                observations.append(all(live[k]==expected[k] for k in live) and ema==expected['ema'])
                log.write(json.dumps(dict(step=step,live=live,ema=ema,rates=w.rates(trainer),
                                          policy=trainer.controller.diagnostics()))+'\n')
    actual=w.state_receipt(trainer,stream,means)
    expected=next(r for line in (single/'state-hashes.jsonl').read_text().splitlines()
                  if (r:=json.loads(line))['step']==2500)
    parameters=[p for m in (trainer.G,trainer.D,trainer.prior) for p in m.parameters()]
    moments=[v for opt in (trainer.opt_g,trainer.opt_d) for state in opt.state.values()
             for k,v in state.items() if isinstance(v,torch.Tensor) and k!='step']
    cuda=all(p.is_cuda and (p.grad is None or p.grad.is_cuda) for p in parameters) and all(v.is_cuda for v in moments)
    w.save_checkpoint(out/'continued-state.pt',trainer,stream,means)
    record('fresh_process_checkpoint_2400_2500',restored and actual==expected and all(observations) and cuda,
           started,dict(initial_restore_exact_including_placement=restored,full_final_receipt_equal=actual==expected,
                        observations_exact=observations,cuda_parameters_gradients_moments=cuda,
                        actual=actual,expected=expected,process_id=os.getpid()))
    (out/'artifact-sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest()
         for p in out.iterdir() if p.is_file() and p.name!='artifact-sha256.json'},indent=2)+'\n')


if __name__=='__main__':
    main()
