"""Report complete arrival histories, never just a favorable suffix."""
import json
from pathlib import Path
import hashlib
import sys


def good(p):
    return p['modes'] == 8 and p['hq'] >= .90


def segment(points, start, end):
    rows = [p for p in points if start < p['step'] <= end]
    first = next((p['step'] for p in rows if good(p)), None)
    after = [p for p in rows if first is not None and p['step'] >= first]
    suffix = []
    for p in reversed(rows):
        if not good(p):
            break
        suffix.append(p)
    return dict(start=start, end=end, first_arrival=first,
                arrival_delay=None if first is None else first-start,
                passing_since_arrival=sum(good(p) for p in after), checks_since_arrival=len(after),
                every_departure=[p['step'] for p in after if not good(p)],
                min_hq_since_arrival=min((p['hq'] for p in after), default=None),
                min_modes_since_arrival=min((p['modes'] for p in after), default=None),
                min_hq_all=min((p['hq'] for p in rows), default=None),
                final_stable_suffix_checks=len(suffix),
                final_stable_suffix_start=suffix[-1]['step'] if suffix else None,
                final_stable_suffix_span=0 if not suffix else suffix[0]['step']-suffix[-1]['step'],
                final=None if not rows else {k: rows[-1][k] for k in ('step','modes','hq')})


def summarize(path):
    points = [json.loads(line) for line in (path/'metrics.jsonl').read_text().splitlines()]
    end=points[-1]['step']
    declaration = json.loads((path/'declaration.json').read_text())
    protocol_name = declaration.get('protocol_name','single_shift')
    protocol = declaration['protocol']['protocols'][protocol_name]
    changes = [p['after_update'] for p in protocol['target_changes'] if p['after_update'] < end]
    first_change = changes[0] if changes else end
    hold=[p for p in points if 1210 <= p['step'] <= first_change]
    summary = dict(acquisition=segment(points,0,first_change),
                   retention=dict(passing=sum(map(good,hold)),total=len(hold),
                                  min_hq=min(p['hq'] for p in hold),
                                  failing_steps=[p['step'] for p in hold if not good(p)]),
                   transitions=[segment(points,a,b) for a,b in zip(changes,changes[1:]+[end])],
                   comparison_3600=segment(points,2400,min(end,3600)),
                   frozen=dict(passing=sum(good(p['frozen']) for p in points if 'frozen' in p),
                               total=sum('frozen' in p for p in points)))
    if protocol_name == 'long_continuation':
        summary['delayed_repeated_9000_prefix'] = [segment(points,0,6000), segment(points,6000,7800), segment(points,7800,9000)]
    rates=[json.loads(line) for line in (path/'learning-rates.jsonl').read_text().splitlines()]
    summary['policy_ranges']={k:[min(p['policy'][k] for p in rates),max(p['policy'][k] for p in rates)]
                              for k in ('mobility','alignment','data_score','data_drive')}
    summary['final_policy']=rates[-1]['policy']
    summary['rates']={k:[min(p[k] for p in rates),max(p[k] for p in rates)]
                      for k in ('generator_0','prior_1','critic_0','input_noise','output_noise')}
    baseline=json.loads(Path('reports/ka2-default-candidate/constant-lr-api/evidence/constant/initial.json').read_text())
    initial=json.loads((path/'initial.json').read_text())
    summary['initialization_matches_original']={k: initial[k]==baseline[k] for k in
        ('models_sha256','optimizers_sha256','streams_sha256','cpu_rng_sha256','cuda_rng_sha256','real_stream_sha256','means_sha256')}
    (path/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    artifacts={str(p.relative_to(path)):hashlib.sha256(p.read_bytes()).hexdigest()
               for p in sorted(path.rglob('*')) if p.is_file() and p.name!='artifact-sha256.json'}
    (path/'artifact-sha256.json').write_text(json.dumps(artifacts,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
    return summary

if __name__=='__main__':
    summarize(Path(sys.argv[1]))
