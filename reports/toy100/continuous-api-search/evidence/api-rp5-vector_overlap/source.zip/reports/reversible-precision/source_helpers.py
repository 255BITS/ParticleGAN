"""Capture project modules already imported by an evaluator, without changing it."""
from pathlib import Path
import sys

def imported_sources(root):
    files=set()
    for module in tuple(sys.modules.values()):
        value=getattr(module,'__file__',None)
        if not value:continue
        p=Path(value).resolve()
        if p.is_relative_to(root) and p.suffix=='.py' and p.is_file():files.add(p)
    return sorted(files)
