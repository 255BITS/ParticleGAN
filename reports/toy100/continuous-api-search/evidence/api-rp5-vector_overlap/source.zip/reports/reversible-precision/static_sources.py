"""Conservative project dependency snapshot; copied supervisor helper only."""
import ast
from pathlib import Path
def local_file(root, module):
    path = root.joinpath(*module.split("."))
    for candidate in (path.with_suffix(".py"), path / "__init__.py"):
        if candidate.is_file():
            return candidate.relative_to(root).as_posix()
    return None


def dependency_closure(root, entries):
    """Conservatively snapshot every statically reachable local Python import.

    Imports inside unused host training functions are included as provenance,
    but are never executed here. External distributions are recorded separately.
    """
    pending, sources, external = list(entries), {}, set()
    while pending:
        name = pending.pop()
        if name in sources:
            continue
        path = root / name
        if not path.is_file():
            raise ValueError(f"missing dependency: {name}")
        sources[name] = path.read_bytes()
        if path.suffix != ".py":
            continue
        tree = ast.parse(sources[name], filename=name)
        package = Path(name).parts[:-1]
        for depth in range(1, len(package) + 1):
            init = root.joinpath(*package[:depth], "__init__.py")
            if init.is_file():
                pending.append(init.relative_to(root).as_posix())
        modules = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                modules.extend(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom):
                prefix = list(package[:len(package) - node.level + 1]) if node.level else []
                base = ".".join(prefix + ([node.module] if node.module else []))
                modules.append(base)
                modules.extend(".".join(filter(None, (base, a.name))) for a in node.names if a.name != "*")
        for module in modules:
            if not module:
                continue
            source = local_file(root, module)
            if source is None:
                sibling = path.parent.joinpath(*module.split(".")).with_suffix(".py")
                if sibling.is_file():
                    source = sibling.relative_to(root).as_posix()
            if source:
                pending.append(source)
            elif not (root / module.split(".")[0]).exists():
                external.add(module.split(".")[0])
    return sources, sorted(external)

