"""Post-run frozen support diagnostic, not a new score or training experiment."""
from pathlib import Path
import hashlib,json,os,sys,time,zipfile
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import torch
from lib.toy_models import SimpleMLPGenerator
P=ROOT/'reports/data-drift-api';out=P/'support-audit';out.mkdir(exist_ok=False)
sources=[Path(__file__),ROOT/'lib/toy_models.py',ROOT/'particlegan/particle_prior.py']
decl={'scope':'Read-only G(prior.z) enumeration without output noise after failed fixed-window tasks. Target centers used only in this post-run diagnostic. No training, parameter edit, new seed trial or quality credit.', 'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},'runs':{}}
for c in ['dv7','dv9']:
 run=P/'runs'/f'{c}-vector_unequal_mass';decl['runs'][c]={'checkpoint':str(run/'final-state.pt'),'sha256':hashlib.sha256((run/'final-state.pt').read_bytes()).hexdigest()}
(out/'declaration.json').write_text(json.dumps(decl,indent=2)+'\n')
with zipfile.ZipFile(out/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sources:z.write(p,str(p.relative_to(ROOT)))
torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
for c in ['dv7','dv9']:
 start=time.monotonic();run=P/'runs'/f'{c}-vector_unequal_mass';manifest=json.loads((run/'declaration.json').read_text());spec=manifest['spec'];state=torch.load(run/'final-state.pt',weights_only=False)
 g=SimpleMLPGenerator(4,64,2,2).cuda();g.load_state_dict(state['models']['G']);g.eval()
 with torch.no_grad():
  points=g(state['models']['prior']['z']);means=points.new_tensor(spec['means']);cov=points.new_tensor(spec['covariances']);index=torch.cdist(points,means).argmin(1);details=[]
  for i in range(len(means)):
   x=points[index==i];centered=x-x.mean(0) if len(x) else x
   matrix=centered.T@centered/max(1,len(x));inv=torch.linalg.inv(torch.linalg.cholesky(cov[i]));eigen=torch.linalg.eigvalsh(inv@matrix@inv.T)
   details.append({'component':i,'particles':len(x),'max_centered_covariance_rank':min(2,max(0,len(x)-1)),'noise_free_whitened_eigenvalues':eigen.tolist()})
 result={'diagnostic_only':True,'prior_rows':len(points),'components':details,'constant_output_noise_variance_ratio':manifest['recipe']['output_noise_std']**2/spec['covariances'][0][0][0], 'note':'Original noisy4096sample quality gates remain FAIL; this enumeration is not a replacement scorer.'}
 artifact=out/(c+'.json');artifact.write_text(json.dumps(result,indent=2)+'\n');row={'candidate':'API-'+c.upper(),'gate':'frozen_support_diagnostic','status':'PASS','seconds':time.monotonic()-start,'metrics':result,'artifact':str(artifact)}
 with (ROOT.parent/'tests.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True)
(out/'artifact-sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='artifact-sha256.json'},indent=2)+'\n')
