"""Mechanics: shared-feature interference, inert prior path and exact replay."""
from copy import deepcopy
import pytest
import torch
from particlegan import GANTrainer, get_recipe
from particlegan.generator_metric import ActivationMetric
from test_training import assert_checkpoint_equal


def test_metric_reduces_correlated_feature_interference_and_preserves_descent():
    layer = torch.nn.Linear(2, 1, bias=False)
    x = torch.tensor([[1., 0.], [1., .1]])
    with ActivationMetric(layer, 'activation_metric') as metric:
        output = layer(x)
    # Opposed sample forces acting through nearly shared features.
    (output[0] - output[1]).sum().backward()
    original = layer.weight.grad.clone()
    before = (x @ original.T).flatten()
    stats = metric.apply()
    after = (x @ layer.weight.grad.T).flatten()
    assert before[0] == 0
    assert after[0] > 0 and after[1] < 0
    assert (original * layer.weight.grad).sum() > 0
    assert torch.allclose(original.norm(), layer.weight.grad.norm())
    assert len(stats) == 1
    assert not layer._forward_pre_hooks


def test_shared_layer_moments_accumulate_and_exception_removes_hooks():
    layer = torch.nn.Linear(3, 2)
    x = torch.randn(5, 3)
    with ActivationMetric(layer, 'activation_metric') as metric:
        output = layer(x) + layer(x)
    output.sum().backward()
    assert metric.apply()[0]['count'] == 10
    with pytest.raises(RuntimeError):
        with ActivationMetric(layer, 'activation_metric'):
            raise RuntimeError('injected')
    assert not layer._forward_pre_hooks


@pytest.mark.parametrize('policy', ['ordinary', 'activation_metric'])
def test_rank_deficient_and_zero_gradients_remain_finite_prior_gradients_untouched(policy):
    layer = torch.nn.Linear(3, 2)
    prior = torch.zeros(7, 3, requires_grad=True)
    with ActivationMetric(layer, policy) as metric:
        output = layer(prior)
    (output.square().sum() * 0).backward()
    prior_grad = prior.grad.clone()
    metric.apply()
    assert torch.equal(prior_grad, prior.grad)
    assert all(torch.isfinite(p.grad).all() for p in layer.parameters())
    assert all(p.grad.count_nonzero() == 0 for p in layer.parameters())


def make():
    torch.manual_seed(12)
    r = get_recipe(total_steps=None, continuous_precision='rp5', game_update='secant_resolvent',
                   generator_update='activation_metric', adam_eager_state=True,
                   noise_policy='constant', input_noise_std=0., num_particles=12, z_dim=2, batch_size=8)
    g = torch.nn.Sequential(torch.nn.Linear(2, 6), torch.nn.Tanh(), torch.nn.Linear(6, 2))
    d = torch.nn.Sequential(torch.nn.Linear(2, 6), torch.nn.Tanh(), torch.nn.Linear(6, 1))
    return GANTrainer(r, g, d, seed=0, serial_backward=True,
                      optimizer_options={'foreach': False, 'fused': False})


def test_metric_public_checkpoint_continuation_and_accepted_clocks():
    trainer = make()
    batch = torch.randn(8, 2)
    trainer.step(batch)
    saved = deepcopy(trainer.state_dict())
    trainer.step(batch)
    expected = deepcopy(trainer.state_dict())
    restored = make()
    restored.load_state_dict(saved)
    restored.step(batch)
    assert_checkpoint_equal(expected, restored.state_dict())
    assert restored.completed_steps == restored.precision.state['updates'] == restored.opt_d.record.calls == 2
    assert restored.game_stats['generator_metric']
    assert all(not m._forward_pre_hooks for m in restored.G.modules())


def test_metric_recipe_rejects_unknown_rule():
    with pytest.raises(ValueError, match='generator_update'):
        get_recipe(generator_update='unknown')


def test_tangent_support_bounds_and_orthogonality_in_output_space():
    from particlegan.generator_support import tangent_support
    x = torch.nn.Parameter(torch.tensor([[0., 0.], [0., 1.], [1., 2.], [1., 4.]]))
    force = torch.tensor([[1., 1.], [1., 0.], [0., 1.], [1., -1.]])
    loss = (x * force).sum()
    grads, stats = tangent_support(x, torch.arange(4), loss, [x])
    aux = grads[0]
    assert torch.allclose((aux * force).sum(1), torch.zeros(4), atol=1e-6)
    assert torch.all(aux.norm(dim=1) <= force.norm(dim=1) + 1e-6)
    assert stats['active_rows'] > 0 and stats['max_force_ratio'] <= 1
    assert torch.isfinite(aux).all()


def test_same_id_never_repels_itself_and_zero_field_cannot_drive_motion():
    from particlegan.generator_support import tangent_support
    x = torch.nn.Parameter(torch.tensor([[0., 0.], [0., 0.], [1., 0.], [1., 0.]]))
    loss = x[:, 1].sum()
    grads, stats = tangent_support(x, torch.tensor([0, 0, 1, 1]), loss, [x])
    assert stats['bandwidth_squared'] == 1 and stats['distinct_particles'] == 2
    assert grads[0][:2, 0].min() > 0 and grads[0][2:, 0].max() < 0
    empty, stats = tangent_support(x, torch.zeros(4, dtype=torch.long), loss, [x])
    assert empty == [None] and stats['active_rows'] == 0
    zero, stats = tangent_support(x, torch.arange(4), loss * 0, [x])
    assert torch.isfinite(zero[0]).all() and zero[0].count_nonzero() == 0


def test_support_pullback_leaves_trainable_prior_gradient_ordinary():
    from particlegan.generator_support import tangent_support
    torch.manual_seed(7)
    prior = torch.nn.Parameter(torch.randn(7, 3))
    model = torch.nn.Linear(3, 2)
    generated = model(prior)
    loss = generated.square().mean()
    expected = torch.autograd.grad(loss, prior, retain_graph=True)[0]
    extra, _ = tangent_support(generated, torch.arange(7), loss, list(model.parameters()))
    loss.backward()
    for parameter, correction in zip(model.parameters(), extra):
        parameter.grad.add_(correction)
    assert torch.equal(prior.grad, expected)


def test_tangent_support_public_exact_checkpoint_continuation():
    torch.manual_seed(12)
    def build():
        recipe = make().recipe.replace(generator_update='tangent_support')
        return GANTrainer(recipe,
            torch.nn.Sequential(torch.nn.Linear(2, 6), torch.nn.Tanh(), torch.nn.Linear(6, 2)),
            torch.nn.Sequential(torch.nn.Linear(2, 6), torch.nn.Tanh(), torch.nn.Linear(6, 1)),
            seed=0, serial_backward=True, optimizer_options={'foreach': False, 'fused': False})
    first = build()
    batch = torch.randn(8, 2)
    first.step(batch)
    saved = deepcopy(first.state_dict())
    first.step(batch)
    expected = deepcopy(first.state_dict())
    restored = build();restored.load_state_dict(saved);restored.step(batch)
    assert_checkpoint_equal(expected, restored.state_dict())
    assert restored.completed_steps == restored.precision.state['updates'] == 2
