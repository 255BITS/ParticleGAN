"""Bounded adversarial-tangent separation of crowded generated support."""
import torch


def tangent_support(generated, indices, adversarial_loss, parameters):
    """Return auxiliary G-only gradients; ordinary prior gradients stay intact.

    Nearest neighbors exclude repeated samples of the same prior row. Kernel
    scale is the current median neighbor distance. Its output gradient is
    projected perpendicular to the ordinary adversarial output gradient and
    bounded by that gradient's norm times current crowding (in [0, 1]).
    No reference data, labels, times, noise draws, or persistent state.
    """
    x = generated.flatten(1)
    with torch.no_grad():
        distinct = indices[:, None] != indices[None, :]
        if not bool(distinct.any()):
            return [None] * len(parameters), dict(policy='tangent_support', active_rows=0)
        distances = torch.cdist(x.detach(), x.detach()).square()
        distances.masked_fill_(~distinct, float('inf'))
        nearest_distance, nearest = distances.min(dim=1)
        numerical_floor = torch.finfo(x.dtype).eps * x.detach().square().mean().clamp_min(torch.finfo(x.dtype).tiny)
        bandwidth = nearest_distance.median().clamp_min(numerical_floor)
    separation = (x - x[nearest]).square().sum(dim=1)
    crowding = (-separation / bandwidth).exp()
    loss = crowding.mean()
    repulsion = torch.autograd.grad(loss, generated, retain_graph=True)[0].flatten(1).detach()
    adversarial = torch.autograd.grad(adversarial_loss, generated, retain_graph=True)[0].flatten(1).detach()
    with torch.no_grad():
        tiny = torch.finfo(x.dtype).tiny
        adv2 = adversarial.square().sum(dim=1, keepdim=True)
        tangent = repulsion - (repulsion * adversarial).sum(dim=1, keepdim=True) / adv2.clamp_min(tiny) * adversarial
        tangent_norm = tangent.norm(dim=1, keepdim=True)
        tangent = tangent / tangent_norm.clamp_min(tiny) * adv2.sqrt() * crowding.detach()[:, None]
        tangent = torch.where(tangent_norm > torch.finfo(x.dtype).eps * repulsion.norm(dim=1, keepdim=True), tangent, torch.zeros_like(tangent))
        stats = dict(policy='tangent_support', distinct_particles=int(torch.unique(indices).numel()),
            active_rows=int((tangent.norm(dim=1)>0).sum()), bandwidth_squared=float(bandwidth),
            median_neighbor_distance=float(nearest_distance.median().sqrt()),
            mean_crowding=float(crowding.mean()), adversarial_norm=float(adversarial.norm()),
            tangent_norm=float(tangent.norm()),
            max_force_ratio=float((tangent.norm(dim=1)/adversarial.norm(dim=1).clamp_min(tiny)).max()),
            max_abs_force_cosine=float(((tangent*adversarial).sum(dim=1)/(tangent.norm(dim=1)*adversarial.norm(dim=1)).clamp_min(tiny)).abs().max()))
    grads = torch.autograd.grad(generated, parameters, grad_outputs=tangent.reshape_as(generated), retain_graph=True, allow_unused=True)
    return grads, stats


def shared_tangent_support(generated, indices, adversarial_loss, parameters, optimizer):
    """Project separation after G pullback, in the existing Adam metric.

    P=(sqrt(v)+eps)^-1 uses the current native second moment only as a
    measurement metric. Native Adam still performs every actual update.
    Bound ||h_perp||_P by mean(crowding)*||g||_P, with <g,h_perp>_P=0.
    There is no projection solver, optimizer-state mutation or new state.
    """
    x = generated.flatten(1)
    with torch.no_grad():
        distinct = indices[:, None] != indices[None, :]
        if not bool(distinct.any()):
            return [None] * len(parameters), dict(policy='shared_tangent_support', active_parameters=0)
        distances = torch.cdist(x.detach(), x.detach()).square()
        distances.masked_fill_(~distinct, float('inf'))
        nearest_distance, nearest = distances.min(dim=1)
        numerical_floor = torch.finfo(x.dtype).eps * x.detach().square().mean().clamp_min(torch.finfo(x.dtype).tiny)
        bandwidth = nearest_distance.median().clamp_min(numerical_floor)
    separation = (x - x[nearest]).square().sum(dim=1)
    crowding = (-separation / bandwidth).exp()
    active = [p for p in parameters if p.requires_grad]
    adversarial = torch.autograd.grad(adversarial_loss, active, retain_graph=True, allow_unused=True)
    repulsive = torch.autograd.grad(crowding.mean(), active, retain_graph=True, allow_unused=True)
    groups = {id(p): group for group in optimizer.param_groups for p in group['params']}
    with torch.no_grad():
        g = [torch.zeros_like(p) if v is None else v for p, v in zip(active, adversarial)]
        h = [torch.zeros_like(p) if v is None else v for p, v in zip(active, repulsive)]
        metric = []
        for p in active:
            state = optimizer.state.get(p, {})
            moment = state.get('exp_avg_sq', torch.zeros_like(p))
            metric.append((moment.sqrt() + groups[id(p)]['eps']).reciprocal())
        tiny = torch.finfo(x.dtype).tiny
        gg = sum((a.square()*m).sum() for a, m in zip(g, metric))
        gh = sum((a*b*m).sum() for a, b, m in zip(g, h, metric))
        coefficient = gh / gg.clamp_min(tiny)
        projected = [b-coefficient*a for a, b in zip(g, h)]
        hh = sum((b.square()*m).sum() for b, m in zip(projected, metric))
        gain = crowding.detach().mean()
        scale = gain * (gg / hh.clamp_min(tiny)).sqrt()
        corrected = [b*scale for b in projected]
        cross = sum((a*b*m).sum() for a, b, m in zip(g, corrected, metric))
        norm2 = sum((b.square()*m).sum() for b, m in zip(corrected, metric))
        values = {id(p): v for p, v in zip(active, corrected)}
        stats = dict(policy='shared_tangent_support', distinct_particles=int(torch.unique(indices).numel()),
            active_parameters=len(active), bandwidth_squared=float(bandwidth),
            median_neighbor_distance=float(nearest_distance.median().sqrt()),mean_crowding=float(gain),
            projection_coefficient=float(coefficient),adversarial_metric_norm=float(gg.sqrt()),
            auxiliary_metric_norm=float(norm2.sqrt()),metric_norm_ratio=float((norm2/gg.clamp_min(tiny)).sqrt()),
            metric_cosine=float(cross/(gg*norm2).sqrt().clamp_min(tiny)),
            metric='native_adam_existing_uncorrected_second_moment',native_state_mutated=False)
    return [values.get(id(p)) for p in parameters], stats
