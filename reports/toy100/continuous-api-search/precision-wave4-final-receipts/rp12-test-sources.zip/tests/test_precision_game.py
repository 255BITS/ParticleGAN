"""Public mechanics checks; no quality qualification from these CPU units."""
from copy import deepcopy
import pytest
import torch
from torch import nn
from particlegan import GANTrainer, get_recipe
from particlegan.game_update import secant_resolvent
from test_training import assert_checkpoint_equal


def make(variant='rp5', game='secant_particle_exploration'):
    torch.manual_seed(0)
    recipe=get_recipe(total_steps=None,continuous_precision=variant,game_update=game,
                      adam_eager_state=True,num_particles=2000,z_dim=2,batch_size=8)
    return GANTrainer(recipe,nn.Sequential(nn.Linear(2,8),nn.Tanh(),nn.Linear(8,2)),
                      nn.Sequential(nn.Linear(2,8),nn.Tanh(),nn.Linear(8,1)),
                      optimizer_options={'foreach':False,'fused':False},serial_backward=True)


@pytest.mark.parametrize('a,b',[(0.,4.),(-3.,2.),(-5.,0.),(0.,0.)])
def test_secant_matches_implicit_linear_game(a,b):
    u=torch.tensor([.2,-.7],dtype=torch.float64)
    j=torch.tensor([[a,-b],[b,a]],dtype=torch.float64)
    delta,_=secant_resolvent([u],[u+j@u])
    expected=torch.linalg.solve(torch.eye(2,dtype=torch.float64)-j,u)
    assert torch.allclose(delta[0],expected,rtol=0,atol=1e-14)


def test_one_accepted_clock_sparse_sampling_and_policy_update():
    t=make();original=t.prior.z.detach().clone();seen=[]
    sample=t.prior.sample
    def capture(*a,**kw):
        value=sample(*a,**kw);seen.append(value[1].clone());return value
    t.prior.sample=capture
    before=[p.clone() for p in t.ema_G.parameters()]
    t.step(torch.ones(8,2))
    assert t.completed_steps==t.opt_d.record.calls==t.opt_d.record.observed_steps==t.precision.state['updates']==1
    assert len(seen)==4 and all(torch.equal(seen[i],seen[i%2]) for i in range(4))
    mask=torch.ones(len(original),dtype=torch.bool);mask[seen[1]]=False
    assert torch.equal(t.prior.z[mask],original[mask])
    assert not torch.equal(t.prior.z[~mask],original[~mask])
    for opt in (t.opt_g,t.opt_d):
        assert all(s['step']==1 for s in opt.state.values())
    for prev,avg,live in zip(before,t.ema_G.parameters(),t.G.parameters()):
        assert torch.equal(avg,prev.mul(t.recipe.ema_decay).add(live,alpha=1-t.recipe.ema_decay))


@pytest.mark.parametrize("variant", ["rp4", "rp5"])
def test_checkpoint_full_controller_exact(variant):
    game='secant_particle_exploration'
    t=make(variant,game);t.step(torch.ones(8,2));saved=t.state_dict()
    t.step(torch.full((8,2),.3));expected=t.state_dict()
    other=make(variant,game);other.load_state_dict(saved);other.step(torch.full((8,2),.3))
    assert_checkpoint_equal(other.state_dict(),expected)


@pytest.mark.parametrize("failure_site", ["corrector_field", "precision_evidence"])
def test_failed_preview_rolls_back_controller_model_optimizer_and_rng(failure_site):
    t=make();saved=t.state_dict();calls=[]
    def fail(module,inputs):
        calls.append(1)
        if failure_site == 'corrector_field' and len(calls)==3:raise RuntimeError('injected corrector_field')
    handle=t.G.register_forward_pre_hook(fail)
    # Separate faults: the G hook must not mask the after-acceptance failure.
    orig=t.precision.observe
    def bad(*args):
        assert failure_site == 'precision_evidence' and len(calls) == 4
        assert t.completed_steps == 1
        raise RuntimeError('injected precision_evidence')
    t.precision.observe=bad
    with pytest.raises(RuntimeError,match='injected '+failure_site):t.step(torch.ones(8,2))
    assert len(calls) == (3 if failure_site == 'corrector_field' else 4)
    handle.remove();t.precision.observe=orig
    assert_checkpoint_equal(saved,t.state_dict())
    assert torch.autograd.is_multithreading_enabled()


def test_generator_callback_once():
    t=make();calls=[]
    t.step(torch.ones(8,2),generator_real=lambda:calls.append(1) or torch.ones(8,2))
    assert calls==[1]


def test_ordinary_optimizer_post_hooks_once():
    t=make(game='ordinary');calls=[]
    for role,opt in [('g',t.opt_g),('d',t.opt_d)]:
        opt.register_step_post_hook(lambda opt,args,kwargs,role=role:calls.append(role))
    t.step(torch.ones(8,2))
    assert calls==['d','g']


def test_ka2_skipping_reference_is_not_forced_to_move():
    t=make();t.opt_d.record.calls=799
    t.step(torch.ones(8,2));before=deepcopy(t.ema_D.state_dict())
    assert t.opt_d.record.anchor_started and t.opt_d.record.ema_skips==1
    t.step(torch.ones(8,2))
    assert_checkpoint_equal(before,t.ema_D.state_dict())
    assert t.opt_d.record.ema_skips==2



@pytest.mark.parametrize('matrix',[[[-1.,-3.],[3.,-7.]],[[0.,-4.],[4.,0.]], [[-2.,0.],[0.,-2.]],[[0.,0.],[0.,0.]]])
def test_measured_second_direction_solves_dissipative_linear_game(matrix):
    from particlegan.game_update import orthogonal_probe,two_direction_resolvent
    u=torch.tensor([.2,-.7],dtype=torch.float64)
    j=torch.tensor(matrix,dtype=torch.float64)
    v=u+j@u
    q=orthogonal_probe([u],[v])[0]
    delta,stats=two_direction_resolvent([u],[v],[u+j@q],[q])
    expected=torch.linalg.solve(torch.eye(2,dtype=torch.float64)-j,u)
    assert torch.allclose(delta[0],expected,rtol=0,atol=1e-13)
    assert stats['norm_ratio']<=1.+1e-14


def test_zero_predictor_stays_finite():
    from particlegan.game_update import orthogonal_probe,two_direction_resolvent
    u=[torch.zeros(2)]
    q=orthogonal_probe(u,u)
    delta,stats=two_direction_resolvent(u,u,u,q)
    assert torch.equal(delta[0],u[0])
    assert stats['norm_ratio']==1.

@pytest.mark.parametrize('gram,rhs,expected', [
    ([[4.,0.],[0.,2.]],[1.,1.],[.25,.5]),
    ([[1.,0.],[0.,1.]],[2.,0.],[1.,0.]),
    ([[2.,1.],[1.,2.]],[-2.,1.],[0.,.5]),
    ([[0.,0.],[0.,0.]],[0.,0.],[0.,0.]),
])
def test_minimum_residual_disk_and_half_plane(gram,rhs,expected):
    from particlegan.game_update import constrained_coefficients
    c,stats=constrained_coefficients(torch.tensor(gram,dtype=torch.float64),torch.tensor(rhs,dtype=torch.float64))
    assert torch.allclose(c,torch.tensor(expected,dtype=torch.float64),rtol=0,atol=1e-8)
    assert c.norm()<=1.+1e-8 and c[0]>=0


def test_out_of_plane_response_is_used_by_minimum_residual():
    from particlegan.game_update import minimum_residual_resolvent,two_direction_resolvent
    u=torch.tensor([1.,0.,0.],dtype=torch.float64)
    q=torch.tensor([0.,1.,0.],dtype=torch.float64)
    w1=torch.tensor([0.,1.,0.],dtype=torch.float64)
    w2=torch.tensor([-1.,0.,5.],dtype=torch.float64)
    measured,stats=minimum_residual_resolvent([u],[u+w1],[u+w2],[q])
    old,_=two_direction_resolvent([u],[u+w1],[u+w2],[q])
    assert torch.allclose(measured[0],torch.tensor([.5,1/27,0.],dtype=torch.float64))
    def residual(delta):return (u-(u-w1)*delta[0]-(q-w2)*delta[1]).norm()
    assert residual(measured[0])<residual(old[0])
    assert stats['linear_residual']==pytest.approx(float(residual(measured[0])))


def test_particle_noise_bound_and_predictor_agreement():
    from particlegan.game_update import particle_exploration
    u=torch.tensor([[1.,2.],[1.,0.],[1.,0.],[0.,0.]])
    v=torch.tensor([[2.,4.],[-1.,0.],[0.,1.],[1.,0.]])
    step=torch.tensor([[.1,.2],[.2,.1],[.2,.1],[0.,0.]])
    stream=torch.Generator().manual_seed(6)
    noise,stats=particle_exploration(u,v,step,stream)
    assert torch.allclose(noise[0],torch.zeros(2),atol=1e-4)
    assert torch.equal(noise[-1],torch.zeros(2))
    assert torch.allclose(noise[1].norm(),step[1].norm())
    assert torch.allclose(noise[2].norm(),step[2].norm()/(2**.5))
    assert torch.all(noise.norm(dim=1)<=step.norm(dim=1)+1e-7)
    assert stats['max_row_noise_to_step']<=1


def test_particle_rng_is_private_and_replayable_without_advancing_other_streams():
    t=make();initial=t.particle_noise_generator.get_state().clone()
    expected=t.latent_generator.get_state().clone()
    reference=torch.Generator();reference.set_state(expected)
    torch.randint(0,2000,(8,),generator=reference);torch.randint(0,2000,(8,),generator=reference)
    t.step(torch.ones(8,2))
    assert torch.equal(t.latent_generator.get_state(),reference.get_state())
    assert not torch.equal(t.particle_noise_generator.get_state(),initial)
    saved=t.state_dict();before=t.particle_noise_generator.get_state().clone()
    t.sample(7,generator=torch.Generator().manual_seed(9))
    assert torch.equal(t.particle_noise_generator.get_state(),before)
    with pytest.raises(ValueError,match='separate'):
        t.sample(7,generator=t.particle_noise_generator)
    # Existing exact continuation test also compares this additional stream.
    other=make();other.load_state_dict(saved)
    assert torch.equal(other.particle_noise_generator.get_state(),before)

@pytest.mark.parametrize('age',[0,1,360,720,30000,10**9])
def test_rp10_stationary_noise_has_no_age_or_budget_dependency(age):
    from particlegan.training import input_noise_std,output_noise_std
    for horizon in [None,1200,7500,30000]:
        r=get_recipe(total_steps=horizon,continuous_precision='rp5' if horizon is None else None,
                     noise_policy='constant',input_noise_std=0.)
        assert input_noise_std(r,age)==0.
        assert output_noise_std(r,age)==.029


def test_rp10_full_checkpoint_continuation_with_constant_noise():
    def construct():
        torch.manual_seed(0)
        r=get_recipe(total_steps=None,continuous_precision='rp5',game_update='secant_resolvent',
                     adam_eager_state=True,noise_policy='constant',input_noise_std=0.,
                     num_particles=12,z_dim=2,batch_size=8)
        return GANTrainer(r,nn.Sequential(nn.Linear(2,8),nn.Tanh(),nn.Linear(8,2)),
                          nn.Sequential(nn.Linear(2,8),nn.Tanh(),nn.Linear(8,1)),
                          optimizer_options={'foreach':False,'fused':False},serial_backward=True)
    t=construct();t.step(torch.ones(8,2));saved=t.state_dict()
    t.step(torch.full((8,2),.3));expected=t.state_dict()
    other=construct();other.load_state_dict(saved);other.step(torch.full((8,2),.3))
    assert_checkpoint_equal(other.state_dict(),expected)
    assert t.game_stats['field_evaluations']==2
    assert 'particle_noise_generator' not in expected['streams']

@pytest.mark.parametrize('role',['d','g'])
def test_all_pairs_is_exact_permutation_average_with_gradients(role):
    import itertools
    from particlegan.gan_loss import GANLoss
    a=torch.tensor([[.4],[-1.],[3.]],dtype=torch.float64,requires_grad=True)
    b=torch.tensor([[1.],[-2.],[.7]],dtype=torch.float64,requires_grad=True)
    fn=lambda loss,x,y:loss.d_loss(x,y) if role=='d' else loss.g_loss(x,y)
    expected=torch.stack([fn(GANLoss(),a,b[list(p)]) for p in itertools.permutations(range(3))]).mean()
    actual=fn(GANLoss('all_pairs'),a,b)
    assert torch.allclose(actual,expected,atol=1e-14,rtol=0)
    for got,want in zip(torch.autograd.grad(actual,(a,b)),torch.autograd.grad(expected,(a,b))):
        assert torch.allclose(got,want,atol=1e-14,rtol=0)


def test_all_pairs_public_api_checkpoint_continuation():
    def construct():
        torch.manual_seed(0)
        r=get_recipe(total_steps=None,continuous_precision='rp5',game_update='secant_resolvent',
                     adam_eager_state=True,noise_policy='constant',input_noise_std=0.,relativistic_pairing='all_pairs',
                     num_particles=12,z_dim=2,batch_size=8)
        return GANTrainer(r,nn.Sequential(nn.Linear(2,8),nn.Tanh(),nn.Linear(8,2)),
                          nn.Sequential(nn.Linear(2,8),nn.Tanh(),nn.Linear(8,1)),
                          optimizer_options={'foreach':False,'fused':False},serial_backward=True)
    t=construct();assert t.loss.pairing=='all_pairs'
    t.step(torch.ones(8,2));saved=t.state_dict();t.step(torch.full((8,2),.3));expected=t.state_dict()
    other=construct();other.load_state_dict(saved);other.step(torch.full((8,2),.3))
    assert_checkpoint_equal(expected,other.state_dict())


def test_sampled_particle_mass_is_equal_and_uses_no_rng():
    r=get_recipe(particle_loss_weighting='uniform_sampled')
    indices=torch.tensor([0,0,2,1,2,2,2],dtype=torch.long)
    before=torch.get_rng_state();weights=r.particle_weights(indices)
    assert torch.equal(before,torch.get_rng_state())
    assert weights.sum()==pytest.approx(1.)
    for i in [0,1,2]:assert weights[indices==i].sum()==pytest.approx(1/3)
    assert get_recipe().particle_weights(indices) is None


@pytest.mark.parametrize('role',['d','g'])
def test_sampled_particle_loss_matches_unique_support_and_gradients(role):
    from particlegan.gan_loss import GANLoss
    indices=torch.tensor([0,0,2,1,2,2,2])
    r=get_recipe(relativistic_pairing='all_pairs',particle_loss_weighting='uniform_sampled')
    real=torch.tensor([.2,-1.,2.],dtype=torch.float64,requires_grad=True)
    fake=torch.tensor([.7,3.,-2.],dtype=torch.float64,requires_grad=True)
    loss=r.make_loss()
    expected=loss.d_loss(real,fake) if role=='d' else loss.g_loss(fake,real)
    actual=(loss.d_loss(real,fake[indices],fake_weights=r.particle_weights(indices)) if role=='d'
            else loss.g_loss(fake[indices],real,fake_weights=r.particle_weights(indices)))
    assert torch.allclose(actual,expected,atol=1e-7,rtol=0)
    for got,want in zip(torch.autograd.grad(actual,(real,fake)),torch.autograd.grad(expected,(real,fake))):
        assert torch.allclose(got,want,atol=1e-7,rtol=0)


def test_sampled_particle_public_api_exact_continuation_and_clocks():
    def construct():
        torch.manual_seed(0)
        r=get_recipe(total_steps=None,continuous_precision='rp5',game_update='secant_resolvent',
                     adam_eager_state=True,noise_policy='constant',input_noise_std=0.,
                     relativistic_pairing='all_pairs',particle_loss_weighting='uniform_sampled',
                     num_particles=12,z_dim=2,batch_size=8)
        return GANTrainer(r,nn.Sequential(nn.Linear(2,8),nn.Tanh(),nn.Linear(8,2)),
                          nn.Sequential(nn.Linear(2,8),nn.Tanh(),nn.Linear(8,1)),
                          optimizer_options={'foreach':False,'fused':False},serial_backward=True)
    t=construct();row=t.step(torch.ones(8,2));saved=t.state_dict()
    assert row['particle_loss_sampling']['g']['distinct_particles']<=8
    assert t.completed_steps==t.opt_d.record.calls==t.opt_d.record.observed_steps==1
    t.step(torch.full((8,2),.3));expected=t.state_dict()
    other=construct();other.load_state_dict(saved);other.step(torch.full((8,2),.3))
    assert_checkpoint_equal(expected,other.state_dict())
