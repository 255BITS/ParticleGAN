"""Execution-mode correctness; these CPU units are not quality benchmarks."""
import copy
import pytest
import torch
from torch import nn
from particlegan import GANTrainer, get_recipe


def make(serial=False):
    torch.manual_seed(0)
    recipe=get_recipe(num_particles=32,z_dim=2,batch_size=8,total_steps=20)
    return GANTrainer(recipe,nn.Sequential(nn.Linear(2,8),nn.Tanh(),nn.Linear(8,2)),
                      nn.Sequential(nn.Linear(2,8),nn.Tanh(),nn.Linear(8,1)),
                      serial_backward=serial,optimizer_options={'foreach':False,'fused':False})


def test_serial_scope_restores_caller_on_success_and_exception():
    trainer=make(True)
    modes=[]
    handle=trainer.D.register_forward_pre_hook(lambda module,inputs:modes.append(torch.autograd.is_multithreading_enabled()))
    with torch.autograd.set_multithreading_enabled(True):
        trainer.step(torch.ones(8,2))
        assert torch.autograd.is_multithreading_enabled()
        assert modes and not any(modes)
        def fail(module,inputs):
            assert not torch.autograd.is_multithreading_enabled()
            raise RuntimeError('injected forward failure')
        failure=trainer.D.register_forward_pre_hook(fail)
        with pytest.raises(RuntimeError,match='injected forward failure'):
            trainer.step(torch.ones(8,2))
        assert torch.autograd.is_multithreading_enabled()
        failure.remove()
    with torch.autograd.set_multithreading_enabled(False):
        trainer.step(torch.ones(8,2))
        assert not torch.autograd.is_multithreading_enabled()
    handle.remove()


def test_serial_execution_mode_is_checkpointed_and_validated_before_mutation():
    serial=make(True);legacy=make(False)
    state=serial.state_dict()
    assert state['serial_backward'] is True
    assert 'serial_backward' not in legacy.state_dict()
    for target,source in [(serial,legacy.state_dict()),(legacy,state)]:
        before=target.G[0].weight.clone()
        with pytest.raises(ValueError,match='serial_backward'):
            target.load_state_dict(source)
        assert torch.equal(before,target.G[0].weight)
    bad=copy.deepcopy(state);bad['serial_backward']=1
    with pytest.raises(ValueError,match='serial_backward'):
        serial.load_state_dict(bad)
    restored=make(True);restored.load_state_dict(state)
    assert restored.state_dict()['serial_backward'] is True


def test_invalid_serial_mode_and_legacy_caller_context():
    with pytest.raises(TypeError,match='serial_backward'):
        make(1)
    legacy=make(False)
    with torch.autograd.set_multithreading_enabled(False):
        legacy.step(torch.ones(8,2))
        assert not torch.autograd.is_multithreading_enabled()


def test_original_recipe_checkpoint_remains_loadable():
    legacy=make(False)
    state=legacy.state_dict()
    state['recipe'].pop('continuous_policy',None)
    legacy.load_state_dict(state)


@pytest.mark.parametrize('failure_site',['nested_grad','outer_backward'])
def test_autograd_engine_exception_restores_caller(failure_site):
    trainer=make(True)
    events=[]
    class FailingGradient(torch.autograd.Function):
        @staticmethod
        def forward(ctx,value):
            return value.clone()
        @staticmethod
        def backward(ctx,gradient):
            events.append(('nested_grad',torch.is_grad_enabled(),torch.autograd.is_multithreading_enabled()))
            raise RuntimeError('injected nested backward failure')
    if failure_site=='nested_grad':
        handle=trainer.D.register_forward_hook(lambda module,inputs,output:FailingGradient.apply(output))
    else:
        def fail(gradient):
            events.append(('outer_backward',torch.is_grad_enabled(),torch.autograd.is_multithreading_enabled()))
            raise RuntimeError('injected outer backward failure')
        handle=trainer.D[0].weight.register_hook(fail)
    try:
        with torch.autograd.set_multithreading_enabled(True):
            with pytest.raises(RuntimeError,match='injected .* backward failure'):
                trainer.step(torch.ones(8,2))
            assert torch.autograd.is_multithreading_enabled()
    finally:
        handle.remove()
    assert events==[(failure_site,failure_site=='nested_grad',False)]
