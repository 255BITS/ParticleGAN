"""Diagnostic continuation from the selected base's own cold-acquired state.

Uses the validated frozen update loop with unchanged acquired Adam/RNG state.
This measures a research blocker; it does not bypass the full toy promotion gate.
"""
import argparse
import gzip
import json
from pathlib import Path
import shutil
import tarfile
import time
import traceback

import stability_runner as runner

ROOT = Path(__file__).resolve().parents[3]
SELECTION = Path(__file__).with_name('current-base.json')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--steps', type=int, choices=(200, 1200), default=200)
    parser.add_argument('--candidate', type=Path, help='own cold candidate; use its complete options')
    parser.add_argument('--ledger', type=Path)
    parser.add_argument('--diagnostic-full-window', action='store_true')
    args = parser.parse_args()
    selection = json.loads(SELECTION.read_text())
    candidate = ROOT / selection['cold_candidate']
    state_sha = selection['cold_checkpoint_sha256']
    if args.candidate:
        candidate = args.candidate.resolve()
        state_sha = runner.sha(candidate/'mode_hold/final-state.pt')
        selection = dict(selection, candidate=candidate.name,
                         cold_candidate=str(candidate.relative_to(ROOT)),
                         cold_checkpoint_sha256=state_sha,
                         options=json.loads((candidate/'options.json').read_text()))
    if selection['options'].get('adam_response'):
        from adam_response import response_policy
        runner.signal_policy = response_policy
        runner.POLICIES['control'] = dict(runner.POLICIES['control'],
            family='selected constant-rate Adam response', epsilon=selection['epsilon'])

    def verify():
        # Reuse acquired-state and optimizer validators; do not rerun the H audit.
        from continuous_screen import verify_receipt
        runner.CANDIDATE, runner.STATE_SHA = candidate, state_sha
        assert runner.sha(candidate/'mode_hold/final-state.pt') == state_sha
        status = json.loads((candidate/'status.json').read_text())
        ring = next(row for row in status['stages'] if row['gate'] == 'mode_hold')
        assert ring['status'] == 'PASS'
        config = json.loads((candidate/'config.json').read_text())
        actual = dict(g=config['lr'], d=config['lr']*config['d_lr_mult'],
                      prior=config['lr']*config['prior_lr_mult'])
        assert actual == selection['fixed_rates']
        assert json.loads((candidate/'options.json').read_text()) == selection['options']
        receipt = json.loads(gzip.decompress((candidate/'mode_hold/signal-policy.json.gz').read_bytes()))
        verify_receipt(receipt, config, task='mode_hold')
        assert receipt['effective_eps'] == selection['epsilon']
        if selection['options'].get('particle_geometry'):
            assert receipt['particle_geometry']['single_optimizer_observer']
            assert receipt['particle_geometry']['transformed_tensors'] == 1200
        runner.ARCHIVE_SHA = runner.sha(candidate.parent/'source.tar.gz')

    runner.verify_sources = verify
    started = time.perf_counter()
    try:
        result = runner.run('control', args.output, args.steps, args.diagnostic_full_window)
    except Exception:
        if args.ledger:
            from critic_signal_screen import append
            args.output.mkdir(parents=True, exist_ok=True)
            error = traceback.format_exc()
            (args.output/'error.txt').write_text(error)
            append(args.ledger, dict(candidate=selection['candidate'],
                   gate=f'own_state_diagnostic_{args.steps}', status='ERROR',
                   seconds=time.perf_counter()-started, metrics={},
                   artifact=str((args.output/'error.txt').resolve()), error=error))
        raise
    if result['status'] == 'SHORT_PASS':
        result['status'] = 'PASS'
    result.update(candidate=selection['candidate'], gate=f'own_state_diagnostic_{args.steps}',
                  qualification='UNQUALIFIED until every required gate passes',
                  borrowed_H_state=False, rates_changed_on_restore=False)
    declaration = json.loads((args.output/'declaration.json').read_text())
    declaration.update(state_origin='own cold acquisition with the same fixed rates',
                       wrapper_sha256=runner.sha(Path(__file__)),
                       qualification='diagnostic only; full cold promotion gates not passed')
    runner.write(args.output/'declaration.json', declaration)
    runner.write(args.output/'summary.json', result)
    shutil.copy2(__file__, args.output/'selected_base_probe.py')
    runner.write(args.output/'current-base.json', selection)
    from adam_response_cold import sources
    manifest = sources()
    runner.write(args.output/'source-manifest.json', manifest)
    with tarfile.open(args.output/'source.tar.gz', 'w:gz') as archive:
        for name in manifest:
            archive.add(ROOT/name, arcname=name)
    if args.ledger:
        from critic_signal_screen import append
        append(args.ledger, dict(candidate=selection['candidate'], gate=result['gate'],
               status=result['status'], seconds=time.perf_counter()-started,
               metrics={k: result[k] for k in ('window', 'final', 'full_budget')},
               artifact=str((args.output/'summary.json').resolve())))
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
