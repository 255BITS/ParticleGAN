"""Two independent adversarial gradient draws, one ordinary Adam commit.

The existing frozen host's complete D block (including regularization) and
complete adversarial G block run twice at unchanged parameters. Sampling and
noise advance normally. Each draw keeps the host batch size; gradients are
averaged before Adam. Schedules, EMA, observations and clocks run only once.
This is restricted to the three declared cheap hosts and own-ring continuation.
"""
import ast
from contextlib import contextmanager, ExitStack
from copy import deepcopy
import hashlib
import inspect
from unittest.mock import patch

import torch
from extra_adam_scratch import _call, _contains

HOSTS = dict(mode_hold=('train_mode_hold', 'opt_g'),
             two_pole=('train', 'opt_p'), unipolar=('_fit_rpgan', 'opt_g'))


def transform(module, task):
    name, gopt = HOSTS[task]
    original = inspect.getsource(getattr(module, name))
    tree = ast.parse(original)
    loop = next(n for n in tree.body[0].body if isinstance(n, ast.For)
                and _contains(n, 'opt_d.step') and _contains(n, gopt+'.step'))
    d_end = next(i for i, n in enumerate(loop.body) if _contains(n, 'schedule_optimizer'))
    d_step = next(i for i, n in enumerate(loop.body) if _contains(n, 'opt_d.step'))
    g_end = next(i for i, n in enumerate(loop.body[d_step+1:], d_step+1)
                 if _contains(n, 'schedule_optimizer'))
    if task == 'mode_hold':
        start = next(i for i, n in enumerate(loop.body) if isinstance(n, ast.Assign)
                     and ast.unparse(n.targets[0]) == 'real')
    elif task == 'two_pole':
        start = next(i for i, n in enumerate(loop.body) if _contains(n, 'opt_d.zero_grad'))
    else:
        start = next(i for i, n in enumerate(loop.body) if _contains(n, 'critic.requires_grad_'))
    for begin, end, role, opt in ((d_step+1, g_end, 'g', gopt), (start, d_end, 'd', 'opt_d')):
        block = loop.body[begin:end]
        assert sum(_call(n, opt+'.zero_grad') for s in block for n in ast.walk(s)) == 1
        assert sum(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                   and n.func.attr == 'backward' for s in block for n in ast.walk(s)) == 1
        assert not any(_contains(n, call) for n in block for call in
                       ('checkpoint', 'noise_policy.set_step', 'schedule_optimizer', opt+'.step'))
        wrapped = ast.parse(f"for _variance_draw in _gradient_average.draws({opt}, '{role}'):\n    pass").body[0]
        wrapped.body = block
        loop.body[begin:end] = [wrapped]
    # The exact inverse recovers every original host AST node.
    class Inverse(ast.NodeTransformer):
        def visit_For(self, node):
            if isinstance(node.target, ast.Name) and node.target.id == '_variance_draw':
                return node.body
            return self.generic_visit(node)
    restored = Inverse().visit(deepcopy(tree))
    assert ast.dump(restored, include_attributes=False) == ast.dump(ast.parse(original), include_attributes=False)
    ast.fix_missing_locations(tree)
    return tree, ast.unparse(tree)+'\n', hashlib.sha256(original.encode()).hexdigest()


class GradientAverage:
    def __init__(self, receipt, count=2):
        if count not in (1, 2):
            raise ValueError('one control draw or two proposal draws only')
        self.count = count
        self.work = receipt.setdefault('gradient_average', dict(
            policy='independent2', draws=count, d_backwards=0, g_backwards=0,
            d_commits=0, g_commits=0, source_transforms={},
            objective='arithmetic mean of complete original adversarial gradients before Adam',
            host_batch_unchanged=True, additional_gradient_evaluations=0))

    def draws(self, opt, role):
        params = [p for group in opt.param_groups for p in group['params']]
        total = {}
        active = None
        for index in range(self.count):
            yield index
            present = {p for p in params if p.grad is not None}
            if active is None:
                active = present
            if present != active:
                raise RuntimeError('draws changed the active trainable directions')
            for p in present:
                if index == 0:
                    total[p] = p.grad.detach().clone()
                else:
                    total[p].add_(p.grad)
            self.work[role+'_backwards'] += 1
        for p, value in total.items():
            p.grad = value.div_(self.count)
        self.work[role+'_commits'] += 1
        self.work['additional_gradient_evaluations'] += self.count-1


@contextmanager
def average_policy(receipt):
    from benchmarks.locked_shared import mode_hold, two_pole
    from benchmarks.locked_shared.hosts import unipolar
    recorder = GradientAverage(receipt)
    with ExitStack() as stack:
        for task, module in dict(mode_hold=mode_hold, two_pole=two_pole, unipolar=unipolar).items():
            tree, source, digest = transform(module, task)
            recorder.work['source_transforms'][task] = dict(
                original_sha256=digest, generated_source=source, inverse_verified=True)
            namespace = {}
            stack.enter_context(patch.dict(module.__dict__, {'_gradient_average': recorder}))
            exec(compile(tree, f'<gradient-average-{task}>', 'exec'), module.__dict__, namespace)
            stack.enter_context(patch.object(module, HOSTS[task][0], namespace[HOSTS[task][0]]))
        yield recorder
    if not recorder.work['d_commits'] or not recorder.work['g_commits']:
        raise RuntimeError('gradient averaging did not execute; unsupported host or missing continuation adapter')
    receipt['additional_gradient_evaluations'] = recorder.work['additional_gradient_evaluations']
