"""Exact g_radial_split_adam particle transform inside the epsilon observer.

One observer owns roles, epsilon application, Adam and final movement receipts.
No new loss, gradients, random draws, schedule or target information is used.
"""
import math

import torch
from continuous_candidates import _EpsilonObserver


class RadialResponseObserver(_EpsilonObserver):
    def __init__(self, eps, geometry, network_geometry='coordinate_adam'):
        super().__init__(eps)
        if geometry['kind'] != 'split_adam' or geometry['shape_basis'] != 'radial':
            raise ValueError('this combination requires declared radial split Adam')
        for key in ('shape_gain', 'mean_gain'):
            value = geometry[key]
            if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
                raise ValueError('fixed subspace gains must be positive')
        self.geometry = dict(geometry)
        if network_geometry not in ('coordinate_adam', 'tensor_rms', 'shape_shared_rms',
                                    'shape_shared_adam', 'shape_shared_row_rms',
                                    'shape_shared_column_rms', 'global_rms',
                                    'shape_shared_column_rms_instant_floor',
                                    'shape_shared_column_rms_current'):
            raise ValueError('unknown combined G geometry')
        self.network_geometry = network_geometry
        self.receipt['network_geometry'] = dict(
            policy=network_geometry, roles=['g'], transformed_tensors=0, updates=[],
            extra_forwards=0, extra_backwards=0, positive_all_directions=True,
            formula='m_hat/(sqrt(mean(v_hat over declared parameter block))+eps)',
            state='unchanged coordinate Adam moments; no additional G state')
        if network_geometry.endswith('_instant_floor') or network_geometry.endswith('_current'):
            self.receipt['network_geometry'].update(
                partition='matching-shape matrix columns; vectors retain shared scalar RMS',
                formula=('m_hat/(sqrt(max(pooled_v_hat, pooled_current_g_squared))+eps)'
                         if network_geometry.endswith('_instant_floor') else
                         'm_hat/(sqrt(pooled_current_g_squared)+eps)'),
                state='Adam moments retained; matrix denominator uses current gradient only or a per-update floor; vector rule unchanged',
                no_time_schedule=True, no_cumulative_max=True)
        self.receipt['particle_geometry'] = dict(
            policy='radial_split_inside_epsilon_observer_v1', **geometry,
            state_keys=['geometry_mean_sq', 'geometry_shape_sq'],
            extra_forwards=0, extra_backwards=0, transformed_tensors=0, updates=[],
            signal='unchanged logistic relativistic discriminator objective',
            protocol='research only; same policy from cold initialization',
            single_optimizer_observer=True, positive_all_directions=True)

    def step(self, optimizer, original_step, closure=None):
        def geometry_step(opt):
            selected = []
            network = []
            for group in opt.param_groups:
                role = self._group_role(group, self.optimizer_roles[id(opt)])
                if role == 'g' and self.network_geometry != 'coordinate_adam':
                    network.extend((p, p.detach().clone(), group) for p in group['params']
                                   if p.grad is not None)
                if role != 'prior':
                    continue
                for p in group['params']:
                    if p.grad is None:
                        continue
                    if p.ndim < 2 or group['betas'][0] != 0:
                        raise ValueError('particle geometry requires particle axis and beta1=0')
                    selected.append((p, p.detach().clone(), group))
            result = original_step(opt)
            with torch.no_grad():
                blocks = {}
                for p, anchor, group in network:
                    key = ('global' if self.network_geometry == 'global_rms' else
                           tuple(p.shape) if self.network_geometry.startswith('shape_shared_') else id(p))
                    blocks.setdefault(key, []).append((p, anchor, group))
                for block in blocks.values():
                    seconds = [(opt.state[p]['exp_avg_sq'] /
                                (1-group['betas'][1]**int(opt.state[p]['step'])))
                               for p, _, group in block]
                    if self.network_geometry == 'shape_shared_adam':
                        second = torch.stack(seconds).mean(0)
                    elif self.network_geometry == 'global_rms':
                        second = sum(v.sum() for v in seconds) / sum(v.numel() for v in seconds)
                    elif (self.network_geometry == 'shape_shared_row_rms' and seconds[0].ndim >= 2):
                        second = torch.stack(seconds).mean(0).mean(
                            dim=tuple(range(1, seconds[0].ndim)), keepdim=True)
                    elif (self.network_geometry.startswith('shape_shared_column_rms') and seconds[0].ndim >= 2):
                        second = torch.stack(seconds).mean(0).mean(dim=0, keepdim=True)
                        if self.network_geometry.endswith(('_instant_floor', '_current')):
                            current = torch.stack([p.grad.square() for p, _, _ in block]).mean(0).mean(
                                dim=0, keepdim=True)
                            second = (torch.maximum(second, current)
                                      if self.network_geometry.endswith('_instant_floor') else current)
                    else:
                        # Keep the exact reduction order of the RMS comparator.
                        second = torch.stack([v.mean() for v in seconds]).mean()
                    for p, anchor, group in block:
                        state = opt.state[p]
                        step = int(state['step'])
                        denom = second.sqrt()+group['eps']
                        p.copy_(anchor).addcdiv_(state['exp_avg'], denom,
                            value=-group['lr']/(1-group['betas'][0]**step))
                        work = self.receipt['network_geometry']
                        work['transformed_tensors'] += 1
                        if step == 1 or step % 50 == 0:
                            work['updates'].append(dict(step=step, shape=list(p.shape),
                                pooled_tensors=len(block), denominator_min=float(denom.min()),
                                denominator_max=float(denom.max()),
                                rate=float(group['lr']), eps=float(group['eps']),
                                applied_rms=float((p-anchor).square().mean().sqrt())))
                for p, anchor, group in selected:
                    state = opt.state[p]
                    step = int(state['step'])
                    ordinary = p - anchor
                    mean = p.grad.mean(dim=0, keepdim=True)
                    shape = p.grad - mean
                    beta2 = group['betas'][1]
                    directions = []
                    for name, grad in (('mean', mean), ('shape', shape)):
                        key = 'geometry_' + name + '_sq'
                        if key not in state:
                            if step != 1:
                                raise RuntimeError('split geometry needs its own acquired optimizer state')
                            state[key] = torch.zeros_like(grad)
                        state[key].mul_(beta2).addcmul_(grad, grad, value=1-beta2)
                        denom = (state[key] / (1-beta2**step)).sqrt() + group['eps']
                        directions.append(grad / denom)
                    mean_direction, shape_direction = directions
                    shape_direction = shape_direction - shape_direction.mean(dim=0, keepdim=True)
                    mean_direction = -group['lr'] * mean_direction
                    shape_direction = -group['lr'] * shape_direction
                    radial = anchor - anchor.mean(dim=0, keepdim=True)
                    projection = radial * ((radial * shape_direction).sum() /
                                           (radial.square().sum() + 1e-12))
                    shape_displacement = shape_direction + (self.geometry['shape_gain']-1) * projection
                    displacement = shape_displacement + self.geometry['mean_gain'] * mean_direction
                    p.copy_(anchor + displacement)
                    work = self.receipt['particle_geometry']
                    work['transformed_tensors'] += 1
                    if step == 1 or step % 50 == 0:
                        applied = p-anchor
                        work['updates'].append(dict(
                            step=step, shape=list(p.shape), eps=float(group['eps']),
                            nominal_rate=float(group['lr']),
                            shape_rate=float(group['lr'])*self.geometry['shape_gain'],
                            tangent_rate=float(group['lr']),
                            mean_rate=float(group['lr'])*self.geometry['mean_gain'],
                            ordinary_rms=float(ordinary.square().mean().sqrt()),
                            applied_rms=float(applied.square().mean().sqrt()),
                            applied_mean_rms=float(applied.mean(0).square().mean().sqrt()),
                            adversarial_gradient_dot_displacement=float((p.grad*applied).sum())))
            return result
        # Epsilon is applied before geometry_step, and the final transformed
        # displacement is observed afterwards. Adam executes exactly once.
        return super().step(optimizer, geometry_step, closure)
