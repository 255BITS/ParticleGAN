"""Read-only b_cap comparison on four exact phase-0 D sample banks."""
import gzip
import hashlib
import json
from pathlib import Path
import sys

import torch

ROOT = Path('/ml2/hypergan/ParticleGAN-continuous-learning')
sys.path.insert(0, str(ROOT))
from benchmarks.locked_shared import mode_hold
from reports.toy100 import pr84_heldout_signal as heldout
from reports.toy100.pr84_population_field import ratio_score


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def score_stats(fn, real, fake):
    xr = real.detach().clone().requires_grad_(True)
    xf = fake.detach().clone().requires_grad_(True)
    sr, sf = fn(xr), fn(xf)
    gr = torch.autograd.grad(sr.sum(), xr)[0].norm(dim=1)
    gf = torch.autograd.grad(sf.sum(), xf)[0].norm(dim=1)
    penalty = .5 * (gr.sub(1).clamp_min(0).square().mean()
                     + gf.sub(1).clamp_min(0).square().mean())
    dloss = torch.nn.functional.softplus(sf-sr).mean()
    return dict(d_loss=float(dloss.detach()), b_cap=float(penalty.detach()),
                total_d_objective=float((dloss+penalty).detach()),
                real_slope_mean=float(gr.mean()), real_slope_rms=float(gr.square().mean().sqrt()),
                fake_slope_mean=float(gf.mean()), fake_slope_rms=float(gf.square().mean().sqrt()),
                real_frac_above_cap=float((gr>1).float().mean()),
                fake_frac_above_cap=float((gf>1).float().mean()))


def main():
    torch.set_num_threads(1)
    evidence = ROOT/'reports/toy100/continuous-evidence/pr84-stationary-failure-diagnosis'
    states_path = evidence/'compact-states.pt.gz'
    diagnosis_path = evidence/'diagnosis.json.gz'
    states = torch.load(gzip.open(states_path,'rb'), weights_only=True)
    diagnosis = json.loads(gzip.decompress(diagnosis_path.read_bytes()))
    rows = {row['step']: row['stages'] for row in diagnosis['rows']}
    config_path = ROOT/'configs/toy100/constraints_simple_regularization.json'
    config = json.loads(config_path.read_text())
    output = []
    with torch.random.fork_rng(devices=[]):
        for step in (1325,1389,1530,1540):
            snapshot = states[step]['pre_step']
            recipe, policy, prior, generator, critic, _, _, data = heldout._construct(snapshot,config)
            q = heldout._clean(generator, prior)
            real = mode_hold.sample_ring(mode_hold.ring_means(), mode_hold.BATCH, mode_hold.SIGMA, data)
            latent, indices = prior.sample(mode_hold.BATCH, generator=data)
            with policy.discriminator():
                fake = generator(latent).detach()
            actual_real = next(b for b in rows[step]['batches'] if b['kind']=='real' and b['phase']==0)
            actual_prior = next(b for b in rows[step]['batches'] if b['kind']=='prior' and b['phase']==0)
            assert torch.equal(real,torch.tensor(actual_real['values']))
            assert indices.tolist()==actual_prior['indices']
            assert torch.equal(latent.detach(),torch.tensor(actual_prior['latent']))
            real_means=mode_hold.ring_means()
            ideal=lambda x: ratio_score(x,real_means,mode_hold.SIGMA,q,.029)
            learned=critic.model
            output.append(dict(step=step,batch='exact_phase0_D_real_and_latent_replayed_fake_from_saved_rng',
                               q_sha256=hashlib.sha256(q.numpy().tobytes()).hexdigest(),
                               ideal=score_stats(ideal,real,fake),
                               learned_pre_step=score_stats(learned,real,fake)))
    result=dict(scope='read_only_actual_phase0_D_banks_four_saved_steps',training_updates=0,
                batch_size=mode_hold.BATCH,
                source_sha256={
                    'reports/toy100/pr84_population_field.py':sha(ROOT/'reports/toy100/pr84_population_field.py'),
                    'reports/toy100/pr84_heldout_signal.py':sha(ROOT/'reports/toy100/pr84_heldout_signal.py'),
                    'benchmarks/locked_shared/mode_hold.py':sha(ROOT/'benchmarks/locked_shared/mode_hold.py'),
                    'configs/toy100/constraints_simple_regularization.json':sha(config_path),
                },inputs_sha256={'compact-states.pt.gz':sha(states_path),
                                 'diagnosis.json.gz':sha(diagnosis_path)},rows=output)
    print(json.dumps(result,indent=2,allow_nan=False))


if __name__=='__main__': main()
