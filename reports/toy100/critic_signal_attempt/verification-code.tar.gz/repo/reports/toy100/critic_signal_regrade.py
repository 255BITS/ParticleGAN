"""Independent read-only regrade of saved cold artifacts, never a new GAN run."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import sys
import tarfile

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import torch
from benchmarks.locked_shared import mode_hold, trajectory
from benchmarks.transfer_suite.protocol import test_verdict
from benchmarks.toy_suite import _episode_rows


def regrade(candidate):
    parent=candidate.parent
    manifest=json.loads((parent/'manifest.json').read_text())
    with tarfile.open(parent/'source.tar.gz') as archive:
        for name,digest in manifest['source_sha256'].items():
            assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==digest, name
    row=next(r for r in manifest['rows'] if r['tag']==candidate.name)
    assert json.loads((candidate/'config.json').read_text())==row['config']
    assert json.loads((candidate/'options.json').read_text())==row['options']
    output={'candidate':candidate.name,'source_archive_verified':True,'gates':[]}
    for task in manifest['tasks']:
        directory=candidate/task
        if not directory.exists():
            output['gates'].append(dict(gate=task,status='SKIPPED'))
            continue
        episode=next((directory/'episodes').glob('*.json.gz'))
        saved=json.loads(gzip.decompress(episode.read_bytes()))
        verdict=test_verdict(saved['spec'],saved['result'])
        assert verdict==saved['verdict']
        audit=_episode_rows(directory,(task,),candidate=True,allow_scratch=True)
        assert audit['status']==verdict['status']
        grade={'gate':task,'status':verdict['status'],'verdict':verdict}
        state_path=directory/'final-state.pt'
        if state_path.exists() and task in ('mode_hold','trajectory'):
            state=torch.load(state_path,map_location='cpu',weights_only=False)
            samples=state['samples']
            if task=='mode_hold':
                metrics=mode_hold.diversity(samples,mode_hold.ring_means(),detailed=True)
                for key in ('modes','hq'):
                    assert metrics[key]==saved['result']['live'][key]
            else:
                _,target=trajectory.trajectories()
                metrics={'identity_mse':trajectory.identity_mse(samples,target)}
                assert metrics['identity_mse']==saved['result']['live']['identity_mse']
            grade.update(saved_sample_metrics=metrics,checkpoint_sha256=hashlib.sha256(state_path.read_bytes()).hexdigest())
            for name,opt in state['optimizers'].items():
                expected_steps=saved['spec']['steps']
                assert all(int(v['step'])==expected_steps for v in opt['state'].values())
                for group in opt['param_groups']:
                    mult=row['config']['d_lr_mult'] if name=='opt_d' else row['config']['prior_lr_mult'] if group['_comparison_prior'] else 1.
                    assert group['lr']==row['config']['lr']*mult
            grade['optimizer_budget_and_rates_verified']=True
        output['gates'].append(grade)
    return output


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--candidate',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    torch.set_num_threads(1)
    result=regrade(args.candidate)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'candidate':result['candidate'],'integrity':'PASS','gates':[(r['gate'],r['status']) for r in result['gates']]}))
