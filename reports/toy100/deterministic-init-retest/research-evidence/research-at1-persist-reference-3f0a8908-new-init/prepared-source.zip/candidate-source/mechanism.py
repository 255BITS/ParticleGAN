"""AT1: persistence-tracked critic reference with a reversible rate.

K3P penalty shape is unchanged when the mix is at an endpoint:
  s == 1: a_r1r2 (R1 on reals + one-sided fake cap)
  s == 0: b_cap on reals and fakes plus prox
  prox = mean ||grad_x D - grad_x Dbar||^2 / d
Dbar is an EMA of critic parameters. Its step size is NOT a residual chase
and NOT the learning-rate ratio:
  alpha = 0.05 during the existing 200-step guard warmup (reference catches
  the moving critic before the anchor can turn on)
  alpha = 0.001 + 0.049 * persist afterward
  persist = EMA of relu(cosine of successive raw critic gradients), decay 0.99
A large anchor residual does not increase alpha. Incoherent motion keeps the
K3P decay 0.999. Directionally persistent motion speeds the reference up to a
20-step memory, which is not a one-step glue.

The mix does not read the applied learning rate or any training horizon:
  s = 1 during warmup, or while persist >= 0.25, or while the mean Adam
      innovation (grad RMS / bias-corrected second-moment RMS) stays >= 1.5
  s = 0 otherwise (quiet, incoherent critic: capped gradients + prox)
A guard-level spike (any tensor innovation >= GUARD_C) reopens the rate even
when s stays 0. That is the decoupling: the critic constraint is not the LR clock.

Rates, also horizon-blind, latched one step ahead for the frozen rate check:
  openness rises to 1 immediately on warmup, learning, or a guard-level spike
  openness otherwise decays by 0.995 per critic step (memory, not a horizon)
  network multiplier = 0.01 + 0.99 * openness
  prior multiplier   = 0.05 + 0.95 * openness
Peak multipliers are the K3P initial rates. Quiet multipliers are the K3P floors.
Input noise is the constant 0. Output noise is the constant configured peak.
The critic guard is unchanged (5x Adam RMS after 200 steps).
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar
import signal_policy

GUARD_C = 5.0
GUARD_MIN_STEPS = 200
PERSIST_DECAY = 0.99
PERSIST_ON = 0.25
INNOVATION_LEARNING = 1.5
OPEN_DECAY = 0.995
ALPHA_FAST = 0.05
ALPHA_SLOW = 0.001
NET_FLOOR = signal_policy.NET_FLOOR
PRIOR_FLOOR = signal_policy.PRIOR_FLOOR

_original_penalty = GradientPenalty.penalty
receipt = {
    'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'rule': 'at1_persist_reference',
    'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
    'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
    'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [],
    'anchor_started_call': None, 'prox_trace': [], 'signal_trace': [],
    'persist_decay': PERSIST_DECAY, 'persist_on': PERSIST_ON,
    'innovation_learning': INNOVATION_LEARNING, 'open_decay': OPEN_DECAY,
    'alpha_fast': ALPHA_FAST, 'alpha_slow': ALPHA_SLOW,
    'network_floor': NET_FLOOR, 'prior_floor': PRIOR_FLOOR,
    'input_noise': signal_policy.INPUT_NOISE, 'output_noise': 'constant_config_peak',
    'schedule': 'signal_openness_and_persistence_ignore_horizon',
}
_state = {
    'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None,
    'depth': 0, 'clips': [], 'critic_ref': None, 'mix_s': 1.0, 'alpha': ALPHA_FAST,
    'persist': 0.0, 'openness': 1.0, 'grad_prev': None, 'seen': 0,
    'innovation_mean': 0.0, 'innovation_max': 0.0, 'coherence': None,
}


def handover_weight():
    """Critic mix from persistence and innovation. Does not read an LR ratio."""
    return float(_state['mix_s'])


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _publish_rates():
    openness = float(_state['openness'])
    signal_policy.state['next_network'] = NET_FLOOR + (1.0 - NET_FLOOR) * openness
    signal_policy.state['next_prior'] = PRIOR_FLOOR + (1.0 - PRIOR_FLOOR) * openness


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
            receipt['extra_critic_forwards'] += 1
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (
                F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _update_signal(opt):
    grads = [p.grad.detach() for group in opt.param_groups for p in group['params'] if p.grad is not None]
    if not grads:
        return
    current = torch.cat([g.flatten() for g in grads])
    previous = _state['grad_prev']
    if previous is None or previous.numel() != current.numel():
        coherence = None
    else:
        coherence = float(F.cosine_similarity(current, previous, dim=0, eps=1e-30))
    _state['grad_prev'] = current
    _state['coherence'] = coherence
    positive = 0.0 if coherence is None else max(0.0, coherence)
    _state['persist'] = PERSIST_DECAY * _state['persist'] + (1.0 - PERSIST_DECAY) * positive
    ratios = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            if isinstance(t, torch.Tensor):
                if int(t.item()) <= 0:
                    continue
                vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            else:
                if t <= 0:
                    continue
                vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratios.append(p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt())
    if ratios:
        stacked = torch.stack(ratios)
        _state['innovation_max'] = float(stacked.max())
        _state['innovation_mean'] = float(stacked.mean())
    else:
        _state['innovation_max'] = 0.0
        _state['innovation_mean'] = 0.0
    _state['seen'] += 1
    warmup = _state['seen'] < GUARD_MIN_STEPS
    learning = _state['persist'] >= PERSIST_ON or _state['innovation_mean'] >= INNOVATION_LEARNING
    surprised = _state['innovation_max'] >= GUARD_C
    _state['mix_s'] = 1.0 if (warmup or learning) else 0.0
    _state['alpha'] = ALPHA_FAST if warmup else (ALPHA_SLOW + (ALPHA_FAST - ALPHA_SLOW) * _state['persist'])
    target = 1.0 if (warmup or learning or surprised) else 0.0
    if target >= _state['openness']:
        _state['openness'] = target
    else:
        _state['openness'] = OPEN_DECAY * _state['openness'] + (1.0 - OPEN_DECAY) * target
    _publish_rates()
    if _state['seen'] == 1 or _state['seen'] % 50 == 0:
        row = dict(
            seen=_state['seen'], persist=round(_state['persist'], 6),
            coherence=None if coherence is None else round(coherence, 6),
            innovation_mean=round(_state['innovation_mean'], 6),
            innovation_max=round(_state['innovation_max'], 6),
            openness=round(_state['openness'], 6), s=_state['mix_s'],
            alpha=round(_state['alpha'], 6),
            network_m=round(signal_policy.state['next_network'], 6),
            prior_m=round(signal_policy.state['next_prior'], 6),
        )
        receipt['signal_trace'].append(row)
        print(json.dumps(dict(signal=row)), flush=True)


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    _update_signal(opt)
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        params = _critic_params()
        with torch.no_grad():
            if _state['ema'] is None:
                _state['ema'] = [p.detach().clone() for p in params]
                receipt['anchor_started_call'] = receipt.get('anchor_started_call')
            else:
                alpha = float(_state['alpha'])
                keep = 1.0 - alpha
                for e, p in zip(_state['ema'], params):
                    e.mul_(keep).add_(p.detach(), alpha=alpha)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_persist'] = _state['persist']
    receipt['final_openness'] = _state['openness']
    receipt['final_alpha'] = _state['alpha']
    receipt['final_innovation_mean'] = _state['innovation_mean']
    receipt['final_innovation_max'] = _state['innovation_max']
    receipt['final_coherence'] = _state['coherence']
    receipt['final_network_m'] = signal_policy.state['next_network']
    receipt['final_prior_m'] = signal_policy.state['next_prior']
    receipt['ignored_horizon_calls'] = signal_policy.state['ignored_horizon_calls']
    receipt['noise_calls'] = signal_policy.state['noise_calls']
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
_publish_rates()
