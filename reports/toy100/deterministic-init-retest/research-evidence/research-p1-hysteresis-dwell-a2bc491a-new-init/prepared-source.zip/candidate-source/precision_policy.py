"""Horizon-blind rate and noise adapters for p1_hysteresis_dwell.

The rate is a latched function of controller openness. Step and horizon
arguments are ignored except as a memo key so a second lookup in the same
update sees the multiplier that was actually applied. Noise amplitudes are
constants: input 0, output equal to the declared peak.
"""
import sys
from particlegan import recipes
from benchmarks.toy100 import models, schedule

DWELL = 0.10  # A3's proven holding fraction of the K3P initial rate
state = {
    'openness': 1.0,  # 1 = K3P initial rates; 0 = dwell fraction
    's': 1.0,         # critic mix: 1 pure R1 until precision locks, then 0
    'precision_locked': False,
    'released': True,
    'last_multiplier': (1.0, 1.0),
    'cache': {},
    'multiplier_trace': [],
}


def multipliers(*args, **kwargs):
    key = args[0] if args and type(args[0]) is int else None
    if key is not None and key in state['cache']:
        return state['cache'][key]
    openness = state['openness']
    multiplier = DWELL + (1.0 - DWELL) * openness
    result = (float(multiplier), float(multiplier))
    state['last_multiplier'] = result
    if key is not None:
        state['cache'][key] = result
        if key % 50 == 0:
            state['multiplier_trace'].append([key, result[0], round(openness, 6), state['s'], state['precision_locked'], state['released']])
    return result


def no_input_noise(*args, **kwargs):
    return 0.0


def constant_output_noise(peak, *args, **kwargs):
    return float(peak)


replacements = [
    (schedule.policy_multipliers, multipliers),
    (models.linear_input_noise, no_input_noise),
    (models.linear_output_noise, constant_output_noise),
]
schedule.policy_multipliers = multipliers
models.linear_input_noise = no_input_noise
models.linear_output_noise = constant_output_noise
# learning_rate_scale stays available but is not consulted: multipliers replaces policy_multipliers.
for module in list(sys.modules.values()):
    if module is None or not getattr(module, '__name__', '').startswith(('particlegan', 'benchmarks')):
        continue
    for name, value in list(vars(module).items()):
        for original, replacement in replacements:
            if value is original:
                setattr(module, name, replacement)
# Silence an unused import if recipes is only a patch anchor.
_ = recipes
