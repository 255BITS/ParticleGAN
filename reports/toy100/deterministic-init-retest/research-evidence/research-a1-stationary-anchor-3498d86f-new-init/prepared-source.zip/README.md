# RESEARCH-a1_stationary_anchor-new-init source preparation

Original candidate `research:continuous-round-1/adaptive_anchor/a1_stationary_anchor` on the declared common frozen tiny host. Exact source/config preserved; new standalone public initialization only. This is research-host evidence and retains its original schedule eligibility. No old pass or new quality is inherited.

The wrapper differs from the reviewed KA2 wrapper only in its source-directory and candidate label. It requires a matching independent CPU constructor/source proof before execution and checks every actual CUDA initial tensor against that proof before optimizer construction. This bundle is prepared, not authorized or executed. Runtime provenance: `EXPLICIT_RETAINED_RUNTIME_RECEIPT`.
