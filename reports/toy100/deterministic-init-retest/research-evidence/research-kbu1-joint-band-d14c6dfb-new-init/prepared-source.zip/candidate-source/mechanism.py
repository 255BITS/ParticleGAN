"""kbu1 joint band: one shared G/D/prior mobility, mixing not on the LR clock.

Measured failures this responds to:
- K3P keeps the early penalty until critic_lr/max_lr falls, then the 1% network
  floor and the EMA anchor are both stuck to that clock. Recovery is 28/81.
- pnb1's per-role gains and pnb2's cosine decay fire during acquisition and
  never hold 8 modes. pnb3's constant full rate loses modes near update 2000.
- ruc1 collapses off the initial gradient peak. ruc2 leaks from step 0 and
  locks 6 modes. ruc3's moment shock resets a boost to 1 and that boost sticks,
  so recovery is 0/81. The 800-step quiet prefix is a fixed timer.

Rule, one shared multiplier m applied to the host rates of G, D, and the prior
(recipe prior/network ratio stays 2). m is not a per-role controller.
- m = 1 until the critic's own relative displacement ||Δθ||/||θ|| has been
  below 0.01 for 100 consecutive critic steps. That is an optimizer signal,
  not a mode count, score, horizon, or shift time.
- After that, m moves by 0.008 of the gap toward
  target = 0.10 + 0.25 * clamp((r - 1) / 1, 0, 1),
  where r is the critic gradient RMS over sqrt(mean bias-corrected Adam v).
  While m is still above 0.35 it only decreases. Inside [0.10, 0.35] it is
  reversible and cannot return to 1. A shock cannot sticky-reset the rate.
- Critic mixing uses the K3P map on m, not on last/max learning rate:
  s = max(0, min(1, 2m) - 2*0.01) / (1 - 2*0.01).
  s = 1 for m >= 0.5 (early penalty only). At the calm end m = 0.10, s ≈ 0.184
  so the EMA anchor (decay 0.999) is on. A bounded reopen loosens it.

Host floors passed to the driver are 1 and 1, so the cosine LR schedule is the
identity at every horizon. Noise still uses the driver's 1200-update horizon.
That noise schedule is an inherited intermediate ablation, not part of this
update rule. Guard (200 steps, ratio 5), particle latent damping, and direct
response are the pinned K3P hooks. No budget, evaluation, target, or shift time
is read.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
MOMENT_BETA2 = 0.999
BAND_LO = 0.10
BAND_HI = 0.35
SETTLE_REL = 0.01
SETTLE_PATIENCE = 100
ALPHA = 0.008
SHOCK_SPAN = 1.0
_original_penalty = GradientPenalty.penalty
receipt = {
    'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
    'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0,
    'blend_calls': 0, 'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None,
    'critic_steps': 0, 'critic_parameters': None, 'lr_max': None, 'lr_last': None,
    's_trace': [], 'rule': 'kbu1_joint_band', 'anchor_decay': ANCHOR_DECAY,
    'anchor_started_call': None, 'prox_trace': [],
    'mixing_signal': 'shared_mobility_m_not_learning_rate', 'lr_clock_decoupled': True,
    'band': [BAND_LO, BAND_HI], 'settle_rel': SETTLE_REL, 'settle_patience': SETTLE_PATIENCE,
    'alpha': ALPHA, 'shock_span': SHOCK_SPAN, 'moment_beta2': MOMENT_BETA2,
    'joint_roles': ['g', 'd', 'prior'], 'rate_trace': [], 'rho_summary': {},
    'lr_overwrite_after_scale': 0, 'settled_critic_step': None,
    'noise_note': 'driver noise_horizon=1200 remains; not an input to m or s',
}
_state = {
    'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None,
    'depth': 0, 'clips': [], 'critic_ref': None, 'm': 1.0, 'settled': False,
    'quiet_run': 0, 'prev_rel': None, 'tick': 0, 'applied_for': None,
    'restore': {}, 'last_ratio': None, 'last_target': None,
}


def handover_weight():
    r = _state['m']
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _is_critic(opt):
    if _state['critic'] is None:
        return bool(_state['pending'])
    return id(opt) == _state['critic']


def _moment_ratio(opt):
    square = None
    count = 0
    second = None
    second_count = 0
    step = None
    moments = True
    for group in opt.param_groups:
        for parameter in group['params']:
            if parameter.grad is None:
                continue
            value = parameter.grad.detach().square().sum()
            square = value if square is None else square + value
            count += parameter.grad.numel()
            moment = opt.state.get(parameter)
            if not moment or 'exp_avg_sq' not in moment or 'step' not in moment:
                moments = False
                continue
            current = moment['step']
            step = current if step is None else step
            value = moment['exp_avg_sq'].sum()
            second = value if second is None else second + value
            second_count += moment['exp_avg_sq'].numel()
    if count == 0 or not moments or second_count != count or step is None:
        return None
    step_value = float(step.detach()) if torch.is_tensor(step) else float(step)
    if step_value < 1.0:
        return None
    grad_rms = (square / count).sqrt()
    corrected = (second / second_count) / (1.0 - MOMENT_BETA2 ** step_value)
    return float((grad_rms / corrected.clamp_min(1e-30).sqrt()).clamp(max=1e6))


def _update_m(opt):
    ratio = _moment_ratio(opt)
    _state['last_ratio'] = ratio
    if not _state['settled']:
        rel = _state['prev_rel']
        if rel is not None and rel < SETTLE_REL:
            _state['quiet_run'] += 1
            if _state['quiet_run'] >= SETTLE_PATIENCE:
                _state['settled'] = True
                receipt['settled_critic_step'] = receipt['critic_steps'] + 1
        else:
            _state['quiet_run'] = 0
        _state['m'] = 1.0
        _state['last_target'] = 1.0
        return
    excess = 0.0 if ratio is None else max(0.0, min(1.0, (ratio - 1.0) / SHOCK_SPAN))
    target = BAND_LO + (BAND_HI - BAND_LO) * excess
    previous = _state['m']
    updated = previous + ALPHA * (target - previous)
    if previous > BAND_HI and updated > previous:
        updated = previous
    if updated < BAND_LO:
        updated = BAND_LO
    if previous <= BAND_HI:
        updated = min(BAND_HI, updated)
    _state['m'] = float(updated)
    _state['last_target'] = float(target)


def _apply_scale(opt):
    key = (id(opt), _state['tick'])
    if _state['applied_for'] == key:
        return
    _state['applied_for'] = key
    if _is_critic(opt):
        _update_m(opt)
    m = _state['m']
    restore = []
    rows = []
    critic = _is_critic(opt)
    for group in opt.param_groups:
        scheduled = float(group['lr'])
        applied = scheduled * m
        group['lr'] = applied
        before = [p.detach().clone() for p in group['params']]
        role = 'prior' if group.get('_comparison_prior') else ('d' if critic else 'g')
        row = [role, round(m, 6), None if _state['last_ratio'] is None else round(_state['last_ratio'], 6),
               round(_state['last_target'] or m, 6), round(m, 6), scheduled, applied, None,
               int(_state['settled']), round(handover_weight(), 6)]
        rows.append((row, before, list(group['params']), group, scheduled, applied))
        summary = receipt['rho_summary'].setdefault(role, {'min': m, 'max': m, 'last': m, 'calls': 0})
        summary['min'] = min(summary['min'], m)
        summary['max'] = max(summary['max'], m)
        summary['last'] = m
        summary['calls'] += 1
        if critic and summary['calls'] % 100 == 0:
            print(json.dumps(dict(kbu=dict(
                role=role, call=summary['calls'], m=m, settled=bool(_state['settled']),
                quiet=_state['quiet_run'], r_moment=_state['last_ratio'],
                target=_state['last_target'], scheduled_lr=scheduled, applied_lr=applied,
                s=handover_weight(), prev_rel=_state['prev_rel']))), flush=True)
    _state['restore'][id(opt)] = rows


def _scale_pre(opt, args, kwargs):
    _state['tick'] += 1
    hooks = opt._optimizer_step_pre_hooks
    for hid, fn in list(hooks.items()):
        if getattr(fn, '_kbu_wrapped', False):
            continue
        def wrapped(optimizer, wargs, wkwargs, inner=fn):
            inner(optimizer, wargs, wkwargs)
            _apply_scale(optimizer)
        wrapped._kbu_wrapped = True
        hooks[hid] = wrapped
    if not any(getattr(fn, '_kbu_wrapped', False) for fn in hooks.values()):
        _apply_scale(opt)


def _scale_post(opt, args, kwargs):
    rows = _state['restore'].pop(id(opt), None)
    if not rows:
        return
    critic = _is_critic(opt)
    rel_for_settle = None
    for row, before, parameters, group, scheduled, applied in rows:
        actual = float(group['lr'])
        if abs(actual - applied) > 1e-8 * max(1.0, abs(applied)):
            receipt['lr_overwrite_after_scale'] += 1
        group['lr'] = scheduled
        delta = None
        base = None
        count = 0
        for current, previous in zip(parameters, before):
            difference = (current.detach() - previous).square().sum()
            magnitude = previous.square().sum()
            delta = difference if delta is None else delta + difference
            base = magnitude if base is None else base + magnitude
            count += current.numel()
        relative = None
        if count:
            relative = float((delta / count).sqrt() / (base / count).clamp_min(1e-30).sqrt())
            row[7] = round(relative, 8)
            if critic and row[0] == 'd':
                rel_for_settle = relative
        calls = receipt['rho_summary'][row[0]]['calls']
        if calls <= 5 or calls % 20 == 0:
            receipt['rate_trace'].append(row)
    if rel_for_settle is not None:
        _state['prev_rel'] = rel_for_settle


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
        receipt['extra_critic_forwards'] += 1
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (
                F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(_state['m'], 6), bool(_state['settled'])])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_m'] = _state['m']
    receipt['settled'] = bool(_state['settled'])
    receipt['host_lr_note'] = (
        'lr_last is the restored host rate after the joint multiplier; '
        'applied rates are rate_trace column 6. Column 5 is the host scheduled rate.'
    )
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_scale_pre)
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_scale_post)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
