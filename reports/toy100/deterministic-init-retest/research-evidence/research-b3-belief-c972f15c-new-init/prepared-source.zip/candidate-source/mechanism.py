"""B3 (opt_belief lane, proposal 3): belief GATE on an Adam-stepped critic.

Lineage: B2 (cands/b2/mechanism.py) — same belief-surprise gate SHAPE
(median-ratio-vs-baseline + hysteretic band), s=0.5, EMA-iff-release-off,
guarded re-seed (60), guard C=5/200 recomputed for belief-scaled grads,
config/latent/response byte-identical.

One coherent change vs B2: the critic steps with PLAIN Adam config betas
(0.0, 0.999) — no optimizer change at all. The hooks only OBSERVE: maintain
a shadow belief buffer (m_belief with beta 0.9, s with beta 0.999, updated
from the post-step grad + Adam m) and compute the belief-surprise stream
from it. This isolates the lane thesis (belief is a denoised surprise GATE)
from the optimizer confound that sank B1/B2 (beta1 0.9 + belief step scale
broke acquisition: 0-1 modes / 4 modes vs R2's 8).

Concretely per critic step (post-hook, read-only of params):
  g = current grad (pre-Adam-update grad, same as R2's signal timing)
  m_b <- 0.9*m_b + 0.1*g   (shadow, own buffer keyed per param)
  r = g - m_b; s <- 0.999*s + 0.001*r^2
  bsur_n = RMS(g)/sqrt(mean(s/(1-0.999^t))+eps), median over tensors
Gate/band/EMA/guard identical to B2 except the guard CLIP still applies
(K3P guard C=5/200 semantics on the belief ratio — declared guard change,
same as B1/B2).

No total-steps/eval/shift-time/target-center reads. Extra compute: shadow
belief buffers only (no extra forwards beyond R2/K3P's EMA anchor).
"""

import atexit
import json
import os
import sys
from pathlib import Path

import torch
import torch.nn.functional as F
from torch.optim.optimizer import (
    register_optimizer_step_post_hook,
    register_optimizer_step_pre_hook,
)
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
S_FIX = 0.5
WARMUP_CALLS = 800
SHORT_WINDOW = 24
GATE_MIN_SAMPLES = 25
REL_HI = 3.0
REL_LO = 1.75
RESEED_STREAK = 60
BASE_WINDOW = 24
HIST_CAP = 400
BELIEF_BETA1 = 0.9
BELIEF_BETA2 = 0.999
BELIEF_EPS = 1e-8
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'rule': 'b3-beliefgate-adamstep',
           'floor': FLOOR, 'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS,
           'pure_a_calls': 0, 'blend_calls': 0, 'pure_b_calls': 0,
           'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [],
           'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None, 'prox_trace': [],
           's_fix': S_FIX, 'lr_decoupled': True, 'w_trace': [], 'bsur_trace': [],
           'bsur_base': None, 'ema_updates': 0, 'ema_skips': 0, 'ema_reseeds': 0,
           'optimizer': 'adabelief-critic-only', 'critic_betas': (BELIEF_BETA1, BELIEF_BETA2),
           'belief_eps': BELIEF_EPS, 'belief_disp_trace': [], 'guard_note':
           'clip test recomputed on belief ratio RMS(g)/sqrt(mean(s_hat_prev)+eps)'}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None,
          'depth': 0, 'clips': [], 'critic_ref': None, 'last_bsur': None,
          'bsur_hist': [], 'bsur_base': None, 'w': 1.0, 'low_streak': 0,
          'stash': {}, 'saved_v': {}, 'saved_lr': {}, 'param_before': {}, 'saved_m': {}}


def handover_weight():
    return S_FIX


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, swapped via .data (restored)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def _median(xs):
    s = sorted(xs)
    return s[len(s) // 2]


def _bsur_gate():
    """Hysteretic belief-surprise band gate. Returns (W, ratio_or_None)."""
    hist = _state['bsur_hist']
    if len(hist) < GATE_MIN_SAMPLES:
        return 1.0, None
    if _state['bsur_base'] is None and len(hist) >= BASE_WINDOW:
        _state['bsur_base'] = _median(hist[:BASE_WINDOW])
        receipt['bsur_base'] = _state['bsur_base']
    base = _state['bsur_base']
    if not base or base <= 0.0:
        return 1.0, None
    ratio = _median(hist[-SHORT_WINDOW:]) / base
    w = _state['w']
    if w >= 1.0 and ratio > REL_HI:
        w = 0.0
    elif w <= 0.0 and ratio < REL_LO:
        w = 1.0
    _state['w'] = w
    return w, ratio


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = S_FIX
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if receipt['calls'] + 1 <= WARMUP_CALLS:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
        w = 1.0
        _state['w'] = w
        if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
            receipt['s_trace'].append([receipt['calls'], round(s, 6)])
        stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s, 'w': w} if collect_stats else {}
        return penalty, stats
    x = x_real.detach().clone().requires_grad_(True)
    g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
    sq_r = g.pow(2).flatten(1).sum(dim=1)
    n_r = torch.sqrt(sq_r + 1e-12)
    n_f = self._grad_norm(D, x_fake, squared=False)
    prox = anchored_gradient_gap(D, x_real, g, dimension)
    prox_val = float(prox.detach())
    if _state['last_bsur'] is not None:
        _state['bsur_hist'].append(float(_state['last_bsur']))
        if len(_state['bsur_hist']) > HIST_CAP:
            del _state['bsur_hist'][:len(_state['bsur_hist']) - HIST_CAP]
    w, ratio = _bsur_gate()
    a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
    b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + w * prox
    penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
    receipt['blend_calls'] += 1
    if w < 0.5 and ratio is not None and ratio > REL_HI:
        _state['low_streak'] += 1
    else:
        _state['low_streak'] = 0
    if receipt['first_blend_call'] is None:
        receipt['first_blend_call'] = receipt['calls']
    if receipt['calls'] % 50 == 0:
        receipt['prox_trace'].append([receipt['calls'], prox_val])
        receipt['w_trace'].append([receipt['calls'], round(w, 6)])
        receipt['bsur_trace'].append([receipt['calls'], float(_state['bsur_hist'][-1]) if _state['bsur_hist'] else None,
                                      round(ratio, 4) if ratio is not None else None])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s, 'w': w} if collect_stats else {}
    return penalty, stats


def _identify_critic(opt):
    _state['critic'] = id(opt)
    _state['critic_ref'] = opt
    receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
    # B3: NO beta override — critic stays Adam config betas (0.0, 0.999).
    # Shadow belief buffers (own keys, never touch Adam state).
    receipt['critic_betas_applied'] = False
    receipt['shadow_belief'] = True
    _state['depth'] = 1


def _belief_shat_prev(opt, p):
    """Bias-corrected belief scale from the previous step (pre-update guard)."""
    st = opt.state.get(p)
    if not st or 'belief_avg' not in st:
        return None, 0
    t_prev = int(st['step'])
    s = st['belief_avg']
    bc = 1.0 - BELIEF_BETA2 ** t_prev if t_prev >= 1 else 1.0
    return s / bc, t_prev


_HOOK_DEBUG = os.environ.get('B1_HOOK_DEBUG') == '1'


def _hook_debug(msg):
    if _HOOK_DEBUG:
        sys.stderr.write('[b1] %s depth=%s steps=%s\n' % (msg, _state['depth'], receipt['critic_steps']))
        sys.stderr.flush()


def _guard(opt, args, kwargs):
    """Pre-hook: stash grads, belief-ratio guard clip, neutralize Adam (lr=0).

    NOTE (torch 2.13): global optimizer hooks fire around EVERY level of the
    drivers' nested Adam.step patches (shift.py wrapper outside,
    continuous_probe recorder inside), because each patch level calls the
    next through the same profile_hook_step wrapper. Trace order per
    opt.step() is: pre, shift-enter, probe-enter, probe-exit, shift-exit,
    post — exactly ONE pre and ONE post per step, and the mobility snapshot
    inside the body legitimately reads lr=0 while the stash is pending.
    The post-hook restore + belief_disp_trace are the audit. The FIRST
    opt.step() only identifies the critic (no pre-hook stash yet).
    """
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    if _state['depth'] != 0:
        receipt['reentrant_pres'] = receipt.get('reentrant_pres', 0) + 1
        return
    _state['depth'] = 1
    # B3: observe-only pre-hook. Stash grads + guard-clip test on the shadow
    # belief ratio. NO lr neutralization, NO beta override — Adam steps pure.
    flags = []
    stash = {}
    for group in opt.param_groups:
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            g = p.grad.detach().clone()
            key = id(p)
            if key not in _state.setdefault('shadow', {}):
                _state['shadow'][key] = {'m': torch.zeros_like(p), 's': torch.zeros_like(p)}
            sh = _state['shadow'][key]
            t_prev = int(st['step'])
            bc = 1.0 - BELIEF_BETA2 ** t_prev if t_prev >= 1 else 1.0
            shat_prev = sh['s'] / bc
            ratio = g.square().mean().sqrt() / (shat_prev.mean().clamp_min(0.0) + BELIEF_EPS).sqrt()
            clip = (t_prev >= GUARD_MIN_STEPS) & bool(ratio > GUARD_C)
            if clip:
                g.mul_(GUARD_C / float(ratio))
                p.grad.copy_(g)
            stash[key] = g
            flags.append(clip)
    _state['stash'].update(stash)
    if flags:
        _state['clips'].append(sum(1 for f in flags if f))


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _identify_critic(opt)
    if id(opt) != _state['critic']:
        return
    if _state['depth'] != 1:
        receipt['reentrant_posts'] = receipt.get('reentrant_posts', 0) + 1
        return
    _state['depth'] = 0
    if True:
        surs = []
        # B3: Adam already stepped (pure config Adam). Update shadow belief
        # from stashed g and compute the belief-surprise stream. Read-only.
        with torch.no_grad():
            for group in opt.param_groups:
                lr = float(group['lr'])
                for p in group['params']:
                    st = opt.state.get(p)
                    key = id(p)
                    if p.grad is None or not st or key not in _state['stash']:
                        continue
                    g = _state['stash'].pop(key)
                    t = int(st['step'])
                    sh = _state['shadow'][key]
                    sh['m'].mul_(BELIEF_BETA1).add_(g, alpha=1.0 - BELIEF_BETA1)
                    r_ = g - sh['m']
                    sh['s'].mul_(BELIEF_BETA2).addcmul_(r_, r_, value=1.0 - BELIEF_BETA2)
                    shat = sh['s'] / (1.0 - BELIEF_BETA2 ** t)
                    sur = g.square().mean().sqrt() / (shat.mean().clamp_min(0.0) + BELIEF_EPS).sqrt()
                    surs.append(float(sur.detach()))
        _state['stash'].clear()
        if surs:
            _state['last_bsur'] = _median(surs)
        if _state['low_streak'] >= RESEED_STREAK and _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.copy_(p.detach())
            receipt['ema_reseeds'] += 1
            _state['low_streak'] = 0
        if _state['ema'] is not None and _state['w'] >= 0.5:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
            receipt['ema_updates'] += 1
        elif _state['ema'] is not None:
            receipt['ema_skips'] += 1
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_w'] = _state['w']
    receipt['final_bsur_base'] = _state['bsur_base']
    receipt['bsur_hist_len'] = len(_state['bsur_hist'])
    if _state['clips']:
        per_step = torch.tensor(_state['clips'])
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        if isinstance(steps, int):
            steps = [steps]
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
