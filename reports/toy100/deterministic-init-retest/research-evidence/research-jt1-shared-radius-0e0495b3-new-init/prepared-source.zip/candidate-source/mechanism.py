"""jt1 shared trust radius: project realized Adam displacement, do not schedule LR.

Measured failures this responds to:
- K3P recovery is 28/81. Mixing follows critic_lr/max_lr, so the 1% floor and the
  EMA anchor are one clock. The parent does not establish constant-rate learning.
- Round-1 per-role cosine controllers cut acquisition. They are not reused.
- Round-2 GD1/GD2/GD3 add a displacement extrapolation or a directional reversal
  on top of the raw step and lose 8-mode coverage. This rule does not add
  beta*(delta-previous) and does not flip the step.
- Round-2 kbu1 left the shared multiplier at 1, then the ring collapsed at
  update 1600 when critic relative displacement jumped from about 0.015 to 0.10.
  kbu2/kbu3 leaked on a displacement threshold or a moment ratio. The moment
  ratio stayed below 1 after the shift, so the band never reopened (0/81).

Rule. Host network and prior floors passed to the driver are 1, so the cosine
LR schedule is the identity at every horizon. One radius rho, in the same
relative RMS units as kbu (||delta||_2 / ||theta||_2), is shared by the critic,
the generator, and the prior. It is not a per-role controller.
- rho starts at 0.05, the critic relative displacement measured on kbu1 at
  update 100. Each parameter group is projected after Adam:
  theta <- theta_old + min(1, rho/rel) * (theta - theta_old).
  Rows whose displacement is already zero stay put. Adam moments are left as
  Adam wrote them from the raw gradient; only parameters are projected.
- rho updates once per critic step from the max attempted relative displacement
  of the critic, generator, and prior (one-step lag on the generator groups).
  ask = peak / rho, ask_ema = 0.99*ask_ema + 0.01*ask, ask_ema starts at 1.
  ask_ema > 1.5 grows rho by 1.02, ask_ema < 0.5 shrinks it by 0.98.
  rho stays inside [0.004, 0.05]. The dead zone is what keeps acquisition-scale
  steps from leaking. Growth is the reversible reopen; it does not reset to 1.
- Critic mixing reads m = rho/0.05, not last/max learning rate:
  s = max(0, min(1, 2m) - 2*0.01) / (1 - 2*0.01).
  s = 1 at the initial radius (early penalty only). At rho = 0.004, m = 0.08
  and s is about 0.143, so the 0.999 EMA anchor is on. A reopen raises s again.

Guard (200 steps, ratio 5), particle latent damping, and direct response are
the pinned K3P hooks and run unchanged. The projection is applied to the
realized step, including a prior group whose direct-response gain already
scaled that step. Noise still uses the driver's 1200-update horizon. That
schedule is an inherited intermediate ablation and is not read here.
No budget, evaluation, target center, or shift time is read.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
RHO_MAX = 0.05
RHO_MIN = 0.004
ASK_EMA = 0.99
ASK_GROW = 1.5
ASK_SHRINK = 0.5
GROW = 1.02
SHRINK = 0.98
_original_penalty = GradientPenalty.penalty
receipt = {
    'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
    'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0,
    'blend_calls': 0, 'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None,
    'critic_steps': 0, 'critic_parameters': None, 'lr_max': None, 'lr_last': None,
    's_trace': [], 'rule': 'jt1_shared_radius', 'anchor_decay': ANCHOR_DECAY,
    'anchor_started_call': None, 'prox_trace': [],
    'mixing_signal': 'shared_trust_radius_over_rho_max_not_learning_rate',
    'lr_clock_decoupled': True,
    'rho_max': RHO_MAX, 'rho_min': RHO_MIN, 'ask_ema_decay': ASK_EMA,
    'ask_grow': ASK_GROW, 'ask_shrink': ASK_SHRINK, 'grow': GROW, 'shrink': SHRINK,
    'adam_moments': 'unchanged by the projection; parameters only',
    'inactive_rows': 'uniform group scale; a zero displacement stays zero',
    'joint_roles': ['g', 'd', 'prior'], 'rate_trace': [], 'rho_summary': {},
    'clipped_groups': 0, 'unclipped_groups': 0,
    'noise_note': 'driver noise_horizon=1200 remains; not an input to rho or s',
    'budget_note': 'rho and s do not read total_steps, network_lr_horizon_cap, scores, or the shift',
}
_state = {
    'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None,
    'depth': 0, 'clips': [], 'critic_ref': None, 'rho': RHO_MAX, 'ask_ema': 1.0,
    'last_ask': None, 'role_peak': {}, 'saved': {}, 'tick': 0,
}


def handover_weight():
    mobility = _state['rho'] / RHO_MAX
    return max(0.0, min(1.0, 2.0 * mobility) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _optimizer_role(opt):
    if _state['critic'] is None:
        return 'd' if _state['pending'] else 'g'
    if id(opt) == _state['critic']:
        return 'd'
    return 'g'


def _group_role(group, optimizer_role):
    if group.get('_comparison_prior'):
        return 'prior'
    return optimizer_role


def _group_relative(parameters, before):
    delta = None
    base = None
    count = 0
    for current, previous in zip(parameters, before):
        difference = (current.detach() - previous).square().sum()
        magnitude = previous.detach().square().sum()
        delta = difference if delta is None else delta + difference
        base = magnitude if base is None else base + magnitude
        count += current.numel()
    if count == 0:
        return 0.0
    return float((delta / count).sqrt() / (base / count).clamp_min(1e-30).sqrt())


def _update_radius():
    peaks = [value for value in _state['role_peak'].values() if value is not None and value > 0.0]
    if not peaks:
        return
    ask = max(peaks) / _state['rho']
    ema = ASK_EMA * _state['ask_ema'] + (1.0 - ASK_EMA) * ask
    _state['ask_ema'] = ema
    _state['last_ask'] = ask
    if ema > ASK_GROW:
        _state['rho'] = min(RHO_MAX, _state['rho'] * GROW)
    elif ema < ASK_SHRINK:
        _state['rho'] = max(RHO_MIN, _state['rho'] * SHRINK)


def _snapshot(opt, args, kwargs):
    _state['tick'] += 1
    bundles = []
    for group in opt.param_groups:
        bundles.append((group, [p.detach().clone() for p in group['params']], float(group['lr'])))
    _state['saved'][id(opt)] = bundles


def _project(opt, args, kwargs):
    bundles = _state['saved'].pop(id(opt), None)
    if not bundles:
        return
    optimizer_role = _optimizer_role(opt)
    rho_used = _state['rho']
    group_peaks = {}
    for group, before, seen_lr in bundles:
        role = _group_role(group, optimizer_role)
        rel = _group_relative(group['params'], before)
        # One scale for the group. Zero-displacement rows are unchanged by it.
        scale = 1.0 if rel <= rho_used or rel < 1e-12 else rho_used / rel
        if scale < 1.0:
            receipt['clipped_groups'] += 1
            with torch.no_grad():
                for current, previous in zip(group['params'], before):
                    current.data.mul_(scale).add_(previous, alpha=1.0 - scale)
            realized_rel = _group_relative(group['params'], before)
        else:
            receipt['unclipped_groups'] += 1
            realized_rel = rel
        group_peaks[role] = max(group_peaks.get(role, 0.0), rel)
        summary = receipt['rho_summary'].setdefault(role, {
            'min_scale': scale, 'max_scale': scale, 'last_scale': scale,
            'min_rho': rho_used, 'max_rho': rho_used, 'last_rho': rho_used,
            'max_attempted_rel': rel, 'last_attempted_rel': rel, 'calls': 0,
        })
        summary['min_scale'] = min(summary['min_scale'], scale)
        summary['max_scale'] = max(summary['max_scale'], scale)
        summary['last_scale'] = scale
        summary['min_rho'] = min(summary['min_rho'], rho_used)
        summary['max_rho'] = max(summary['max_rho'], rho_used)
        summary['last_rho'] = rho_used
        summary['max_attempted_rel'] = max(summary['max_attempted_rel'], rel)
        summary['last_attempted_rel'] = rel
        summary['calls'] += 1
        if summary['calls'] <= 5 or summary['calls'] % 20 == 0:
            receipt['rate_trace'].append([
                role, summary['calls'], round(rho_used, 6), round(rel, 8), round(realized_rel, 8),
                round(scale, 6), round(_state['ask_ema'], 6),
                None if _state['last_ask'] is None else round(_state['last_ask'], 6),
                round(handover_weight(), 6), seen_lr, round(_state['rho'], 6),
            ])
        if role == 'd' and (summary['calls'] <= 3 or summary['calls'] % 100 == 0):
            print(json.dumps(dict(jt1=dict(
                call=summary['calls'], rho=rho_used, attempted_rel=rel, realized_rel=realized_rel,
                scale=scale, ask_ema=_state['ask_ema'], ask=_state['last_ask'],
                s=handover_weight(), seen_lr=seen_lr, role_peak=dict(_state['role_peak']),
            ))), flush=True)
    for role, peak in group_peaks.items():
        _state['role_peak'][role] = peak
    if optimizer_role == 'd':
        _update_radius()


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
        receipt['extra_critic_forwards'] += 1
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (
                F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(_state['rho'], 6), round(_state['ask_ema'], 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_rho'] = _state['rho']
    receipt['final_ask_ema'] = _state['ask_ema']
    receipt['final_role_peak'] = _state['role_peak']
    receipt['host_lr_note'] = (
        'lr_last is the critic param-group lr observed after the step. '
        'With host floors 1 this is the constant recipe rate, not a trust scale. '
        'rate_trace columns: role, call, rho_used, attempted_rel, realized_rel, scale, '
        'ask_ema, ask, s, group_lr_seen_at_step, rho_after_update.'
    )
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_snapshot)
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_project)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
