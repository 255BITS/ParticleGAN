"""Materialize reviewed conflict shapes; leave every unknown hunk unresolved.

These are source-only merge compositions, not a candidate algorithm adapter.
The emitted manifest binds all three complete input files and output bytes.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import textwrap

INIT_CHECK = '''        if self.initialization not in (None, "batch_feature_zero"):
            raise ValueError("initialization must be 'batch_feature_zero' or None")
'''
DOC_OLD = '''    the caller's modules are never modified. ``sample`` includes the output
    noise.
'''
DOC_NEW = '''    fresh network weights follow ``recipe.initialization``. ``sample`` includes
    the output noise.
'''
BLOCK = re.compile(r'^<<<<<<< .*?\n(.*?)^\|\|\|\|\|\|\| .*?\n(.*?)^=======\n(.*?)^>>>>>>> .*?\n', re.M | re.S)


def resolve(candidate, base, upstream):
    if not base and upstream == INIT_CHECK:
        tree = ast.parse(textwrap.dedent(candidate))
        if any(isinstance(n, ast.Attribute) and n.attr == 'initialization' for n in ast.walk(tree)):
            raise ValueError('candidate initialization-field behavior needs separate review')
        if not all(isinstance(n, (ast.If, ast.For)) for n in tree.body):
            raise ValueError('unreviewed validation insertion shape')
        return candidate + upstream, 'preserve_candidate_validation_then_exact_initializer_validation'
    if base == DOC_OLD and upstream == DOC_NEW and candidate.startswith(DOC_OLD + '\n    ``serial_backward=True``'):
        return upstream + candidate[len(base):], 'replace_obsolete_initializer_doc_retain_serial_contract'
    if base == '        return ParticlePrior(**options)\n' and upstream == '        return initialize(ParticlePrior(**options))\n':
        body = ast.parse(textwrap.dedent(candidate)).body
        if len(body) != 1 or not isinstance(body[0], ast.Return) or not isinstance(body[0].value, ast.Call) or not isinstance(body[0].value.func, ast.Name) or body[0].value.func.id != 'ParticlePrior':
            raise ValueError('unreviewed prior return shape')
        return '        return initialize(' + candidate.strip()[len('return '):] + ')\n', 'wrap_exact_candidate_prior_constructor_before_return'
    dv_saved = '''        for key in ("recipe", "optimizer_options", "penalty_options", "device", "dtype", "requires_grad"):
            value = state[key]
            if key == "recipe" and isinstance(value, dict):
                # The experimental continuous option did not exist in PR195.
                value = {"continuous_policy": None, **value}
            if value != expected[key]:
'''
    old_saved = '''        for key in ("recipe", "optimizer_options", "penalty_options", "device", "dtype", "requires_grad"):
            if state[key] != expected[key]:
'''
    if candidate == dv_saved and base == old_saved and upstream.startswith('        saved_recipe = state["recipe"]\n'):
        return upstream.replace('        saved_recipe = state["recipe"]\n',
            '        saved_recipe = state["recipe"]\n        if isinstance(saved_recipe, dict):\n'
            '            # Preserve the candidate\'s pre-continuous checkpoint compatibility.\n'
            '            saved_recipe = {"continuous_policy": None, **saved_recipe}\n'), 'compose_saved_initialization_with_existing_continuous_policy_default'
    raise ValueError('UNKNOWN_CONFLICT_REQUIRES_REVIEW')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--inspection', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    manifest = json.loads((args.inspection / 'port-manifest.json').read_text())
    args.output.mkdir(parents=True, exist_ok=False)
    result = {k: manifest[k] for k in ('candidate', 'old_base')}
    result.update(schema=1, new_base=manifest['new_api_base'], resolutions={}, unknown=[])
    for name in manifest['unresolved_conflicts']:
        folder = args.inspection / 'merge-inputs' / name
        source = (folder / 'three-way-result').read_text()
        changes = []
        for block in BLOCK.finditer(source):
            try:
                value, reason = resolve(*block.groups())
                changes.append((block.start(), block.end(), value, reason))
            except ValueError as exc:
                result['unknown'].append({'file': name, 'reason': str(exc), 'candidate_hunk': block[1], 'base_hunk': block[2], 'upstream_hunk': block[3]})
        if any(x['file'] == name for x in result['unknown']):
            continue
        for start, end, value, _ in reversed(changes):
            source = source[:start] + value + source[end:]
        ast.parse(source)
        path = args.output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(source)
        row = {k: manifest['files'][name][k] for k in ('candidate_sha256', 'old_base_sha256', 'new_base_sha256')}
        row.update(resolution_file=name, resolution_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                   reviewed_shapes=[reason for *_, reason in changes])
        result['resolutions'][name] = row
    (args.output / 'resolutions.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'candidate': result['candidate'], 'reviewed': list(result['resolutions']), 'unknown': result['unknown']}, indent=2))
    raise SystemExit(2 if result['unknown'] else 0)


if __name__ == '__main__':
    main()
