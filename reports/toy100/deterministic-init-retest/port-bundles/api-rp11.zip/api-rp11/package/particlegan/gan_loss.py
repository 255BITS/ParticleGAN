"""The adversarial loss: relativistic pairing (RpGAN) with the logistic link."""
import torch
import torch.nn.functional as F


class GANLoss:
    """RpGAN logistic loss (Jolicoeur-Martineau), built by ``recipe.make_loss()``.

    The critic scores each real against the fake in the same batch row:
    ``d_loss = E[softplus(-(D(real) - D(fake)))]`` and
    ``g_loss = E[softplus(-(D(fake) - D(real)))]``. Pairing needs real and
    fake logits of the same shape in both calls.
    """

    def __init__(self, pairing="row"):
        if pairing not in ("row", "all_pairs"):
            raise ValueError("pairing must be row or all_pairs")
        self.pairing = pairing

    def _difference(self, first, second):
        if self.pairing == "row":
            return first - second
        if first.ndim < 1 or second.ndim != first.ndim or first.shape[1:] != second.shape[1:]:
            raise ValueError("all_pairs logits must have matching nonbatch dimensions")
        # Average out the random row assignment, without drawing more data or
        # scoring any synthetic targets. This is the mean of all row-pairing
        # permutations for equal batch sizes, including their gradients.
        return first.unsqueeze(1) - second.unsqueeze(0)

    def d_loss(self, real_logits: torch.Tensor, fake_logits: torch.Tensor) -> torch.Tensor:
        """Critic loss (minimized)."""
        return F.softplus(-self._difference(real_logits, fake_logits)).mean()

    def g_loss(self, fake_logits: torch.Tensor, real_logits: torch.Tensor = None) -> torch.Tensor:
        """Generator loss (minimized); ``real_logits`` is required."""
        if real_logits is None:
            raise ValueError("RpGAN requires real_logits in g_loss")
        return F.softplus(-self._difference(fake_logits, real_logits)).mean()
