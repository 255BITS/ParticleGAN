"""Standard-library source verification only."""
from pathlib import Path
import ast
import hashlib
import json
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def verify(bundle):
    manifest=json.loads((bundle/'bundle-sha256.json').read_text())
    declaration=json.loads((bundle/'declaration.json').read_text())
    for name,wanted in manifest['files'].items():
        assert sha(bundle/name)==wanted, name
    package={str(p.relative_to(bundle/'source')):sha(p) for p in (bundle/'source/particlegan').glob('*.py')}
    assert package==declaration['package_sha256']
    recipe=declaration['recipe']
    assert recipe['initialization']=='batch_feature_zero' and recipe['total_steps'] is None
    assert (recipe['num_particles'],recipe['z_dim'],recipe['batch_size'])==(20000,2,2048)
    assert recipe['input_noise_std']==0 and recipe['output_noise_std']==.029 and recipe['noise_policy']=='constant'
    assert recipe['continuous_precision']=='rp5' and recipe['game_update']=='secant_resolvent'
    assert recipe['adam_eager_state'] is True
    assert declaration['initial_optimizer_state']=='declared_eager'
    assert declaration['optimizer_step_devices']=={'D':'parameter','G':'parameter'}
    for name in ('worker.py','ring_contract.py','execution_contract.py','source/frozen_host.py'):ast.parse((bundle/name).read_text())
    return dict(status='PASS_SOURCE_ONLY',manifest_sha256=sha(bundle/'bundle-sha256.json'),package_files=len(package),quality='NOT_RUN')
if __name__=='__main__':
    print(json.dumps(verify(Path(__file__).resolve().parent),indent=2))
