"""Joint secant response checked against the actual implicit residual.

Nominal native Adam rates are constant. Numerical damping starts at one on
every public call; no horizon, convergence detector or persistent step schedule.
"""
from copy import deepcopy
import torch

from .game_update import (JointStage, check_transaction_hooks, copies, restore,
                          secant_resolvent)


class ProbeStage(JointStage):
    def before(self, role):
        if role == 'd':
            self.reference_before = deepcopy(self.trainer.ema_D.state_dict())
        super().before(role)

    def finalize(self):
        # The transaction commits once, after checking the implicit equation.
        pass


def rewind(trainer, checkpoint):
    for opt, state in zip((trainer.opt_g, trainer.opt_d), checkpoint['optimizers']):
        opt.load_state_dict(deepcopy(state))
    for name in ('ema_G', 'ema_prior'):
        getattr(trainer, name).load_state_dict(checkpoint['models'][name])
    for name in ('G', 'D', 'prior'):
        restore([(b, checkpoint['models'][name][key])
                 for key, b in getattr(trainer, name).named_buffers()])
    trainer.completed_steps = checkpoint['completed_steps']
    for name, state in checkpoint['streams'].items():
        getattr(trainer, name).set_state(state.cpu())
    torch.set_rng_state(checkpoint['cpu_rng'].cpu())
    if trainer.device.type == 'cuda':
        torch.cuda.set_rng_state(checkpoint['cuda_rng'].cpu(), trainer.device)


def checked_secant_step(trainer, real, generator_real, collect_stats):
    check_transaction_hooks(trainer)
    if callable(generator_real):
        generator_real = generator_real()
    checkpoint = trainer.state_dict()
    base = {'d': copies(trainer.D.parameters()),
            'g': copies(list(trainer.G.parameters()) + list(trainer.prior.parameters()))}
    pairs = base['d'] + base['g']
    lengths = [len(base['d']), len(list(trainer.G.parameters())),
               len(list(trainer.prior.parameters()))]
    try:
        trainer._game_stage = ProbeStage(trainer, base)
        result = trainer._ordinary_step(real, generator_real=generator_real,
                                        collect_stats=collect_stats)
        native = [deepcopy(o.state_dict()) for o in (trainer.opt_g, trainer.opt_d)]
        reference = trainer._game_stage.reference_before
        u = [p.detach().clone() - b for p, b in pairs]

        def field(displacement):
            rewind(trainer, checkpoint)
            restore([(p, b+d) for (p, b), d in zip(pairs, displacement)])
            trainer._game_stage = ProbeStage(trainer, base, correction=True)
            trainer._ordinary_step(real, generator_real=generator_real, collect_stats=False)
            return [p.detach().clone() - b for p, b in pairs]

        trials = []
        for backtracks in range(17):
            fraction = 2. ** -backtracks
            v = field([fraction*x for x in u])
            delta, secant = secant_resolvent([fraction*x for x in u],
                                            [fraction*x for x in v])
            checked = field(delta)
            ratios, start = {}, 0
            for role, length in zip(('D', 'G', 'prior'), lengths):
                d, w = delta[start:start+length], checked[start:start+length]
                residual2 = sum((x-fraction*y).square().sum() for x, y in zip(d, w))
                displacement2 = sum(x.square().sum() for x in d).clamp_min(1e-30)
                ratios[role] = float((residual2 / displacement2).sqrt())
                start += length
            trials.append({'fraction': fraction, 'relative_implicit_residual': ratios})
            if all(value <= .5 for value in ratios.values()):
                break
        else:
            raise RuntimeError('implicit residual check failed after16 backtracks')

        restore([(p, b+d) for (p, b), d in zip(pairs, delta)])
        # Native history comes from the actual starting-state gradient, once.
        for opt, state in zip((trainer.opt_g, trainer.opt_d), native):
            opt.load_state_dict(deepcopy(state))
        trainer.ema_D.load_state_dict(reference)
        if trainer.opt_d.record.anchor_started:
            trainer.opt_d.anchor.update_()
        with torch.no_grad():
            for name, source in (('ema_G', trainer.G), ('ema_prior', trainer.prior)):
                target = getattr(trainer, name)
                target.load_state_dict(checkpoint['models'][name])
                for averaged, current in zip(target.parameters(), source.parameters()):
                    averaged.mul_(trainer.recipe.ema_decay).add_(current, alpha=1-trainer.recipe.ema_decay)
                for averaged, current in zip(target.buffers(), source.buffers()):
                    averaged.copy_(current)
        trainer.game_stats = {'policy': 'checked_secant', 'field_evaluations': 1+2*len(trials),
                              'accepted_updates': trainer.completed_steps, 'trials': trials,
                              'secant': secant, 'moment_source': 'base_gradient',
                              'loss_source': 'base_state', 'fraction': fraction}
        start = 0
        for role, length in zip(('D', 'G', 'prior'), lengths):
            preview = u[start:start+length]
            actual = [p.detach()-b for p, b in pairs[start:start+length]]
            trainer.game_stats[role] = {
                'preview_l2': float(sum(x.square().sum() for x in preview).sqrt()),
                'applied_l2': float(sum(x.square().sum() for x in actual).sqrt()),
                'correction_l2': float(sum((x-y).square().sum() for x, y in zip(actual, preview)).sqrt())}
            start += length
        return result
    except Exception:
        trainer.load_state_dict(checkpoint)
        raise
    finally:
        trainer._game_stage = None
