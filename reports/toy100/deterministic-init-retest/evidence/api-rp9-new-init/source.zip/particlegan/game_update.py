"""Transactional joint predictor/corrector using the installed Adam optimizers.

Both fields in a stage see the same joint parameter state. A preview never
advances accepted optimizer/controller/EMA/RNG clocks. No evaluator inputs.
"""
from copy import deepcopy
import torch


IMPLICIT_POLICIES = ("secant_resolvent", "two_direction_resolvent", "minimum_residual_resolvent", "secant_particle_exploration")
THREE_FIELD_POLICIES = ("two_direction_resolvent", "minimum_residual_resolvent")


@torch.no_grad()
def restore(pairs):
    for parameter, value in pairs:
        parameter.copy_(value)


def copies(parameters):
    return [(p, p.detach().clone()) for p in parameters]


class JointStage:
    def __init__(self, trainer, base, correction=False):
        self.trainer, self.base, self.correction = trainer, base, correction
        self.pending = None
        self.predicted_d = None
        self.reference_before = None
        self.predictor_state = None
        self.predicted = None
        self.secant_stats = None
        self.first_field = None
        self.second_direction = None

    def before(self, role):
        if role == "d" and self.trainer.recipe.game_update in IMPLICIT_POLICIES:
            self.reference_before = deepcopy(self.trainer.ema_D.state_dict())
            self.record_before = self.trainer.opt_d.record.state_dict()
        if self.correction:
            if role == 'd':
                self.predicted_d = copies(self.trainer.D.parameters())
            restore(self.base[role])

    def after(self, role):
        if role == 'd':
            self.pending = copies(self.trainer.D.parameters())
            restore(self.predicted_d if self.correction else self.base['d'])
        else:
            restore(self.pending)
            self.pending = None

    def finalize(self):
        # Called only after the trainer restores the critic's original flags.
        if self.correction and (self.trainer.recipe.game_update in ("secant_resolvent", "secant_particle_exploration")
                                or self.second_direction is not None):
            self.resolve()

    def resolve(self):
        pairs = self.base['d'] + self.base['g']
        predicted = self.predicted['d'] + self.predicted['g']
        u = [q - b for (_, q), (_, b) in zip(predicted, pairs)]
        v = [p.detach() - b for p, b in pairs]
        if self.second_direction is None:
            delta, self.secant_stats = secant_resolvent(u, v)
        else:
            solver = (minimum_residual_resolvent if self.trainer.recipe.game_update == "minimum_residual_resolvent"
                      else two_direction_resolvent)
            delta, self.secant_stats = solver(
                u, self.first_field, v, self.second_direction)
        if self.trainer.recipe.game_update == "secant_particle_exploration":
            index = next(i for i, (p, _) in enumerate(pairs) if p is self.trainer.prior.z)
            noise, stats = particle_exploration(u[index], v[index], delta[index],
                                               self.trainer.particle_noise_generator)
            delta[index] = delta[index] + noise
            self.secant_stats['particle_exploration'] = stats
        restore([(p, b + d) for (p, b), d in zip(pairs, delta)])
        # Persist ordinary gradients at the actual state, so extreme preview
        # gradients cannot blind the next base-state Adam normalization.
        for opt, state in zip((self.trainer.opt_g, self.trainer.opt_d), self.predictor_state):
            opt.load_state_dict(deepcopy(state))
        self.trainer.ema_D.load_state_dict(self.predictor_reference)
        record = self.trainer.opt_d.record
        if record.ema_reseeds > self.predictor_record_before["ema_reseeds"]:
            self.trainer.opt_d.anchor.start_()
        if record.ema_updates > self.predictor_record_before["ema_updates"]:
            self.trainer.opt_d.anchor.update_()


@torch.no_grad()
def secant_resolvent(u, v):
    """Backward-Euler response in a fitted dissipative/rotational plane.

    Fit J u = v-u = a*u+r, r orthogonal to u. Project a to <=0;
    on this plane use J=a*I+b*R (R a quarter-turn). Then
    (I-J)^-1 u = ((1-a)*u+r)/((1-a)^2+b^2).
    No norm threshold or tuned clipping coefficient. Exact for that local
    linear game model; it is only a secant approximation for a nonlinear GAN.
    """
    norm2 = sum(x.square().sum() for x in u).clamp_min(torch.finfo(u[0].dtype).tiny)
    w = [y-x for x,y in zip(u,v)]
    a = sum((x*y).sum() for x,y in zip(u,w)) / norm2
    perpendicular = [y-a*x for x,y in zip(u,w)]
    b2 = sum(x.square().sum() for x in perpendicular) / norm2
    radial = 1 + (-a).clamp_min(0)
    denominator = radial.square() + b2
    delta = [(radial*x+y)/denominator for x,y in zip(u,perpendicular)]
    stats = {'radial_secant': float(a), 'rotation_squared': float(b2),
             'denominator': float(denominator),
             'norm_ratio': float(denominator.rsqrt()), 'moment_source': 'base_gradient'}
    return delta, stats


@torch.no_grad()
def particle_exploration(predictor, corrector, accepted, generator):
    """Zero-mean bounded exploration from two current particle directions."""
    tiny = torch.finfo(predictor.dtype).tiny
    first = predictor.square().sum(-1).sqrt()
    second = corrector.square().sum(-1).sqrt()
    active = (first > 0) & (second > 0)
    cosine = ((predictor * corrector).sum(-1) / (first * second).clamp_min(tiny)).clamp(-1, 1)
    disagreement = torch.where(active, (1-cosine)*.5, torch.zeros_like(cosine))
    accepted_norm = accepted.square().sum(-1).sqrt()
    sigma = accepted_norm * (disagreement / predictor.shape[-1]).sqrt()
    signs = torch.randint(0, 2, predictor.shape, device=predictor.device, generator=generator)
    noise = (2*signs-1).to(predictor.dtype) * sigma.unsqueeze(-1)
    return noise, dict(mean_sigma=float(sigma.mean()), max_sigma=float(sigma.max()),
        mean_disagreement=float(disagreement.mean()), active_rows=int(active.sum()),
        noisy_rows=int((sigma>0).sum()), noise_l2=float(noise.norm()),
        deterministic_prior_l2=float(accepted.norm()),
        max_row_noise_to_step=float(disagreement.sqrt().max()), stream='particle_noise_generator')


@torch.no_grad()
def orthogonal_probe(u, v):
    """Second secant direction, with the same length as the first predictor."""
    tiny = torch.finfo(u[0].dtype).tiny
    norm2 = sum(x.square().sum() for x in u).clamp_min(tiny)
    w = [y - x for x, y in zip(u, v)]
    radial = sum((x * y).sum() for x, y in zip(u, w)) / norm2
    residual = [y - radial * x for x, y in zip(u, w)]
    rotation = (sum(x.square().sum() for x in residual) / norm2).sqrt()
    valid = rotation > torch.finfo(u[0].dtype).eps
    return [torch.where(valid, x / rotation.clamp_min(tiny), torch.zeros_like(x))
            for x in residual]


@torch.no_grad()
def two_direction_resolvent(u, v, third, direction):
    """Measure both columns of the local game on a two-direction plane.

    Unlike the isotropic rotation model, the second column is observed. The
    symmetric part is projected onto the negative semidefinite cone, retaining
    the measured skew component, then a two-dimensional implicit solve is used.
    All probes reuse the original minibatches and native Adam state.
    """
    tiny = torch.finfo(u[0].dtype).tiny
    norm2 = sum(x.square().sum() for x in u).clamp_min(tiny)
    basis = (u, direction)
    columns = ([y - x for x, y in zip(u, v)],
               [y - x for x, y in zip(u, third)])
    h = torch.stack([torch.stack([sum((q * w).sum() for q, w in zip(row, column)) / norm2
                                 for column in columns]) for row in basis])
    symmetric = (h + h.T) * .5
    values, vectors = torch.linalg.eigh(symmetric)
    dissipative = (vectors * values.clamp_max(0)) @ vectors.T + (h - h.T) * .5
    rhs = h.new_tensor([1., 0.])
    coefficients = torch.linalg.solve(torch.eye(2, device=h.device, dtype=h.dtype) - dissipative, rhs)
    delta = [coefficients[0] * x + coefficients[1] * y for x, y in zip(u, direction)]
    outside = [w - h[0, 1] * x - h[1, 1] * y for w, x, y in zip(columns[1], u, direction)]
    return delta, dict(model="measured_two_direction", fitted_matrix=h.tolist(),
        symmetric_eigenvalues=values.tolist(), applied_matrix=dissipative.tolist(),
        coefficients=coefficients.tolist(), norm_ratio=float(coefficients.norm()),
        second_column_outside_ratio=float((sum(x.square().sum() for x in outside) / norm2).sqrt()),
        moment_source="base_gradient")


@torch.no_grad()
def constrained_coefficients(gram, rhs):
    """Two-variable PSD least squares on the forward half of the unit disk."""
    tiny = torch.finfo(gram.dtype).tiny
    values, vectors = torch.linalg.eigh(gram)
    values = values.clamp_min(0)
    coordinates = vectors.T @ rhs
    rank = values > torch.finfo(gram.dtype).eps * values.max()
    unconstrained = torch.where(rank, coordinates / values.clamp_min(tiny), torch.zeros_like(coordinates))
    multiplier = gram.new_zeros(())
    constrained = bool(unconstrained.norm() > 1)
    if constrained:
        lower, upper = gram.new_zeros(()), rhs.norm()
        for _ in range(32):
            midpoint = (lower + upper) * .5
            norm = (coordinates / (values + midpoint).clamp_min(tiny)).norm()
            lower = torch.where(norm > 1, midpoint, lower)
            upper = torch.where(norm > 1, upper, midpoint)
        multiplier = upper
        unconstrained = coordinates / (values + multiplier).clamp_min(tiny)
    coefficients = vectors @ unconstrained
    half_plane = bool(coefficients[0] < 0)
    if half_plane:
        scalar = torch.where(gram[1, 1] > tiny, rhs[1] / gram[1, 1].clamp_min(tiny), gram.new_zeros(())).clamp(-1, 1)
        coefficients = torch.stack((gram.new_zeros(()), scalar))
    return coefficients, dict(trust_multiplier=float(multiplier), trust_boundary=constrained,
                              half_plane_active=half_plane, gram_rank=int(rank.sum()))


@torch.no_grad()
def minimum_residual_resolvent(u, v, third, direction):
    """Use all measured response coordinates, including out-of-plane motion."""
    norm2 = sum(x.square().sum() for x in u).clamp_min(torch.finfo(u[0].dtype).tiny)
    columns = ([2*x-y for x, y in zip(u, v)],
               [q-y+x for x, y, q in zip(u, third, direction)])
    gram = torch.stack([torch.stack([sum((x*y).sum() for x, y in zip(a, b)) / norm2
                                    for b in columns]) for a in columns])
    rhs = torch.stack([sum((x*y).sum() for x, y in zip(a, u)) / norm2 for a in columns])
    coefficients, stats = constrained_coefficients(gram, rhs)
    delta = [coefficients[0]*x + coefficients[1]*q for x, q in zip(u, direction)]
    residual = [x-coefficients[0]*a-coefficients[1]*b for x, a, b in zip(u, *columns)]
    stats.update(model="full_linear_minimum_residual", coefficients=coefficients.tolist(),
                 gram=gram.tolist(), rhs=rhs.tolist(), norm_ratio=float(coefficients.norm()),
                 linear_residual=float((sum(x.square().sum() for x in residual) / norm2).sqrt()),
                 zero_update=all(not bool(x.count_nonzero()) for x in delta), moment_source="base_gradient")
    return delta, stats


def restore_preview_state(trainer, checkpoint):
    """Reset all accepted nonparameter clocks before another same-oracle field."""
    for opt, state in zip((trainer.opt_g, trainer.opt_d), checkpoint['optimizers']):
        opt.load_state_dict(deepcopy(state))
    for name in ('ema_G', 'ema_prior'):
        getattr(trainer, name).load_state_dict(checkpoint['models'][name])
    for name in ('G', 'D', 'prior'):
        module = getattr(trainer, name)
        restore([(b, checkpoint['models'][name][key]) for key, b in module.named_buffers()])
    trainer.completed_steps = checkpoint['completed_steps']
    for name, state in checkpoint['streams'].items():
        getattr(trainer, name).set_state(state.cpu())
    torch.set_rng_state(checkpoint['cpu_rng'].cpu())
    if trainer.device.type == 'cuda':
        torch.cuda.set_rng_state(checkpoint['cuda_rng'].cpu(), trainer.device)


def joint_step(trainer, real, generator_real, collect_stats):
    if callable(generator_real):
        generator_real = generator_real()
    checkpoint = trainer.state_dict()
    base = {'d': copies(trainer.D.parameters()),
            'g': copies(list(trainer.G.parameters()) + list(trainer.prior.parameters()))}
    trainer._game_stage = JointStage(trainer, base)
    try:
        trainer._ordinary_step(real, generator_real=generator_real, collect_stats=False)
        predictor_state = None
        predictor_reference = None
        if trainer.recipe.game_update in IMPLICIT_POLICIES:
            predictor_state = [deepcopy(o.state_dict()) for o in (trainer.opt_g, trainer.opt_d)]
            predictor_reference = trainer._game_stage.reference_before
            predictor_record_before = trainer._game_stage.record_before
        predicted = {role: copies([p for p, _ in pairs]) for role, pairs in base.items()}
        # Keep preview parameters, restore all other accepted state. Adam's
        # ordinary CPU scalar step metadata remains on CPU.
        restore_preview_state(trainer, checkpoint)
        trainer._game_stage = JointStage(trainer, base, correction=True)
        trainer._game_stage.predictor_state = predictor_state
        trainer._game_stage.predictor_reference = predictor_reference
        trainer._game_stage.predictor_record_before = predictor_record_before
        trainer._game_stage.predicted = predicted
        result = trainer._ordinary_step(real, generator_real=generator_real, collect_stats=collect_stats)
        if trainer.recipe.game_update in THREE_FIELD_POLICIES:
            pairs = base['d'] + base['g']
            u = [q - b for (_, q), (_, b) in zip(predicted['d'] + predicted['g'], pairs)]
            v = [p.detach() - b for p, b in pairs]
            direction = orthogonal_probe(u, v)
            restore_preview_state(trainer, checkpoint)
            restore([(p, b + q) for (p, b), q in zip(pairs, direction)])
            trainer._game_stage = JointStage(trainer, base, correction=True)
            trainer._game_stage.predictor_state = predictor_state
            trainer._game_stage.predictor_reference = predictor_reference
            trainer._game_stage.predictor_record_before = predictor_record_before
            trainer._game_stage.predicted = predicted
            trainer._game_stage.first_field = v
            trainer._game_stage.second_direction = direction
            result = trainer._ordinary_step(real, generator_real=generator_real, collect_stats=collect_stats)
        telemetry = {'policy': trainer.recipe.game_update,
                     'field_evaluations': 3 if trainer.recipe.game_update in THREE_FIELD_POLICIES else 2,
                     'accepted_updates': trainer.completed_steps, 'preview_moments_discarded': trainer.recipe.game_update == 'extragradient'}
        if trainer._game_stage.secant_stats is not None:
            telemetry["secant"] = trainer._game_stage.secant_stats
        for role, pairs in base.items():
            preview = [q - b for (_, q), (_, b) in zip(predicted[role], pairs)]
            actual = [p.detach() - b for p, b in pairs]
            telemetry[role] = {'preview_l2': float(sum(x.square().sum() for x in preview).sqrt()),
                               'applied_l2': float(sum(x.square().sum() for x in actual).sqrt()),
                               'correction_l2': float(sum((x-y).square().sum() for x,y in zip(actual,preview)).sqrt())}
        if trainer.precision is not None:
            before = {id(p): value for p, value in base["g"]}
            activity = trainer.precision.update_activity(trainer.opt_g, before)
            trainer.precision.observe(trainer.D, real, activity)
        trainer.game_stats = telemetry
        return result
    except Exception:
        trainer.load_state_dict(checkpoint)
        raise
    finally:
        trainer._game_stage = None
