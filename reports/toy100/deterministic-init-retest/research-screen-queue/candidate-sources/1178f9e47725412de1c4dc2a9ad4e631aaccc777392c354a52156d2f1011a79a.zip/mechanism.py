"""rcm2: K3P penalties with a reversible anchor-disagreement mix.

rcm1 closed by critic step 300 because a spiked gradient peak made ordinary
gradients look inactive, and the ring then stayed at 7/8 modes. This candidate
does not use that peak. The mixing weight follows the normalized gap between
the live critic's real-data input gradient and the same gradient of the EMA
anchor. Anchor decay, the penalties, the guard and the particle hooks stay K3P.

pen = 0.5 * (s * A + (1 - s) * (B + P))
  A, B, P, kappa=1, coefficient=1, anchor decay 0.999, guard 5x after 200 steps:
  unchanged from K3P. s starts at 1, and s >= 1 uses A only.

Signal, detached, not a function of the learning rate, step index, horizon,
scores or target:
  delta = mean_i 0.5 * ||g_i - gbar_i||^2 / (||g_i||^2 + ||gbar_i||^2 + eps)
          so delta is 0 when the two input gradients match and 1 when they oppose.
  m <- 0.995 * m + 0.005 * delta     (m starts at 1; no update on the EMA-clone step)
  m >= 0.06 -> target = 1
  m <= 0.01 -> target = 0
  otherwise the previous target is kept
  s <- 0.96 * s + 0.04 * target      (s starts at 1)

While s >= 1 the signal still evaluates the anchor once per penalty so the mix
can close later. That forward is counted in anchor_forwards and is not an
optimizer step. While s < 1 the penalty's own anchor evaluation is reused.

Inherited K3P schedules, not read by s:
  network LR cosine on min(total_steps, 1600) down to floor 0.01
  prior LR cosine on total_steps down to floor 0.05
  base LR 0.00425, prior multiplier 2, anneal start 0.6
  noise horizon 1200 inside the unmodified hold and shift drivers
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
MEM_DECAY = 0.995
OPEN_M = 0.06
CLOSE_M = 0.01
S_SMOOTH = 0.04
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
           'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
           'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'rcm2',
           'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None, 'prox_trace': [],
           'anchor_forwards': 0, 'signal_live_forwards': 0, 'anchor_penalty_calls': 0,
           'anchor_weight_sum': 0.0, 'first_close_step': None, 'first_reopen_step': None,
           'mix_trace': [],
           'controller': {
               'name': 'normalized_anchor_disagreement',
               'memory_decay': MEM_DECAY, 'open_m': OPEN_M, 'close_m': CLOSE_M, 's_smooth': S_SMOOTH,
               'initial_s': 1.0, 'initial_target': 1.0, 'initial_m': 1.0,
               'reads_learning_rate': False, 'reads_horizon': False, 'reads_step_index': False,
               'reads_metrics': False, 'reads_target': False,
           },
           'inherited_budget_dependencies': [
               'network LR cosine uses min(total_steps, network_lr_horizon_cap=1600) and network floor 0.01',
               'prior LR cosine uses total_steps and lr_floor 0.05',
               'input/output noise horizon is 1200 inside the unmodified hold/shift drivers',
           ]}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0,
          'clips': [], 'critic_ref': None, 's': 1.0, 'target': 1.0, 'm': None,
          'last_delta': None, 'last_m': None}


def handover_weight():
    return _state['s']


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _ema_input_grad(D, x_real, params):
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    receipt['anchor_forwards'] += 1
    return gb


def _ready_params():
    if _state['critic_ref'] is None:
        return None
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return None
    return params


def _delta(g, gb):
    """Batch-mean gap. A symmetric zero mean counts as agreement (eps in the denominator).

    Per-sample ratios stay near 1/2 whenever the two 2-d gradients are noisy, including
    at a settled critic, so they cannot close the mix. The batch mean does.
    """
    gm = g.detach().flatten(1).mean(dim=0)
    bm = gb.detach().flatten(1).mean(dim=0)
    num = (gm - bm).pow(2).sum()
    den = gm.pow(2).sum() + bm.pow(2).sum()
    return (num / (den + 1e-6)).clamp(0.0, 2.0) * 0.5


def _signal_delta(D, x_real):
    params = _ready_params()
    if params is None:
        return None
    xb = x_real.detach().clone().requires_grad_(True)
    with torch.enable_grad():
        g = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    receipt['signal_live_forwards'] += 1
    gb = _ema_input_grad(D, x_real, params)
    return _delta(g, gb)


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar||^2 / d. Returns (prox, anchor_grad or None)."""
    params = _ready_params()
    if params is None:
        return g.new_zeros(()), None
    gb = _ema_input_grad(D, x_real, params)
    prox = (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension
    return prox, gb


def _update_mix(delta):
    if delta is None:
        return
    m = delta.detach().new_tensor(1.0) if _state['m'] is None else _state['m']
    m = m * MEM_DECAY + delta.detach() * (1.0 - MEM_DECAY)
    _state['m'] = m
    mf = float(m)
    df = float(delta.detach())
    target = _state['target']
    if mf >= OPEN_M:
        target = 1.0
    elif mf <= CLOSE_M:
        target = 0.0
    if target == 0.0 and receipt['first_close_step'] is None:
        receipt['first_close_step'] = receipt['calls']
    if (target == 1.0 and receipt['first_close_step'] is not None
            and receipt['first_reopen_step'] is None and receipt['calls'] != receipt['first_close_step']):
        receipt['first_reopen_step'] = receipt['calls']
    _state['target'] = target
    _state['s'] = (1.0 - S_SMOOTH) * _state['s'] + S_SMOOTH * target
    _state['last_delta'] = df
    _state['last_m'] = mf


def _note_mix():
    row = [receipt['calls'], round(_state['s'], 6), round(_state['target'], 3),
           None if _state['last_m'] is None else round(_state['last_m'], 6),
           None if _state['last_delta'] is None else round(_state['last_delta'], 6),
           _state['lr_last'], receipt['anchor_forwards']]
    receipt['mix_trace'].append(row)
    call = receipt['calls']
    if call == 1 or call % 50 == 0:
        print(json.dumps({'rcm2': True, 'call': call, 's': row[1], 'target': row[2], 'm': row[3],
                          'delta': row[4], 'lr': row[5], 'anchor_forwards': row[6],
                          'critic_steps': receipt['critic_steps']}), flush=True)


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    # Probe the anchor before the penalty graph exists. Swapping .data while that
    # graph is open corrupts the critic step (the aborted rcm2 launch did this).
    delta = _signal_delta(D, x_real) if s >= 1.0 else None
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox, gb = anchored_gradient_gap(D, x_real, g, dimension)
        if gb is not None:
            delta = _delta(g, gb)
        receipt['anchor_penalty_calls'] += 1
        receipt['anchor_weight_sum'] += (1.0 - s)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    _update_mix(delta)
    _note_mix()
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(_state['target'], 3)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_target'] = _state['target']
    receipt['final_m'] = None if _state['m'] is None else float(_state['m'])
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
