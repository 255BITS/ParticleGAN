"""SN1: score-gap mobility with horizon-free noise. K3P penalty, guard, anchor.

Round-2 noise lanes: successive-gradient cosine never left full rate (ns1);
a fixed pace floored at five modes (ns2); a copied 1600/120/240 schedule held
the ring but a lifetime grad-RMS shock both nudged the settled ring and missed
the shift, because post-shift grad RMS stays inside the settled band
(about 0.001-0.004). This rule does not read that RMS, a step horizon, or
total_steps.

Signals, once per critic penalty, CUDA FP32:
  q = mean D(real) - mean D(fake) on the training batch (not HQ, not modes).
  q_fast = 0.9 q_fast + 0.1 q
  q_slow = 0.995 q_slow + 0.005 q
  rel = |q_fast - q_slow| / max(ema_|q|, 1e-3)
  Generator+prior displacement RMS, EMA 0.95. disp_ref is the max of that EMA
  over the first 200 generator steps (estimator calibration), then frozen.

Warmup: the first 30 critic penalties do not move heat or noise.
quiet when rel < 0.05. surprise when rel > 0.20.
heat starts at 1.
  quiet_run > 40 and disp_ema < 0.15 * disp_ref: heat *= 0.992
  surprise_run >= 20: heat = 0.992*heat + 0.008*cap
  cap is 1 until heat has been below 0.08, then 0.20 (moderate reopen).
Network multiplier = 0.01 + 0.99*heat. Prior multiplier = 0.05 + 0.95*heat.
Applied LR is not the mix clock.

anchor_heat starts at 1. It increases by 0.005 only while heat > 0.5, and
otherwise multiplies by 0.995. s is the K3P handover of
r = 0.01 + 0.99*anchor_heat, so a moderate reopen leaves the EMA anchor on.
Restoring a_r1r2 requires heat above one half, not a schedule.

Noise, same signals, no step span:
  quiet_run > 15: noise_heat *= 0.96
  surprise_run >= 8: recharge toward 1, or toward at most 0.10 after noise_heat
  has already been below 0.05.
  input std = 0.5 * noise_heat
  output std = 0.029 * (1 - noise_heat)
The host linear schedules and policy_multipliers are called and discarded.
Guard 5x after 200 and anchor decay 0.999 are unchanged. Direct response and
the sparse latent rule are the copied K3P modules.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
PRIOR_FLOOR = 0.05
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
INPUT_PEAK = 0.5
OUTPUT_PEAK = 0.029
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'extra_score_forwards': 0,
           'floor': FLOOR, 'prior_floor': PRIOR_FLOOR, 'guard_c': GUARD_C,
           'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
           'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [],
           'rule': 'sn1_gap_mobility', 'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None,
           'prox_trace': [],
           'handover': 's from anchor_heat, not applied LR and not heat, unless heat > 0.5',
           'noise_rule': 'input 0.5*noise_heat; output 0.029*(1-noise_heat); noise_heat from score-gap quiet/surprise',
           'optimizer_policy': 'network 0.01+0.99*heat; prior 0.05+0.95*heat; heat from score gap and displacement'}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0, 'clips': [], 'critic_ref': None}
_ctrl = {'q_fast': None, 'q_slow': None, 'amp': None, 'heat': 1.0, 'anchor_heat': 1.0,
         'noise_heat': 1.0, 'noise_settled': False, 'floor_seen': False, 'quiet_run': 0,
         'surprise_run': 0, 'disp_ema': None, 'disp_ref': None, 'prev': None,
         'input_std': INPUT_PEAK, 'output_std': 0.0, 'last_rel': None, 'last_q': None,
         'trace': []}


def handover_weight():
    r = FLOOR + (1.0 - FLOOR) * float(_ctrl['anchor_heat'])
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def network_multiplier():
    return FLOOR + (1.0 - FLOOR) * float(_ctrl['heat'])


def prior_multiplier():
    return PRIOR_FLOOR + (1.0 - PRIOR_FLOOR) * float(_ctrl['heat'])


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _update_scores(q):
    q = q.detach().to(dtype=torch.float32)
    if _ctrl['q_fast'] is None:
        _ctrl['q_fast'] = q.clone()
        _ctrl['q_slow'] = q.clone()
        _ctrl['amp'] = q.abs().clamp_min(1e-3)
        return
    _ctrl['q_fast'] = _ctrl['q_fast'] * 0.9 + q * 0.1
    _ctrl['q_slow'] = _ctrl['q_slow'] * 0.995 + q * 0.005
    _ctrl['amp'] = _ctrl['amp'] * 0.995 + q.abs() * 0.005
    dev = (_ctrl['q_fast'] - _ctrl['q_slow']).abs()
    rel = dev / _ctrl['amp'].clamp_min(1e-3)
    rel_f = float(rel)
    _ctrl['last_rel'] = rel_f
    _ctrl['last_q'] = float(q)
    if receipt['calls'] <= 30:
        _ctrl['quiet_run'] = 0
        _ctrl['surprise_run'] = 0
        return
    if rel_f < 0.05:
        _ctrl['quiet_run'] += 1
    else:
        _ctrl['quiet_run'] = 0
    if rel_f > 0.20:
        _ctrl['surprise_run'] += 1
    else:
        _ctrl['surprise_run'] = 0
    disp_ema = _ctrl['disp_ema']
    disp_ref = _ctrl['disp_ref']
    move_settled = (disp_ema is not None and disp_ref is not None and float(disp_ref) > 0.0
                    and float(disp_ema) < 0.15 * float(disp_ref))
    if _ctrl['quiet_run'] > 40 and move_settled:
        _ctrl['heat'] *= 0.992
    elif _ctrl['surprise_run'] >= 20:
        cap = 0.20 if _ctrl['floor_seen'] else 1.0
        _ctrl['heat'] = _ctrl['heat'] * 0.992 + 0.008 * cap
    _ctrl['heat'] = min(1.0, max(0.0, float(_ctrl['heat'])))
    if _ctrl['heat'] < 0.08:
        _ctrl['floor_seen'] = True
    if _ctrl['heat'] > 0.5:
        _ctrl['anchor_heat'] = min(1.0, _ctrl['anchor_heat'] + 0.005)
    else:
        _ctrl['anchor_heat'] *= 0.995
    if _ctrl['quiet_run'] > 15:
        _ctrl['noise_heat'] *= 0.96
    elif _ctrl['surprise_run'] >= 8:
        if _ctrl['noise_settled']:
            _ctrl['noise_heat'] = min(0.10, _ctrl['noise_heat'] * 0.9 + 0.01)
        else:
            _ctrl['noise_heat'] = min(1.0, _ctrl['noise_heat'] * 0.9 + 0.1)
    _ctrl['noise_heat'] = min(1.0, max(0.0, float(_ctrl['noise_heat'])))
    if _ctrl['noise_heat'] < 0.05:
        _ctrl['noise_settled'] = True
    _ctrl['input_std'] = INPUT_PEAK * _ctrl['noise_heat']
    _ctrl['output_std'] = OUTPUT_PEAK * (1.0 - _ctrl['noise_heat'])


def _update_disp(opt):
    if len(opt.param_groups) < 2:
        return
    params = [p for g in opt.param_groups for p in g['params']]
    prev = _ctrl['prev']
    if prev is not None and len(prev) == len(params):
        acc = None
        count = 0
        for p, old in zip(params, prev):
            diff = (p.detach() - old).square().sum()
            acc = diff if acc is None else acc + diff
            count += p.numel()
        disp = torch.sqrt(acc / count)
        if _ctrl['disp_ema'] is None:
            _ctrl['disp_ema'] = disp.detach()
        else:
            _ctrl['disp_ema'] = _ctrl['disp_ema'] * 0.95 + disp * 0.05
        if receipt['critic_steps'] <= 200:
            ref = _ctrl['disp_ref']
            _ctrl['disp_ref'] = _ctrl['disp_ema'].detach() if ref is None else torch.maximum(ref, _ctrl['disp_ema'].detach())
    _ctrl['prev'] = [p.detach().clone() for p in params]


def anchored_gradient_gap(D, x_real, g, dimension):
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    receipt['extra_critic_forwards'] += 1
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    with torch.no_grad():
        q = D(x_real.detach()).mean() - D(x_fake.detach()).mean()
    receipt['extra_score_forwards'] += 2
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    receipt['calls'] += 1
    _update_scores(q)
    s = handover_weight()
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(float(_ctrl['heat']), 6),
                                   round(float(_ctrl['anchor_heat']), 6), round(float(_ctrl['noise_heat']), 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        _update_disp(opt)
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
        if receipt['critic_steps'] == 1 or receipt['critic_steps'] % 50 == 0:
            disp = None if _ctrl['disp_ema'] is None else round(float(_ctrl['disp_ema']), 8)
            ref = None if _ctrl['disp_ref'] is None else round(float(_ctrl['disp_ref']), 8)
            row = [receipt['critic_steps'], round(lr, 8), round(network_multiplier(), 6),
                   round(prior_multiplier(), 6), round(handover_weight(), 6),
                   round(float(_ctrl['heat']), 6), round(float(_ctrl['anchor_heat']), 6),
                   round(float(_ctrl['noise_heat']), 6), round(_ctrl['input_std'], 6),
                   round(_ctrl['output_std'], 6), None if _ctrl['last_q'] is None else round(_ctrl['last_q'], 6),
                   None if _ctrl['last_rel'] is None else round(_ctrl['last_rel'], 6),
                   disp, ref, _ctrl['quiet_run'], _ctrl['surprise_run']]
            _ctrl['trace'].append(row)
            print(json.dumps({'sn1': row}), flush=True)
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_heat'] = float(_ctrl['heat'])
    receipt['final_anchor_heat'] = float(_ctrl['anchor_heat'])
    receipt['final_noise_heat'] = float(_ctrl['noise_heat'])
    receipt['final_input_std'] = _ctrl['input_std']
    receipt['final_output_std'] = _ctrl['output_std']
    receipt['floor_seen'] = _ctrl['floor_seen']
    receipt['noise_settled'] = _ctrl['noise_settled']
    receipt['lr_trace'] = _ctrl['trace']
    receipt['trace_columns'] = ['critic_step', 'applied_critic_lr', 'network_mult', 'prior_mult', 's',
                                'heat', 'anchor_heat', 'noise_heat', 'input_std', 'output_std', 'q', 'rel',
                                'disp_ema', 'disp_ref', 'quiet_run', 'surprise_run']
    receipt['budget_dependencies'] = [
        'Applied rates and noise do not read total_steps, noise_horizon, network_lr_horizon_cap, step index, or evaluation scores.',
        'The frozen linear_* and policy_multipliers functions are called and their returns are discarded.',
        'EMA decays, the 30-step score warmup, the 200-step displacement calibration, and the quiet/surprise counters are estimator constants.',
        'Direct-response gain still multiplies direct particle steps and restores the base rate.',
        'Guard warmup of 200 critic steps is the parent estimator constant.',
        'Changing the declared horizon does not enter the formulas. A paired prefix is required to confirm the training state matches.',
    ]
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


def _install_rules():
    import benchmarks.toy100.models as models
    import benchmarks.toy100.schedule as schedule
    original_input = models.linear_input_noise
    original_output = models.linear_output_noise
    original_policy = schedule.policy_multipliers

    def input_noise(peak, completed_steps, total_steps, end_fraction):
        original_input(peak, completed_steps, total_steps, end_fraction)
        return float(_ctrl['input_std'])

    def output_noise(peak, completed_steps, total_steps, warmup_fraction=0.0):
        original_output(peak, completed_steps, total_steps, warmup_fraction)
        return float(_ctrl['output_std'])

    def policy_multipliers(completed_step, total_steps, anneal_start, floor,
                           network_lr_horizon_cap=None, *, network_lr_floor=None):
        original_policy(completed_step, total_steps, anneal_start, floor,
                        network_lr_horizon_cap, network_lr_floor=network_lr_floor)
        return (network_multiplier(), prior_multiplier())

    models.linear_input_noise = input_noise
    models.linear_output_noise = output_noise
    schedule.policy_multipliers = policy_multipliers
    for mod in list(sys.modules.values()):
        if mod is None:
            continue
        for name, value in list(vars(mod).items()):
            if value is original_input:
                setattr(mod, name, input_noise)
            elif value is original_output:
                setattr(mod, name, output_noise)
            elif value is original_policy:
                setattr(mod, name, policy_multipliers)


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
_install_rules()
atexit.register(_write_receipt)
