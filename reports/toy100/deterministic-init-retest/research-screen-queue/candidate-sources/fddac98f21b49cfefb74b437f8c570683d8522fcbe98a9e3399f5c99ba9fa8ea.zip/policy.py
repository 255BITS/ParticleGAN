"""Stationary rates and noise; budget/step arguments are accepted, never inspected."""
import sys, json, atexit
from pathlib import Path
from particlegan import recipes
from benchmarks.toy100 import models, schedule

def rate(*args,**kwargs): return 1.0
def multipliers(*args,**kwargs): return 1.0,1.0
def input_noise(*args,**kwargs): return 0.0
def output_noise(peak,*args,**kwargs): return float(peak)
replacements=[(recipes.learning_rate_scale,rate),(schedule.policy_multipliers,multipliers),(models.linear_input_noise,input_noise),(models.linear_output_noise,output_noise)]
installed=[]
for module in list(sys.modules.values()):
 if module is None or not getattr(module,'__name__','').startswith(('particlegan','benchmarks')):continue
 for name,value in list(vars(module).items()):
  for original,replacement in replacements:
   if value is original:
    setattr(module,name,replacement);installed.append(module.__name__+'.'+name)
def save():
 if '--output' in sys.argv:
  out=Path(sys.argv[sys.argv.index('--output')+1])
  if out.is_dir():(out/'policy-receipt.json').write_text(json.dumps(dict(installed=installed,rule='G/D=.000425; prior=.00085 before inherited direct gain; input0/output.029 stationary; s=0'),indent=2))
atexit.register(save)
