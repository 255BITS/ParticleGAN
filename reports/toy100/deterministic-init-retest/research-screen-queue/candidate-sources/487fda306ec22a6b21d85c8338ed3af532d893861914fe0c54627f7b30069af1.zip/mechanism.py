"""AT3: constant peak rate, slow reference after a tracking warmup.

AT1 damped on critic Adam innovation before 8 modes existed, then reopened the
full rate on one-tensor spikes and collapsed the ring. Max live modes 7.
AT2 damped when the generator gradient fell. That fall happened at 7 modes and
HQ 1.0 around step 500, and the low rate plus the anchor never found the 8th
mode through step 4350.

AT3 keeps the K3P peak rates for the whole run (network multiplier 1, prior
multiplier 1). It does not read a horizon and it does not read gradient
magnitude to cut the step size. The critic mix is decoupled from that constant
rate: K3P's LR-ratio handover would stay at s=1 and leave the anchor off.
Here s=1 only during the existing 200-step guard warmup, with reference alpha
0.05 so the EMA catches the critic. After warmup, s=0 (b_cap + prox) and alpha
is locked at 0.001. A large prox residual does not speed the reference.

Input noise is constant 0. Output noise is the constant configured peak.
The critic guard, particle response, latent rule, and host losses are K3P.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar
import signal_policy

GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ALPHA_FAST = 0.05
ALPHA_SLOW = 0.001

_original_penalty = GradientPenalty.penalty
receipt = {
    'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'rule': 'at3_peak_rate_slow_reference',
    'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
    'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
    'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [],
    'anchor_started_call': None, 'prox_trace': [], 'signal_trace': [],
    'alpha_fast': ALPHA_FAST, 'alpha_slow': ALPHA_SLOW,
    'network_multiplier': 1.0, 'prior_multiplier': 1.0,
    'input_noise': signal_policy.INPUT_NOISE, 'output_noise': 'constant_config_peak',
    'schedule': 'constant_peak_rates_anchor_after_guard_warmup_ignores_horizon',
    'addresses': 'at1 and at2 both cut the rate before the 8th mode; K3P LR-ratio handover would disable the anchor at a constant peak rate',
}
_state = {
    'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None,
    'depth': 0, 'clips': [], 'critic_ref': None, 'mix_s': 1.0, 'alpha': ALPHA_FAST,
    'seen': 0, 'g_rms': None,
}


def handover_weight():
    """1 during guard warmup, else 0. Does not read the applied learning rate."""
    return float(_state['mix_s'])


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _publish_rates():
    signal_policy.state['next_network'] = 1.0
    signal_policy.state['next_prior'] = 1.0


def anchored_gradient_gap(D, x_real, g, dimension):
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
            receipt['extra_critic_forwards'] += 1
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (
                F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _note_generator(opt):
    grads = [p.grad.detach() for p in opt.param_groups[0]['params'] if p.grad is not None]
    if not grads:
        return
    flat = torch.cat([g.flatten() for g in grads])
    _state['g_rms'] = float(flat.square().mean().sqrt())
    _state['seen'] += 1
    if _state['seen'] < GUARD_MIN_STEPS:
        _state['mix_s'] = 1.0
        _state['alpha'] = ALPHA_FAST
    else:
        _state['mix_s'] = 0.0
        _state['alpha'] = ALPHA_SLOW
    _publish_rates()
    if _state['seen'] == 1 or _state['seen'] % 50 == 0:
        row = dict(
            seen=_state['seen'], g_rms=round(_state['g_rms'], 8),
            s=_state['mix_s'], alpha=_state['alpha'],
            network_m=1.0, prior_m=1.0,
        )
        receipt['signal_trace'].append(row)
        print(json.dumps(dict(signal=row)), flush=True)


def _guard(opt, args, kwargs):
    if len(opt.param_groups) >= 2:
        _note_generator(opt)
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        params = _critic_params()
        with torch.no_grad():
            if _state['ema'] is None:
                _state['ema'] = [p.detach().clone() for p in params]
                if receipt['anchor_started_call'] is None:
                    receipt['anchor_started_call'] = receipt['calls']
            else:
                alpha = float(_state['alpha'])
                keep = 1.0 - alpha
                for e, p in zip(_state['ema'], params):
                    e.mul_(keep).add_(p.detach(), alpha=alpha)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_alpha'] = _state['alpha']
    receipt['final_g_rms'] = _state['g_rms']
    receipt['final_network_m'] = signal_policy.state['next_network']
    receipt['final_prior_m'] = signal_policy.state['next_prior']
    receipt['ignored_horizon_calls'] = signal_policy.state['ignored_horizon_calls']
    receipt['noise_calls'] = signal_policy.state['noise_calls']
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
_publish_rates()
