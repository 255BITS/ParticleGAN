"""PN3: K3P penalty and LR handover, noise from a frozen raw-motion peak.

PN1's raw cumulative budget of 1 closed input noise by update 15 and its
instantaneous 3× reopen fired 42 times; the ring never reached 8 modes.
PN2 divided motion by the applied LR. The rate-normalized level stayed above
about 0.15 even at the LR floor, so output noise never reached its peak, and a
late spike raised that peak from 15.2 to 27.5. The ring again stopped at 7 modes.

PN3 tracks raw ||Δθ||/(||θ||), not motion/LR, with a fast EMA (decay 0.9).
The peak freezes the first time that EMA falls below 90% of the highest EMA so
far. Later spikes cannot raise the denominator. Input noise is clip(2*level-1)
and output noise is clip(1-level), so the LR floor can finish output noise.
After output noise has reached 0.98, a separate rate-normalized fast EMA can
raise a residual of at most 0.25 if it exceeds twice the post-precision slow
EMA. One step cannot do that. Rates, mixing s, the anchor and the guard stay
on the K3P rules. total_steps and noise_horizon are validated and ignored.
"""
import atexit, json, math, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
_original_penalty = GradientPenalty.penalty
FAST_DECAY = 0.9
SLOW_DECAY = 0.99
RESIDUAL_CAP = 0.25
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
           'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
           'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'pn3_frozen_raw_peak',
           'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None, 'prox_trace': [],
           'noise': 'raw ||dθ||/||θ|| EMA 0.9 over a peak frozen at the first 10% contraction; input=clip(2*level-1); output=clip(1-level); residual<=0.25 only after output fraction 0.98',
           'fast_decay': FAST_DECAY, 'slow_decay': SLOW_DECAY, 'residual_cap': RESIDUAL_CAP,
           'motion_trace': [], 'early_motion': [], 'peak_frozen_update': None, 'residual_max': 0.0,
           'horizons_seen': [], 'input_zero_update': None, 'output_full_update': None,
           'budget_dependencies': [
               'noise amplitudes do not read total_steps or noise_horizon',
               'K3P network cosine still reads network_lr_horizon_cap 1600, lr_anneal_start and the floors',
               'K3P prior multiplier still reads the host total_steps when the frozen schedule is applied',
               'guard warmup 200 and anchor decay 0.999 are estimator memories, not the training budget',
               'fast decay 0.9 is an estimator memory of about ten updates, not a task horizon',
           ]}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0, 'clips': [], 'critic_ref': None}
_motion = {'before': {}, 'pending_raw': [], 'pending_u': [], 'fast': None, 'scale': None, 'frozen': False,
           'level': 1.0, 'residual': 0.0, 'fast_u': None, 'slow_u': None, 'precise_updates': 0,
           'ever_precise': False, 'updates': 0, 'committed_step': None, 'last_m': None,
           'last_input': None, 'last_output': None}


def handover_weight():
    if _state['lr_last'] is None or _state['lr_max'] <= 0.0:
        return 1.0
    r = _state['lr_last'] / _state['lr_max']
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    receipt['motion_fast'] = _motion['fast']
    receipt['motion_scale'] = _motion['scale']
    receipt['motion_level'] = _motion['level']
    receipt['motion_frozen'] = _motion['frozen']
    receipt['motion_residual'] = _motion['residual']
    receipt['motion_updates'] = _motion['updates']
    receipt['last_input_sigma_fraction'] = _motion['last_input']
    receipt['last_output_sigma_fraction'] = _motion['last_output']
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


def _snap_motion(opt, args, kwargs):
    _motion['before'][id(opt)] = [p.detach().clone() for group in opt.param_groups for p in group['params']]


def _measure_motion(opt, args, kwargs):
    saved = _motion['before'].pop(id(opt), None)
    if not saved:
        return
    raws = []
    units = []
    index = 0
    for group in opt.param_groups:
        lr = max(float(group['lr']), 1e-12)
        for param in group['params']:
            before = saved[index]
            index += 1
            if before.numel() < 8:
                continue
            base = before.square().sum().sqrt()
            delta = (param.detach() - before).square().sum().sqrt()
            raw = delta / (base + 1e-12)
            raws.append(raw)
            units.append(raw / lr)
    if index != len(saved) or not raws:
        return
    _motion['pending_raw'].append(torch.stack(raws).mean().detach())
    _motion['pending_u'].append(torch.stack(units).mean().detach())


def _mean_clear(key):
    pending = _motion[key]
    if not pending:
        return 0.0
    value = float(torch.stack(pending).mean())
    pending.clear()
    return value


def _fractions():
    level = _motion['level']
    residual = _motion['residual']
    input_frac = min(1.0, max(0.0, 2.0 * level - 1.0))
    output_frac = min(1.0, max(0.0, 1.0 - level))
    input_frac = min(1.0, max(input_frac, residual))
    output_frac *= (1.0 - residual)
    return input_frac, output_frac


def _advance_motion():
    raw = _mean_clear('pending_raw')
    unit = _mean_clear('pending_u')
    fast = raw if _motion['fast'] is None else FAST_DECAY * _motion['fast'] + (1.0 - FAST_DECAY) * raw
    if _motion['scale'] is None:
        scale = fast
    elif not _motion['frozen']:
        scale = max(_motion['scale'], fast)
        if fast < 0.9 * scale and _motion['updates'] >= 10:
            _motion['frozen'] = True
            receipt['peak_frozen_update'] = _motion['updates'] + 1
    else:
        scale = _motion['scale']
    level = 0.0 if scale <= 0.0 else min(1.0, fast / scale)
    base_out = min(1.0, max(0.0, 1.0 - level))
    if base_out >= 0.98:
        _motion['ever_precise'] = True
    residual = _motion['residual']
    if _motion['ever_precise']:
        _motion['precise_updates'] += 1
        fast_u = unit if _motion['fast_u'] is None else FAST_DECAY * _motion['fast_u'] + (1.0 - FAST_DECAY) * unit
        slow_u = unit if _motion['slow_u'] is None else SLOW_DECAY * _motion['slow_u'] + (1.0 - SLOW_DECAY) * unit
        _motion['fast_u'] = fast_u
        _motion['slow_u'] = slow_u
        if _motion['precise_updates'] > 50 and slow_u > 0.0 and fast_u > 2.0 * slow_u:
            residual = min(RESIDUAL_CAP, (fast_u / slow_u - 2.0) / 2.0)
        else:
            residual *= FAST_DECAY
    _motion['fast'] = fast
    _motion['scale'] = scale
    _motion['level'] = level
    _motion['residual'] = residual
    receipt['residual_max'] = max(receipt['residual_max'], residual)
    _motion['updates'] += 1
    _motion['last_m'] = raw
    input_frac, output_frac = _fractions()
    _motion['last_input'] = input_frac
    _motion['last_output'] = output_frac
    if _motion['updates'] <= 20:
        receipt['early_motion'].append([_motion['updates'], round(raw, 6), round(level, 6), round(input_frac, 6), round(output_frac, 6)])
    if _motion['updates'] == 1 or _motion['updates'] % 50 == 0:
        row = [_motion['updates'], round(raw, 6), round(fast, 6), round(scale, 6), round(level, 6),
               round(input_frac, 6), round(output_frac, 6), round(residual, 6), int(_motion['frozen'])]
        receipt['motion_trace'].append(row)
        print(json.dumps({'pn3': {'update': row[0], 'raw': row[1], 'fast': row[2], 'scale': row[3], 'level': row[4], 'in': row[5], 'out': row[6], 'resid': row[7], 'frozen': row[8]}}), flush=True)
    if receipt['input_zero_update'] is None and input_frac <= 0.0:
        receipt['input_zero_update'] = _motion['updates']
    if receipt['output_full_update'] is None and output_frac >= 1.0 - 1e-6:
        receipt['output_full_update'] = _motion['updates']


def _sync_motion(completed_steps):
    if type(completed_steps) is not int or completed_steps < 0:
        raise ValueError("invalid input noise step count")
    if _motion['committed_step'] is None:
        if completed_steps != 0:
            raise RuntimeError("motion noise saw a nonzero step before step 0")
        _motion['committed_step'] = 0
        _motion['pending_raw'].clear()
        _motion['pending_u'].clear()
        return
    if completed_steps == _motion['committed_step'] + 1:
        _advance_motion()
        _motion['committed_step'] = completed_steps
    elif completed_steps > _motion['committed_step'] + 1:
        raise RuntimeError(f"motion noise step jumped from {_motion['committed_step']} to {completed_steps}")


def _check_noise_args(peak, completed_steps, total_steps, fraction, *, output):
    if isinstance(peak, bool) or not math.isfinite(peak) or peak < 0:
        raise ValueError("noise std must be finite and nonnegative")
    if type(completed_steps) is not int or completed_steps < 0 or type(total_steps) is not int or total_steps <= 0:
        raise ValueError("invalid noise step count")
    if isinstance(fraction, bool) or not math.isfinite(fraction):
        raise ValueError("invalid noise fraction")
    if output:
        if not 0 <= fraction <= 1:
            raise ValueError("output noise warmup must be a finite fraction in [0, 1]")
    elif not 0 < fraction <= 1:
        raise ValueError("input noise anneal end must be in (0, 1]")
    if total_steps not in receipt['horizons_seen']:
        receipt['horizons_seen'].append(total_steps)


def motion_input_noise(peak, completed_steps, total_steps, end_fraction):
    """On while rate-normalized motion stays above half its peak. total_steps is ignored."""
    _check_noise_args(peak, completed_steps, total_steps, end_fraction, output=False)
    _sync_motion(completed_steps)
    input_frac, _ = _fractions()
    _motion['last_input'] = input_frac
    return float(peak * input_frac)


def motion_output_noise(peak, completed_steps, total_steps, warmup_fraction=0.0):
    """Rise as rate-normalized motion falls below its peak, when warmup is requested.

    A zero warmup stays at the peak, matching the original constant-noise contract.
    total_steps and the warmup fraction do not set a step window.
    """
    _check_noise_args(peak, completed_steps, total_steps, warmup_fraction, output=True)
    if warmup_fraction == 0:
        return float(peak)
    _sync_motion(completed_steps)
    _, output_frac = _fractions()
    _motion['last_output'] = output_frac
    return float(peak * output_frac)


def _patch_noise():
    import benchmarks.toy100.models as toy_models
    old_input = toy_models.linear_input_noise
    old_output = toy_models.linear_output_noise
    toy_models.linear_input_noise = motion_input_noise
    toy_models.linear_output_noise = motion_output_noise
    sites = []
    for module in list(sys.modules.values()):
        if module is None:
            continue
        for attr, value in list(vars(module).items()):
            if value is old_input:
                setattr(module, attr, motion_input_noise)
                sites.append(f"{getattr(module, '__name__', '?')}.{attr}:input")
            elif value is old_output:
                setattr(module, attr, motion_output_noise)
                sites.append(f"{getattr(module, '__name__', '?')}.{attr}:output")
    left = motion_input_noise(0.5, 0, 1200, 0.1)
    right = motion_input_noise(0.5, 0, 7000, 0.1)
    out_left = motion_output_noise(0.029, 0, 1200, 0.2)
    out_right = motion_output_noise(0.029, 0, 4800, 0.2)
    if left != right or left != 0.5 or out_left != out_right or out_left != 0.0:
        raise RuntimeError("motion noise depends on the declared horizon at step 0")
    receipt['noise_horizon_audit'] = {'step': 0, 'horizons': [1200, 7000, 4800], 'input': left, 'output': out_left, 'identical': True}
    receipt['horizons_seen'] = []
    receipt['noise_patch_sites'] = sites


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_snap_motion)
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_measure_motion)
register_optimizer_step_post_hook(_record)
_patch_noise()
atexit.register(_write_receipt)
