"""Observation-only full training-state hashes, called before the benchmark changes data."""
import torch,hashlib,json

def save(out,checkpoint,mechanism,response,latent,game,mobility):
 tensors={}; scalars={}
 def collect(k,v):
  if isinstance(v,torch.Tensor):tensors[k]=v.detach().clone()
  elif isinstance(v,dict):
   for n,x in v.items():collect(k+'/'+str(n),x)
  elif isinstance(v,(list,tuple)):
   for n,x in enumerate(v):collect(k+'/'+str(n),x)
  elif v is None or type(v) in (str,int,float,bool):scalars[k]=v
 ids={id(o):i for i,o in enumerate(checkpoint.optimizers)}
 for i,o in enumerate(checkpoint.optimizers):
  collect(f'optimizer/{i}/state',o.state_dict())
  for gi,g in enumerate(o.param_groups):
   for pi,p in enumerate(g['params']):
    collect(f'parameter/{i}/{gi}/{pi}',p)
    if id(p) in game.history:collect(f'game/{i}/{gi}/{pi}',game.history[id(p)])
 for k,v in mechanism._state.items():
  if k not in ['critic','critic_ref']:collect('critic/'+k,v)
 for (oid,gi),v in response.previous.items():collect(f'response/{ids[oid]}/{gi}',v)
 collect('latent_counts',list(latent.stats.values()))
 for (_,name),frame in checkpoint.frames.items():
  for k,v in frame.f_locals.items():
   if isinstance(v,torch.nn.Module):collect(name+'/'+k,v.state_dict())
   elif isinstance(v,torch.Generator):collect(name+'/'+k+'_rng',v.get_state())
   elif name=='train_mode_hold' and k in ['ema_g','ema_z']:collect(name+'/'+k,v)
   elif v.__class__.__name__=='NoisePolicy':
    collect(name+'/'+k+'/input_stream_rng',v.input_stream.get_state())
    for field in ['input_sigma','output_sigma','_step_calls','_last_sigma','_last_output_sigma','_nonzero_steps','_nonzero_output_steps','_counts']:collect(name+'/'+k+'/'+field,getattr(v,field,None))
 collect('cpu_rng',torch.get_rng_state());collect('cuda_rng',torch.cuda.get_rng_state_all())
 traces=dict(mobility=mobility,mixing=mechanism.receipt['s_trace'],game=[{**r,'optimizer':ids[r['optimizer']]} for r in game.rows])
 hashes={k:hashlib.sha256(v.cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes()).hexdigest() for k,v in tensors.items()}
 metadata={k:dict(device=str(v.device),dtype=str(v.dtype),shape=list(v.shape)) for k,v in tensors.items()}
 torch.save(dict(tensors=tensors,scalars=scalars,traces=traces),out/'pre-shift-state.pt')
 (out/'pre-shift-state.json').write_text(json.dumps(dict(hashes=hashes,metadata=metadata,scalars=scalars,traces=traces),indent=2))
