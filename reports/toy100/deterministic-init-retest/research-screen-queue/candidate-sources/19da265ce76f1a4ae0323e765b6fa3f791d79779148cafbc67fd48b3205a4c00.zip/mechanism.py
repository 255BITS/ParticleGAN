"""lc3: eta-independent secant. lc2 ratcheted to the floor because raw secant scaled with dx.

The host may still write its horizon schedule into param groups. This module
overwrites the LR actually used by Adam and restores the host value after the
update. The controller never reads the training budget, horizon cap, scores,
targets, or shift time.

lc2's raw secant rms(dx)/(2 rms(dg)) fell in proportion to eta, so dividing by
the early reference ratcheted every role to its floor by step ~400 and froze
a 6-mode cover. lc3 calibrates raw/eta, which cancels that step-size factor,
and applies m = clamp((raw/eta) / ref, floor, 1).

After calibration, a positive directional secant may only shrink eta. A
non-positive one holds eta: opponent sign flips were common on lc1 and must
not force the growth bound. Growth is allowed only while the fast gradient RMS
exceeds 1.5 times the slow RMS (a reversible rise, not a timed dwell) and a
positive secant is not asking to shrink. growth = sqrt(1 + eta/eta_prev) * eta.

Critic mixing uses the K3P floor map on eta_critic/base_critic, not the
max-observed host LR. K3P noise stays a horizon-dependent intermediate.
"""
import atexit, json, math, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
PRIOR_FLOOR = 0.05
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
GRAD_NEW = 0.1
ETA_BLEND = 0.05
CALIBRATE_SECANTS = 100
RISE = 1.5
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
           'prior_floor': PRIOR_FLOOR, 'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS,
           'pure_a_calls': 0, 'blend_calls': 0, 'pure_b_calls': 0, 'first_blend_call': None,
           'first_pure_b_call': None, 'critic_steps': 0, 'critic_parameters': None,
           'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'lc3_step_independent_secant',
           'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None, 'prox_trace': [],
           'grad_new': GRAD_NEW, 'eta_blend': ETA_BLEND,
           'calibrate_secants': CALIBRATE_SECANTS, 'rise': RISE,
           'mixing_rule': 'k3p_map(eta_critic/base_critic), not last/max host LR',
           'noise_rule': 'intermediate_k3p_horizon_noise',
           'budget_dependencies': [
               'host input/output noise still follows noise_horizon',
               'host horizon LR is written then overwritten for the Adam update and restored',
           ],
           'rate_trace': [], 'applied_lr_minmax': {}}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None,
          'depth': 0, 'clips': [], 'critic_ref': None, 'apply_rates': False, 'saved_lrs': None,
          'roles': {}, 'hook_handles': {}}


def _role_name(opt, group):
    if group.get('_comparison_prior'):
        return 'prior'
    if len(opt.param_groups) == 1:
        return 'd'
    return 'g'


def _response_gain(group, host_lr):
    if not group.get('_comparison_prior'):
        return 1.0
    import response
    rows = response.receipt.get('rows') or []
    if not rows:
        return 1.0
    last = rows[-1]
    if abs(float(last['effective_lr']) - float(host_lr)) <= 1e-8:
        return float(last['gain'])
    return 1.0


def handover_weight():
    role = _state['roles'].get('d')
    if role is None or role.get('base') is None or role['base'] <= 0.0 or role.get('eta') is None:
        return 1.0
    r = role['eta'] / role['base']
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
        receipt['extra_critic_forwards'] += 1
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _flat(tensors):
    return torch.cat([t.detach().reshape(-1) for t in tensors])


def _advance_role(name, params, grads, host_lr, gain):
    role = _state['roles'].setdefault(name, {
        'base': None, 'eta': None, 'eta_prev': None, 'x': None, 'g_bar': None, 'steps': 0,
        'floor': PRIOR_FLOOR if name == 'prior' else FLOOR,
        'raw_sum': 0.0, 'raw_count': 0, 'raw_ref': None, 'g_fast': None, 'g_slow': None})
    base_host = float(host_lr) / gain if gain else float(host_lr)
    if role['base'] is None:
        flat_g = _flat(grads)
        role['base'] = base_host
        role['eta'] = base_host
        role['eta_prev'] = base_host
        role['x'] = _flat(params)
        role['g_bar'] = flat_g
        g_rms = float(flat_g.square().mean().sqrt())
        role['g_fast'] = g_rms
        role['g_slow'] = g_rms
        role['steps'] = 1
        return role['eta'], None, None, 'init', None
    x = _flat(params)
    g = _flat(grads)
    if x.numel() != role['x'].numel() or g.numel() != role['g_bar'].numel():
        role['x'] = x
        role['g_bar'] = g
        role['steps'] += 1
        return role['eta'], None, None, 'reset', None
    dx = x - role['x']
    g_prev = role['g_bar']
    g_bar = g_prev.mul(1.0 - GRAD_NEW).add(g, alpha=GRAD_NEW)
    dg = (g_bar - g_prev) / GRAD_NEW
    dx_rms = float(dx.square().mean().sqrt())
    dg_rms = float(dg.square().mean().sqrt())
    g_rms = float(g_bar.square().mean().sqrt())
    directional = float(torch.dot(dx, dg))
    role['g_fast'] = 0.9 * role['g_fast'] + 0.1 * g_rms
    role['g_slow'] = 0.99 * role['g_slow'] + 0.01 * g_rms
    eta = role['eta']
    eta_prev = role['eta_prev'] if role['eta_prev'] else eta
    theta = eta / eta_prev if eta_prev > 0.0 else 1.0
    growth = math.sqrt(1.0 + theta) * eta
    lo = role['base'] * role['floor']
    hi = role['base']
    finite = math.isfinite(dx_rms) and math.isfinite(dg_rms) and dx_rms >= 1e-12
    raw = dx_rms / (2.0 * max(dg_rms, 1e-12)) if finite else None
    indep = (raw / eta) if (raw is not None and eta > 0.0 and math.isfinite(raw)) else None
    if role['raw_ref'] is None:
        if finite and directional > 0.0 and indep is not None and math.isfinite(indep):
            role['raw_sum'] += indep
            role['raw_count'] += 1
            if role['raw_count'] >= CALIBRATE_SECANTS:
                role['raw_ref'] = role['raw_sum'] / role['raw_count']
                receipt.setdefault('raw_ref', {})[name] = role['raw_ref']
                receipt.setdefault('calibrated_at_step', {})[name] = role['steps'] + 1
        target = hi
        reason = 'calibrate'
        m_sec = 1.0
    elif not finite:
        target = eta
        reason = 'hold'
        m_sec = eta / hi
    else:
        m_sec = min(1.0, max(role['floor'], (indep or 0.0) / role['raw_ref']))
        secant_eta = m_sec * hi
        rise = role['g_fast'] > RISE * max(role['g_slow'], 1e-12)
        if directional <= 0.0:
            target = min(hi, growth) if rise else eta
            reason = 'rise' if rise else 'nonmonotone'
        elif secant_eta < eta:
            target = secant_eta
            reason = 'shrink'
        elif rise:
            target = min(hi, growth)
            reason = 'rise'
        else:
            target = eta
            reason = 'secant_hold'
    if not math.isfinite(target):
        target = eta
    target = min(hi, max(lo, target))
    eta_next = (1.0 - ETA_BLEND) * eta + ETA_BLEND * target
    eta_next = min(hi, max(lo, eta_next))
    role['eta_prev'] = eta
    role['eta'] = eta_next
    role['x'] = x
    role['g_bar'] = g_bar
    role['steps'] += 1
    info = dict(raw=raw, indep=indep, raw_ref=role['raw_ref'], m=m_sec, g_fast=role['g_fast'], g_slow=role['g_slow'])
    return eta_next, target, dx_rms, reason, info


def _apply_rates(opt, args, kwargs):
    if not _state['apply_rates']:
        return
    _state['apply_rates'] = False
    saved = _state['saved_lrs']
    applied = {}
    detail = {}
    for group, host_lr, gain in saved:
        name = _role_name(opt, group)
        params = [p for p in group['params'] if p.grad is not None]
        if not params:
            continue
        grads = [p.grad for p in params]
        assert all(p.device.type == 'cuda' and g.device.type == 'cuda' for p, g in zip(params, grads))
        eta, proposal, dx_rms, reason, info = _advance_role(name, params, grads, host_lr, gain)
        group['lr'] = float(eta) * float(gain)
        applied[name] = group['lr']
        detail[name] = dict(eta=eta, gain=gain, proposal=proposal, dx_rms=dx_rms, reason=reason,
                            base=_state['roles'][name]['base'], **(info or {}))
        slot = receipt['applied_lr_minmax'].setdefault(name, {'min': group['lr'], 'max': group['lr']})
        slot['min'] = min(slot['min'], group['lr'])
        slot['max'] = max(slot['max'], group['lr'])
    if applied:
        step_no = max(role['steps'] for role in _state['roles'].values())
        if step_no == 1 or step_no % 10 == 0:
            row = dict(step=step_no, applied=applied, s=handover_weight(),
                       reasons={k: v['reason'] for k, v in detail.items()},
                       eta={k: v['eta'] for k, v in detail.items()},
                       m={k: v.get('m') for k, v in detail.items()},
                       raw={k: v.get('raw') for k, v in detail.items()})
            receipt['rate_trace'].append(row)
        if step_no == 1 or step_no % 50 == 0:
            print(json.dumps(dict(lc3=dict(
                step=step_no, applied=applied, s=round(handover_weight(), 6),
                reasons={k: v['reason'] for k, v in detail.items()},
                eta={k: v['eta'] for k, v in detail.items()},
                m={k: v.get('m') for k, v in detail.items()},
                raw={k: v.get('raw') for k, v in detail.items()},
                raw_ref={k: v.get('raw_ref') for k, v in detail.items()}))), flush=True)


def _ensure_last_hook(opt):
    handle = _state['hook_handles'].get(id(opt))
    if handle is None:
        handle = opt.register_step_pre_hook(_apply_rates)
        _state['hook_handles'][id(opt)] = handle
    opt._optimizer_step_pre_hooks.move_to_end(handle.id)


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        # Still schedule a rate overwrite for non-critic optimizers once known,
        # and for every optimizer including the critic. Critic id is learned in _record.
        pass
    _state['depth'] += 1
    if _state['depth'] != 1:
        _state['apply_rates'] = False
        return
    saved = []
    for group in opt.param_groups:
        host_lr = float(group['lr'])
        saved.append((group, host_lr, _response_gain(group, host_lr)))
    _state['saved_lrs'] = saved
    _state['apply_rates'] = True
    _ensure_last_hook(opt)
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    saved = _state['saved_lrs']
    if saved and _state['depth'] == 1:
        for group, host_lr, _gain in saved:
            group['lr'] = host_lr
    if _state['critic'] is None:
        if not _state['pending']:
            _state['depth'] = max(0, _state['depth'] - 1)
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        if _state['depth'] == 0:
            _state['depth'] = 1
    if id(opt) != _state['critic']:
        _state['depth'] = max(0, _state['depth'] - 1)
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        role = _state['roles'].get('d')
        lr = None if role is None else role.get('eta')
        _state['lr_last'] = lr
        if lr is not None:
            _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_eta'] = {name: role.get('eta') for name, role in _state['roles'].items()}
    receipt['final_base'] = {name: role.get('base') for name, role in _state['roles'].items()}
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
