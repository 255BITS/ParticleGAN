"""Reversible gradient-coherence rate control; no task, horizon or score inputs."""
import atexit, json, sys
from pathlib import Path
import torch
BETA = 0.95
state = {}
trace = []
def register(opt):
    for group in opt.param_groups:
        state[id(group)] = dict(base=None, n=0, means=None, power=None)
@torch.no_grad()
def apply(opt):
    for i, group in enumerate(opt.param_groups):
        st=state[id(group)]
        grads=[p.grad.detach() for p in group['params'] if p.grad is not None]
        if not grads: continue
        assert all(g.is_cuda and g.dtype == torch.float32 for g in grads)
        if st['means'] is None:
            st['means']=[torch.zeros_like(g) for g in grads]
            st['power']=torch.zeros((),device=grads[0].device,dtype=torch.float32)
        if st['base'] is None: st['base']=float(group['lr'])
        st['n']+=1
        for m,g in zip(st['means'],grads): m.lerp_(g,1-BETA)
        energy=sum(g.square().sum() for g in grads)
        st['power'].lerp_(energy,1-BETA)
        coherence=(sum(m.square().sum() for m in st['means']) / (st['power']*(1-BETA**st['n'])).clamp_min(1e-30)).clamp(0,1)
        floor=0.05 if group.get('_comparison_prior',False) else 0.01
        factor=floor+(1-floor)*float(coherence)
        group['lr']=st['base']*factor
        trace.append(dict(optimizer=id(opt),group=i,step=st['n'],base=st['base'],coherence=float(coherence),factor=factor,lr=group['lr']))
def write():
    if '--output' not in sys.argv: return
    out=Path(sys.argv[sys.argv.index('--output')+1])
    if out.is_dir():
        ids=list(dict.fromkeys(x['optimizer'] for x in trace))
        for row in trace: row['optimizer']=ids.index(row['optimizer'])
        (out/'controller-trace.json').write_text(json.dumps(trace)+'\n')
atexit.register(write)
