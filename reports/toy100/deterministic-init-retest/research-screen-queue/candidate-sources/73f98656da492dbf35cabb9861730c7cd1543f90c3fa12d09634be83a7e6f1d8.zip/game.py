"""Negative momentum on the previous actual parameter displacement.

Gidel alternating update, applied after the ordinary Adam step:
    x_next = x_adam + beta * (x_t - x_{t-1}),  beta = -0.5
    x_t - x_{t-1} is the previous ACTUAL displacement, which already includes
    that step's beta term. Memory for the next step is x_next - x_t, not the
    raw Adam delta.

This is not GD1. GD1 applied raw + 0.5*(raw - previous_raw) and stored raw.
That extrapolates the change in the Adam proposal. Here the stored vector is
the displacement that remained after the correction, and the coefficient is negative.

Adam moments (exp_avg, exp_avg_sq, step) are written by Adam from the gradient
before this correction and are not edited. The critic EMA update runs after
this correction in the same optimizer post-hook, so the anchor sees corrected
parameters.

Scope, per tensor, each optimizer step:
- Generator and critic network tensors, including a generator-owned output-scale
  tensor if one is present: apply the correction. Alternating order is unchanged.
- Registered ParticlePrior tables: excluded. Inactive sparse rows live on those
  tables and keep the K3P latent rule with no momentum state and no transport
  from this correction.
- Direct-response particles (comparison-prior group, not a ParticlePrior): excluded.
  Their K3P aligned-gradient gain is unchanged.

beta is the single declared coefficient -0.5. No horizon, score, target, or
shift time is read. Inherited K3P learning-rate and noise schedules still are
horizon-dependent; this file does not remove them. Labeled intermediate ablation.
"""
import atexit
import json
import sys
from pathlib import Path

import torch

BETA = -0.5
pending = {}
history = {}
rows = []
player_calls = {}
seen_network = set()
excluded_prior = set()
excluded_direct = set()
corrections = 0
checks = 0


def begin(opt):
    import response
    items = []
    for group in opt.param_groups:
        prior_group = bool(group.get('_comparison_prior', False))
        for p in group['params']:
            if id(p) in response.prior_ids:
                excluded_prior.add(id(p))
                continue
            if prior_group:
                excluded_direct.add(id(p))
                continue
            if p.grad is None:
                continue
            items.append((p, p.detach().clone()))
            seen_network.add(id(p))
    player_calls[id(opt)] = player_calls.get(id(opt), 0) + 1
    pending[id(opt)] = (items, player_calls[id(opt)])


@torch.no_grad()
def finish(opt):
    global corrections, checks
    packed = pending.pop(id(opt), None)
    if packed is None:
        return
    items, player_call = packed
    if not items:
        return
    raw_sq = 0.0
    actual_sq = 0.0
    correction_sq = 0.0
    count = 0
    for p, before in items:
        raw = (p.detach() - before).clone()
        prev = history.get(id(p))
        if prev is not None:
            p.data.add_(prev, alpha=BETA)
            corrections += 1
        actual = (p.detach() - before).clone()
        if prev is not None and (checks < 2 or player_call % 500 == 0):
            expect = raw + prev * BETA
            if not torch.allclose(actual, expect, rtol=1e-5, atol=1e-6):
                raise RuntimeError('actual-displacement recurrence failed')
            checks += 1
        if actual.device.type != 'cuda' or actual.dtype != torch.float32:
            raise RuntimeError('momentum history must stay CUDA FP32')
        history[id(p)] = actual
        raw_sq += float(raw.square().sum())
        actual_sq += float(actual.square().sum())
        if prev is not None:
            correction_sq += float((prev * BETA).square().sum())
        count += actual.numel()
    player = 'generator' if any(g.get('_comparison_prior', False) for g in opt.param_groups) else 'critic'
    rows.append(dict(
        optimizer=id(opt), player=player, call=player_call, tensors=len(items), elements=count,
        raw_l2=raw_sq ** 0.5, actual_l2=actual_sq ** 0.5, correction_l2=correction_sq ** 0.5,
        raw_rms=(raw_sq / count) ** 0.5 if count else 0.0,
        actual_rms=(actual_sq / count) ** 0.5 if count else 0.0,
    ))
    if player_call == 1 or player_call % 400 == 0:
        print(json.dumps(dict(game=rows[-1], beta=BETA)), flush=True)


def write():
    if '--output' not in sys.argv:
        return
    out = Path(sys.argv[sys.argv.index('--output') + 1])
    if not out.is_dir():
        return
    post = [row for row in rows if row['call'] > 2400]
    (out / 'game-trace.json').write_text(json.dumps(dict(
        rule='x_next = x_adam + beta*(x_t-x_previous); memory = actual x_next-x_t; beta=-0.5',
        beta=BETA,
        distinction='GD1 stored raw Adam delta and added +0.5*(raw-previous_raw). This stores the post-correction displacement and adds beta times that actual displacement.',
        adam_moments='unchanged by the correction; Adam writes them from the gradient before the post-hook',
        scope=dict(
            network_tensors=len(seen_network),
            excluded_particle_prior_tensors=len(excluded_prior),
            excluded_direct_response_tensors=len(excluded_direct),
            sparse_rows='excluded with their ParticlePrior table; no per-row momentum',
        ),
        corrections=corrections,
        recurrence_checks=checks,
        history_devices=sorted({str(v.device) for v in history.values()}),
        history_dtypes=sorted({str(v.dtype) for v in history.values()}),
        post_shift_min_actual_rms=(min(row['actual_rms'] for row in post) if post else None),
        post_shift_min_actual_l2=(min(row['actual_l2'] for row in post) if post else None),
        rows=rows,
    )))


atexit.register(write)
