"""Observer-only full learner state fingerprints; never consulted by training."""
import hashlib,json
import torch

def describe(v):
    if isinstance(v,torch.Tensor):
        if v.is_floating_point():assert v.dtype==torch.float32 and v.device.type=='cuda',(v.dtype,v.device)
        raw=v.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes()
        return dict(sha256=hashlib.sha256(raw).hexdigest(),shape=list(v.shape),dtype=str(v.dtype))
    if isinstance(v,dict):return {str(k):describe(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [describe(x) for x in v]
    if v is None or type(v) in (str,int,float,bool):return v
    raise TypeError(type(v).__name__)

def snapshot(v,mechanism,response,latent):
    opt=[v['opt_g'],v['opt_d']];params=[p for o in opt for g in o.param_groups for p in g['params']];noise=v['noise_policy']
    payload=dict(models={n:describe(v[n].state_dict()) for n in ['generator','critic','prior']},gradients=describe([p.grad for p in params]),optimizers=describe([o.state_dict() for o in opt]),generator_ema=describe(v['ema_g']),prior_ema=describe(v['ema_z']),critic_state=describe({k:x for k,x in mechanism._state.items() if k not in ['critic','critic_ref']}),controller=describe(mechanism.control.state),controller_trace=describe(mechanism.control.receipt),latent_counts=list(latent.stats.values()),response_history=describe(list(response.previous.values())),training_rng=describe(v['stream'].get_state()),cpu_rng=describe(torch.get_rng_state()),cuda_rng=describe(torch.cuda.get_rng_state_all()),noise_input_rng=describe(noise.input_stream.get_state()),input_sigma=noise.input_sigma,output_sigma=noise.output_sigma,means=describe(v['means']))
    if getattr(noise,'output_stream',None) is not None:payload['noise_output_rng']=describe(noise.output_stream.get_state())
    encoded=json.dumps(payload,sort_keys=True).encode();return dict(state_sha256=hashlib.sha256(encoded).hexdigest(),state=payload)

def capture_from_frame(path,mechanism,response,latent):
    import inspect
    frame=inspect.currentframe()
    while frame and frame.f_code.co_name!='train_mode_hold':frame=frame.f_back
    assert frame is not None
    payload=snapshot(frame.f_locals,mechanism,response,latent)
    path.write_text(json.dumps(payload,indent=2)+'\n')
    return payload['state_sha256']
