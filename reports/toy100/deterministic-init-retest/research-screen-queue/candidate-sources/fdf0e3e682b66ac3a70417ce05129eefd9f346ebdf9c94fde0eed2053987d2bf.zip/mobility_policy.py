"""pm1: separate network and learned-prior mobility after a joint acquire latch.

The host cosine is not the applied rate. This function ignores total_steps,
anneal_start, floor, the horizon cap, and the network floor except that
completed_step is a memo key so the post-step rate check sees the applied
multipliers. K3P input/output noise stays on the driver's frozen noise horizon
of 1200. That noise is a labeled scheduled ablation, not part of this controller.

Acquire: both multipliers stay at 1 until the 0.98 EMA of the concatenated
generator+prior gradient RMS falls below 0.05 of its own peak (peak at least
0.005), confirmed by a 0.9 leak above 0.5. That is the collapse measured when
the ring first reached HQ 1. Neither role damps before that latch.

After the latch, each role dwells at 0.10 of its initial rate and reopens to
0.25 when its own raw gradient RMS exceeds five times its own quiet floor.
The floor creeps only while dwelling. It is frozen during a reopen. The return
to dwell compares RMS with that frozen floor, not with the lifetime peak.
Critic mixing follows the K3P map of the network multiplier, except while
acquired and dwelling at the dwell rate: then s is 0 so the EMA anchor stays
fully on. A rate reopen (adapt) follows the map again. s is never last/max LR.
"""
from benchmarks.toy100 import schedule

DWELL = 0.10
ADAPT = 0.25
RATIO_DWELL = 0.05
REOPEN_FACTOR = 5.0
CONFIRM_DECAY = 0.9
SLEW = 0.9
PEAK_MIN = 0.005
QUIET_DECAY = 0.98
MIX_FLOOR = 0.01

def _role():
    return {'m': 1.0, 'phase': 'acquire', 'peak': 0.0, 'quiet': None,
            'floor': None, 'rms': None, 'confirm': 0.0}

roles = {'network': _role(), 'prior': _role()}
joint = {'peak': 0.0, 'quiet': None, 'rms': None, 'confirm': 0.0, 'ratio': 1.0}
state = {
    'acquired': False,
    'accept': False,
    'observe_calls': 0,
    'observe_skips': 0,
    'cache': {},
    'trace': [],
    'last': (1.0, 1.0),
    'ignored_total_steps': None,
    'ignored_cap': None,
}


def mixing_weight(multiplier=None):
    m = roles['network']['m'] if multiplier is None else float(multiplier)
    # Settled dwell only. The slew down from acquire, and a later adapt reopen,
    # still use the K3P map so the anchor is not forced on at a high rate.
    if (state['acquired'] and roles['network']['phase'] == 'dwell'
            and roles['network']['m'] <= DWELL + 0.02):
        return 0.0
    return max(0.0, min(1.0, 2.0 * m) - 2.0 * MIX_FLOOR) / (1.0 - 2.0 * MIX_FLOOR)


def _track(bucket, rms):
    bucket['rms'] = float(rms)
    bucket['peak'] = max(bucket['peak'], float(rms))
    if bucket['quiet'] is None:
        bucket['quiet'] = float(rms)
    else:
        bucket['quiet'] = QUIET_DECAY * bucket['quiet'] + (1.0 - QUIET_DECAY) * float(rms)


def _slew(role, target):
    role['m'] = SLEW * role['m'] + (1.0 - SLEW) * target


def _confirm(role, flag):
    role['confirm'] = CONFIRM_DECAY * role['confirm'] + (1.0 - CONFIRM_DECAY) * (1.0 if flag else 0.0)


def _dwell_or_adapt(role):
    rms = role['rms']
    if role['phase'] == 'dwell':
        if role['floor'] is None:
            role['floor'] = role['quiet']
        elif rms < role['floor']:
            role['floor'] = 0.98 * role['floor'] + 0.02 * rms
        else:
            role['floor'] = 0.999 * role['floor'] + 0.001 * rms
        hot = role['floor'] is not None and role['floor'] > 0.0 and rms > REOPEN_FACTOR * role['floor']
        _confirm(role, hot)
        if role['confirm'] > 0.5:
            role['phase'] = 'adapt'
            role['confirm'] = 0.0
        _slew(role, ADAPT if role['phase'] == 'adapt' else DWELL)
        return
    cool = role['floor'] is not None and role['floor'] > 0.0 and rms < REOPEN_FACTOR * role['floor']
    _confirm(role, cool)
    if role['confirm'] > 0.5:
        role['phase'] = 'dwell'
        role['confirm'] = 0.0
        _slew(role, DWELL)
    else:
        _slew(role, ADAPT)


def observe(net_rms, prior_rms, joint_rms):
    if not state['accept']:
        state['observe_skips'] += 1
        return
    state['accept'] = False
    state['observe_calls'] += 1
    _track(roles['network'], net_rms)
    _track(roles['prior'], prior_rms)
    _track(joint, joint_rms)
    call = state['observe_calls']
    if not state['acquired']:
        peak = joint['peak']
        quiet = joint['quiet']
        ratio = (quiet / peak) if peak > 0.0 else 1.0
        joint['ratio'] = ratio
        cool = peak >= PEAK_MIN and ratio < RATIO_DWELL
        joint['confirm'] = CONFIRM_DECAY * joint['confirm'] + (1.0 - CONFIRM_DECAY) * (1.0 if cool else 0.0)
        for role in roles.values():
            role['m'] = 1.0
            role['phase'] = 'acquire'
        if joint['confirm'] > 0.5:
            state['acquired'] = True
            for role in roles.values():
                role['phase'] = 'dwell'
                role['floor'] = role['quiet']
                role['confirm'] = 0.0
                _slew(role, DWELL)
    else:
        joint['ratio'] = (joint['quiet'] / joint['peak']) if joint['peak'] > 0.0 else 1.0
        _dwell_or_adapt(roles['network'])
        _dwell_or_adapt(roles['prior'])
    if call == 1 or call % 50 == 0 or state['acquired'] and call < 5:
        _trace(call)


def _trace(call):
    state['trace'].append({
        'call': call,
        'acquired': state['acquired'],
        'joint_rms': joint['rms'],
        'joint_quiet': joint['quiet'],
        'joint_peak': joint['peak'],
        'joint_ratio': joint['ratio'],
        'joint_confirm': joint['confirm'],
        'network_m': roles['network']['m'],
        'network_phase': roles['network']['phase'],
        'network_rms': roles['network']['rms'],
        'network_floor': roles['network']['floor'],
        'prior_m': roles['prior']['m'],
        'prior_phase': roles['prior']['phase'],
        'prior_rms': roles['prior']['rms'],
        'prior_floor': roles['prior']['floor'],
        's': mixing_weight(),
    })


def multipliers(completed_step, total_steps, anneal_start, floor, network_lr_horizon_cap=None, *, network_lr_floor=None):
    if type(completed_step) is not int:
        raise ValueError('completed_step must be an int memo key')
    cached = state['cache'].get(completed_step)
    if cached is not None:
        return cached
    result = (float(roles['network']['m']), float(roles['prior']['m']))
    state['cache'][completed_step] = result
    state['last'] = result
    state['accept'] = True
    state['ignored_total_steps'] = total_steps
    state['ignored_cap'] = network_lr_horizon_cap
    return result


def snapshot():
    return {
        'acquired': state['acquired'],
        'observe_calls': state['observe_calls'],
        'observe_skips': state['observe_skips'],
        'last_multiplier': state['last'],
        'network': dict(roles['network']),
        'prior': dict(roles['prior']),
        'joint': dict(joint),
        'ignored_total_steps': state['ignored_total_steps'],
        'ignored_cap': state['ignored_cap'],
        'trace': state['trace'],
        'dwell': DWELL,
        'adapt': ADAPT,
        'ratio_dwell': RATIO_DWELL,
        'reopen_factor': REOPEN_FACTOR,
        'mix_floor': MIX_FLOOR,
        'final_s': mixing_weight(),
    }


schedule.policy_multipliers = multipliers
