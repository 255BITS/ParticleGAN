"""SN2: SN1 noise and anchor, plus a reversible rate driven by critic reversal.

SN1 held the anchor on and let input noise fall to zero, then lost the ring
33 updates after convergence because G/D stayed at the full base rate 0.00425.
This copy keeps that noise rule and that anchor. The base multiplier is no
longer frozen at 1. A critic-gradient cosine EMA (decay 0.9, a memory
constant) sets

    calm = 1 - ema(relu(-cosine))
    network_mult = 0.01 + 0.99 * calm
    prior_mult   = 0.05 + 0.95 * calm

Aligned or not-yet-seen gradients keep the full base rate. Sustained reversal
moves the rates to the parent's holding floors, and a later aligned run moves
them back. The map does not read total_steps. The frozen policy_multipliers
is still called, and its horizon-dependent return value is discarded. The
value actually applied is cached per step index so a later audit of that same
index matches the rate used.

Parent K3P is unchanged on disk. This copy changes three declared rules:

1. Optimizer policy. See the reversal map above. Config floors stay at 1 so an
   unpatched schedule would be a constant ceiling; the patched multiplier is
   what training uses. Direct-particle response gain still multiplies direct
   particles after this base rate. The critic mix does not read the LR.

2. Critic anchor. s = 0.5 * scale, scale in [0, 1], so the EMA prox term's
   weight 1-s stays in [0.5, 1] on every penalty call, including step 0.
   scale is 1 until the critic Adam second moment yields a finite surprise
   ratio, then scale = clip((ratio - 1) / (GUARD_C - 1), 0, 1),
   ratio = grad RMS / sqrt(bias-corrected v). No LR ratio, no total_steps,
   no convergence flag. High surprise reopens the early penalty halfway;
   a calm critic uses b_cap + the EMA anchor only. The move reverses when
   the ratio falls.

3. Noise. Output amplitude is the declared peak on every step (warmup is
   ignored after validation). Input amplitude is input_peak * scale, the same
   surprise scale. K3P's linear decay to zero is validated, then discarded.
   observation_sigma stays the constant host term 0.03. No noise-amplitude
   search: the only amplitudes are the parent's declared peaks, and the only
   gate is the parent's existing guard ratio.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
           'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
           'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'sn2', 'anchor_decay': ANCHOR_DECAY,
           'anchor_started_call': None, 'prox_trace': [],
           'handover': 's=0.5*adam_surprise_scale; anchor weight 1-s always in [0.5,1]; LR clock unused',
           'noise_rule': 'input=input_peak*scale; output=output_peak constant; observation_sigma host constant 0.03',
           'optimizer_policy': 'network=0.01+0.99*calm, prior=0.05+0.95*calm, calm=1-ema_0.9(relu(-critic_grad_cosine)); direct-response gain retained'}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0, 'clips': [], 'critic_ref': None}
_rate_state = {'flip_ema': 0.0, 'last_cosine': None, 'cosine_updates': 0, 'prev_grad': None, 'multiplier_cache': {}}
# scale stays at the ceiling until a finite critic Adam surprise exists. That is estimator availability, not a step budget.
_noise_state = {'scale': 1.0, 'surprise_ratio': None, 'scale_updates': 0, 'last_input_sigma': None,
                'last_output_sigma': None, 'input_calls': 0, 'output_calls': 0, 'lr_trace': []}


def handover_weight():
    """Always-on anchor. Does not read LR, step index, or total_steps."""
    scale = float(_noise_state['scale'])
    if not 0.0 <= scale <= 1.0:
        raise RuntimeError('surprise scale left [0, 1]')
    return 0.5 * scale


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(float(_noise_state['scale']), 6),
                                   None if _noise_state['last_input_sigma'] is None else round(_noise_state['last_input_sigma'], 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    finite = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
            if bool(torch.isfinite(ratio).detach()):
                finite.append(float(ratio.detach()))
    if finite:
        surprise = max(finite)
        excess = max(0.0, surprise - 1.0)
        _noise_state['scale'] = min(1.0, excess / (GUARD_C - 1.0))
        _noise_state['surprise_ratio'] = surprise
        _noise_state['scale_updates'] += 1
    parts = [p.grad.detach().reshape(-1) for group in opt.param_groups for p in group['params'] if p.grad is not None]
    if parts:
        vec = torch.cat(parts)
        prev = _rate_state['prev_grad']
        if prev is not None and prev.shape == vec.shape:
            cos = float(F.cosine_similarity(vec, prev, dim=0, eps=1e-12))
            _rate_state['flip_ema'] = 0.9 * _rate_state['flip_ema'] + 0.1 * max(0.0, -cos)
            _rate_state['last_cosine'] = cos
            _rate_state['cosine_updates'] += 1
        _rate_state['prev_grad'] = vec
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
        if receipt['critic_steps'] == 1 or receipt['critic_steps'] % 50 == 0:
            calm = min(1.0, max(0.0, 1.0 - float(_rate_state['flip_ema'])))
            _noise_state['lr_trace'].append([receipt['critic_steps'], lr, round(_noise_state['scale'], 6),
                                              None if _noise_state['surprise_ratio'] is None else round(_noise_state['surprise_ratio'], 6),
                                              round(0.01 + 0.99 * calm, 6), round(0.05 + 0.95 * calm, 6),
                                              round(_rate_state['flip_ema'], 6)])
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['noise_state'] = {k: _noise_state[k] for k in ('scale', 'surprise_ratio', 'scale_updates', 'last_input_sigma', 'last_output_sigma', 'input_calls', 'output_calls')}
    receipt['lr_trace'] = _noise_state['lr_trace']
    receipt['rate_state'] = {k: _rate_state[k] for k in ('flip_ema', 'last_cosine', 'cosine_updates')}
    receipt['multiplier_cache_entries'] = len(_rate_state['multiplier_cache'])
    receipt['budget_dependencies'] = [
        'Returned input/output amplitudes do not use total_steps, noise_horizon, or anneal fractions.',
        'Those integers are still passed into the frozen validators and NoisePolicy constructor.',
        'policy_multipliers is still called with total_steps and network_lr_horizon_cap; that return value is discarded.',
        'Applied network/prior multipliers are the reversal map, cached by step index, not by the horizon.',
        'Direct-response gain multiplies direct particle steps from gradient alignment and restores the base rate.',
        'Guard estimator warmup of 200 critic steps and the 0.9 cosine EMA are memory constants, not a training horizon.',
    ]
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


def _install_noise_rule():
    """Replace horizon anneals after validation. Later imports bind these wrappers."""
    import benchmarks.toy100.models as models
    original_input = models.linear_input_noise
    original_output = models.linear_output_noise

    def input_noise(peak, completed_steps, total_steps, end_fraction):
        original_input(peak, completed_steps, total_steps, end_fraction)
        sigma = float(peak) * float(_noise_state['scale'])
        _noise_state['last_input_sigma'] = sigma
        _noise_state['input_calls'] += 1
        return sigma

    def output_noise(peak, completed_steps, total_steps, warmup_fraction=0.0):
        original_output(peak, completed_steps, total_steps, warmup_fraction)
        _noise_state['last_output_sigma'] = float(peak)
        _noise_state['output_calls'] += 1
        return float(peak)

    models.linear_input_noise = input_noise
    models.linear_output_noise = output_noise
    import benchmarks.toy100.schedule as schedule
    original_policy = schedule.policy_multipliers

    def policy_multipliers(completed_step, total_steps, anneal_start, floor,
                           network_lr_horizon_cap=None, *, network_lr_floor=None):
        original_policy(completed_step, total_steps, anneal_start, floor,
                        network_lr_horizon_cap, network_lr_floor=network_lr_floor)
        cached = _rate_state['multiplier_cache'].get(completed_step)
        if cached is None:
            calm = min(1.0, max(0.0, 1.0 - float(_rate_state['flip_ema'])))
            cached = (0.01 + 0.99 * calm, 0.05 + 0.95 * calm)
            _rate_state['multiplier_cache'][completed_step] = cached
        return cached

    schedule.policy_multipliers = policy_multipliers
    for mod in list(sys.modules.values()):
        if mod is None:
            continue
        for name, value in list(vars(mod).items()):
            if value is original_input:
                setattr(mod, name, input_noise)
            elif value is original_output:
                setattr(mod, name, output_noise)
            elif value is original_policy:
                setattr(mod, name, policy_multipliers)


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
_install_noise_rule()
atexit.register(_write_receipt)
