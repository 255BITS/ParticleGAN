"""NS2: paced floor plus shock recharge. Same K3P penalty, anchor, and guard.

NS1 kept the critic LR near 0.00414 and the mix at s=1 for all 6300 updates.
Critic-gradient cosine kept flipping sign, so slow cosine never reached -0.5,
heat stayed 0.97, and the EMA anchor never started (pure_a=6300, blend=0,
pure_b=0). The ring never held 8 modes (max 7) and the settling gate failed
4800/4800. Full rate was the measured failure, same pattern as stationary-noise
SN1. Cosine is not a floor signal on this problem.

This copy still does not read total_steps, the horizon cap, eval scores, or
shift times. Three rules:

1. Rate. pace = 0.9995*pace + 0.0005 from 0 (memory, not a budget). While
   pace < 0.40 the multiplier heat stays at 1, so the base rates run for the
   same early window the parent spends at full rate. After that,
   heat = 0.994*heat, which reaches the parent floors without a cosine gate.
   network = 0.01 + 0.99*heat, prior = 0.05 + 0.95*heat.
   A shock recharges heat by 0.08*shock, shock in [0,1], so one noisy step
   cannot restore full rate and a sustained jump can. Shock is
   clip((rms/env - 1.5)/1.5, 0, 1), where rms is the critic parameter-gradient
   RMS and env rises with weight 0.05 and falls with weight 0.01.
   The frozen policy_multipliers return value is discarded.

2. Anchor mix, not the LR clock. s = min(1, heat/0.5). Pure a_r1r2 at heat>=0.5
   and pure b_cap + EMA prox at heat=0. Constant LR would still move s.

3. Noise. burst starts at 1. burst = clip(0.98*burst + 0.20*shock, 0, 1).
   input = parent_peak * burst, output = parent_peak * (1-burst). Positive
   cosine no longer recharges noise. observation_sigma stays 0.03.

Guard stays 5x after 200 critic steps. Anchor decay stays 0.999. Particle
prior, direct response, and sparse latent hooks are the K3P copies.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
PRIOR_FLOOR = 0.05
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
           'prior_floor': PRIOR_FLOOR, 'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS,
           'pure_a_calls': 0, 'blend_calls': 0, 'pure_b_calls': 0, 'first_blend_call': None,
           'first_pure_b_call': None, 'critic_steps': 0, 'critic_parameters': None,
           'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'ns2_paced_floor',
           'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None, 'prox_trace': [],
           'handover': 's=min(1, heat/0.5); heat leaks after pace memory crosses 0.40; LR clock unused',
           'noise_rule': 'burst=clip(0.98*burst+0.20*shock,0,1) from 1; input=peak*burst; output=peak*(1-burst)',
           'optimizer_policy': 'network=0.01+0.99*heat; prior=0.05+0.95*heat; heat=1 until pace>=0.40 then *0.994, plus 0.08*shock'}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0, 'clips': [], 'critic_ref': None}
_rate_state = {'heat': None, 'pace': None, 'burst': None, 'env': None, 'shock': None, 'rms': None,
               'multiplier_cache': {}, 'trace': []}


def _num(value, default):
    return default if value is None else float(value)


def current_heat():
    return _num(_rate_state['heat'], 1.0)


def current_burst():
    return _num(_rate_state['burst'], 1.0)


def multipliers_now():
    heat = current_heat()
    return (FLOOR + (1.0 - FLOOR) * heat, PRIOR_FLOOR + (1.0 - PRIOR_FLOOR) * heat)


def handover_weight():
    """Early penalty until heat falls through 1/2, then the EMA anchor. No LR read."""
    return min(1.0, current_heat() / 0.5)


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    receipt['extra_critic_forwards'] += 1
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(current_heat(), 6), round(current_burst(), 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _update_control(vec):
    rms = vec.detach().square().mean().sqrt()
    env = _rate_state['env']
    if env is None:
        env = rms.clone()
    else:
        env = torch.where(rms > env, env * 0.95 + rms * 0.05, env * 0.99 + rms * 0.01)
    shock = ((rms / env.clamp_min(1e-12) - 1.5) / 1.5).clamp(0, 1)
    pace = _rate_state['pace']
    heat = _rate_state['heat']
    burst = _rate_state['burst']
    if pace is None:
        pace = rms.new_zeros(())
        heat = rms.new_ones(())
        burst = rms.new_ones(())
    pace = pace * 0.9995 + 0.0005
    heat = torch.where(pace >= 0.40, heat * 0.994, heat)
    heat = (heat + shock * 0.08).clamp(0, 1)
    burst = (burst * 0.98 + shock * 0.20).clamp(0, 1)
    _rate_state['env'] = env
    _rate_state['pace'] = pace
    _rate_state['heat'] = heat
    _rate_state['burst'] = burst
    _rate_state['shock'] = shock
    _rate_state['rms'] = rms


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    parts = [p.grad.detach().reshape(-1) for group in opt.param_groups for p in group['params'] if p.grad is not None]
    if parts:
        _update_control(torch.cat(parts))
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
        if receipt['critic_steps'] == 1 or receipt['critic_steps'] % 50 == 0:
            row = [receipt['critic_steps'], round(lr, 8), round(current_heat(), 6), round(handover_weight(), 6),
                   None if _rate_state['pace'] is None else round(float(_rate_state['pace']), 6),
                   None if _rate_state['shock'] is None else round(float(_rate_state['shock']), 6),
                   round(current_burst(), 6),
                   None if _rate_state['rms'] is None else round(float(_rate_state['rms']), 6)]
            _rate_state['trace'].append(row)
            print(json.dumps({'ns2': row}), flush=True)
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_heat'] = current_heat()
    receipt['final_burst'] = current_burst()
    network, prior = multipliers_now()
    receipt['final_multipliers'] = [network, prior]
    receipt['lr_trace'] = _rate_state['trace']
    receipt['trace_columns'] = ['critic_step', 'applied_critic_lr', 'heat', 's', 'pace', 'shock', 'burst', 'grad_rms']
    receipt['multiplier_cache_entries'] = len(_rate_state['multiplier_cache'])
    receipt['budget_dependencies'] = [
        'Applied input/output amplitudes and rate multipliers do not use total_steps, noise_horizon, anneal fractions, or network_lr_horizon_cap.',
        'Those integers are still passed into the frozen validators. linear_* and policy_multipliers are called and their schedule returns are discarded.',
        'network_lr_horizon_cap stays in the config because the frozen policy requires it beside a network floor.',
        'pace is a fixed 0.9995 memory. It does not read the declared horizon. Changing total_steps or the cap does not change pace.',
        'Direct-response gain still multiplies direct particle steps from particle-gradient alignment and restores the base rate.',
        'Guard warmup of 200 critic steps is an estimator constant, not a training horizon.',
    ]
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


def _install_rules():
    """Validate the frozen schedules, then replace their returned amplitudes."""
    import benchmarks.toy100.models as models
    import benchmarks.toy100.schedule as schedule
    original_input = models.linear_input_noise
    original_output = models.linear_output_noise
    original_policy = schedule.policy_multipliers

    def input_noise(peak, completed_steps, total_steps, end_fraction):
        original_input(peak, completed_steps, total_steps, end_fraction)
        return float(peak) * current_burst()

    def output_noise(peak, completed_steps, total_steps, warmup_fraction=0.0):
        original_output(peak, completed_steps, total_steps, warmup_fraction)
        return float(peak) * (1.0 - current_burst())

    def policy_multipliers(completed_step, total_steps, anneal_start, floor,
                           network_lr_horizon_cap=None, *, network_lr_floor=None):
        original_policy(completed_step, total_steps, anneal_start, floor,
                        network_lr_horizon_cap, network_lr_floor=network_lr_floor)
        cached = _rate_state['multiplier_cache'].get(completed_step)
        if cached is None:
            cached = multipliers_now()
            _rate_state['multiplier_cache'][completed_step] = cached
        return cached

    models.linear_input_noise = input_noise
    models.linear_output_noise = output_noise
    schedule.policy_multipliers = policy_multipliers
    for mod in list(sys.modules.values()):
        if mod is None:
            continue
        for name, value in list(vars(mod).items()):
            if value is original_input:
                setattr(mod, name, input_noise)
            elif value is original_output:
                setattr(mod, name, output_noise)
            elif value is original_policy:
                setattr(mod, name, policy_multipliers)


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
_install_rules()
atexit.register(_write_receipt)
