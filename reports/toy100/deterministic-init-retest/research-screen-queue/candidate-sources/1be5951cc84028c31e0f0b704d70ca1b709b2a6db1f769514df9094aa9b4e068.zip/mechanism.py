"""SN2: absolute score-gap noise burn-in, grad-level rate leak. K3P penalty.

SN1 kept input noise at 0.5 through step 3800. Its quiet test was
|q_fast-q_slow| / ema|q| < 0.05. The gap itself was already ~0.01, so the
ratio stayed large, quiet_run never lasted, and live modes stayed at or below 5.
Displacement had already fallen while the ring was still uncovered, so it is
not used as a floor trigger (that is the ns2 failure).

Noise does not read a step horizon. q_noise = 0.8 q_noise + 0.2 q.
dev = |q - q_noise| before the update.
After 10 critic penalties, dev <= 0.08 multiplies noise_base by 0.955.
dev > 0.08 pauses the burn-in. After noise_base < 0.05, fifteen consecutive
steps with dev > 0.08 add at most 0.08 of noise_reopen (0.98/0.02), else the
reopen leaks by 0.98. input std = 0.5 * min(1, noise_base+reopen).
output std = 0.029 * (1 - that heat).

Rate uses critic grad RMS, not the score ratio. g_fast = 0.9 g_fast + 0.1 rms.
g_peak is the max of g_fast over the first 200 critic steps, then frozen.
After that, g_fast < 0.15 * g_peak starts a leak heat *= 0.996 down to 0.
Network multiplier = 0.01 + 0.99*heat. Prior = 0.05 + 0.95*heat.
The 0.15 fraction is the ns3 ring trace's late-acquisition drop (RMS fell
through ~0.15 of its early peak between steps 800 and 1000), not a grid.

Once heat < 0.05, 25 consecutive steps with dev > 0.05 set
heat = 0.995*heat + 0.005*0.22 instead of the leak. The leak resumes when
that run breaks. anchor_heat increases only while heat > 0.5 and otherwise
multiplies by 0.995. s is the K3P handover of r = 0.01 + 0.99*anchor_heat,
so the moderate reopen does not restore a_r1r2.

Host linear schedules and policy_multipliers are called and discarded.
Guard 5x after 200 and anchor decay 0.999 are unchanged.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
PRIOR_FLOOR = 0.05
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
INPUT_PEAK = 0.5
OUTPUT_PEAK = 0.029
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'extra_score_forwards': 0,
           'floor': FLOOR, 'prior_floor': PRIOR_FLOOR, 'guard_c': GUARD_C,
           'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
           'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [],
           'rule': 'sn2_absolute_gap_noise', 'anchor_decay': ANCHOR_DECAY,
           'anchor_started_call': None, 'prox_trace': [],
           'handover': 's from anchor_heat; anchor_heat moves up only when heat > 0.5',
           'noise_rule': 'noise_base *= 0.955 when |q-q_noise|<=0.08 else pause; reopen capped at 0.08',
           'optimizer_policy': 'leak heat*=0.996 after g_fast<0.15*g_peak; reopen equilibrium 0.22'}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0,
          'clips': [], 'critic_ref': None}
_ctrl = {'q_noise': None, 'dev': None, 'noise_base': 1.0, 'noise_reopen': 0.0, 'noise_hi': 0,
         'rate_hi': 0, 'heat': 1.0, 'anchor_heat': 1.0, 'g_fast': None, 'g_peak': None,
         'pending_rms': None, 'decaying': False, 'floor_seen': False,
         'input_std': INPUT_PEAK, 'output_std': 0.0, 'last_q': None, 'trace': []}


def handover_weight():
    r = FLOOR + (1.0 - FLOOR) * float(_ctrl['anchor_heat'])
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def network_multiplier():
    return FLOOR + (1.0 - FLOOR) * float(_ctrl['heat'])


def prior_multiplier():
    return PRIOR_FLOOR + (1.0 - PRIOR_FLOOR) * float(_ctrl['heat'])


def _noise_heat():
    return min(1.0, float(_ctrl['noise_base']) + float(_ctrl['noise_reopen']))


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _update_noise(q):
    q = q.detach().to(dtype=torch.float32)
    _ctrl['last_q'] = float(q)
    if _ctrl['q_noise'] is None:
        _ctrl['q_noise'] = q.clone()
        _ctrl['dev'] = q.new_zeros(())
        return
    dev = (q - _ctrl['q_noise']).abs()
    _ctrl['q_noise'] = _ctrl['q_noise'] * 0.8 + q * 0.2
    _ctrl['dev'] = dev
    if receipt['calls'] <= 10:
        return
    dev_f = float(dev)
    if dev_f <= 0.08:
        _ctrl['noise_base'] *= 0.955
    if _ctrl['noise_base'] < 0.05 and dev_f > 0.08:
        _ctrl['noise_hi'] += 1
    else:
        _ctrl['noise_hi'] = 0
    if _ctrl['noise_hi'] >= 15:
        _ctrl['noise_reopen'] = min(0.08, _ctrl['noise_reopen'] * 0.98 + 0.02)
    else:
        _ctrl['noise_reopen'] *= 0.98
    _ctrl['noise_base'] = min(1.0, max(0.0, float(_ctrl['noise_base'])))
    heat = _noise_heat()
    _ctrl['input_std'] = INPUT_PEAK * heat
    _ctrl['output_std'] = OUTPUT_PEAK * (1.0 - heat)


def _update_rate():
    rms = _ctrl['pending_rms']
    if rms is None:
        return
    rms_f = float(rms)
    if _ctrl['g_fast'] is None:
        _ctrl['g_fast'] = rms_f
    else:
        _ctrl['g_fast'] = 0.9 * _ctrl['g_fast'] + 0.1 * rms_f
    if receipt['critic_steps'] <= 200:
        peak = _ctrl['g_peak']
        _ctrl['g_peak'] = _ctrl['g_fast'] if peak is None else max(peak, _ctrl['g_fast'])
    elif _ctrl['g_peak'] and _ctrl['g_fast'] < 0.15 * _ctrl['g_peak']:
        _ctrl['decaying'] = True
    dev = _ctrl['dev']
    dev_f = 0.0 if dev is None else float(dev)
    if _ctrl['floor_seen'] and dev_f > 0.05:
        _ctrl['rate_hi'] += 1
    else:
        _ctrl['rate_hi'] = 0
    if _ctrl['floor_seen'] and _ctrl['rate_hi'] >= 25:
        _ctrl['heat'] = _ctrl['heat'] * 0.995 + 0.005 * 0.22
    elif _ctrl['decaying']:
        _ctrl['heat'] *= 0.996
    _ctrl['heat'] = min(1.0, max(0.0, float(_ctrl['heat'])))
    if _ctrl['heat'] < 0.05:
        _ctrl['floor_seen'] = True
    if _ctrl['heat'] > 0.5:
        _ctrl['anchor_heat'] = min(1.0, _ctrl['anchor_heat'] + 0.005)
    else:
        _ctrl['anchor_heat'] *= 0.995


def anchored_gradient_gap(D, x_real, g, dimension):
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    receipt['extra_critic_forwards'] += 1
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    with torch.no_grad():
        q = D(x_real.detach()).mean() - D(x_fake.detach()).mean()
    receipt['extra_score_forwards'] += 2
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    receipt['calls'] += 1
    _update_noise(q)
    s = handover_weight()
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(float(_ctrl['heat']), 6),
                                   round(_noise_heat(), 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    parts = [p.grad.detach().reshape(-1) for group in opt.param_groups for p in group['params'] if p.grad is not None]
    if parts:
        _ctrl['pending_rms'] = torch.cat(parts).square().mean().sqrt()
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        _update_rate()
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
        if receipt['critic_steps'] == 1 or receipt['critic_steps'] % 50 == 0:
            dev = None if _ctrl['dev'] is None else round(float(_ctrl['dev']), 6)
            row = [receipt['critic_steps'], round(lr, 8), round(network_multiplier(), 6),
                   round(prior_multiplier(), 6), round(handover_weight(), 6),
                   round(float(_ctrl['heat']), 6), round(float(_ctrl['anchor_heat']), 6),
                   round(_noise_heat(), 6), round(_ctrl['input_std'], 6), round(_ctrl['output_std'], 6),
                   None if _ctrl['last_q'] is None else round(_ctrl['last_q'], 6), dev,
                   None if _ctrl['g_fast'] is None else round(_ctrl['g_fast'], 6),
                   None if _ctrl['g_peak'] is None else round(_ctrl['g_peak'], 6),
                   int(_ctrl['decaying']), int(_ctrl['floor_seen']), _ctrl['rate_hi']]
            _ctrl['trace'].append(row)
            print(json.dumps({'sn2': row}), flush=True)
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_heat'] = float(_ctrl['heat'])
    receipt['final_anchor_heat'] = float(_ctrl['anchor_heat'])
    receipt['final_noise_heat'] = _noise_heat()
    receipt['final_input_std'] = _ctrl['input_std']
    receipt['final_output_std'] = _ctrl['output_std']
    receipt['floor_seen'] = _ctrl['floor_seen']
    receipt['decaying'] = _ctrl['decaying']
    receipt['g_peak'] = _ctrl['g_peak']
    receipt['lr_trace'] = _ctrl['trace']
    receipt['trace_columns'] = ['critic_step', 'applied_critic_lr', 'network_mult', 'prior_mult', 's',
                                'heat', 'anchor_heat', 'noise_heat', 'input_std', 'output_std', 'q', 'dev',
                                'g_fast', 'g_peak', 'decaying', 'floor_seen', 'rate_hi']
    receipt['budget_dependencies'] = [
        'Applied rates and noise do not read total_steps, noise_horizon, network_lr_horizon_cap, or evaluation scores.',
        'The frozen linear_* and policy_multipliers functions are called and their returns are discarded.',
        '0.955, 0.996, 0.15*g_peak, the 10-step and 200-step calibrations, and the dev thresholds are estimator constants.',
        'g_peak is frozen after 200 critic steps. It is not a training budget.',
        'Direct-response gain still multiplies direct particle steps and restores the base rate.',
        'Guard warmup of 200 critic steps is the parent estimator constant.',
    ]
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


def _install_rules():
    import benchmarks.toy100.models as models
    import benchmarks.toy100.schedule as schedule
    original_input = models.linear_input_noise
    original_output = models.linear_output_noise
    original_policy = schedule.policy_multipliers

    def input_noise(peak, completed_steps, total_steps, end_fraction):
        original_input(peak, completed_steps, total_steps, end_fraction)
        return float(_ctrl['input_std'])

    def output_noise(peak, completed_steps, total_steps, warmup_fraction=0.0):
        original_output(peak, completed_steps, total_steps, warmup_fraction)
        return float(_ctrl['output_std'])

    def policy_multipliers(completed_step, total_steps, anneal_start, floor,
                           network_lr_horizon_cap=None, *, network_lr_floor=None):
        original_policy(completed_step, total_steps, anneal_start, floor,
                        network_lr_horizon_cap, network_lr_floor=network_lr_floor)
        return (network_multiplier(), prior_multiplier())

    models.linear_input_noise = input_noise
    models.linear_output_noise = output_noise
    schedule.policy_multipliers = policy_multipliers
    for mod in list(sys.modules.values()):
        if mod is None:
            continue
        for name, value in list(vars(mod).items()):
            if value is original_input:
                setattr(mod, name, input_noise)
            elif value is original_output:
                setattr(mod, name, output_noise)
            elif value is original_policy:
                setattr(mod, name, policy_multipliers)


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
_install_rules()
atexit.register(_write_receipt)
