"""B3 (a3_fastref lane, proposal 3): B1 short/long gate + guarded novelty re-seed.

Lineage: exact B1 gate (800-call pure-A warmup, s=0.5, W=clamp(1-med24/med200));
one coherent guard on the re-seed: re-seed the EMA to the current critic only
when BOTH hold for RESEED_STREAK=40 consecutive blended calls: (i) W<0.25
(gate says sustained novelty) AND (ii) prox_med_short > 4x the frozen
convergence baseline prox_short_med_at_800 (first short-window median after
warmup; ordinary training signal, no budget/shift/metric reads). In B1 hold
the short median stays ~1e-3 (no re-seed); post-shift prox jumps ~10-30x
(re-seed fires, reference follows the moved critic, anchor relaxes on new
data). EMA otherwise updates only while W>=0.5 (A3 rule). LR-decoupled.
Remaining budget dependency (labeled ablation): inherited LR/noise schedules.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
S_FIX = 0.5
WARMUP_CALLS = 800
SHORT_WINDOW = 24
LONG_WINDOW = 200
GATE_MIN_SAMPLES = 25
GATE_HOLD_W = 0.5
RESEED_W = 0.25
RESEED_STREAK = 40
RESEED_RATIO = 4.0
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'rule': 'b3-shortref-guarded-reseed',
           'floor': FLOOR, 'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS,
           'pure_a_calls': 0, 'blend_calls': 0, 'pure_b_calls': 0,
           'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [],
           'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None, 'prox_trace': [],
            's_fix': S_FIX, 'lr_decoupled': True, 'w_trace': [],
            'ema_updates': 0, 'ema_skips': 0, 'ema_reseeds': 0}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None,
          'depth': 0, 'clips': [], 'critic_ref': None, 'prox_hist': [], 'w_last': 1.0,
          'low_streak': 0, 'base_med': None}


def handover_weight():
    return S_FIX


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, swapped via .data (restored)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def _median(xs):
    s = sorted(xs)
    return s[len(s) // 2]


def innovation_weight(_prox_val):
    hist = _state['prox_hist']
    if len(hist) < GATE_MIN_SAMPLES:
        return 1.0
    short = hist[-SHORT_WINDOW:]
    med_s = _median(short)
    med_l = _median(hist)
    if med_l <= 0.0:
        return 1.0
    r = med_s / med_l
    return max(0.0, min(1.0, 1.0 - r))


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = S_FIX
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if receipt['calls'] + 1 <= WARMUP_CALLS:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
        w = 0.0
        _state['w_last'] = w
        if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
            receipt['s_trace'].append([receipt['calls'], round(s, 6)])
        stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s, 'w': w} if collect_stats else {}
        return penalty, stats
    x = x_real.detach().clone().requires_grad_(True)
    g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
    sq_r = g.pow(2).flatten(1).sum(dim=1)
    n_r = torch.sqrt(sq_r + 1e-12)
    n_f = self._grad_norm(D, x_fake, squared=False)
    prox = anchored_gradient_gap(D, x_real, g, dimension)
    prox_val = float(prox.detach())
    w = innovation_weight(prox_val)
    _state['w_last'] = w
    _state['prox_hist'].append(prox_val)
    if len(_state['prox_hist']) > LONG_WINDOW:
        del _state['prox_hist'][:len(_state['prox_hist']) - LONG_WINDOW]
    a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
    b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + w * prox
    penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
    receipt['blend_calls'] += 1
    short = _state['prox_hist'][-SHORT_WINDOW:]
    med_s_now = _median(short)
    if _state['base_med'] is None and len(_state['prox_hist']) >= SHORT_WINDOW:
        _state['base_med'] = med_s_now
    base = _state['base_med'] or 0.0
    novel = base > 0.0 and med_s_now > RESEED_RATIO * base
    if w < RESEED_W and novel:
        _state['low_streak'] += 1
    else:
        _state['low_streak'] = 0
    if receipt['first_blend_call'] is None:
        receipt['first_blend_call'] = receipt['calls']
    if receipt['calls'] % 50 == 0:
        receipt['prox_trace'].append([receipt['calls'], prox_val])
        receipt['w_trace'].append([receipt['calls'], round(w, 6)])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s, 'w': w} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['low_streak'] >= RESEED_STREAK and _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.copy_(p.detach())
            receipt['ema_reseeds'] += 1
            _state['low_streak'] = 0
        if _state['ema'] is not None and _state['w_last'] >= GATE_HOLD_W:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
            receipt['ema_updates'] += 1
        elif _state['ema'] is not None:
            receipt['ema_skips'] += 1
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_w'] = _state['w_last']
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
