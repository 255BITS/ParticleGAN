"""cc2: batch margin uncertainty replaces the half-split coherence controller.

cc1 measured half-batch parameter-gradient coherence on the ring hold. The EMA
stayed inside [0.536, 0.980], the gain stayed 1, s stayed 1, and the anchor
never started. Full rate reached a 200-update 8-mode streak at step 3933 and
then lost the hold at step 4087. Agreement of the two half-batch gradients is
not a closing signal on this task: it is high while the ring is still being
learned and still high while full-rate updates collapse it.

cc2 uses a different minibatch statistic, the coefficient of variation of the
paired critic margin:

  margin_i = mean over non-batch axes of D(real_i) - D(fake_i)
  uncertainty = variance(margin) / (variance(margin) + mean(margin)^2)

Both moments are over the batch, so the ratio does not grow with batch size.
The margin is reduced to one scalar per pair, so there is no parameter
dimension in the statistic. uncertainty is 0 when every pair shares the same
nonzero margin and 1 when the mean margin vanishes. confidence = 1 - uncertainty.
A coefficient of variation of 1 is confidence 0.5.

Controller, reversible, and not a function of the training horizon:

  Symmetric EMA with new-sample weight 0.05. The first 200 critic steps force
  gain 1 while the EMA fills and acquisition runs. After that

    gain = relu(2 * confidence_ema - 1)

  which is 1 at confidence 1, 0 at confidence 0.5 (CV >= 1), and linear between.
  Network multiplier = 0.01 + 0.99 * gain.
  Prior multiplier   = 0.05 + 0.95 * gain.
  Mixing gain equals rate gain. The K3P handover maps that gain to s and does
  not read the applied learning rate. A later fall in uncertainty raises the
  gain again, including the early penalty.

Noise remains the unchanged host schedule (intermediate ablation; the ring
driver still passes noise_horizon 1200). The rate rule does not read step,
total, horizon, scores, task identity, centers, or the shift time.

Extra evaluations per penalty call: two critic forwards under torch.no_grad.
No extra backward and no new random sample.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
PRIOR_FLOOR = 0.05
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
WARMUP = 200
EMA_WEIGHT = 0.05
_original_penalty = GradientPenalty.penalty
receipt = {
    'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'extra_critic_backwards': 0,
    'floor': FLOOR, 'prior_floor': PRIOR_FLOOR, 'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS,
    'pure_a_calls': 0, 'blend_calls': 0, 'pure_b_calls': 0, 'first_blend_call': None,
    'first_pure_b_call': None, 'critic_steps': 0, 'critic_parameters': None,
    'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'cc2_margin_uncertainty',
    'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None, 'prox_trace': [], 'phase_trace': [],
    'signal': 'paired_margin_coefficient_of_variation',
    'uncertainty_formula': 'var(margin)/(var(margin)+mean(margin)^2); confidence=1-uncertainty; gain=relu(2*confidence-1)',
    'normalization': 'mean and variance over batch pairs; each pair is one scalar margin averaged over remaining axes',
    'ema_weight': EMA_WEIGHT, 'warmup': WARMUP,
    'cv_close': 'gain reaches 0 when confidence <= 0.5, i.e. the batch std of the margin is at least the absolute mean',
    'rate_rule': 'network=0.01+0.99*gain prior=0.05+0.95*gain after warmup; warmup forces gain 1',
    'mix_rule': 'mix gain equals rate gain; K3P handover maps that gain to s and does not read applied LR',
    'noise': 'unchanged host schedule; intermediate ablation; ring driver still passes noise_horizon 1200',
    'budget_dependencies': [
        'host noise still receives a horizon (ring driver hardcodes 1200; transfer tasks pass their step count)',
        'config network_lr_horizon_cap remains because the host requires it; phase_multipliers ignores the value',
        'phase_multipliers still accepts step, total, anneal, and floors and does not use them',
        'warmup 200 and EMA weight 0.05 are estimator constants, not a training horizon',
    ],
    'ignored_schedule_args_sample': None,
    'parent_failure': 'cc1 half-split coherence EMA stayed in [0.536, 0.980] and never left gain 1',
    'uncertainty_min': None, 'uncertainty_max': None, 'confidence_min': None, 'confidence_max': None,
}
_state = {
    'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0,
    'clips': [], 'critic_ref': None, 'rate_gain': 1.0, 'mix_gain': 1.0, 'confidence_ema': None,
    'uncertainty_raw': None, 'pending_uncertainty': None, 'grad_rms': None,
}


def _uncertainty(mean, var):
    denom = var + mean * mean
    if not denom > 0.0:
        return 1.0
    return min(1.0, max(0.0, var / denom))


def _gain_from_confidence(confidence):
    return max(0.0, 2.0 * confidence - 1.0)


def _self_check():
    if _uncertainty(2.0, 0.0) != 0.0:
        raise RuntimeError('zero-variance margin must be certain')
    if _uncertainty(0.0, 3.0) != 1.0:
        raise RuntimeError('zero-mean margin must be fully uncertain')
    if abs(_uncertainty(2.0, 4.0) - 0.5) > 1e-12:
        raise RuntimeError('CV=1 must be uncertainty 0.5')
    if _gain_from_confidence(1.0) != 1.0 or _gain_from_confidence(0.5) != 0.0 or _gain_from_confidence(0.0) != 0.0:
        raise RuntimeError('gain map failed')
    if abs(_gain_from_confidence(0.75) - 0.5) > 1e-12:
        raise RuntimeError('midpoint gain failed')


_self_check()


def handover_weight():
    """K3P map on the mixing gain. Does not read learning rates or step counts."""
    r = _state['mix_gain']
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def phase_multipliers(*args, **kwargs):
    """Drop-in for schedule.policy_multipliers. Ignores step, horizon, and anneal."""
    if receipt['ignored_schedule_args_sample'] is None and len(args) > 0:
        receipt['ignored_schedule_args_sample'] = {
            'nargs': len(args),
            'has_network_lr_floor': 'network_lr_floor' in kwargs,
        }
    gain = _state['rate_gain']
    return (FLOOR + (1.0 - FLOOR) * gain,
            PRIOR_FLOOR + (1.0 - PRIOR_FLOOR) * gain)


def _install_phase_rates():
    from benchmarks.toy100 import schedule
    original = schedule.policy_multipliers
    schedule.policy_multipliers = phase_multipliers
    sites = ['benchmarks.toy100.schedule.policy_multipliers']
    for module in list(sys.modules.values()):
        if module is None:
            continue
        name = getattr(module, '__name__', '')
        if not name.startswith(('particlegan', 'benchmarks')):
            continue
        for attr, value in list(vars(module).items()):
            if value is original:
                setattr(module, attr, phase_multipliers)
                sites.append(f'{name}.{attr}')
    receipt['phase_install_sites'] = sites


_install_phase_rates()


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _note(key, value, extremum):
    previous = receipt[key]
    if previous is None:
        receipt[key] = value
    elif extremum == 'min':
        receipt[key] = min(previous, value)
    else:
        receipt[key] = max(previous, value)


def _update_confidence(uncertainty):
    confidence = 1.0 - uncertainty
    ema = _state['confidence_ema']
    ema = confidence if ema is None else (1.0 - EMA_WEIGHT) * ema + EMA_WEIGHT * confidence
    _state['confidence_ema'] = ema
    _state['uncertainty_raw'] = uncertainty
    if receipt['critic_steps'] <= WARMUP:
        gain = 1.0
    else:
        gain = _gain_from_confidence(ema)
    _state['rate_gain'] = gain
    _state['mix_gain'] = gain
    _note('uncertainty_min', uncertainty, 'min')
    _note('uncertainty_max', uncertainty, 'max')
    _note('confidence_min', ema, 'min')
    _note('confidence_max', ema, 'max')
    receipt['final_s'] = handover_weight()
    receipt['final_rate_gain'] = gain
    receipt['final_mix_gain'] = gain
    receipt['final_confidence_ema'] = ema
    receipt['final_uncertainty_raw'] = uncertainty


def _margin_uncertainty(D, x_real, x_fake):
    """Two no-grad critic forwards. Does not write gradients or draw random numbers."""
    if x_real.device.type != 'cuda' or x_fake.device.type != 'cuda':
        raise RuntimeError('margin probe requires CUDA real and fake batches')
    if x_real.shape[0] != x_fake.shape[0] or x_real.shape[0] < 2:
        raise RuntimeError('margin probe needs a matched batch of at least 2')
    with torch.no_grad():
        real_score = D(x_real.detach())
        fake_score = D(x_fake.detach())
    receipt['extra_critic_forwards'] += 2
    if real_score.shape != fake_score.shape or real_score.shape[0] != x_real.shape[0]:
        raise RuntimeError('critic scores do not match the paired batch')
    margin = (real_score - fake_score).reshape(real_score.shape[0], -1).mean(dim=1)
    mean = float(margin.mean())
    var = float(margin.var(unbiased=False))
    return _uncertainty(mean, var)


def _grad_rms(opt):
    total = None
    count = 0
    for group in opt.param_groups:
        for parameter in group['params']:
            if parameter.grad is None:
                continue
            term = parameter.grad.detach().square().sum()
            total = term if total is None else total + term
            count += parameter.grad.numel()
    if total is None or count == 0:
        return None
    return float(torch.sqrt(total / count))


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    receipt['extra_critic_forwards'] += 1
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def _phase_row(s):
    net, prior = phase_multipliers()
    ema = _state['confidence_ema']
    raw = _state['pending_uncertainty']
    return dict(
        critic_steps=receipt['critic_steps'], calls=receipt['calls'],
        rate_gain=round(_state['rate_gain'], 6), mix_gain=round(_state['mix_gain'], 6),
        s=round(s, 6),
        uncertainty_raw=None if raw is None else round(raw, 6),
        confidence_ema=None if ema is None else round(ema, 6),
        grad_rms=None if _state['grad_rms'] is None else round(_state['grad_rms'], 8),
        network_multiplier=net, prior_multiplier=prior, lr_last=_state['lr_last'],
    )


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    _state['pending_uncertainty'] = _margin_uncertainty(D, x_real, x_fake)
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if receipt.get('batch') is None:
        receipt['batch'] = int(x_real.shape[0])
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (
                F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        row = _phase_row(s)
        receipt['s_trace'].append([receipt['calls'], row['s']])
        receipt['phase_trace'].append(row)
        print(json.dumps(dict(phase=row)), flush=True)
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        _state['grad_rms'] = _grad_rms(opt)
        receipt['critic_steps'] += 1
        if _state['pending_uncertainty'] is not None:
            _update_confidence(_state['pending_uncertainty'])
            _state['pending_uncertainty'] = None
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_rate_gain'] = _state['rate_gain']
    receipt['final_mix_gain'] = _state['mix_gain']
    receipt['final_confidence_ema'] = _state['confidence_ema']
    receipt['final_uncertainty_raw'] = _state['uncertainty_raw']
    receipt['final_grad_rms'] = _state['grad_rms']
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
