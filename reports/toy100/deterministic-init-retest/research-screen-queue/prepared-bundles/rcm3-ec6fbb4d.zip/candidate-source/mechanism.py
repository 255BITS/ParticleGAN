"""rcm3: K3P penalties with a reversible applied-step mix.

rcm1 closed by step 300 on a spiked gradient peak and then stuck at 7/8 modes.
rcm2's anchor-gradient gap stayed near one half after the ring had partially
settled, so the mix never left the early penalty and the hold stayed at 6 modes.
Neither gradient agreement nor the anchor gap marked the settled regime.
The applied critic step does: its RMS falls about 200x as the optimizer slows,
and it can rise again later. This file does not read that step's learning rate,
the training horizon, scores, or the target.

pen = 0.5 * (s * A + (1 - s) * (B + P)) with K3P's A, B, P, kappa, coefficient,
anchor decay 0.999 and guard (5x after 200 steps). s >= 1 is the pure early
penalty and does not evaluate the anchor. s starts at 1.

After each critic Adam step, disp = ||theta - theta_previous||.
  fast <- 0.8 * fast + 0.2 * disp
  slow <- 0.995 * slow + 0.005 * disp
  ratio = fast / (slow + 1e-12)
  m <- 0.9 * m + 0.1 * ratio          (m, fast, slow start at the first disp)
  m <= 0.50 -> target = 0             (step just shrank)
  m >= 1.25 -> target = 1             (step just grew)
  otherwise the previous target is kept
  s <- 0.94 * s + 0.06 * target

Inherited K3P schedules are not inputs to s, and they still move disp:
  network LR cosine on min(total_steps, 1600) to floor 0.01
  prior LR cosine on total_steps to floor 0.05
  base LR 0.00425, prior multiplier 2, anneal start 0.6
  noise horizon 1200 in the unmodified hold/shift drivers
A constant critic LR would keep disp large while gradients stay large, so s
would stay at 1. That is the decoupling from the LR-ratio clock: the mix
follows the step that was actually taken.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
FAST_DECAY = 0.8
SLOW_DECAY = 0.995
M_DECAY = 0.9
CLOSE_M = 0.50
OPEN_M = 1.25
S_SMOOTH = 0.06
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
           'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
           'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'rcm3',
           'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None, 'prox_trace': [],
           'anchor_forwards': 0, 'anchor_penalty_calls': 0, 'anchor_weight_sum': 0.0,
           'first_close_step': None, 'first_reopen_step': None, 'mix_trace': [],
           'controller': {
               'name': 'applied_step_ratio',
               'fast_decay': FAST_DECAY, 'slow_decay': SLOW_DECAY, 'm_decay': M_DECAY,
               'close_m': CLOSE_M, 'open_m': OPEN_M, 's_smooth': S_SMOOTH,
               'initial_s': 1.0, 'initial_target': 1.0,
               'reads_learning_rate': False, 'reads_horizon': False, 'reads_step_index': False,
               'reads_metrics': False, 'reads_target': False,
           },
           'inherited_budget_dependencies': [
               'network LR cosine uses min(total_steps, network_lr_horizon_cap=1600) and network floor 0.01',
               'prior LR cosine uses total_steps and lr_floor 0.05',
               'input/output noise horizon is 1200 inside the unmodified hold/shift drivers',
               's reacts to the resulting applied step, so a different horizon changes s only by changing that step',
           ]}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0,
          'clips': [], 'critic_ref': None, 's': 1.0, 'target': 1.0, 'prev': None,
          'fast': None, 'slow': None, 'm': None, 'last_disp': None, 'last_ratio': None}


def handover_weight():
    return _state['s']


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _update_step_mix(opt):
    params = [p for group in opt.param_groups for p in group['params']]
    if _state['prev'] is None or len(_state['prev']) != len(params):
        _state['prev'] = [p.detach().clone() for p in params]
        return
    disp2 = params[0].new_zeros(())
    for p, prev in zip(params, _state['prev']):
        delta = p.detach() - prev
        disp2 = disp2 + delta.pow(2).sum()
        prev.copy_(p.detach())
    disp = disp2.sqrt()
    if _state['fast'] is None:
        _state['fast'] = disp.detach().clone()
        _state['slow'] = disp.detach().clone()
        _state['m'] = disp.detach().new_tensor(1.0)
        _state['last_disp'] = float(disp)
        _state['last_ratio'] = 1.0
        _note_mix()
        return
    fast = _state['fast'] * FAST_DECAY + disp.detach() * (1.0 - FAST_DECAY)
    slow = _state['slow'] * SLOW_DECAY + disp.detach() * (1.0 - SLOW_DECAY)
    ratio = fast / slow.clamp_min(1e-12)
    m = _state['m'] * M_DECAY + ratio * (1.0 - M_DECAY)
    _state['fast'], _state['slow'], _state['m'] = fast, slow, m
    mf = float(m)
    target = _state['target']
    if mf <= CLOSE_M:
        target = 0.0
    elif mf >= OPEN_M:
        target = 1.0
    if target == 0.0 and receipt['first_close_step'] is None:
        receipt['first_close_step'] = receipt['critic_steps']
    if (target == 1.0 and receipt['first_close_step'] is not None
            and receipt['first_reopen_step'] is None
            and receipt['critic_steps'] != receipt['first_close_step']):
        receipt['first_reopen_step'] = receipt['critic_steps']
    _state['target'] = target
    _state['s'] = (1.0 - S_SMOOTH) * _state['s'] + S_SMOOTH * target
    _state['last_disp'] = float(disp)
    _state['last_ratio'] = float(ratio)
    _note_mix()


def _note_mix():
    row = [receipt['critic_steps'], round(_state['s'], 6), round(_state['target'], 3),
           None if _state['m'] is None else round(float(_state['m']), 6),
           None if _state['last_ratio'] is None else round(_state['last_ratio'], 6),
           None if _state['last_disp'] is None else round(_state['last_disp'], 8),
           _state['lr_last']]
    receipt['mix_trace'].append(row)
    step = receipt['critic_steps']
    if step == 1 or step % 50 == 0:
        print(json.dumps({'rcm3': True, 'critic_step': step, 's': row[1], 'target': row[2],
                          'm': row[3], 'ratio': row[4], 'disp': row[5], 'lr': row[6],
                          'anchor_forwards': receipt['anchor_forwards']}), flush=True)


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    receipt['anchor_forwards'] += 1
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        receipt['anchor_penalty_calls'] += 1
        receipt['anchor_weight_sum'] += (1.0 - s)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(_state['target'], 3)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
        _update_step_mix(opt)
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_target'] = _state['target']
    receipt['final_m'] = None if _state['m'] is None else float(_state['m'])
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
