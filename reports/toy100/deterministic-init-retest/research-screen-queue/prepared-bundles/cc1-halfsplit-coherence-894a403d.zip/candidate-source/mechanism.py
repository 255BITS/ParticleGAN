"""cc1: half-batch critic coherence replaces K3P's learning-rate handover clock.

Parent is pinned K3P. Learned particle prior, direct response, bounded sparse
latent rule, a_r1r2 / b_cap / EMA prox, anchor decay 0.999, and the 5x guard
after 200 critic steps are unchanged.

Closing signal (not a learning-rate ratio, not successive-gradient cosine, not
a secant step, not raw RMS versus a historical peak):

  On the critic penalty call, split the current real/fake batch into the first
  half and the second half. No shuffle and no extra RNG. Drop one trailing
  sample when the batch is odd. Each half is scored with the Rp logistic
  critic loss, reduced by a mean over that half (batch normalization).
  Parameter gradients g1 and g2 of that loss give

    coherence = clip(1 - ||g1 - g2||^2 / ||g1 + g2||^2, 0, 1)

  The ratio cancels a global scale and a shared dimension factor. Independent
  equal-variance halves give a ratio near 1, so coherence is 0. Identical
  halves give coherence 1. If both gradients vanish, coherence is 0 (no shared
  direction: close). This is the minibatch uncertainty of the critic parameter
  gradient.

Controller, reversible and not a function of the training horizon:

  An estimator EMA rises with weight 0.10 when the new coherence is higher and
  falls with weight 0.01 when it is lower. For the first 200 critic steps the
  rate and mix gains stay 1 while that EMA fills. Afterward

    gain = 0 at ema <= 0.08, 1 at ema >= 0.35, linear between.

  Applied network multiplier = 0.01 + 0.99 * gain.
  Applied prior multiplier   = 0.05 + 0.95 * gain.
  Mixing gain equals rate gain. The K3P handover map is applied to that gain,
  never to the last applied learning rate. s stays 1 until gain falls below
  0.5 and reaches 0 at gain 0.01, which turns on capped gradients plus the
  EMA anchor. A later rise in coherence raises the gain again, including the
  early penalty. Nothing reads evaluation scores, convergence, task identity,
  target centers, or a shift time.

Noise is the unchanged host schedule. On the ring drivers that schedule is
still tied to the driver's noise_horizon argument (1200). That is a labeled
intermediate ablation, not a horizon-independent noise rule. phase_multipliers
receives step, total, anneal, floor, and the horizon cap because the host
calls that signature, and it does not use those numbers.

Extra evaluations per penalty call: four critic forwards (two halves, real and
fake) and two parameter backwards. They are not optimizer steps. The probe
does not write .grad and does not keep a graph into the training penalty.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
PRIOR_FLOOR = 0.05
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
WARMUP = 200
CLOSE_AT = 0.08
OPEN_AT = 0.35
RISE = 0.10
FALL = 0.01
_original_penalty = GradientPenalty.penalty
receipt = {
    'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'extra_critic_backwards': 0,
    'floor': FLOOR, 'prior_floor': PRIOR_FLOOR, 'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS,
    'pure_a_calls': 0, 'blend_calls': 0, 'pure_b_calls': 0, 'first_blend_call': None,
    'first_pure_b_call': None, 'critic_steps': 0, 'critic_parameters': None,
    'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'cc1_halfsplit_coherence',
    'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None, 'prox_trace': [], 'phase_trace': [],
    'signal': 'half_batch_parameter_gradient_coherence',
    'coherence_formula': 'clip(1 - ||g1-g2||^2 / ||g1+g2||^2, 0, 1)',
    'normalization': 'loss mean over each half; coherence is a ratio of squared Euclidean norms',
    'split': 'deterministic prefix halves; no shuffle; drop one trailing sample if odd; undersized batches stay open',
    'loss': 'Rp logistic softplus(-(real-fake)).mean() on critic parameters; penalty graph is separate',
    'close_at': CLOSE_AT, 'open_at': OPEN_AT, 'rise': RISE, 'fall': FALL, 'warmup': WARMUP,
    'rate_rule': 'network=0.01+0.99*gain prior=0.05+0.95*gain; gain from coherence EMA after warmup',
    'mix_rule': 'mix gain equals rate gain; K3P handover maps that gain to s and does not read applied LR',
    'noise': 'unchanged host schedule; intermediate ablation; ring driver still passes noise_horizon 1200',
    'budget_dependencies': [
        'host noise still receives a horizon (ring driver hardcodes 1200; transfer tasks pass their step count)',
        'config network_lr_horizon_cap remains because the host requires it; phase_multipliers ignores the value',
        'phase_multipliers still accepts step, total, anneal, and floors and does not use them',
        'warmup 200 and the rise/fall EMA weights are estimator constants, not a training horizon',
    ],
    'ignored_schedule_args_sample': None,
    'undersized_batches': 0, 'raw_min': None, 'raw_max': None, 'ema_min': None, 'ema_max': None,
}
_state = {
    'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0,
    'clips': [], 'critic_ref': None, 'rate_gain': 1.0, 'mix_gain': 1.0, 'conf_ema': None,
    'conf_raw': None, 'pending_raw': None,
}


def _coherence_values(diff2, sum2):
    """Scale-free agreement. A zero combined gradient is incoherent (close)."""
    if not float(sum2) > 0.0:
        return 0.0
    return float(min(1.0, max(0.0, 1.0 - float(diff2) / float(sum2))))


def _self_check():
    same = _coherence_values(torch.zeros(()), torch.tensor(4.0))
    opposite = _coherence_values(torch.tensor(4.0), torch.zeros(()))
    null = _coherence_values(torch.tensor(2.0), torch.tensor(2.0))
    if same != 1.0 or opposite != 0.0 or null != 0.0:
        raise RuntimeError(f"coherence self-check failed: {same}, {opposite}, {null}")


_self_check()


def _map_gain(ema):
    if ema <= CLOSE_AT:
        return 0.0
    if ema >= OPEN_AT:
        return 1.0
    return (ema - CLOSE_AT) / (OPEN_AT - CLOSE_AT)


def handover_weight():
    """K3P map on the mixing gain. Does not read learning rates or step counts."""
    r = _state['mix_gain']
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def phase_multipliers(*args, **kwargs):
    """Drop-in for schedule.policy_multipliers. Ignores step, horizon, and anneal."""
    if receipt['ignored_schedule_args_sample'] is None and len(args) > 0:
        receipt['ignored_schedule_args_sample'] = {
            'nargs': len(args),
            'has_network_lr_floor': 'network_lr_floor' in kwargs,
        }
    gain = _state['rate_gain']
    return (FLOOR + (1.0 - FLOOR) * gain,
            PRIOR_FLOOR + (1.0 - PRIOR_FLOOR) * gain)


def _install_phase_rates():
    from benchmarks.toy100 import schedule
    original = schedule.policy_multipliers
    schedule.policy_multipliers = phase_multipliers
    sites = ['benchmarks.toy100.schedule.policy_multipliers']
    for module in list(sys.modules.values()):
        if module is None:
            continue
        name = getattr(module, '__name__', '')
        if not name.startswith(('particlegan', 'benchmarks')):
            continue
        for attr, value in list(vars(module).items()):
            if value is original:
                setattr(module, attr, phase_multipliers)
                sites.append(f'{name}.{attr}')
    receipt['phase_install_sites'] = sites


_install_phase_rates()


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _note_extremes(raw, ema):
    for key, value in (('raw_min', raw), ('raw_max', raw), ('ema_min', ema), ('ema_max', ema)):
        previous = receipt[key]
        if previous is None:
            receipt[key] = value
        elif key.endswith('min'):
            receipt[key] = min(previous, value)
        else:
            receipt[key] = max(previous, value)


def _update_confidence(raw):
    ema = _state['conf_ema']
    if ema is None:
        ema = raw
    elif raw >= ema:
        ema = (1.0 - RISE) * ema + RISE * raw
    else:
        ema = (1.0 - FALL) * ema + FALL * raw
    _state['conf_ema'] = ema
    _state['conf_raw'] = raw
    if receipt['critic_steps'] <= WARMUP:
        gain = 1.0
    else:
        gain = _map_gain(ema)
    _state['rate_gain'] = gain
    _state['mix_gain'] = gain
    _note_extremes(raw, ema)


def _half_coherence(D, x_real, x_fake):
    """Two half-batch critic backwards. Does not write parameter.grad."""
    count = min(int(x_real.shape[0]), int(x_fake.shape[0]))
    half = count // 2
    if half < 1:
        receipt['undersized_batches'] += 1
        return 1.0
    if x_real.device.type != 'cuda' or x_fake.device.type != 'cuda':
        raise RuntimeError('coherence probe requires CUDA real and fake batches')
    params = [p for p in D.parameters() if p.requires_grad]
    if not params:
        raise RuntimeError('critic has no trainable parameters for the coherence probe')
    real = x_real.detach()
    fake = x_fake.detach()

    def gradients(start, stop):
        loss = F.softplus(-(D(real[start:stop]) - D(fake[start:stop]))).mean()
        grads = torch.autograd.grad(loss, params, allow_unused=True, retain_graph=False)
        receipt['extra_critic_forwards'] += 2
        receipt['extra_critic_backwards'] += 1
        return grads

    first = gradients(0, half)
    second = gradients(half, 2 * half)
    diff2 = None
    sum2 = None
    for left, right in zip(first, second):
        if left is None and right is None:
            continue
        if left is None:
            left = torch.zeros_like(right)
        elif right is None:
            right = torch.zeros_like(left)
        difference = left.detach() - right.detach()
        combined = left.detach() + right.detach()
        dterm = difference.square().sum()
        sterm = combined.square().sum()
        diff2 = dterm if diff2 is None else diff2 + dterm
        sum2 = sterm if sum2 is None else sum2 + sterm
    if diff2 is None:
        raise RuntimeError('coherence probe produced no parameter gradients')
    return _coherence_values(diff2, sum2)


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    receipt['extra_critic_forwards'] += 1
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def _phase_row(s):
    net, prior = phase_multipliers()
    ema = _state['conf_ema']
    raw = _state['pending_raw'] if _state['pending_raw'] is not None else _state['conf_raw']
    return dict(
        critic_steps=receipt['critic_steps'], calls=receipt['calls'],
        rate_gain=round(_state['rate_gain'], 6), mix_gain=round(_state['mix_gain'], 6),
        s=round(s, 6),
        coherence_raw=None if raw is None else round(raw, 6),
        coherence_ema=None if ema is None else round(ema, 6),
        network_multiplier=net, prior_multiplier=prior, lr_last=_state['lr_last'],
    )


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    _state['pending_raw'] = _half_coherence(D, x_real, x_fake)
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if receipt.get('half') is None:
        receipt['half'] = min(int(x_real.shape[0]), int(x_fake.shape[0])) // 2
        receipt['batch'] = int(x_real.shape[0])
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (
                F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        row = _phase_row(s)
        receipt['s_trace'].append([receipt['calls'], row['s']])
        receipt['phase_trace'].append(row)
        print(json.dumps(dict(phase=row)), flush=True)
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
        if _state['pending_raw'] is not None:
            _update_confidence(_state['pending_raw'])
            _state['pending_raw'] = None
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_rate_gain'] = _state['rate_gain']
    receipt['final_mix_gain'] = _state['mix_gain']
    receipt['final_coherence_ema'] = _state['conf_ema']
    receipt['final_coherence_raw'] = _state['conf_raw']
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
