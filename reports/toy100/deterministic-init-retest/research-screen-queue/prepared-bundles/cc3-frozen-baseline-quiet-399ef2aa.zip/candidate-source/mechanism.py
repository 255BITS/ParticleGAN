"""cc3: sustained critic-gradient quiet with a frozen baseline.

cc1 half-batch gradient coherence stayed high (EMA in [0.536, 0.980]) and
never left full rate, so the anchor never started and the ring hold collapsed
after a short 8-mode streak. cc2's paired-margin coefficient of variation was
high on this multi-modal batch from the end of warmup: uncertainty stayed near
0.5–0.7, gain hit 0 by step 202, and the 6300-update settle never reached 8
modes (longest streak 0, final 6 modes). Brief low-uncertainty samples did not
reopen acquisition. Margin spread is not a closing signal here; it is the
mixture.

cc3 does not use either statistic. It watches the training critic-gradient RMS
only (no extra forward or backward). While open, a slow EMA (weight 0.005)
tracks that RMS. After 200 critic steps, 100 consecutive steps below half of
that EMA freeze the EMA as a baseline and decay the gain by 0.98 per step down
to 0. The K3P handover follows the gain, so the anchor comes on as the gain
falls, and it does not read the applied learning rate.

The baseline stays frozen while closing or closed. Reopening requires 100
consecutive steps above 3× that frozen baseline, measured before the rate is
raised, then gain returns to 1 and the EMA starts again from the current RMS.
A one-step spike cannot reopen. The reference is not updated by the reopened
rate, which is the false-restart latch in the RP1 grid trace: a stationary
reopen to multiplier 0.208 worsened center RMS after it had fallen to 0.206.
This rule does not copy that 3-step surprise or that 0.2 reopen, and it does
not read the 5672 clip step.

Network multiplier = 0.01 + 0.99 * gain. Prior multiplier = 0.05 + 0.95 * gain.
Host noise is unchanged (intermediate ablation; the ring driver still passes
noise_horizon 1200). The controller does not read step, total, horizon, scores,
task identity, centers, or the shift time.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
PRIOR_FLOOR = 0.05
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
WARMUP = 200
SLOW_WEIGHT = 0.005
QUIET_RATIO = 0.5
QUIET_DWELL = 100
REOPEN_RATIO = 3.0
REOPEN_DWELL = 100
CLOSE_DECAY = 0.98
_original_penalty = GradientPenalty.penalty
receipt = {
    'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'extra_critic_backwards': 0,
    'floor': FLOOR, 'prior_floor': PRIOR_FLOOR, 'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS,
    'pure_a_calls': 0, 'blend_calls': 0, 'pure_b_calls': 0, 'first_blend_call': None,
    'first_pure_b_call': None, 'critic_steps': 0, 'critic_parameters': None,
    'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'cc3_frozen_baseline_quiet',
    'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None, 'prox_trace': [], 'phase_trace': [],
    'signal': 'sustained_critic_grad_rms_versus_frozen_slow_baseline',
    'normalization': 'RMS is the root mean square over critic parameters (mean of squares, so dimension cancels in the ratio to the baseline). No batch split.',
    'slow_weight': SLOW_WEIGHT, 'quiet_ratio': QUIET_RATIO, 'quiet_dwell': QUIET_DWELL,
    'reopen_ratio': REOPEN_RATIO, 'reopen_dwell': REOPEN_DWELL, 'close_decay': CLOSE_DECAY, 'warmup': WARMUP,
    'rate_rule': 'network=0.01+0.99*gain prior=0.05+0.95*gain; gain decays at 0.98 after 100 quiet steps and returns to 1 only after 100 steps above 3x the frozen baseline',
    'mix_rule': 'mix gain equals rate gain; K3P handover maps that gain to s and does not read applied LR',
    'noise': 'unchanged host schedule; intermediate ablation; ring driver still passes noise_horizon 1200',
    'false_restart_evidence': 'RP1 grid center RMS improved to 0.206 at the floor, then a stationary reopen to multiplier 0.208 worsened it to 0.287. Baseline here is frozen before any reopen.',
    'budget_dependencies': [
        'host noise still receives a horizon (ring driver hardcodes 1200; transfer tasks pass their step count)',
        'config network_lr_horizon_cap remains because the host requires it; phase_multipliers ignores the value',
        'phase_multipliers still accepts step, total, anneal, and floors and does not use them',
        'warmup 200, quiet/reopen dwells of 100, and the slow EMA weight are estimator constants, not a training horizon',
    ],
    'ignored_schedule_args_sample': None,
    'reopen_count': 0, 'close_count': 0,
}
_state = {
    'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0,
    'clips': [], 'critic_ref': None, 'rate_gain': 1.0, 'mix_gain': 1.0,
    'phase': 'open', 'slow': None, 'baseline': None, 'quiet': 0, 'reopen': 0, 'grad_rms': None,
}


def handover_weight():
    """K3P map on the mixing gain. Does not read learning rates or step counts."""
    r = _state['mix_gain']
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def phase_multipliers(*args, **kwargs):
    """Drop-in for schedule.policy_multipliers. Ignores step, horizon, and anneal."""
    if receipt['ignored_schedule_args_sample'] is None and len(args) > 0:
        receipt['ignored_schedule_args_sample'] = {
            'nargs': len(args),
            'has_network_lr_floor': 'network_lr_floor' in kwargs,
        }
    gain = _state['rate_gain']
    return (FLOOR + (1.0 - FLOOR) * gain,
            PRIOR_FLOOR + (1.0 - PRIOR_FLOOR) * gain)


def _install_phase_rates():
    from benchmarks.toy100 import schedule
    original = schedule.policy_multipliers
    schedule.policy_multipliers = phase_multipliers
    sites = ['benchmarks.toy100.schedule.policy_multipliers']
    for module in list(sys.modules.values()):
        if module is None:
            continue
        name = getattr(module, '__name__', '')
        if not name.startswith(('particlegan', 'benchmarks')):
            continue
        for attr, value in list(vars(module).items()):
            if value is original:
                setattr(module, attr, phase_multipliers)
                sites.append(f'{name}.{attr}')
    receipt['phase_install_sites'] = sites


_install_phase_rates()


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _grad_rms(opt):
    total = None
    count = 0
    for group in opt.param_groups:
        for parameter in group['params']:
            if parameter.grad is None:
                continue
            term = parameter.grad.detach().square().sum()
            total = term if total is None else total + term
            count += parameter.grad.numel()
    if total is None or count == 0:
        return None
    return float(torch.sqrt(total / count))


def _sync_gain(gain):
    _state['rate_gain'] = gain
    _state['mix_gain'] = gain
    receipt['final_s'] = handover_weight()
    receipt['final_rate_gain'] = gain
    receipt['final_mix_gain'] = gain
    receipt['final_phase'] = _state['phase']
    receipt['final_baseline'] = _state['baseline']
    receipt['final_slow'] = _state['slow']
    receipt['final_grad_rms'] = _state['grad_rms']


def _update_magnitude(rms):
    """Quiet and reopen from the critic gradient already produced by training."""
    if rms is None or not rms > 0.0:
        return
    _state['grad_rms'] = rms
    if _state['slow'] is None:
        _state['slow'] = rms
        _sync_gain(_state['rate_gain'])
        return
    if _state['phase'] == 'open':
        slow = (1.0 - SLOW_WEIGHT) * _state['slow'] + SLOW_WEIGHT * rms
        _state['slow'] = slow
        if rms < QUIET_RATIO * slow:
            _state['quiet'] += 1
        else:
            _state['quiet'] = 0
        if receipt['critic_steps'] > WARMUP and _state['quiet'] >= QUIET_DWELL:
            _state['phase'] = 'closing'
            _state['baseline'] = slow
            _state['quiet'] = 0
            _state['reopen'] = 0
            receipt['close_count'] += 1
        _sync_gain(1.0)
        return
    baseline = _state['baseline']
    if baseline is None or not baseline > 0.0:
        raise RuntimeError('frozen baseline missing while the controller is not open')
    if rms > REOPEN_RATIO * baseline:
        _state['reopen'] += 1
    else:
        _state['reopen'] = 0
    if _state['reopen'] >= REOPEN_DWELL:
        _state['phase'] = 'open'
        _state['slow'] = rms
        _state['baseline'] = None
        _state['reopen'] = 0
        _state['quiet'] = 0
        receipt['reopen_count'] += 1
        _sync_gain(1.0)
        return
    gain = _state['rate_gain']
    if _state['phase'] == 'closing':
        gain *= CLOSE_DECAY
        if gain <= FLOOR:
            gain = 0.0
            _state['phase'] = 'closed'
    _sync_gain(gain)


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    receipt['extra_critic_forwards'] += 1
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def _phase_row(s):
    net, prior = phase_multipliers()
    return dict(
        critic_steps=receipt['critic_steps'], calls=receipt['calls'],
        phase=_state['phase'], rate_gain=round(_state['rate_gain'], 6),
        mix_gain=round(_state['mix_gain'], 6), s=round(s, 6),
        grad_rms=None if _state['grad_rms'] is None else round(_state['grad_rms'], 8),
        slow=None if _state['slow'] is None else round(_state['slow'], 8),
        baseline=None if _state['baseline'] is None else round(_state['baseline'], 8),
        quiet=_state['quiet'], reopen_run=_state['reopen'],
        network_multiplier=net, prior_multiplier=prior, lr_last=_state['lr_last'],
    )


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (
                F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        row = _phase_row(s)
        receipt['s_trace'].append([receipt['calls'], row['s']])
        receipt['phase_trace'].append(row)
        print(json.dumps(dict(phase=row)), flush=True)
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
        _update_magnitude(_grad_rms(opt))
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_rate_gain'] = _state['rate_gain']
    receipt['final_mix_gain'] = _state['mix_gain']
    receipt['final_phase'] = _state['phase']
    receipt['final_baseline'] = _state['baseline']
    receipt['final_slow'] = _state['slow']
    receipt['final_grad_rms'] = _state['grad_rms']
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
