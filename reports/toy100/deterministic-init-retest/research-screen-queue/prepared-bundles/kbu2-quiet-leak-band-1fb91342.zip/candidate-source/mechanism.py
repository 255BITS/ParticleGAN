"""kbu2 joint band: quiet-proportional leak, then a reversible capped band.

kbu1 kept one shared multiplier but required 100 consecutive critic steps with
relative displacement below 0.01. On the ring that streak never formed: full-rate
displacement jitters through about 0.005-0.015, so m stayed 1 for all 3600
steps. Eight modes held from update 500, then the ring collapsed to 0 modes at
update 1600. pnb3 already showed constant full rate loses modes. ruc3's fix of
resetting a boost to 1 stuck and scored 0/81. This rule does not do that.

One shared multiplier m on G, D, and the prior (recipe ratio stays 2).
- Above 0.35, m decreases only when the previous critic relative displacement
  is below 0.02. quiet = clamp((0.02 - rel) / 0.02, 0, 1),
  m += 0.003 * quiet * (target - m), and m is not allowed to increase.
  At rel >= 0.02 the multiplier holds. No streak counter and no step timer.
- target = 0.10 + 0.25 * clamp((r - 1) / 1, 0, 1), r = critic grad RMS over
  sqrt(mean bias-corrected Adam v). Calm r keeps the target at 0.10.
- Once m has entered [0.10, 0.35], m += 0.02 * (target - m) inside that band.
  A sustained moment-ratio shock can reopen to 0.35 and the same rule decays
  back to 0.10. It cannot return to 1.
- Critic mixing is the K3P map of m, not of last/max learning rate.
  s = 1 for m >= 0.5. At m = 0.10, s ≈ 0.184 and the 0.999 EMA anchor is on.
  Reopening m loosens the anchor without turning it off.

Host floors passed to the driver are 1 and 1, so the cosine LR schedule is the
identity at every horizon. Noise still uses the driver's 1200-update horizon
(labeled intermediate ablation; m and s do not read it). Guard, latent damping,
and direct response are the pinned K3P hooks. No budget, score, target center,
or shift time is read.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
MOMENT_BETA2 = 0.999
BAND_LO = 0.10
BAND_HI = 0.35
QUIET_REL = 0.02
ALPHA_LEAK = 0.003
ALPHA_BAND = 0.02
SHOCK_SPAN = 1.0
_original_penalty = GradientPenalty.penalty
receipt = {
    'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
    'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0,
    'blend_calls': 0, 'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None,
    'critic_steps': 0, 'critic_parameters': None, 'lr_max': None, 'lr_last': None,
    's_trace': [], 'rule': 'kbu2_quiet_leak_band', 'anchor_decay': ANCHOR_DECAY,
    'anchor_started_call': None, 'prox_trace': [],
    'mixing_signal': 'shared_mobility_m_not_learning_rate', 'lr_clock_decoupled': True,
    'band': [BAND_LO, BAND_HI], 'quiet_rel': QUIET_REL,
    'alpha_leak': ALPHA_LEAK, 'alpha_band': ALPHA_BAND, 'shock_span': SHOCK_SPAN,
    'moment_beta2': MOMENT_BETA2,
    'joint_roles': ['g', 'd', 'prior'], 'rate_trace': [], 'rho_summary': {},
    'lr_overwrite_after_scale': 0, 'settled_critic_step': None,
    'noise_note': 'driver noise_horizon=1200 remains; not an input to m or s',
}
_state = {
    'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None,
    'depth': 0, 'clips': [], 'critic_ref': None, 'm': 1.0, 'settled': False,
    'quiet_run': 0, 'prev_rel': None, 'tick': 0, 'applied_for': None,
    'restore': {}, 'last_ratio': None, 'last_target': None,
}


def handover_weight():
    r = _state['m']
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _is_critic(opt):
    if _state['critic'] is None:
        return bool(_state['pending'])
    return id(opt) == _state['critic']


def _moment_ratio(opt):
    square = None
    count = 0
    second = None
    second_count = 0
    step = None
    moments = True
    for group in opt.param_groups:
        for parameter in group['params']:
            if parameter.grad is None:
                continue
            value = parameter.grad.detach().square().sum()
            square = value if square is None else square + value
            count += parameter.grad.numel()
            moment = opt.state.get(parameter)
            if not moment or 'exp_avg_sq' not in moment or 'step' not in moment:
                moments = False
                continue
            current = moment['step']
            step = current if step is None else step
            value = moment['exp_avg_sq'].sum()
            second = value if second is None else second + value
            second_count += moment['exp_avg_sq'].numel()
    if count == 0 or not moments or second_count != count or step is None:
        return None
    step_value = float(step.detach()) if torch.is_tensor(step) else float(step)
    if step_value < 1.0:
        return None
    grad_rms = (square / count).sqrt()
    corrected = (second / second_count) / (1.0 - MOMENT_BETA2 ** step_value)
    return float((grad_rms / corrected.clamp_min(1e-30).sqrt()).clamp(max=1e6))


def _update_m(opt):
    ratio = _moment_ratio(opt)
    _state['last_ratio'] = ratio
    rel = _state['prev_rel']
    if rel is None:
        quiet = 0.0
    else:
        quiet = max(0.0, min(1.0, (QUIET_REL - rel) / QUIET_REL))
    _state['quiet_run'] = quiet
    excess = 0.0 if ratio is None else max(0.0, min(1.0, (ratio - 1.0) / SHOCK_SPAN))
    target = BAND_LO + (BAND_HI - BAND_LO) * excess
    previous = _state['m']
    if previous > BAND_HI:
        updated = previous + (ALPHA_LEAK * quiet) * (target - previous)
        if updated > previous:
            updated = previous
    else:
        updated = previous + ALPHA_BAND * (target - previous)
        if updated < BAND_LO:
            updated = BAND_LO
        if updated > BAND_HI:
            updated = BAND_HI
        if not _state['settled']:
            _state['settled'] = True
            receipt['settled_critic_step'] = receipt['critic_steps'] + 1
    _state['m'] = float(updated)
    _state['last_target'] = float(target)


def _apply_scale(opt):
    key = (id(opt), _state['tick'])
    if _state['applied_for'] == key:
        return
    _state['applied_for'] = key
    if _is_critic(opt):
        _update_m(opt)
    m = _state['m']
    restore = []
    rows = []
    critic = _is_critic(opt)
    for group in opt.param_groups:
        scheduled = float(group['lr'])
        applied = scheduled * m
        group['lr'] = applied
        before = [p.detach().clone() for p in group['params']]
        role = 'prior' if group.get('_comparison_prior') else ('d' if critic else 'g')
        row = [role, round(m, 6), None if _state['last_ratio'] is None else round(_state['last_ratio'], 6),
               round(_state['last_target'] or m, 6), round(m, 6), scheduled, applied, None,
               int(_state['settled']), round(handover_weight(), 6)]
        rows.append((row, before, list(group['params']), group, scheduled, applied))
        summary = receipt['rho_summary'].setdefault(role, {'min': m, 'max': m, 'last': m, 'calls': 0})
        summary['min'] = min(summary['min'], m)
        summary['max'] = max(summary['max'], m)
        summary['last'] = m
        summary['calls'] += 1
        if critic and summary['calls'] % 100 == 0:
            print(json.dumps(dict(kbu=dict(
                role=role, call=summary['calls'], m=m, settled=bool(_state['settled']),
                quiet=_state['quiet_run'], r_moment=_state['last_ratio'],
                target=_state['last_target'], scheduled_lr=scheduled, applied_lr=applied,
                s=handover_weight(), prev_rel=_state['prev_rel']))), flush=True)
    _state['restore'][id(opt)] = rows


def _scale_pre(opt, args, kwargs):
    _state['tick'] += 1
    hooks = opt._optimizer_step_pre_hooks
    for hid, fn in list(hooks.items()):
        if getattr(fn, '_kbu_wrapped', False):
            continue
        def wrapped(optimizer, wargs, wkwargs, inner=fn):
            inner(optimizer, wargs, wkwargs)
            _apply_scale(optimizer)
        wrapped._kbu_wrapped = True
        hooks[hid] = wrapped
    if not any(getattr(fn, '_kbu_wrapped', False) for fn in hooks.values()):
        _apply_scale(opt)


def _scale_post(opt, args, kwargs):
    rows = _state['restore'].pop(id(opt), None)
    if not rows:
        return
    critic = _is_critic(opt)
    rel_for_settle = None
    for row, before, parameters, group, scheduled, applied in rows:
        actual = float(group['lr'])
        if abs(actual - applied) > 1e-8 * max(1.0, abs(applied)):
            receipt['lr_overwrite_after_scale'] += 1
        group['lr'] = scheduled
        delta = None
        base = None
        count = 0
        for current, previous in zip(parameters, before):
            difference = (current.detach() - previous).square().sum()
            magnitude = previous.square().sum()
            delta = difference if delta is None else delta + difference
            base = magnitude if base is None else base + magnitude
            count += current.numel()
        relative = None
        if count:
            relative = float((delta / count).sqrt() / (base / count).clamp_min(1e-30).sqrt())
            row[7] = round(relative, 8)
            if critic and row[0] == 'd':
                rel_for_settle = relative
        calls = receipt['rho_summary'][row[0]]['calls']
        if calls <= 5 or calls % 20 == 0:
            receipt['rate_trace'].append(row)
    if rel_for_settle is not None:
        _state['prev_rel'] = rel_for_settle


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
        receipt['extra_critic_forwards'] += 1
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (
                F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(_state['m'], 6), bool(_state['settled'])])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_m'] = _state['m']
    receipt['settled'] = bool(_state['settled'])
    receipt['host_lr_note'] = (
        'lr_last is the restored host rate after the joint multiplier; '
        'applied rates are rate_trace column 6. Column 5 is the host scheduled rate.'
    )
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_scale_pre)
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_scale_post)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
