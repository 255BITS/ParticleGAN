# RESEARCH-ap1_magnitude_phase-new-init source preparation

Original candidate `research:continuous-round-2/k3p_adversarial_progress/ap1_magnitude_phase` on the declared common frozen tiny host. Exact source/config preserved; new standalone public initialization only. This is research-host evidence and retains its original schedule eligibility. No old pass or new quality is inherited.

The wrapper differs from the reviewed KA2 wrapper only in its source-directory and candidate label. It requires a matching independent CPU constructor/source proof before execution and checks every actual CUDA initial tensor against that proof before optimizer construction. This bundle is prepared, not authorized or executed. Runtime provenance: `DECLARED_COMMON_RETEST_HOST; HISTORICAL_RUNTIME_RECEIPT_UNRESOLVED`.
