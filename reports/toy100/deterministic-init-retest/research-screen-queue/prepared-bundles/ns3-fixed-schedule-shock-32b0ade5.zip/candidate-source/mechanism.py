"""NS3: fixed parent ring schedule, plus a shock reopen that does not move s.

NS1 stayed at critic LR 0.00414 with s=1 and never covered 8 modes for 200
steps (max 7). NS2's pace floor began near step 1020 at 5 modes, reached the
parent floor too early, then a gradient-RMS shock reopened noise and the
partial ring collapsed. Eight modes appeared only at step 6300, streak 15.

Acquisition therefore keeps the parent's network cosine: horizon 1600, anneal
0.6, floor 0.01, as constants. Those numbers are not read from total_steps or
network_lr_horizon_cap. Prior multiplier stays 1, which is the parent's prior
multiplier through step 1600 on both the hold and shift budgets. Noise uses
the ring probe's 120-step input decay and 240-step output warmup as constants.

After the scheduled multiplier is <= 0.05, a critic grad-RMS shock builds
boost = 0.98*boost + 0.02*shock. Applied network multiplier is
scheduled + (1-scheduled)*boost. Boost stays 0 during acquisition, so the
acquisition prefix matches this fixed schedule. The mix s uses the scheduled
multiplier in the K3P handover, not the applied LR, so a reopen does not
disable the EMA anchor. Input noise reopens with boost; output noise drops
with boost. Guard 5x after 200 and anchor decay 0.999 are unchanged.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
NETWORK_HORIZON = 1600
ANNEAL_START = 0.6
INPUT_SPAN = 120
OUTPUT_SPAN = 240
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
           'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
           'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'ns3_fixed_schedule_shock',
           'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None, 'prox_trace': [],
           'handover': 'K3P s from the fixed scheduled multiplier, not the applied LR',
           'noise_rule': 'input peak*max(0,1-step/120) then max with peak*boost; output peak*min(1,step/240)*(1-boost)',
           'optimizer_policy': 'network=learning_rate_scale(step,1600,0.6,0.01) then reopen with boost; prior multiplier 1'}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0, 'clips': [], 'critic_ref': None}
_rate_state = {'boost': None, 'env': None, 'shock': None, 'rms': None, 'scheduled': 1.0, 'completed_step': 0,
               'multiplier_cache': {}, 'trace': []}


def _scheduled(step):
    from particlegan.recipes import learning_rate_scale
    return float(learning_rate_scale(int(step), NETWORK_HORIZON, ANNEAL_START, FLOOR))


def current_boost():
    if _rate_state['boost'] is None:
        return 0.0
    if _rate_state['scheduled'] > 0.05:
        return 0.0
    return float(_rate_state['boost'])


def handover_weight():
    """Parent mix on the unboosted schedule. Applied LR is not read."""
    r = float(_rate_state['scheduled'])
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def anchored_gradient_gap(D, x_real, g, dimension):
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    receipt['extra_critic_forwards'] += 1
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(float(_rate_state['scheduled']), 6), round(current_boost(), 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _update_shock(vec):
    rms = vec.detach().square().mean().sqrt()
    env = _rate_state['env']
    if env is None:
        env = rms.clone()
    else:
        env = torch.where(rms > env, env * 0.95 + rms * 0.05, env * 0.99 + rms * 0.01)
    shock = ((rms / env.clamp_min(1e-12) - 1.5) / 1.5).clamp(0, 1)
    boost = _rate_state['boost']
    if boost is None:
        boost = rms.new_zeros(())
    scheduled = _scheduled(_rate_state['completed_step'])
    _rate_state['scheduled'] = scheduled
    if scheduled <= 0.05:
        boost = boost * 0.98 + shock * 0.02
    else:
        boost = rms.new_zeros(())
    _rate_state['env'] = env
    _rate_state['shock'] = shock
    _rate_state['rms'] = rms
    _rate_state['boost'] = boost


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    parts = [p.grad.detach().reshape(-1) for group in opt.param_groups for p in group['params'] if p.grad is not None]
    if parts:
        _update_shock(torch.cat(parts))
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
        if receipt['critic_steps'] == 1 or receipt['critic_steps'] % 50 == 0:
            row = [receipt['critic_steps'], round(lr, 8), round(float(_rate_state['scheduled']), 6),
                   round(handover_weight(), 6), round(current_boost(), 6),
                   None if _rate_state['shock'] is None else round(float(_rate_state['shock']), 6),
                   None if _rate_state['rms'] is None else round(float(_rate_state['rms']), 6)]
            _rate_state['trace'].append(row)
            print(json.dumps({'ns3': row}), flush=True)
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_scheduled'] = _rate_state['scheduled']
    receipt['final_boost'] = current_boost()
    receipt['lr_trace'] = _rate_state['trace']
    receipt['trace_columns'] = ['critic_step', 'applied_critic_lr', 'scheduled', 's', 'boost', 'shock', 'grad_rms']
    receipt['multiplier_cache_entries'] = len(_rate_state['multiplier_cache'])
    receipt['budget_dependencies'] = [
        'Applied rates and noise do not read total_steps, noise_horizon, or network_lr_horizon_cap.',
        'The frozen linear_* and policy_multipliers functions are called and their returns are discarded.',
        '1600, 0.6, 0.01, 120, and 240 are fixed copies of the parent ring schedule, not the run budget.',
        'Changing the declared horizon does not change those constants. A two-horizon prefix is still required to confirm.',
        'Direct-response gain still multiplies direct particle steps and restores the base rate.',
        'Guard warmup of 200 critic steps is an estimator constant.',
    ]
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


def _install_rules():
    import benchmarks.toy100.models as models
    import benchmarks.toy100.schedule as schedule
    original_input = models.linear_input_noise
    original_output = models.linear_output_noise
    original_policy = schedule.policy_multipliers

    def input_noise(peak, completed_steps, total_steps, end_fraction):
        original_input(peak, completed_steps, total_steps, end_fraction)
        base = float(peak) * max(0.0, 1.0 - completed_steps / float(INPUT_SPAN))
        return max(base, float(peak) * current_boost())

    def output_noise(peak, completed_steps, total_steps, warmup_fraction=0.0):
        original_output(peak, completed_steps, total_steps, warmup_fraction)
        warm = min(1.0, completed_steps / float(OUTPUT_SPAN))
        return float(peak) * warm * (1.0 - current_boost())

    def policy_multipliers(completed_step, total_steps, anneal_start, floor,
                           network_lr_horizon_cap=None, *, network_lr_floor=None):
        original_policy(completed_step, total_steps, anneal_start, floor,
                        network_lr_horizon_cap, network_lr_floor=network_lr_floor)
        cached = _rate_state['multiplier_cache'].get(completed_step)
        if cached is None:
            _rate_state['completed_step'] = int(completed_step)
            scheduled = _scheduled(completed_step)
            _rate_state['scheduled'] = scheduled
            boost = current_boost()
            network = scheduled + (1.0 - scheduled) * boost
            cached = (network, 1.0)
            _rate_state['multiplier_cache'][completed_step] = cached
        return cached

    models.linear_input_noise = input_noise
    models.linear_output_noise = output_noise
    schedule.policy_multipliers = policy_multipliers
    for mod in list(sys.modules.values()):
        if mod is None:
            continue
        for name, value in list(vars(mod).items()):
            if value is original_input:
                setattr(mod, name, input_noise)
            elif value is original_output:
                setattr(mod, name, output_noise)
            elif value is original_policy:
                setattr(mod, name, policy_multipliers)


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
_install_rules()
atexit.register(_write_receipt)
