"""AT2: generator-energy reference tracking. Horizon is ignored.

AT1 measured failure: critic-gradient cosine stayed near 0.05 persistence and
Adam innovation fell below 1.5 by step 100, so the anchor engaged at step 200
and the rate decayed while the ring still had 2 modes. Later single-tensor
innovation spikes reopened the full rate with the anchor still on and knocked
a 7-mode state down to 1 mode. Max live modes 7, streak 0 at step 5650.

AT2 does not use cosine or per-tensor Adam innovation.
The controller reads the dense generator's gradient RMS:
  g_fast = 0.98 EMA (~50 steps)
  g_peak rises immediately and leaks downward at 0.9995 (~2000 steps)
  openness = g_fast / g_peak, forced to 1 for the existing 200-step guard warmup
  network multiplier = 0.01 + 0.99 * openness
  prior multiplier   = 0.05 + 0.95 * openness
While openness >= 0.5 the penalty is pure a_r1r2 (s = 1) and the reference
tracks quickly (alpha = 0.001 + 0.049 * openness) so a later anchor is not
stuck on initialization. While openness < 0.5 the penalty is b_cap + prox and
alpha is near the K3P decay 0.999. A large prox residual does not change alpha.
s and alpha do not read the applied learning rate. A one-tensor critic spike
does not reopen the rate.

Input noise is constant 0. Output noise is the constant configured peak.
The critic guard is unchanged. Particle response, latent rule, and host losses
are unchanged K3P.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar
import signal_policy

GUARD_C = 5.0
GUARD_MIN_STEPS = 200
OPEN_ANCHOR = 0.5
FAST_DECAY = 0.98
PEAK_LEAK = 0.9995
ALPHA_FAST = 0.05
ALPHA_SLOW = 0.001
NET_FLOOR = signal_policy.NET_FLOOR
PRIOR_FLOOR = signal_policy.PRIOR_FLOOR

_original_penalty = GradientPenalty.penalty
receipt = {
    'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'rule': 'at2_generator_energy',
    'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
    'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
    'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [],
    'anchor_started_call': None, 'prox_trace': [], 'signal_trace': [],
    'open_anchor': OPEN_ANCHOR, 'fast_decay': FAST_DECAY, 'peak_leak': PEAK_LEAK,
    'alpha_fast': ALPHA_FAST, 'alpha_slow': ALPHA_SLOW,
    'network_floor': NET_FLOOR, 'prior_floor': PRIOR_FLOOR,
    'input_noise': signal_policy.INPUT_NOISE, 'output_noise': 'constant_config_peak',
    'schedule': 'generator_gradient_energy_over_leaking_peak_ignores_horizon',
    'addresses': 'at1 damped on critic Adam innovation before acquisition and reopened on one-tensor spikes',
}
_state = {
    'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None,
    'depth': 0, 'clips': [], 'critic_ref': None, 'mix_s': 1.0, 'alpha': ALPHA_FAST,
    'openness': 1.0, 'seen': 0, 'g_fast': None, 'g_peak': None, 'g_rms': None,
}


def handover_weight():
    """Critic mix from generator-gradient energy. Does not read an LR ratio."""
    return float(_state['mix_s'])


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _publish_rates():
    openness = float(_state['openness'])
    signal_policy.state['next_network'] = NET_FLOOR + (1.0 - NET_FLOOR) * openness
    signal_policy.state['next_prior'] = PRIOR_FLOOR + (1.0 - PRIOR_FLOOR) * openness


def anchored_gradient_gap(D, x_real, g, dimension):
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
            receipt['extra_critic_forwards'] += 1
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (
                F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _update_generator_signal(opt):
    grads = [p.grad.detach() for p in opt.param_groups[0]['params'] if p.grad is not None]
    if not grads:
        return
    flat = torch.cat([g.flatten() for g in grads])
    g_rms = float(flat.square().mean().sqrt())
    _state['g_rms'] = g_rms
    if _state['g_fast'] is None:
        _state['g_fast'] = g_rms
        _state['g_peak'] = g_rms
    else:
        _state['g_fast'] = FAST_DECAY * _state['g_fast'] + (1.0 - FAST_DECAY) * g_rms
        if _state['g_fast'] >= _state['g_peak']:
            _state['g_peak'] = _state['g_fast']
        else:
            _state['g_peak'] = PEAK_LEAK * _state['g_peak'] + (1.0 - PEAK_LEAK) * _state['g_fast']
    _state['seen'] += 1
    if _state['seen'] < GUARD_MIN_STEPS or _state['g_peak'] <= 0.0:
        openness = 1.0
    else:
        openness = min(1.0, _state['g_fast'] / _state['g_peak'])
    _state['openness'] = openness
    _state['mix_s'] = 1.0 if openness >= OPEN_ANCHOR else 0.0
    _state['alpha'] = ALPHA_SLOW + (ALPHA_FAST - ALPHA_SLOW) * openness
    _publish_rates()
    if _state['seen'] == 1 or _state['seen'] % 50 == 0:
        row = dict(
            seen=_state['seen'], g_rms=round(g_rms, 8),
            g_fast=round(_state['g_fast'], 8), g_peak=round(_state['g_peak'], 8),
            openness=round(openness, 6), s=_state['mix_s'],
            alpha=round(_state['alpha'], 6),
            network_m=round(signal_policy.state['next_network'], 6),
            prior_m=round(signal_policy.state['next_prior'], 6),
        )
        receipt['signal_trace'].append(row)
        print(json.dumps(dict(signal=row)), flush=True)


def _guard(opt, args, kwargs):
    if len(opt.param_groups) >= 2:
        _update_generator_signal(opt)
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        params = _critic_params()
        with torch.no_grad():
            if _state['ema'] is None:
                _state['ema'] = [p.detach().clone() for p in params]
                if receipt['anchor_started_call'] is None:
                    receipt['anchor_started_call'] = receipt['calls']
            else:
                alpha = float(_state['alpha'])
                keep = 1.0 - alpha
                for e, p in zip(_state['ema'], params):
                    e.mul_(keep).add_(p.detach(), alpha=alpha)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_openness'] = _state['openness']
    receipt['final_alpha'] = _state['alpha']
    receipt['final_g_fast'] = _state['g_fast']
    receipt['final_g_peak'] = _state['g_peak']
    receipt['final_g_rms'] = _state['g_rms']
    receipt['final_network_m'] = signal_policy.state['next_network']
    receipt['final_prior_m'] = signal_policy.state['next_prior']
    receipt['ignored_horizon_calls'] = signal_policy.state['ignored_horizon_calls']
    receipt['noise_calls'] = signal_policy.state['noise_calls']
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
_publish_rates()
