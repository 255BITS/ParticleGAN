"""Horizon-blind rate and noise adapters for at1.

The host still passes step counts and budgets. Those arguments are ignored.
Multipliers are latched from the critic signal updated in mechanism.py.
The same latch is returned for every call with the same completed step, so the
frozen post-step rate check sees the multiplier that was actually applied.
"""
import sys
from particlegan import recipes
from benchmarks.toy100 import models, schedule

NET_FLOOR = 0.01
PRIOR_FLOOR = 0.05
INPUT_NOISE = 0.0

state = {
    'next_network': 1.0,
    'next_prior': 1.0,
    'ignored_horizon_calls': 0,
    'noise_calls': 0,
}
latch = {'step': None, 'network': 1.0, 'prior': 1.0}


def signal_multipliers(completed_step, *args, **kwargs):
    state['ignored_horizon_calls'] += 1
    key = completed_step if type(completed_step) is int else ('other', completed_step)
    if latch['step'] != key:
        latch['step'] = key
        latch['network'] = float(state['next_network'])
        latch['prior'] = float(state['next_prior'])
    return latch['network'], latch['prior']


def constant_input_noise(*args, **kwargs):
    state['noise_calls'] += 1
    state['ignored_horizon_calls'] += 1
    return INPUT_NOISE


def constant_output_noise(peak, *args, **kwargs):
    state['noise_calls'] += 1
    state['ignored_horizon_calls'] += 1
    return float(peak)


replacements = [
    (schedule.policy_multipliers, signal_multipliers),
    (models.linear_input_noise, constant_input_noise),
    (models.linear_output_noise, constant_output_noise),
]
for module in list(sys.modules.values()):
    if module is None or not getattr(module, '__name__', '').startswith(('particlegan', 'benchmarks')):
        continue
    for name, value in list(vars(module).items()):
        for original, replacement in replacements:
            if value is original:
                setattr(module, name, replacement)
# learning_rate_scale is left in place. This candidate never calls it.
_ = recipes.learning_rate_scale
