"""ruc1: K3P penalty with the critic mix decoupled from the learning-rate clock.

The host schedule is held at an identity multiplier (network and prior floors 1).
That identity does not depend on the horizon cap or the total step count.
Applied rates are base_lr * response_gain * rho, restored before the step returns.

rho uses only the current raw gradient and Adam's existing second moment:
  peak <- max(peak * PEAK_DECAY, grad_rms)          # reversible energy memory
  r_energy = grad_rms / peak                        # in (0, 1]
  r_moment = grad_rms / sqrt(mean v_hat)            # ~1 when v matches g
  shock = 0 if r_moment <= 1 else 1 - 1/r_moment    # 0 at a match, -> 1 on a jump
  r_open = min(1, max(r_energy, shock))
  rho = rho_min + (1 - rho_min) * r_open
rho_min is 0.01 on generator and critic groups and 0.05 on prior groups
(the parent's stationary fractions). rho is 1 at the energy peak and when the
gradient jumps far above its second moment, and it falls back when the jump is
absorbed. No total budget, horizon, evaluation, target, or shift time is read.

Critic mixing keeps the K3P map but the argument is r_energy, not last_lr/max_lr:
  s = max(0, min(1, 2*r_energy) - 2*f) / (1 - 2*f), f = 0.01
s is 1 until r_energy < 0.5 and is 0 at r_energy <= 0.01. The EMA anchor is the
(1-s) term, so it is active in the stationary-energy regime even if a moment
shock has temporarily reopened rho. A shock does not turn the anchor off.
The guard, EMA decay, direct response, and sparse-latent rule are unchanged.
Noise still uses the driver's 1,200-update horizon (labeled intermediate).
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
PRIOR_FLOOR = 0.05
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
PEAK_DECAY = 0.9995
MOMENT_BETA2 = 0.999
_original_penalty = GradientPenalty.penalty
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
           'prior_floor': PRIOR_FLOOR, 'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS,
           'pure_a_calls': 0, 'blend_calls': 0, 'pure_b_calls': 0, 'first_blend_call': None,
           'first_pure_b_call': None, 'critic_steps': 0, 'critic_parameters': None,
           'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'ruc1_energy_moment',
           'anchor_decay': ANCHOR_DECAY, 'peak_decay': PEAK_DECAY,
           'anchor_started_call': None, 'prox_trace': [],
           'mixing_signal': 'critic_grad_rms / decaying_peak',
           'lr_clock_decoupled': True,
           'rate_trace': [],
           'rho_summary': {}}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None,
          'depth': 0, 'clips': [], 'critic_ref': None, 'critic_r': None, 'peaks': {},
          'scale': {}}


def handover_weight():
    r = _state['critic_r']
    if r is None:
        return 1.0
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def _is_critic(opt):
    if _state['critic'] is None:
        return bool(_state['pending'])
    return id(opt) == _state['critic']


def _group_energy(opt, group):
    square = None
    count = 0
    second = None
    second_count = 0
    step = None
    moments = True
    for parameter in group['params']:
        if parameter.grad is None:
            continue
        value = parameter.grad.detach().square().sum()
        square = value if square is None else square + value
        count += parameter.grad.numel()
        moment = opt.state.get(parameter)
        if not moment or 'exp_avg_sq' not in moment or 'step' not in moment:
            moments = False
            continue
        current = moment['step']
        step = current if step is None else step
        value = moment['exp_avg_sq'].sum()
        second = value if second is None else second + value
        second_count += moment['exp_avg_sq'].numel()
    if count == 0:
        return None
    grad_rms = (square / count).sqrt()
    moment_ratio = None
    if moments and second_count == count and step is not None and float(step) >= 1.0:
        # Persistent Adam beta2. Direct response temporarily replaces a particle
        # group's beta2 inside this step; stored second moments were not built with that value.
        corrected = (second / second_count) / (1.0 - MOMENT_BETA2 ** float(step))
        moment_ratio = float((grad_rms / corrected.clamp_min(1e-30).sqrt()).clamp(max=1e6))
    return grad_rms, moment_ratio


def _scale_pre(opt, args, kwargs):
    restore = []
    rows = []
    critic = _is_critic(opt)
    for group in opt.param_groups:
        signal = _group_energy(opt, group)
        if signal is None:
            continue
        grad_rms, moment_ratio = signal
        key = id(group)
        previous = _state['peaks'].get(key)
        peak = grad_rms.detach() if previous is None else torch.maximum(previous * PEAK_DECAY, grad_rms.detach())
        _state['peaks'][key] = peak
        energy = float((grad_rms / peak.clamp_min(1e-30)).clamp(0, 1))
        if energy != energy:
            energy = 1.0
        shock = 0.0 if moment_ratio is None or moment_ratio <= 1.0 else 1.0 - 1.0 / moment_ratio
        opened = energy if shock < energy else shock
        if opened > 1.0:
            opened = 1.0
        role = 'prior' if group.get('_comparison_prior') else ('d' if critic else 'g')
        rho_min = PRIOR_FLOOR if role == 'prior' else FLOOR
        rho = rho_min + (1.0 - rho_min) * opened
        scheduled = float(group['lr'])
        group['lr'] = scheduled * rho
        restore.append((group, scheduled))
        if critic and role == 'd':
            _state['critic_r'] = energy
        before = [p.detach().clone() for p in group['params']]
        row = [role, round(energy, 6), None if moment_ratio is None else round(moment_ratio, 6),
               round(opened, 6), round(rho, 6), scheduled, scheduled * rho, None]
        rows.append((row, before, list(group['params'])))
        summary = receipt['rho_summary'].setdefault(role, {'min': rho, 'max': rho, 'last': rho, 'calls': 0})
        summary['min'] = min(summary['min'], rho)
        summary['max'] = max(summary['max'], rho)
        summary['last'] = rho
        summary['calls'] += 1
        if summary['calls'] % 100 == 0:
            print(json.dumps(dict(ruc=dict(role=role, call=summary['calls'], r_energy=energy,
                                           r_moment=moment_ratio, rho=rho, applied_lr=scheduled * rho,
                                           s=handover_weight()))), flush=True)
    _state['scale'][id(opt)] = (restore, rows)


def _scale_post(opt, args, kwargs):
    item = _state['scale'].pop(id(opt), None)
    if item is None:
        return
    restore, rows = item
    for group, scheduled in restore:
        group['lr'] = scheduled
    for row, before, parameters in rows:
        delta = None
        base = None
        count = 0
        for current, previous in zip(parameters, before):
            difference = (current.detach() - previous).square().sum()
            magnitude = previous.square().sum()
            delta = difference if delta is None else delta + difference
            base = magnitude if base is None else base + magnitude
            count += current.numel()
        relative = float((delta / count).sqrt() / (base / count).clamp_min(1e-30).sqrt()) if count else None
        row[7] = None if relative is None else round(relative, 8)
        calls = receipt['rho_summary'][row[0]]['calls']
        if calls <= 5 or calls % 10 == 0:
            receipt['rate_trace'].append(row)


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), _state['critic_r']])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_critic_r'] = _state['critic_r']
    receipt['host_lr_note'] = 'lr_last is the restored host rate after rho; applied rates are rate_trace column 6'
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_scale_pre)
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_scale_post)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
