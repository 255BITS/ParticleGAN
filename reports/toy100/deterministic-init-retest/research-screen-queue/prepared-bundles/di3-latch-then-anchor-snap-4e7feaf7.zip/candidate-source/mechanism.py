"""DI3: DI2 latch, and the critic anchor snaps to the current critic when that latch releases.

DI2 recovered the ring to 8 modes with the anchor still on the scheduled s=0 path, then lost
one mode on checks 3570-3600 (77/81). Real-batch z was already back near 1, so that tail is
not a new data change. The 0.999 anchor had only partly followed the critic during the short
reopen, and full prox then restores toward that older reference. When the 200-step hold ends,
DI3 copies the current critic parameters into the anchor once. Decay stays 0.999. No snap
occurs on a run that never latches, so a stationary ring keeps the DI2/K3P anchor.

DI2: K3P rates, plus a latched reopen after persistent real-batch evidence.

DI1 kept the stationary ring with mobility 0 (z_rms max 2.02) and saw the ring translation
(z_rms 3.67) but mapped it through a short proportional leak. Mobility peaked near 0.06 and the
network multiplier near 0.022, then the 0.01 reference absorbed the shift. Deadline checks were
33/81 with no stable suffix.

DI2 uses the same batch-size-normalized mean z-scores. Evidence is the largest |z| across
coordinates, so an unchanged coordinate does not dilute a one-axis change. Five consecutive
batches with max |z| >= 3.5 open mobility to 1. A single null extreme cannot: DI1's stationary
z_rms stayed <= 2.02, and one batch at the null tail is not five. While evidence continues, a
200-step hold is refreshed. After evidence stops, mobility stays at 1 for those 200 steps, then
multiplies by 0.97 per step until it is 0. The 200 and 0.97 are one declared release, chosen
because DI1's pulse died inside about 100 updates, not a coefficient search.

Rates and mixing match DI1: K3P schedule at mobility 0; otherwise pull each multiplier toward
max(schedule, 0.20), never below the schedule. s follows the scheduled network multiplier, so the
early penalty and the 0.999 anchor stay on the LR clock. Guard, response, latent, and horizon
noise are unchanged K3P. No budget, score, target, or shift time is read.

Limit: real-mean innovation still cannot see generator-side forgetting or a mean-preserving change.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

FLOOR = 0.01
GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
REFERENCE_ALPHA = 0.01
Z_EVIDENCE = 3.5
STREAK_NEED = 5
LATCH = 200
CLOSE = 0.97
REOPEN = 0.20
_original_penalty = GradientPenalty.penalty
_original_policy = None
receipt = {'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'floor': FLOOR,
           'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS, 'pure_a_calls': 0, 'blend_calls': 0,
           'pure_b_calls': 0, 'first_blend_call': None, 'first_pure_b_call': None, 'critic_steps': 0,
           'critic_parameters': None, 'lr_max': None, 'lr_last': None, 's_trace': [], 'rule': 'di3_latch_then_anchor_snap', 'anchor_snaps': 0,
           'anchor_decay': ANCHOR_DECAY, 'anchor_started_call': None, 'prox_trace': [],
           'reference_alpha': REFERENCE_ALPHA, 'z_evidence': Z_EVIDENCE, 'streak_need': STREAK_NEED,
           'latch': LATCH, 'close': CLOSE, 'reopen': REOPEN, 'applied_network_max': 0.0,
           'applied_prior_max': 0.0, 'z_max_seen': 0.0, 'first_latch_call': None,
           'signal': 'max_abs_coordinate_z_vs_slow_ema_se_five_batch_streak',
           'rate_rule': 'K3P schedule when mobility is 0; else pull each multiplier toward max(schedule, 0.20), never below the schedule',
           'latch_rule': 'five consecutive max|z|>=3.5 sets mobility to 1 and refreshes a 200-step hold; then mobility *= 0.97',
           'mix_rule': 's uses the scheduled network multiplier, not the data-boosted applied LR',
           'anchor_rule': 'K3P prox and decay 0.999; mobility does not scale the anchor',
           'noise': 'inherited K3P horizon noise; labeled intermediate, not horizon-independent',
           'limit': 'real-mean innovation cannot detect generator-side forgetting or a mean-preserving change',
           'budget_dependencies': [
               'K3P network/prior multipliers still read total_steps, anneal start, floors, and network_lr_horizon_cap',
               'input and output noise still anneal on the driver noise_horizon (1200 on these ring drivers)',
               'mobility, the z threshold, and the 0.20 ceiling do not read the budget or the shift time',
           ],
           'innovation_trace': [], 'rate_trace': []}
_state = {'ema': None, 'critic': None, 'pending': False, 'lr_max': 0.0, 'lr_last': None, 'depth': 0, 'clips': [],
          'critic_ref': None, 'slow_mean': None, 'slow_var': None, 'mobility': 0.0, 'z_rms': 0.0,
          'z_max': 0.0, 'streak': 0, 'hold_left': 0, 'snap_anchor': False,
          'scheduled_network': None, 'scheduled_prior': None, 'applied_network': None, 'applied_prior': None}


def handover_weight():
    """K3P map on the scheduled network multiplier. Ignores the data-boosted applied LR."""
    r = _state['scheduled_network']
    if r is None or not r > 0.0:
        return 1.0
    return max(0.0, min(1.0, 2.0 * r) - 2.0 * FLOOR) / (1.0 - 2.0 * FLOOR)


def _mix(scheduled, mobility):
    if mobility <= 0.0 or scheduled >= REOPEN:
        return scheduled
    return scheduled * (1.0 - mobility) + REOPEN * mobility


def phase_multipliers(*args, **kwargs):
    """K3P multipliers, raised toward the reopen ceiling only while real-data mobility is positive."""
    network, prior = _original_policy(*args, **kwargs)
    mobility = float(_state['mobility'])
    _state['scheduled_network'] = float(network)
    _state['scheduled_prior'] = float(prior)
    applied_network = _mix(float(network), mobility)
    applied_prior = _mix(float(prior), mobility)
    _state['applied_network'] = applied_network
    _state['applied_prior'] = applied_prior
    receipt['applied_network_max'] = max(receipt['applied_network_max'], applied_network)
    receipt['applied_prior_max'] = max(receipt['applied_prior_max'], applied_prior)
    step = args[0] if args else None
    if step == 0 or (isinstance(step, int) and step % 50 == 0):
        row = [step, round(float(network), 6), round(applied_network, 6), round(float(prior), 6),
               round(applied_prior, 6), round(mobility, 6), round(_state['z_rms'], 6), round(handover_weight(), 6)]
        receipt['rate_trace'].append(row)
        if len(receipt['rate_trace']) > 400:
            del receipt['rate_trace'][:-400]
    return applied_network, applied_prior


def _install_phase_rates():
    global _original_policy
    from benchmarks.toy100 import schedule
    _original_policy = schedule.policy_multipliers
    if _original_policy is phase_multipliers:
        raise RuntimeError('policy_multipliers patch applied twice')
    schedule.policy_multipliers = phase_multipliers
    for module in list(sys.modules.values()):
        if module is None:
            continue
        name = getattr(module, '__name__', '')
        if not name.startswith(('particlegan', 'benchmarks')):
            continue
        for attr, value in list(vars(module).items()):
            if value is _original_policy:
                setattr(module, attr, phase_multipliers)


_install_phase_rates()


def _update_innovation(x_real):
    flat = x_real.detach().reshape(x_real.shape[0], -1).float()
    if flat.device.type != 'cuda' or flat.dtype != torch.float32:
        raise RuntimeError(f'real batch must be CUDA FP32, got {flat.device} {flat.dtype}')
    batch = int(flat.shape[0])
    if batch < 2:
        raise RuntimeError('innovation SE needs a batch of at least 2')
    mean = flat.mean(dim=0)
    var = flat.var(dim=0, unbiased=True).clamp_min(1e-8)
    if _state['slow_mean'] is None:
        _state['slow_mean'] = mean.clone()
        _state['slow_var'] = var.clone()
        _state['mobility'] = 0.0
        _state['z_rms'] = 0.0
        receipt['innovation_init'] = dict(batch=batch, dim=int(flat.shape[1]), device=str(flat.device), dtype=str(flat.dtype))
        return
    se = (_state['slow_var'] / batch).sqrt().clamp_min(1e-8)
    z = (mean - _state['slow_mean']) / se
    z_rms = float(torch.sqrt(z.square().mean()).clamp_max(1e6))
    z_max = float(z.abs().max().clamp_max(1e6))
    _state['slow_mean'].mul_(1.0 - REFERENCE_ALPHA).add_(mean, alpha=REFERENCE_ALPHA)
    _state['slow_var'].mul_(1.0 - REFERENCE_ALPHA).add_(var, alpha=REFERENCE_ALPHA)
    if z_max >= Z_EVIDENCE:
        _state['streak'] += 1
    else:
        _state['streak'] = 0
    if _state['streak'] >= STREAK_NEED:
        _state['mobility'] = 1.0
        _state['hold_left'] = LATCH
        if receipt['first_latch_call'] is None:
            receipt['first_latch_call'] = receipt['calls']
    elif _state['hold_left'] > 0:
        _state['hold_left'] -= 1
        _state['mobility'] = 1.0
        if _state['hold_left'] == 0:
            _state['snap_anchor'] = True
    elif _state['mobility'] > 0.0:
        _state['mobility'] = float(_state['mobility']) * CLOSE
        if _state['mobility'] < 1e-4:
            _state['mobility'] = 0.0
    _state['z_rms'] = z_rms
    _state['z_max'] = z_max
    receipt['z_max_seen'] = max(receipt['z_max_seen'], z_max)
    if receipt['calls'] % 50 == 0:
        receipt['innovation_trace'].append([receipt['calls'], round(z_rms, 6), round(z_max, 6),
                                            round(float(_state['mobility']), 6), _state['streak'],
                                            _state['hold_left'], batch])
        if len(receipt['innovation_trace']) > 400:
            del receipt['innovation_trace'][:-400]
    if receipt['calls'] % 200 == 0:
        print(json.dumps(dict(innovation_call=receipt['calls'], z_rms=round(z_rms, 4), z_max=round(z_max, 4),
                              mobility=round(float(_state['mobility']), 4), streak=_state['streak'],
                              hold_left=_state['hold_left'], s=round(handover_weight(), 4),
                              scheduled_network=_state['scheduled_network'],
                              applied_network=_state['applied_network'])), flush=True)


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d; Dbar = parameter EMA, evaluated by swapping .data (restored before return)."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    receipt['calls'] += 1
    _update_innovation(x_real)
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = handover_weight()
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    if s >= 1.0:
        real_squared = self._grad_norm(D, x_real, squared=True) / dimension
        fake_norm = self._grad_norm(D, x_fake, squared=False) / dimension ** 0.5
        fake_cap = (fake_norm - self.kappa).relu().square()
        penalty = (coefficient / 2.0) * (real_squared.mean() + fake_cap.mean())
        receipt['pure_a_calls'] += 1
    else:
        x = x_real.detach().clone().requires_grad_(True)
        g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
        sq_r = g.pow(2).flatten(1).sum(dim=1)
        n_r = torch.sqrt(sq_r + 1e-12)
        n_f = self._grad_norm(D, x_fake, squared=False)
        prox = anchored_gradient_gap(D, x_real, g, dimension)
        if s > 0.0:
            a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
            b_term = F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox
            penalty = (coefficient / 2.0) * (s * a_term + (1.0 - s) * b_term)
            receipt['blend_calls'] += 1
            if receipt['first_blend_call'] is None:
                receipt['first_blend_call'] = receipt['calls']
        else:
            penalty = (coefficient / 2.0) * (F.relu(n_r - self.kappa).pow(2).mean() + F.relu(n_f - self.kappa).pow(2).mean() + prox)
            receipt['pure_b_calls'] += 1
            if receipt['first_pure_b_call'] is None:
                receipt['first_pure_b_call'] = receipt['calls']
        if receipt['calls'] % 50 == 0:
            receipt['prox_trace'].append([receipt['calls'], float(prox.detach()), round(float(_state['mobility']), 6)])
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(float(_state['mobility']), 6), round(float(_state['z_rms']), 6)])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa, 's': s,
             'mobility': float(_state['mobility']), 'z_rms': float(_state['z_rms'])} if collect_stats else {}
    return penalty, stats


def _guard(opt, args, kwargs):
    if _state['critic'] is None or id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                params = _critic_params()
                if _state['snap_anchor']:
                    for e, p in zip(_state['ema'], params):
                        e.copy_(p.detach())
                    _state['snap_anchor'] = False
                    receipt['anchor_snaps'] += 1
                else:
                    for e, p in zip(_state['ema'], params):
                        e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        lr = max(float(g['lr']) for g in opt.param_groups)
        _state['lr_last'] = lr
        _state['lr_max'] = max(_state['lr_max'], lr)
        receipt['critic_steps'] += 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _write_receipt():
    receipt['lr_max'] = _state['lr_max']
    receipt['lr_last'] = _state['lr_last']
    receipt['final_s'] = handover_weight()
    receipt['final_mobility'] = _state['mobility']
    receipt['final_z_rms'] = _state['z_rms']
    receipt['final_scheduled_network'] = _state['scheduled_network']
    receipt['final_applied_network'] = _state['applied_network']
    receipt['final_scheduled_prior'] = _state['scheduled_prior']
    receipt['final_applied_prior'] = _state['applied_prior']
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_post_hook(_record)
atexit.register(_write_receipt)
