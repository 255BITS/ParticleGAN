"""PNB2: shared reversible rate for particle, generator and critic.

PNB1 failed the ring before the shift: critic cosine went negative by
update ~130, the penalty left the early term, and per-role gains were
updated on every optimizer and then re-amplified by a cross-role floor.
Modes never reached 8.

This candidate keeps K3P's early penalty for the whole run and adds the
EMA anchor at a constant weight, so the anchor does not wait on the LR
clock and does not turn the early penalty off. One shared gain multiplies
the initial rate of every role, so the recipe prior/network ratio (2x)
cannot drift into K3P's 10x floor imbalance. The host horizon rate is
overwritten for the update and restored afterward.

  lr = initial_group_lr * shared_gain * direct_response_gain
  shared_gain starts at 1
  once per critic step:
    spike (critic grad_rms > 2 * its previous grad-RMS EMA): gain *= 1.01
    elif critic gradient-cosine EMA < 0: gain *= 0.997
    clip to [0.05, 1]
  penalty = coeff/2 * (A + 0.25 * P)

A is R1 on reals plus the one-sided fake RMS cap. P is the EMA-critic
gap, decay 0.999. The critic spike guard is unchanged. No step index,
horizon, score, target, or shift time is read. Host noise is still the
K3P schedule against the driver horizon (intermediate, not a controller
input). latent.py and response.py are unchanged.
"""
import atexit, json, sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.optim.optimizer import register_optimizer_step_post_hook, register_optimizer_step_pre_hook
from particlegan.grad_regularizers import GradientPenalty, _score_scalar

GUARD_C = 5.0
GUARD_MIN_STEPS = 200
ANCHOR_DECAY = 0.999
GAIN_MIN = 0.05
GAIN_MAX = 1.0
COS_EMA = 0.95
GRAD_EMA = 0.99
RISE = 1.01
DECAY_NEG = 0.997
SPIKE = 2.0
ANCHOR_FLOOR = 0.25
ROLES = ('g', 'd', 'prior')

receipt = {
    'calls': 0, 'dimensions': {}, 'extra_critic_forwards': 0, 'anchor_forwards': 0,
    'rule': 'pnb2', 'guard_c': GUARD_C, 'guard_min_steps': GUARD_MIN_STEPS,
    'anchor_decay': ANCHOR_DECAY, 'anchor_floor': ANCHOR_FLOOR,
    'gain_min': GAIN_MIN, 'gain_max': GAIN_MAX,
    'cos_ema': COS_EMA, 'rise': RISE, 'decay_neg': DECAY_NEG,
    'spike_ratio': SPIKE,
    'formula': 'shared gain on initial lr; decay 0.997 once per critic step if critic cos ema<0; '
               'rise 1.01 on critic grad spike; penalty=A+0.25*P',
    'budget_dependencies': [
        'LR gain and critic mix do not read step, total_steps, horizon cap, floors, scores, or targets',
        'host noise schedule is unchanged K3P (driver noise_horizon 1200); intermediate, not a controller input',
        'host horizon LR is overwritten for the Adam update and restored before the step returns',
    ],
    'critic_parameters': None, 'anchor_started_call': None,
    's_trace': [], 'prox_trace': [], 'balance_trace': [],
    'applied_lr_last': {}, 'scheduled_lr_last': {},
}
_state = {
    'ema': None, 'critic': None, 'pending': False, 'depth': 0, 'clips': [], 'critic_ref': None,
    'initial_lr': {}, 'restore': {}, 'before': {}, 'prev_grad': {},
    'cos_ema': {r: 1.0 for r in ROLES}, 'grad_ema': {r: None for r in ROLES},
    'gain': {r: 1.0 for r in ROLES}, 'shared': 1.0, 'seen': {r: 0 for r in ROLES},
    'disp_ema': {r: None for r in ROLES},
}
_original_penalty = GradientPenalty.penalty


def _critic_params():
    return [p for g in _state['critic_ref'].param_groups for p in g['params']]


def mix_weight():
    """Early penalty stays fully on. The anchor weight is ANCHOR_FLOOR, not an LR ratio."""
    return 1.0


def anchored_gradient_gap(D, x_real, g, dimension):
    """mean ||g - grad_x Dbar(x_real)||^2 / d. One extra critic evaluation after the EMA exists."""
    if _state['critic_ref'] is None:
        return g.new_zeros(())
    params = _critic_params()
    if _state['ema'] is None:
        _state['ema'] = [p.detach().clone() for p in params]
        receipt['anchor_started_call'] = receipt['calls']
        return g.new_zeros(())
    saved = [p.data for p in params]
    try:
        for p, e in zip(params, _state['ema']):
            p.data = e
        xb = x_real.detach().clone().requires_grad_(True)
        with torch.enable_grad():
            gb = torch.autograd.grad(_score_scalar(D(xb)), xb)[0].detach()
    finally:
        for p, v in zip(params, saved):
            p.data = v
    receipt['anchor_forwards'] += 1
    return (g - gb).pow(2).flatten(1).sum(dim=1).mean() / dimension


def scaled_penalty(self, D, x_real, x_fake, step=1, generator=None, collect_stats=True):
    if self.arm != 'a_r1r2' or (self.lazy_k > 1 and step % self.lazy_k != 0):
        return _original_penalty(self, D, x_real, x_fake, step, generator, collect_stats)
    _state['pending'] = True
    coefficient = self.coeff * self.lazy_k if self.lazy_k > 1 else self.coeff
    dimension = x_real[0].numel()
    assert dimension == x_fake[0].numel()
    s = mix_weight()
    w = ANCHOR_FLOOR
    receipt['calls'] += 1
    receipt['dimensions'][str(dimension)] = receipt['dimensions'].get(str(dimension), 0) + 1
    x = x_real.detach().clone().requires_grad_(True)
    g = torch.autograd.grad(_score_scalar(D(x)), x, create_graph=True)[0]
    sq_r = g.pow(2).flatten(1).sum(dim=1)
    n_f = self._grad_norm(D, x_fake, squared=False)
    prox = anchored_gradient_gap(D, x_real, g, dimension)
    a_term = (sq_r / dimension).mean() + (n_f / dimension ** 0.5 - self.kappa).relu().square().mean()
    penalty = (coefficient / 2.0) * (a_term + w * prox)
    if receipt['calls'] == 1 or receipt['calls'] % 50 == 0:
        receipt['s_trace'].append([receipt['calls'], round(s, 6), round(w, 6)])
        receipt['prox_trace'].append([receipt['calls'], float(prox.detach())])
    stats = {'applied': True, 'pen': float(penalty.detach()), 'fake_cap': self.kappa,
             's': s, 'anchor_w': w} if collect_stats else {}
    return penalty, stats


def _role(opt, group):
    if group.get('_comparison_prior'):
        return 'prior'
    if _state['critic'] is not None and id(opt) == _state['critic']:
        return 'd'
    return 'g'


def _response_gain(group, host_lr):
    try:
        import response
    except ImportError:
        return 1.0
    rows = response.receipt.get('rows') or []
    if not rows:
        return 1.0
    row = rows[-1]
    if abs(float(row['effective_lr']) - host_lr) <= 1e-12 * max(1.0, abs(host_lr)):
        return float(row['gain'])
    return 1.0


def _flat_grad(group):
    parts = [p.grad.detach().reshape(-1) for p in group['params'] if p.grad is not None]
    if not parts:
        return None
    return torch.cat(parts)


def apply_rates(opt):
    """Overwrite host rates with the signal gain. Last call before the update wins."""
    restore = []
    before = []
    for index, group in enumerate(opt.param_groups):
        host = float(group['lr'])
        role = _role(opt, group)
        key = id(group['params'][0]) if group['params'] else (id(opt), index)
        if key not in _state['initial_lr']:
            # First sight is the undecaayed recipe rate (host scale is 1 at step 0).
            peeled = host
            try:
                import response
                rows = response.receipt.get('rows') or []
                if rows and abs(float(rows[-1]['effective_lr']) - host) <= 1e-12 * max(1.0, abs(host)):
                    peeled = float(rows[-1]['scheduled_lr'])
            except ImportError:
                pass
            _state['initial_lr'][key] = peeled
        resp = _response_gain(group, host)
        applied = _state['initial_lr'][key] * _state['gain'][role] * resp
        restore.append(host)
        group['lr'] = applied
        if id(opt) not in _state['before']:
            grads = _flat_grad(group)
            params = [p.detach().clone() for p in group['params']]
            before.append((role, key, params, grads, applied))
        receipt['applied_lr_last'][role] = applied
        receipt['scheduled_lr_last'][role] = host / resp if resp else host
    _state['restore'][id(opt)] = restore
    if before:
        _state['before'][id(opt)] = before


def _rebalance_gains(updated):
    for role, cos, grad_rms, rel in updated:
        prev_g = _state['grad_ema'][role]
        spike = prev_g is not None and prev_g > 0.0 and grad_rms > SPIKE * prev_g
        if _state['seen'][role] == 0:
            _state['grad_ema'][role] = grad_rms
        else:
            _state['grad_ema'][role] = (1.0 - GRAD_EMA) * grad_rms + GRAD_EMA * prev_g
        if _state['prev_grad'].get(role) is None:
            cos_now = 1.0
        else:
            prev = _state['prev_grad'][role]
            if prev.shape != cos.shape:
                cos_now = 1.0
            else:
                cos_now = float(F.cosine_similarity(cos, prev, dim=0, eps=1e-12))
        _state['prev_grad'][role] = cos.detach()
        _state['cos_ema'][role] = COS_EMA * _state['cos_ema'][role] + (1.0 - COS_EMA) * cos_now
        _state['seen'][role] += 1
        prev_d = _state['disp_ema'][role]
        _state['disp_ema'][role] = rel if prev_d is None else 0.9 * prev_d + 0.1 * rel
        if role == 'd':
            gain = _state['shared']
            if spike:
                gain *= RISE
            elif _state['cos_ema']['d'] < 0.0:
                gain *= DECAY_NEG
            _state['shared'] = min(GAIN_MAX, max(GAIN_MIN, gain))
    for role in ROLES:
        _state['gain'][role] = _state['shared']


def _update_signals(opt):
    rows = _state['before'].pop(id(opt), None)
    if not rows:
        return
    updated = []
    for role, key, params, grad, applied in rows:
        if grad is None:
            continue
        sq = 0.0
        n = 0
        ps = 0.0
        for p, b in zip(opt_params_for(key, opt), params):
            d = (p.detach() - b).reshape(-1)
            sq += float((d * d).sum())
            n += d.numel()
            ps += float((p.detach().reshape(-1) ** 2).sum())
        disp = (sq / max(n, 1)) ** 0.5
        param_rms = (ps / max(n, 1)) ** 0.5
        rel = disp / (param_rms + 1e-8)
        grad_rms = float(grad.square().mean().sqrt())
        updated.append((role, grad, grad_rms, rel))
    if updated:
        _rebalance_gains(updated)
        step_n = sum(_state['seen'].values())
        if step_n <= 3 or step_n % 50 == 0:
            row = {
                'updates': dict(_state['seen']),
                'gain': {r: round(_state['gain'][r], 6) for r in ROLES},
                'cos_ema': {r: round(_state['cos_ema'][r], 6) for r in ROLES},
                'applied_lr': {r: receipt['applied_lr_last'].get(r) for r in ROLES},
                'scheduled_lr': {r: receipt['scheduled_lr_last'].get(r) for r in ROLES},
                's': round(mix_weight(), 6),
            }
            receipt['balance_trace'].append(row)
            print(json.dumps({'balance': row}), flush=True)


def opt_params_for(key, opt):
    for group in opt.param_groups:
        if group['params'] and id(group['params'][0]) == key:
            return group['params']
    return []


def _restore(opt):
    saved = _state['restore'].pop(id(opt), None)
    if not saved:
        return
    for group, host in zip(opt.param_groups, saved):
        group['lr'] = host


def _guard(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
    if id(opt) != _state['critic']:
        return
    _state['depth'] += 1
    if _state['depth'] != 1:
        return
    flags = []
    for group in opt.param_groups:
        beta2 = group['betas'][1]
        for p in group['params']:
            st = opt.state.get(p)
            if p.grad is None or not st or 'exp_avg_sq' not in st:
                continue
            t = st['step']
            vhat = st['exp_avg_sq'].mean() / (1.0 - beta2 ** t)
            ratio = p.grad.square().mean().sqrt() / vhat.clamp_min(1e-30).sqrt()
            clip = (t >= GUARD_MIN_STEPS) & (ratio > GUARD_C)
            p.grad.mul_(torch.where(clip, GUARD_C / ratio, torch.ones_like(ratio)))
            flags.append(clip)
    if flags:
        _state['clips'].append(torch.stack(flags).sum())


def _record(opt, args, kwargs):
    if _state['critic'] is None:
        if not _state['pending']:
            return
        _state['critic'] = id(opt)
        _state['critic_ref'] = opt
        receipt['critic_parameters'] = sum(p.numel() for g in opt.param_groups for p in g['params'])
        _state['depth'] = 1
    if id(opt) != _state['critic']:
        return
    if _state['depth'] == 1:
        if _state['ema'] is not None:
            with torch.no_grad():
                for e, p in zip(_state['ema'], _critic_params()):
                    e.mul_(ANCHOR_DECAY).add_(p.detach(), alpha=1.0 - ANCHOR_DECAY)
        receipt['critic_steps'] = receipt.get('critic_steps', 0) + 1
    _state['depth'] = max(0, _state['depth'] - 1)


def _after(opt, args, kwargs):
    _update_signals(opt)
    _restore(opt)


def _write_receipt():
    receipt['final_s'] = mix_weight()
    receipt['final_gain'] = dict(_state['gain'])
    receipt['final_cos_ema'] = dict(_state['cos_ema'])
    receipt['seen'] = dict(_state['seen'])
    if _state['clips']:
        per_step = torch.stack(_state['clips']).cpu()
        steps = torch.nonzero(per_step > 0).flatten().tolist()
        receipt['guard_clipped_tensors'] = int(per_step.sum())
        receipt['guard_clip_steps'] = [s + 1 for s in steps][:200]
        receipt['guard_clip_step_count'] = len(steps)
    else:
        receipt['guard_clipped_tensors'] = 0
        receipt['guard_clip_steps'] = []
        receipt['guard_clip_step_count'] = 0
    if '--output' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--output') + 1])
        if out.is_dir():
            (out / 'mechanism-receipt.json').write_text(json.dumps(receipt, indent=1, default=str) + '\n')


_orig_register = torch.optim.Optimizer.register_step_pre_hook


def _register(self, hook, *args, **kwargs):
    def chained(optimizer, hook_args, hook_kwargs):
        out = hook(optimizer, hook_args, hook_kwargs)
        apply_rates(optimizer)
        return out
    return _orig_register(self, chained, *args, **kwargs)


torch.optim.Optimizer.register_step_pre_hook = _register
GradientPenalty.penalty = scaled_penalty
register_optimizer_step_pre_hook(_guard)
register_optimizer_step_pre_hook(lambda opt, args, kwargs: apply_rates(opt))
register_optimizer_step_post_hook(_record)
register_optimizer_step_post_hook(_after)
atexit.register(_write_receipt)
