# RESEARCH-c03_smooth_cap-new-init

Prepared original inline-penalty/config probe on the common frozen tiny host. Original source/config preserved. Public standalone initialization replaces fresh parameter values, with original constructor RNG consumption retained. No historical tensors loaded.

This is research-host evidence. Original scheduled policies remain scheduled; no old pass or public API qualification transfers. A separate matching CPU constructor/source proof is mandatory. The original probe does not save final optimizer/model state, so the screen does not establish continuation or replay. Runtime provenance: `DECLARED_COMMON_RETEST_HOST; HISTORICAL_RUNTIME_RECEIPT_UNRESOLVED`.
